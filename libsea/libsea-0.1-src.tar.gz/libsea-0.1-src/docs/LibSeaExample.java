// An example showing how to load a LibSea graph file using the LibSea graph
// library.
//
// You may do anything you like with this file, without restriction, including
// basing your own projects on it.  Consider the code in this file public
// domain.  This code is excerpted from the file H3Main.java in Walrus v0.6.3.
//
// $Id: LibSeaExample.java,v 1.1 2005/03/28 22:04:38 youngh Exp $

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import org.caida.libsea.*;

public class LibSeaExample
{
    public static void main(String[] args)
    {
	new LibSeaExample();
    }

    ///////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ///////////////////////////////////////////////////////////////////////

    public LibSeaExample()
    {
	m_frame = new JFrame("LibSea Graph Loading Example");
	m_frame.setBackground(Color.black);
	m_frame.getContentPane().setBackground(Color.black);

	m_frame.setSize(DEFAULT_FRAME_WIDTH, DEFAULT_FRAME_HEIGHT);
	m_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	m_splashLabel = new JLabel(SPLASH_HTML_LABEL, JLabel.CENTER);
	m_frame.getContentPane().add(m_splashLabel, BorderLayout.CENTER);

	m_frame.setJMenuBar(createInitialMenuBar());

	m_frame.show();
    }

    /////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    /////////////////////////////////////////////////////////////////////

    private void handleOpenFileRequest()
    {
	File file = askUserForFile();
	if (file != null)
	{
	    try
	    {
		ASCIIInputStreamReader reader =
		    new ASCIIInputStreamReader(new FileInputStream(file));

		Graph graph = loadGraph(file, reader);

		if (graph != null)
		{
		    System.out.println("Graph loaded successfully.");
		    // XXX Do something with graph.
		}
		else
		{
		    System.out.println("Graph loading failed.");
		}
	    }
	    catch (FileNotFoundException e)
	    {
		String msg =  "File not found: " + file.getPath();
		JOptionPane dialog = new JOptionPane();
		dialog.showMessageDialog(null, msg, "File Not Found",
					 JOptionPane.ERROR_MESSAGE);
	    }
	}
    }

    /////////////////////////////////////////////////////////////////////

    private Graph loadGraph(File file, Reader reader)
    {
	Graph retval = null;

	try
	{
	    GraphBuilder builder = GraphFactory.makeImmutableGraph();

	    GraphFileLexer lexer = new GraphFileLexer(reader);
	    GraphFileParser parser = new GraphFileParser(lexer);
	    parser.file(builder);

	    retval = builder.endConstruction();
	}
	catch (antlr.ANTLRException e)
	{
	    // NOTE: ANTLRException.toMessage() doesn't include position.
	    String msg = "Error parsing file `" + file.getPath() + "': "
		+ e.toString();
	    JOptionPane dialog = new JOptionPane();
	    dialog.showMessageDialog(null, msg, "Open Failed",
				     JOptionPane.ERROR_MESSAGE);
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private File askUserForFile()
    {
	File retval = null;
	int result = m_fileChooser.showOpenDialog(m_frame);
	if (result == JFileChooser.APPROVE_OPTION)
	{
	    retval = m_fileChooser.getSelectedFile();
	    if (!retval.isFile())
	    {
		if (retval.exists())
		{
		    String msg =  "Path is not that of an ordinary file: "
			+ retval.getPath();
		    JOptionPane dialog = new JOptionPane();
		    dialog.showMessageDialog(null, msg, "Invalid Path",
					     JOptionPane.ERROR_MESSAGE);
		}
		else
		{
		    String msg =  "File not found: " + retval.getPath();
		    JOptionPane dialog = new JOptionPane();
		    dialog.showMessageDialog(null, msg, "File Not Found",
					     JOptionPane.ERROR_MESSAGE);
		}
	    }
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private JMenuBar createInitialMenuBar()
    {
	// Create "File" menu. --------------------------------------------

	JMenuItem openMenuItem = new JMenuItem("Open");
	openMenuItem.setMnemonic(KeyEvent.VK_O);
	openMenuItem.setAccelerator
	    (KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
	openMenuItem.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e)
		{
		    handleOpenFileRequest();
		}
	    });

	JMenuItem exitMenuItem = new JMenuItem("Exit");
	exitMenuItem.setMnemonic(KeyEvent.VK_X);
	exitMenuItem.setAccelerator
	    (KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
	exitMenuItem.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e)
		{
		    System.exit(0);
		}
	    });

	m_fileMenu = new JMenu("File");
	m_fileMenu.setMnemonic(KeyEvent.VK_F);
	m_fileMenu.add(openMenuItem);
	m_fileMenu.addSeparator();
	m_fileMenu.add(exitMenuItem);

	// Create menu bar. ------------------------------------------------

	JMenuBar retval = new JMenuBar();
	retval.add(m_fileMenu);
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    private static final int DEFAULT_FRAME_WIDTH = 800;
    private static final int DEFAULT_FRAME_HEIGHT = 600;

    private static final String SPLASH_HTML_LABEL = "<html><table border=0><tr><td align=center><b><font color=#CAFF70 size=+4>LibSea Graph Loading Example</font></b></td></tr><tr><td align=center><font color=#1E9619 size=+2>Select 'Open' from menu.</font></td></tr></table></html>";

    ///////////////////////////////////////////////////////////////////////

    private JFrame m_frame;
    private JLabel m_splashLabel;
    private JFileChooser m_fileChooser = new JFileChooser();

    private JMenu m_fileMenu;
}
