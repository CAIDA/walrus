// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

abstract class ImmutableAbstractValueIterator
    implements ValueIterator
{
    public ImmutableAbstractValueIterator() {}

    public void setBooleanValue(boolean value)
    {
	throw new ImmutableDataException();
    }

    public void setIntegerValue(int value)
    {
	throw new ImmutableDataException();
    }

    public void setFloatValue(float value)
    {
	throw new ImmutableDataException();
    }

    public void setDoubleValue(double value)
    {
	throw new ImmutableDataException();
    }

    public void setStringValue(String value)
    {
	throw new ImmutableDataException();
    }

    public void setFloat3Value(float x, float y, float z)
    {
	throw new ImmutableDataException();
    }

    public void setFloat3Value(float[] value)
    {
	throw new ImmutableDataException();
    }

    public void setDouble3Value(double x, double y, double z)
    {
	throw new ImmutableDataException();
    }

    public void setDouble3Value(double[] value)
    {
	throw new ImmutableDataException();
    }

    public void setEnumerationValue(String enumerator)
    {
	throw new ImmutableDataException();
    }

    public void setEnumerationValue(int enumerator)
    {
	throw new ImmutableDataException();
    }

    public void removeValue()
    {
	throw new ImmutableDataException();
    }

    public void insertValue()
    {
	throw new ImmutableDataException();
    }

    public void appendValue()
    {
	throw new ImmutableDataException();
    }
}
