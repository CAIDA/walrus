// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

public interface ValueIterator extends Iterator
{
    boolean  isEmpty();
    int      getLength();

    ValueType  getType();
    boolean  getBooleanValue();
    int      getIntegerValue();
    float    getFloatValue();
    double   getDoubleValue();
    String   getStringValue();
    float[]  getFloat3Value();
    void     getFloat3Value(float[] value);
    double[] getDouble3Value();
    void     getDouble3Value(double[] value);
    int      getEnumerationValue();
    int      getEvaluatedEnumerationValue();

    void     setBooleanValue(boolean value);
    void     setIntegerValue(int value);
    void     setFloatValue(float value);
    void     setDoubleValue(double value);
    void     setStringValue(String value);
    void     setFloat3Value(float x, float y, float z);
    void     setFloat3Value(float[] value);
    void     setDouble3Value(double x, double y, double z);
    void     setDouble3Value(double[] value);
    void     setEnumerationValue(String enumerator);
    void     setEnumerationValue(int enumerator);

    void     removeValue();
    void     insertValue();
    void     appendValue();
}
