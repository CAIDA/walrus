// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.Arrays;
import java.util.Random;
import java.util.LinkedList;
import java.util.ListIterator;

class IntBinArrayTester
    extends AbstractTester
{
    public static void main(String[] args)
    {
	int startingTest = parseArguments(args);
	new IntBinArrayTester().testAll(startingTest);
    }

    public IntBinArrayTester()
    {
	super();
    }

    public void testAll(int startingTest)
    {
	try
	{
	    if (startingTest == 0)
	    {
		println("**** TEST 0 ****");
		println(":::: Unordered IntBinArray ::::");
		testAllocationsBasic(new IntBinArray(false), 10, true);
		testAllocationsBasic(new IntBinArray(false, 128), 500, true);
	    }

	    if (startingTest <= 1)
	    {
		println("**** TEST 1 ****");
		println(":::: Ordered IntBinArray ::::");
		testAllocationsBasic(new IntBinArray(true), 10, true);
		testAllocationsBasic(new IntBinArray(true, 128), 500, true);
	    }

	    if (startingTest <= 2)
	    {
		println("**** TEST 2 ****");
		println(":::: Unordered IntBinArray ::::");
		testAllocationsRandom(new IntBinArray(false), 10, true);
		testAllocationsRandom(new IntBinArray(false, 128), 500, true);
	    }

	    if (startingTest <= 3)
	    {
		println("**** TEST 3 ****");
		println(":::: Ordered IntBinArray ::::");
		testAllocationsRandom(new IntBinArray(true), 10, true);
		testAllocationsRandom(new IntBinArray(true, 128), 500, true);
	    }

	    if (startingTest <= 4)
	    {
		println("**** TEST 4 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		int[] slots = allocateValues(array, 10);
		testAccessesEmptyList(array, slots, true);
	    }

	    if (startingTest <= 5)
	    {
		println("**** TEST 5 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		int[] slots = allocateValues(array, 10);
		testAccessesEmptyList(array, slots, true);
	    }

	    if (startingTest <= 6)
	    {
		println("**** TEST 6 ****");
		for (int i = 1; i <= 13; i++)
		{
		    testAccessesAppendBoth(i, 3, 512);
		}
	    }

	    if (startingTest <= 7)
	    {
		println("**** TEST 7 ****");
		testAccessesAppendBoth(100, 3, 512);
	    }

	    if (startingTest <= 8)
	    {
		println("**** TEST 8 ****");
		testAccessesAppendBoth(13, 200, 128);
	    }

	    // NOTE: Unordered inserts become appends.
	    if (false && startingTest <= 9)
	    {
		println("**** TEST 9 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		testAccessesInsertElement(array, true);
	    }

	    if (startingTest <= 10)
	    {
		println("**** TEST 10 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesInsertElement(array, true);
	    }

	    if (startingTest <= 11)
	    {
		println("**** TEST 11 ****");
		for (int i = 1; i <= 10; i++)
		{
		    testAccessesInsertBoth(i, 3, 512);
		}
	    }

	    if (startingTest <= 12)
	    {
		println("**** TEST 12 ****");
		testAccessesInsertBoth(100, 3, 512);
	    }

	    if (startingTest <= 13)
	    {
		println("**** TEST 13 ****");
		testAccessesInsertBoth(13, 200, 128);
	    }

	    if (startingTest <= 14)
	    {
		println("**** TEST 14 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesInsertOrderedSplit(array, 20,
					       new int[] { 42 }, true);
	    }

	    if (startingTest <= 15)
	    {
		println("**** TEST 15 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesInsertOrderedPreviousBin(array, 4,
						     new int[] { 42 }, true);
	    }

	    if (startingTest <= 16)
	    {
		println("**** TEST 16 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesInsertOrderedRandom(array, 100, true);
	    }

	    if (startingTest <= 17)
	    {
		println("**** TEST 17 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		testAccessesRemoveElement(array, true);
	    }

	    if (startingTest <= 18)
	    {
		println("**** TEST 18 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesRemoveElement(array, true);
	    }

	    if (startingTest <= 19)
	    {
		println("**** TEST 19 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		testAccessesRemoveBin4Element(array, 20, false, true);
	    }

	    if (startingTest <= 20)
	    {
		println("**** TEST 20 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesRemoveBin4Element(array, 20, true, true);
	    }

	    if (startingTest <= 21)
	    {
		println("**** TEST 21 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		array.relaxRemovalSemantics();
		testAccessesRemoveAllBin4Elements(array, 20, 0, false, true);
	    }

	    if (startingTest <= 22)
	    {
		println("**** TEST 22 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		array.relaxRemovalSemantics();
		testAccessesRemoveAllBin4Elements(array, 20, 19, false, true);
	    }

	    if (startingTest <= 23)
	    {
		println("**** TEST 23 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		array.relaxRemovalSemantics();
		testAccessesRemoveAllBin4Elements(array, 20, 9, false, true);
	    }

	    if (startingTest <= 24)
	    {
		println("**** TEST 24 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		testAccessesRemoveBin4ElementsRandom(array, 50, false, true);
	    }

	    if (startingTest <= 25)
	    {
		println("**** TEST 25 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		array.relaxRemovalSemantics();
		testAccessesRemoveAllBin4Elements(array, 20, 0, true, true);
	    }

	    if (startingTest <= 26)
	    {
		println("**** TEST 26 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		array.relaxRemovalSemantics();
		testAccessesRemoveAllBin4Elements(array, 20, 19, true, true);
	    }

	    if (startingTest <= 27)
	    {
		println("**** TEST 27 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		array.relaxRemovalSemantics();
		testAccessesRemoveAllBin4Elements(array, 20, 9, true, true);
	    }

	    if (startingTest <= 28)
	    {
		println("**** TEST 28 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesRemoveBin4ElementsRandom(array, 50, true, true);
	    }

	    if (startingTest <= 29)
	    {
		println("**** TEST 29 ****");
		println(":::: Unordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(false);
		testAccessesInsertAndRemoveElements(array, 100, 50,
						    false, true);
	    }

	    if (startingTest <= 30)
	    {
		println("**** TEST 30 ****");
		println(":::: Ordered IntBinArray ::::");
		IntBinArray array = new IntBinArray(true);
		testAccessesInsertAndRemoveElements(array, 100, 50,
						    true, true);
	    }
	}
	catch (TestFailedException e)
	{
	    System.out.println("FAILED: " + e);
	    e.printStackTrace(System.out);
	}
	catch (RuntimeException e)
	{
	    System.out.println("ERROR: " + e);
	    e.printStackTrace(System.out);
	}
    }

    private void testAccessesAppendBoth(int numAppends, int numAllocations,
					int segmentSize)
	throws TestFailedException
    {
	{
	    println(":::: Unordered IntBinArray ::::");
	    IntBinArray array = new IntBinArray(false, segmentSize);
	    int[] slots = allocateValues(array, numAllocations);
	    testAccessesAppend(array, slots, numAppends, true);
	}

	{
	    println(":::: Ordered IntBinArray ::::");
	    IntBinArray array = new IntBinArray(true, segmentSize);
	    int[] slots = allocateValues(array, numAllocations);
	    testAccessesAppend(array, slots, numAppends, true);
	}
    }

    private void testAccessesInsertBoth(int numAppends, int numAllocations,
					int segmentSize)
	throws TestFailedException
    {
	{
	    println(":::: Unordered IntBinArray ::::");
	    IntBinArray array = new IntBinArray(false, segmentSize);
	    int[] slots = allocateValues(array, numAllocations);
	    testAccessesInsert(array, slots, numAppends, false, true);
	}

	{
	    println(":::: Ordered IntBinArray ::::");
	    IntBinArray array = new IntBinArray(true, segmentSize);
	    int[] slots = allocateValues(array, numAllocations);
	    testAccessesInsert(array, slots, numAppends, true, true);
	}
    }

    private void testAllocationsBasic(IntBinArray array, int numAllocations,
				     boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAllocationsBasic(numAllocations=" + numAllocations + ")");
	println("===========================================================");

	int[] slots = new int[numAllocations];

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("Allocating values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    slots[i] = array.allocate();

	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }
	}

	verifyEqual("# allocated", array.getNumAllocated(), numAllocations);

	println("Checking for duplicate indices...");
	{
	    int[] slots2 = (int[])slots.clone();
	    Arrays.sort(slots2);

	    int last = slots2[0];
	    for (int i = 1; i < slots2.length; i++)
	    {
		if (slots2[i] == last)
		{
		    fail("Index " + last + " allocated more than once.");
		}

		last = slots2[i];
	    }
	}

	println("Checking allocation map...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (!array.checkAllocated(slots[i]))
	    {
		fail("Index " + i + " is not marked as allocated.");
	    }
	}

	println("Freeing values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    array.free(slots[i]);
	}

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("ALL PASSED!");
    }

    private void testAllocationsRandom(IntBinArray array, int numAllocations,
				      boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAllocationsRandom(numAllocations=" + numAllocations +")");
	println("===========================================================");

	int[] slots = new int[numAllocations];

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("Allocating values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    slots[i] = array.allocate();

	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }
	}

	verifyEqual("# allocated", array.getNumAllocated(), numAllocations);

	shuffle(slots);

	println("Freeing values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    array.free(slots[i]);
	}

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("ALL PASSED!");
    }

    private void testAccessesEmptyList(IntBinArray array, int[] slots,
				      boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesEmptyList(numAllocations=" + slots.length + ")");
	println("===========================================================");

	int numAllocations = slots.length;

	verifyEqual("# allocated", array.getNumAllocated(), numAllocations);

	println("Getting values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    ValueIterator iterator = array.getValue(slots[i]);

	    verify(false, "iterator != null", iterator != null);
	    verify(false, "isEmpty() == true", iterator.isEmpty());
	    verify(false, "atEnd() == true", iterator.atEnd());
	    verifyEqual("getLength()", iterator.getLength(), 0);
	}

	println("Freeing values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    array.free(slots[i]);
	}

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("ALL PASSED!");
    }

    private void testAccessesAppend(IntBinArray array, int[] slots,
				   int numInsertions, boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesAppend(numAllocations=" + slots.length + ", "
		+ "numInsertions=" + numInsertions + ")");
	println("===========================================================");

	int numAllocations = slots.length;

	int[][] values = new int[numInsertions][];
	for (int i = 0; i < numInsertions; i++)
	{
	    try { Thread.sleep(10); } catch (InterruptedException e) { }
	    values[i] = createRandomValues(numAllocations);
	}

	verifyEqual("# allocated", array.getNumAllocated(), numAllocations);

	println("Setting values: appending...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    ValueIterator iterator = array.getValue(slots[i]);

	    verify(false, "iterator != null", iterator != null);
	    verify(false, "isEmpty() == true", iterator.isEmpty());
	    verify(false, "atEnd() == true", iterator.atEnd());
	    verifyEqual("getLength()", iterator.getLength(), 0);

	    for (int j = 0; j < numInsertions; j++)
	    {
		println("appendValue()...");
		iterator.appendValue();

		verify(false, "isEmpty() == false", !iterator.isEmpty());
		verify(false, "atEnd() == false", !iterator.atEnd());
		verifyEqual("getLength()", iterator.getLength(),
			    j + 1);

		println("array.checkListInvariants(" + slots[i] + ")");
		array.checkListInvariants(slots[i]);
		array.checkForMemoryLeaks();

		println("setIntegerValue(" + values[j][i] + ")...");
		iterator.setIntegerValue(values[j][i]);

		int value = iterator.getIntegerValue();
		verifyEqual("getIntegerValue()", value, values[j][i]);
	    }
	}

	println("Getting values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    ValueIterator iterator = array.getValue(slots[i]);

	    verify(false, "iterator != null", iterator != null);
	    verify(false, "isEmpty() == false", !iterator.isEmpty());
	    verifyEqual("getLength()", iterator.getLength(),
			numInsertions);

	    for (int j = 0; j < numInsertions; j++)
	    {
		verify(false, "atEnd() == false", !iterator.atEnd());

		int expected = values[j][i];
		int value = iterator.getIntegerValue();
		verifyEqual("getIntegerValue()", value, expected);

		if (j < numInsertions - 1)
		{
		    iterator.advance();
		}
	    }
	}

	println("Freeing values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    array.free(slots[i]);
	}

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("ALL PASSED!");
    }

    private void testAccessesInsertElement(IntBinArray array,
					   boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesInsertElement()");
	println("===========================================================");

	int[] values = createRandomValues(4);

	if (showSlots)
	{
	    printValues(values);
	}

	for (int i = 1; i <= 3; i++)
	{
	    for (int j = 0; j < i; j++)
	    {
		println("Creating and populating list of length " + i + "...");

		int list = array.allocate();
		ValueIterator iterator = array.getValue(list);

		LinkedList mirror = new LinkedList();

		populate(iterator, values, i);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		populate(mirror, values, i);

		println("Inserting element at position " + j + "...");
		insert(iterator, j, new int[] { 42 });

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		insert(mirror, j, new int[] { 42 });

		println("Comparing values...");
		print("iterator = ", iterator);
		print("mirror = ", mirror);
		compare(iterator, mirror, i + 1);

		println("Freeing values...");
		array.free(list);
	    }
	}

	println("ALL PASSED!");
    }

    private void testAccessesInsert(IntBinArray array, int[] slots,
				   int numInsertions, boolean isOrdered,
				   boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesInsert(numAllocations=" + slots.length + ", "
		+ "numInsertions=" + numInsertions + ")");
	println("===========================================================");

	int numAllocations = slots.length;

	int[][] values = new int[numInsertions][];
	for (int i = 0; i < numInsertions; i++)
	{
	    try { Thread.sleep(10); } catch (InterruptedException e) { }
	    values[i] = createRandomValues(numAllocations);
	}

	verifyEqual("# allocated", array.getNumAllocated(), numAllocations);

	println("Setting values: inserting...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    ValueIterator iterator = array.getValue(slots[i]);

	    verify(false, "iterator != null", iterator != null);
	    verify(false, "isEmpty() == true", iterator.isEmpty());
	    verify(false, "atEnd() == true", iterator.atEnd());
	    verifyEqual("getLength()", iterator.getLength(), 0);

	    for (int j = 0; j < numInsertions; j++)
	    {
		println("insertValue()...");
		iterator.insertValue();

		verify(false, "isEmpty() == false", !iterator.isEmpty());
		verify(false, "atEnd() == false", !iterator.atEnd());
		verifyEqual("getLength()",
			    iterator.getLength(), j + 1);

		println("array.checkListInvariants(" + slots[i] + ")");
		array.checkListInvariants(slots[i]);
		array.checkForMemoryLeaks();

		println("setIntegerValue(" + values[j][i] + ")...");
		iterator.setIntegerValue(values[j][i]);

		int value = iterator.getIntegerValue();
		verifyEqual("getIntegerValue()", value, values[j][i]);
	    }
	}

	println("Getting values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    ValueIterator iterator = array.getValue(slots[i]);

	    verify(false, "iterator != null", iterator != null);
	    verify(false, "isEmpty() == false", !iterator.isEmpty());
	    verifyEqual("getLength()", iterator.getLength(),
			numInsertions);

	    for (int j = 0; j < numInsertions; j++)
	    {
		verify(false, "atEnd() == false", !iterator.atEnd());

		int expected =values[isOrdered ? numInsertions - j - 1 : j][i];
		int value = iterator.getIntegerValue();
		verifyEqual("getIntegerValue()", value, expected);

		if (j < numInsertions - 1)
		{
		    iterator.advance();
		}
	    }
	}

	println("Freeing values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    array.free(slots[i]);
	}

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("ALL PASSED!");
    }

    private void testAccessesInsertOrderedSplit(IntBinArray array,
						int numInsertions,
						int[] insertedValues,
						boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesInsertOrderedSplit(numInsertions="
		+ numInsertions + ")");
	println("===========================================================");

	int[] values = createRandomValues(numInsertions);

	for (int i = 0; i < numInsertions; i++)
	{
	    println("Inserting at position " + i + "...");

	    int list = array.allocate();
	    ValueIterator iterator = array.getValue(list);

	    LinkedList mirror = new LinkedList();

	    populate(iterator, values);

	    println("array.checkListInvariants(" + list + ")");
	    array.checkListInvariants(list);
	    array.checkForMemoryLeaks();

	    populate(mirror, values);

	    insert(iterator, i, insertedValues);

	    println("array.checkListInvariants(" + list + ")");
	    array.checkListInvariants(list);
	    array.checkForMemoryLeaks();

	    insert(mirror, i, insertedValues);

	    println("Comparing values...");
	    print("iterator = ", iterator);
	    print("mirror = ", mirror);
	    compare(iterator, mirror, numInsertions + 1);

	    println("Freeing values...");
	    array.free(list);
	}

	println("ALL PASSED!");
    }

    private void testAccessesInsertOrderedPreviousBin(IntBinArray array,
						      int numInsertions,
						      int[] insertedValues,
						      boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesInsertOrderedPreviousBin(numInsertions="
		+ numInsertions + ")");
	println("===========================================================");

	int[] values = createRandomValues(numInsertions);

	for (int i = 1; i < numInsertions; i += 4)
	{
	    for (int j = i; j <= i + 3; j++)
	    {
		int list = array.allocate();
		ValueIterator iterator = array.getValue(list);

		LinkedList mirror = new LinkedList();

		populate(iterator, values);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		populate(mirror, values);

		println("Inserting at position " + i + " to split bin...");

		insert(iterator, i, new int[] { 99 });
		insert(mirror, i, new int[] { 99 });

		println("Inserting further at position " + j + "...");

		insert(iterator, j, insertedValues);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		insert(mirror, j, insertedValues);

		println("Comparing values...");
		print("iterator = ", iterator);
		print("mirror = ", mirror);
		compare(iterator, mirror, numInsertions + 2);

		println("Freeing values...");
		array.free(list);
	    }
	}

	println("ALL PASSED!");
    }

    private void testAccessesInsertOrderedRandom(IntBinArray array,
						 int numInsertions,
						 boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesInsertOrderedRandom(numInsertions="
		+ numInsertions + ")");
	println("===========================================================");

	int list = array.allocate();
	int[] values = createRandomValues(numInsertions);

	LinkedList mirror = new LinkedList();
	mirror.add(new Integer(values[0]));

	ValueIterator iterator = array.getValue(list);

	verify(false, "iterator != null", iterator != null);
	verify(false, "isEmpty() == true", iterator.isEmpty());
	verify(false, "atEnd() == true", iterator.atEnd());
	verifyEqual("getLength()", iterator.getLength(), 0);

	iterator.appendValue();

	verify(false, "isEmpty() == false", !iterator.isEmpty());
	verify(false, "atEnd() == false", !iterator.atEnd());
	verifyEqual("getLength()", iterator.getLength(), 1);

	println("array.checkListInvariants(" + list + ")");
	array.checkListInvariants(list);
	array.checkForMemoryLeaks();

	iterator.setIntegerValue(values[0]);

	println("Setting values: inserting...");
	for (int i = 1; i < numInsertions; i++)
	{
	    int next = m_random.nextInt(i);
	    println("next = " + next);

	    insert(iterator, next, new int[] { values[i] });

	    println("array.checkListInvariants(" + list + ")");
	    array.checkListInvariants(list);
	    array.checkForMemoryLeaks();

	    insert(mirror, next, new int[] { values[i] });
	}

	println("Comparing values...");
	print("iterator = ", iterator);
	print("mirror = ", mirror);
	compare(iterator, mirror, numInsertions);

	println("Freeing values...");
	array.free(list);

	println("ALL PASSED!");
    }

    private void testAccessesRemoveElement(IntBinArray array,
					   boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesRemoveElement()");
	println("===========================================================");

	int[] values = createRandomValues(4);

	if (showSlots)
	{
	    printValues(values);
	}

	for (int i = 1; i <= 4; i++)
	{
	    for (int j = 0; j < i; j++)
	    {
		println("Creating and populating list of length " + i + "...");

		int list = array.allocate();
		ValueIterator iterator = array.getValue(list);

		LinkedList mirror = new LinkedList();

		populate(iterator, values, i);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		populate(mirror, values, i);

		println("Removing element at position " + j + "...");
		remove(iterator, j, 1);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		remove(mirror, j, 1);

		println("Comparing values...");
		print("iterator = ", iterator);
		print("mirror = ", mirror);
		compare(iterator, mirror, i - 1);

		println("Freeing values...");
		array.free(list);
	    }
	}

	println("ALL PASSED!");
    }

    private void testAccessesRemoveBin4Element(IntBinArray array,
					       int numInsertions,
					       boolean isOrdered,
					       boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesRemoveBin4Element(numInsertions="
		+ numInsertions + ")");
	println("===========================================================");

	int[] values = createRandomValues(numInsertions);

	if (showSlots)
	{
	    printValues(values);
	}

	for (int i = 5; i <= numInsertions; i++)
	{
	    for (int j = 0; j < i; j++)
	    {
		println("Creating and populating list of length " + i + "...");

		int list = array.allocate();
		ValueIterator iterator = array.getValue(list);

		LinkedList mirror = new LinkedList();

		populate(iterator, values, i);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		populate(mirror, values, i);

		println("Removing element at position " + j + "...");
		remove(iterator, j, 1);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		if (isOrdered)
		{
		    remove(mirror, j, 1);
		}
		else
		{
		    removeUnordered(mirror, j, 1);
		}

		println("Comparing values...");
		print("iterator = ", iterator);
		print("mirror = ", mirror);
		compare(iterator, mirror, i - 1);

		println("Freeing values...");
		array.free(list);
	    }
	}

	println("ALL PASSED!");
    }

    private void testAccessesRemoveAllBin4Elements(IntBinArray array,
						   int numInsertions,
						   int index,
						   boolean isOrdered,
						   boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesRemoveAllBin4Elements(numInsertions="
		+ numInsertions + ", index=" + index + ")");
	println("===========================================================");

	int[] values = createRandomValues(numInsertions);

	if (showSlots)
	{
	    printValues(values);
	}

	int list = array.allocate();
	ValueIterator iterator = array.getValue(list);

	LinkedList mirror = new LinkedList();

	populate(iterator, values);

	println("array.checkListInvariants(" + list + ")");
	array.checkListInvariants(list);
	array.checkForMemoryLeaks();

	populate(mirror, values);

	reposition(iterator, index);

	for (int i = numInsertions - 1; i >= 4; i--)
	{
	    println("length = " + (i + 1) + "; index = " + index);

	    println("removeValue()...");
	    iterator.removeValue();

	    verifyEqual("getLength()", iterator.getLength(), i);

	    println("array.checkListInvariants(" + list + ")");
	    array.checkListInvariants(list);
	    array.checkForMemoryLeaks();

	    if (isOrdered)
	    {
		mirror.remove(index);
	    }
	    else
	    {
		removeUnordered(mirror, index, 1);
	    }

	    if (index == i)
	    {
		--index;
	    }

	    println("Comparing values...");
	    print("iterator = ", array.getValue(list));
	    print("mirror = ", mirror);
	    compare(array.getValue(list), mirror, i);
	}

	println("Freeing values...");
	array.free(list);

	println("ALL PASSED!");
    }

    private void testAccessesRemoveBin4ElementsRandom(IntBinArray array,
						      int numInsertions,
						      boolean isOrdered,
						      boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesRemoveBin4ElementRandom(numInsertions="
		+ numInsertions + ")");
	println("===========================================================");

	int[] values = createRandomValues(numInsertions);

	if (showSlots)
	{
	    printValues(values);
	}

	int list = array.allocate();
	ValueIterator iterator = array.getValue(list);

	LinkedList mirror = new LinkedList();

	populate(iterator, values);

	println("array.checkListInvariants(" + list + ")");
	array.checkListInvariants(list);
	array.checkForMemoryLeaks();

	populate(mirror, values);

	for (int i = numInsertions - 1; i >= 4; i--)
	{
	    println("length = " + (i + 1));

	    int index = m_random.nextInt(i + 1);
	    println("Removing element at position " + index + "...");

	    remove(iterator, index, 1);

	    println("array.checkListInvariants(" + list + ")");
	    array.checkListInvariants(list);
	    array.checkForMemoryLeaks();

	    if (isOrdered)
	    {
		remove(mirror, index, 1);
	    }
	    else
	    {
		removeUnordered(mirror, index, 1);
	    }

	    println("Comparing values...");
	    print("iterator = ", iterator);
	    print("mirror = ", mirror);
	    compare(iterator, mirror, i);
	}

	println("Freeing values...");
	array.free(list);

	println("ALL PASSED!");
    }

    private void testAccessesInsertAndRemoveElements(IntBinArray array,
						     int numInsertions,
						     int numIterations,
						     boolean isOrdered,
						     boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccessesInsertAndRemoveElements(numInsertions="
		+ numInsertions + ", numIterations=" + numIterations + ")");
	println("===========================================================");

	if (numInsertions < 5)
	{
	    throw new IllegalArgumentException();
	}

	int list = array.allocate();
	ValueIterator iterator = array.getValue(list);

	LinkedList mirror = new LinkedList();

	{
	    int[] values = createRandomValues(numInsertions);
	    if (showSlots)
	    {
		printValues(values);
	    }

	    populate(iterator, values);

	    println("array.checkListInvariants(" + list + ")");
	    array.checkListInvariants(list);
	    array.checkForMemoryLeaks();

	    populate(mirror, values);
	}

	int length = numInsertions;

	for (int i = 0; i < numIterations; i++)
	{
	    int numChange = m_random.nextInt(numInsertions - 4) + 1;
	    println("Changing " + numChange + " elements...");

	    for (int j = 0; j < numChange; j++)
	    {
		int index = m_random.nextInt(length--);

		println("Removing element at position " + index + "...");

		remove(iterator, index, 1);

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		if (isOrdered)
		{
		    remove(mirror, index, 1);
		}
		else
		{
		    removeUnordered(mirror, index, 1);
		}

		println("Comparing values...");
		print("iterator = ", iterator);
		print("mirror = ", mirror);
		compare(iterator, mirror, length);
	    }

	    for (int j = 0; j < numChange; j++)
	    {
		int index = m_random.nextInt(length++);

		println("Inserting element at position " + index + "...");

		int value = m_random.nextInt();
		println("Inserting " + value + "...");

		insert(iterator, index, new int[] { value });

		println("array.checkListInvariants(" + list + ")");
		array.checkListInvariants(list);
		array.checkForMemoryLeaks();

		if (isOrdered)
		{
		    insert(mirror, index, new int[] { value });
		}
		else
		{
		    insertUnordered(mirror, index, new int[] { value });
		}

		println("Comparing values...");
		print("iterator = ", iterator);
		print("mirror = ", mirror);
		compare(iterator, mirror, length);
	    }
	}

	println("Freeing values...");
	array.free(list);

	println("ALL PASSED!");
    }

    /////////////////////////////////////////////////////////////////////////

    private void compare(ValueIterator iterator, LinkedList list, int length)
	throws TestFailedException
    {
	verifyEqual("getLength()", iterator.getLength(), length);
	verifyEqual("list.size()", list.size(), length);

	iterator.rewind();
	ListIterator listIterator = list.listIterator(0);

	for (int i = 0; i < length; i++)
	{
	    verify(false, "atEnd() == false", !iterator.atEnd());

	    int expected = ((Integer)listIterator.next()).intValue();
	    int value = iterator.getIntegerValue();
	    verifyEqual("getIntegerValue()", value, expected);

	    if (i < length - 1)
	    {
		iterator.advance();
	    }
	}
    }

    private void insert(ValueIterator iterator, int index, int[] values)
	throws TestFailedException
    {
	int length = iterator.getLength();
	reposition(iterator, index);

	for (int i = 0; i < values.length; i++)
	{
	    println("insertValue()...");
	    iterator.insertValue();

	    verifyEqual("getLength()", iterator.getLength(),
			length + i + 1);

	    println("setIntegerValue(" + values[i] + ")...");
	    iterator.setIntegerValue(values[i]);

	    int storedValue = iterator.getIntegerValue();
	    verifyEqual("getIntegerValue()", storedValue, values[i]);
	}
    }

    private void insert(LinkedList list, int index, int[] values)
	throws TestFailedException
    {
	ListIterator iterator = list.listIterator(index);

	for (int i = 0; i < values.length; i++)
	{
	    iterator.add(new Integer(values[i]));
	    iterator.previous();
	}
    }

    private void insertUnordered(LinkedList list, int index, int[] values)
	throws TestFailedException
    {
	for (int i = 0; i < values.length; i++)
	{
	    list.add(new Integer(values[i]));
	}
    }

    private void remove(ValueIterator iterator, int index, int n)
	throws TestFailedException
    {
	int length = iterator.getLength();
	reposition(iterator, index);

	for (int i = 1; i <= n; i++)
	{
	    println("removeValue()...");
	    iterator.removeValue();

	    verifyEqual("getLength()", iterator.getLength(),
			length - i);
	}
    }

    private void remove(LinkedList list, int index, int n)
	throws TestFailedException
    {
	ListIterator iterator = list.listIterator(index);

	while (n > 0 && iterator.hasNext())
	{
	    System.out.println("[removing next element at position "
			       + iterator.nextIndex() + "]");
	    --n;
	    iterator.next();
	    iterator.remove();
	}

	while (n > 0 && iterator.hasPrevious())
	{
	    System.out.println("[removing previous element at position "
			       + iterator.previousIndex() + "]");
	    --n;
	    iterator.previous();
	    iterator.remove();
	}

	verifyEqual("requested # elements removed", n, 0);
    }

    private void removeUnordered(LinkedList list, int index, int n)
	throws TestFailedException
    {
	while (n > 0)
	{
	    if (index == list.size() - 1)
	    {
		list.removeLast();
		--index;
	    }
	    else
	    {
		list.set(index, list.removeLast());
	    }

	    --n;
	}
    }

    private void populate(ValueIterator iterator, int[] values)
	throws TestFailedException
    {
	populate(iterator, values, values.length);
    }

    private void populate(ValueIterator iterator, int[] values, int length)
	throws TestFailedException
    {
	verify(false, "iterator != null", iterator != null);
	verify(false, "isEmpty() == true", iterator.isEmpty());
	verify(false, "atEnd() == true", iterator.atEnd());
	verifyEqual("getLength()", iterator.getLength(), 0);

	for (int i = 0; i < length; i++)
	{
	    iterator.appendValue();

	    verify(false, "isEmpty() == false", !iterator.isEmpty());
	    verify(false, "atEnd() == false", !iterator.atEnd());
	    verifyEqual("getLength()", iterator.getLength(), i + 1);

	    iterator.setIntegerValue(values[i]);

	    int value = iterator.getIntegerValue();
	    verifyEqual("getIntegerValue()", value, values[i]);
	}
    }

    private void populate(LinkedList list, int[] values)
	throws TestFailedException
    {
	populate(list, values, values.length);
    }

    private void populate(LinkedList list, int[] values, int length)
	throws TestFailedException
    {
	for (int i = 0; i < length; i++)
	{
	    list.add(new Integer(values[i]));
	}
    }

    private void reposition(ValueIterator iterator, int index)
	throws TestFailedException
    {		      
	verify("getLength()", iterator.getLength(), Op.GREATER, index);

	iterator.rewind();
	for (int i = 0; i < index; i++)
	{
	    verify(false, "atEnd() == false", !iterator.atEnd());
	    iterator.advance();
	}

	verify(false, "atEnd() == false", !iterator.atEnd());
    }

    private void print(String s, ValueIterator iterator)
    {
	System.out.print(s);
	System.out.print("[");

	iterator.rewind();

	int length = iterator.getLength();
	for (int i = 0; i < length; i++)
	{
	    int value = iterator.getIntegerValue();
	    System.out.print(" " + value);

	    iterator.advance();
	}

	System.out.println(" ]");
    }

    private void print(String s, LinkedList list)
    {
	System.out.print(s);
	System.out.print("[");

	ListIterator iterator = list.listIterator(0);
	while (iterator.hasNext())
	{
	    int value = ((Integer)iterator.next()).intValue();
	    System.out.print(" " + value);
	}

	System.out.println(" ]");
    }

    private int[] allocateValues(IntBinArray array, int numAllocations)
    {
	int[] retval = new int[numAllocations];
	for (int i = 0; i < numAllocations; i++)
	{
	    retval[i] = array.allocate();
	}

	return retval;
    }
}
