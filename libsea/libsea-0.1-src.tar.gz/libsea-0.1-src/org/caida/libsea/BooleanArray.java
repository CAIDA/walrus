// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

class BooleanArray extends HeapArray
{
    ////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ////////////////////////////////////////////////////////////////////////

    public BooleanArray()
    {
	super(BITS_PER_ENTRY);
    }

    // {segmentSize} must be a power of 2.
    public BooleanArray(int segmentSize)
    {
	super(BITS_PER_ENTRY, segmentSize);
    }

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ////////////////////////////////////////////////////////////////////////

    public boolean getValue(int index)
    {
	if (!checkAllocated(index))
	{
	    throw new UnallocatedElementException();
	}

	return getValueUnchecked(index);
    }

    public void setValue(int index, boolean value)
    {
	if (!checkAllocated(index))
	{
	    throw new UnallocatedElementException();
	}

	setValueUnchecked(index, value);
    }

    public void clear()
    {
	super.clear();
	m_numAllocatedSegments = 0;
	m_segments = new int[STARTING_NUM_SEGMENTS][];
    }

    ////////////////////////////////////////////////////////////////////////
    // PROTECTED METHODS
    ////////////////////////////////////////////////////////////////////////

    protected int getNumAllocatedSegments()
    {
	return m_numAllocatedSegments;
    }

    protected void allocateSegment()
    {
	if (m_numAllocatedSegments == m_segments.length)
	{
	    expandSegmentsArray();
	}

	m_segments[m_numAllocatedSegments++] = new int[m_segmentSize];
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ///////////////////////////////////////////////////////////////////////

    private boolean getValueUnchecked(int index)
    {
	int entry = index >> ENTRY_INDEX_SHIFT;
	int position = index & ENTRY_POSITION_MASK;
	int segment = entry >> m_segmentSizeBits;
	int offset = entry & m_segmentMask;

	int bits = m_segments[segment][offset];
	return (bits & POSITION_MASK[position]) == POSITION_MASK[position];
    }

    private void setValueUnchecked(int index, boolean value)
    {
	int entry = index >> ENTRY_INDEX_SHIFT;
	int position = index & ENTRY_POSITION_MASK;
	int segment = entry >> m_segmentSizeBits;
	int offset = entry & m_segmentMask;

	int bits = m_segments[segment][offset];

	if (value)
	{
	    bits |= POSITION_MASK[position];
	}
	else
	{
	    bits &= ~POSITION_MASK[position];
	}

	m_segments[segment][offset] = bits;
    }

    private void expandSegmentsArray()
    {
	int[][] oldSegments = m_segments;
	m_segments = new int[oldSegments.length * 2][];
	System.arraycopy(oldSegments, 0, m_segments, 0, oldSegments.length);
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE CONSTANTS
    ////////////////////////////////////////////////////////////////////////

    private static final boolean DEBUG = true;

    private static final int STARTING_NUM_SEGMENTS = 32;

    private static final int ENTRY_INDEX_SHIFT = 5;
    private static final int ENTRY_POSITION_MASK = 0x1F;
    private static final int BITS_PER_ENTRY = 32;
    private static final int[] POSITION_MASK =
    {
	0x00000001, 0x00000002, 0x00000004, 0x00000008,
	0x00000010, 0x00000020, 0x00000040, 0x00000080,
	0x00000100, 0x00000200, 0x00000400, 0x00000800,
	0x00001000, 0x00002000, 0x00004000, 0x00008000,
	0x00010000, 0x00020000, 0x00040000, 0x00080000,
	0x00100000, 0x00200000, 0x00400000, 0x00800000,
	0x01000000, 0x02000000, 0x04000000, 0x08000000,
	0x10000000, 0x20000000, 0x40000000, 0x80000000
    };

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ////////////////////////////////////////////////////////////////////////

    private int  m_numAllocatedSegments = 0;
    private int[][]  m_segments = new int[STARTING_NUM_SEGMENTS][];
}
