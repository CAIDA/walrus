// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.*;

class IntArrayTester
    extends AbstractTester
{
    public static void main(String[] args)
    {
	new IntArrayTester().testAll();
    }

    public IntArrayTester()
    {
	super();
    }

    public void testAll()
    {
	try
	{
	    testAllocationsBasic(new IntArray(), 10, true);
	    testAllocationsBasic(new IntArray(128), 1000, true);

	    testAllocationsRandom(new IntArray(), 10, true);
	    testAllocationsRandom(new IntArray(128), 1000, true);

	    {
		IntArray array = new IntArray();
		int[] slots = allocateValues(array, 10);
		testAccess(array, slots, true);
	    }

	    {
		IntArray array = new IntArray();
		int[] slots = allocateValues(array, 1000);
		testAccess(array, slots, true);
	    }
	}
	catch (TestFailedException e)
	{
	    System.out.println("FAILED: " + e);
	}
	catch (RuntimeException e)
	{
	    System.out.println("ERROR: " + e);
	}
    }

    public void testAllocationsBasic(IntArray array, int numAllocations,
				     boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAllocationsBasic(numAllocations=" + numAllocations + ")");
	println("===========================================================");

	int[] slots = new int[numAllocations];

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("Allocating values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    slots[i] = array.allocate();

	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }
	}

	verifyEqual("# allocated", array.getNumAllocated(), numAllocations);

	println("Checking for duplicate indices...");
	{
	    int[] slots2 = (int[])slots.clone();
	    Arrays.sort(slots2);

	    int last = slots2[0];
	    for (int i = 1; i < slots2.length; i++)
	    {
		if (slots2[i] == last)
		{
		    fail("Index " + last + " allocated more than once.");
		}

		last = slots2[i];
	    }
	}

	println("Checking allocation map...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (!array.checkAllocated(slots[i]))
	    {
		fail("Index " + i + " is not marked as allocated.");
	    }
	}

	println("Freeing values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    array.free(slots[i]);
	}

	verifyEqual("# allocated", array.getNumAllocated(), 0);
	println("ALL PASSED!");
    }

    public void testAllocationsRandom(IntArray array, int numAllocations,
				      boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAllocationsRandom(numAllocations=" + numAllocations +")");
	println("===========================================================");

	int[] slots = new int[numAllocations];

	verifyEqual("# allocated", array.getNumAllocated(), 0);

	println("Allocating values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    slots[i] = array.allocate();

	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }
	}

	verifyEqual("# allocated", array.getNumAllocated(), numAllocations);

	shuffle(slots);

	println("Freeing values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    array.free(slots[i]);
	}

	verifyEqual("# allocated", array.getNumAllocated(), 0);
	println("ALL PASSED!");
    }

    public void testAccess(IntArray array, int[] slots, boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAccess(numAllocations=" + slots.length + ")");
	println("===========================================================");

	int numAllocations = slots.length;
	int[] values = createRandomValues(numAllocations);

	println("Setting values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i] + " = " + values[i]);
	    }

	    array.setValue(slots[i], values[i]);
	}

	println("Getting values...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i] + " = " + values[i]);
	    }

	    int value = array.getValue(slots[i]);
	    verifyEqual("getValue()", value, values[i]);
	}

	println("ALL PASSED!");
    }

    private int[] allocateValues(IntArray array, int numAllocations)
    {
	int[] retval = new int[numAllocations];
	for (int i = 0; i < numAllocations; i++)
	{
	    retval[i] = array.allocate();
	}

	return retval;
    }
}
