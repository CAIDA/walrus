// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.*;

class AllocationTableTester
    extends AbstractTester
{
    public static void main(String[] args)
    {
	int startingTest = parseArguments(args);
	new AllocationTableTester().testAll(startingTest);
    }

    public AllocationTableTester()
    {
	super();
    }

    public void testAll(int startingTest)
    {
	try
	{
	    if (startingTest == 0)
	    {
		println("**** TEST 0 ****");
		testAllocationsBasic(new AllocationTable(), 32, true);
	    }

	    if (startingTest <= 1)
	    {
		println("**** TEST 1 ****");
		testAllocationsBasic(new AllocationTable(), 320, true);
	    }

	    if (startingTest <= 2)
	    {
		println("**** TEST 2 ****");
		testAllocationsBasic(new AllocationTable(), 32000, false);
	    }

	    if (startingTest <= 3)
	    {
		println("**** TEST 3 ****");
		testAllocationsRandom(new AllocationTable(), 32, true);
	    }

	    if (startingTest <= 4)
	    {
		println("**** TEST 4 ****");
		testAllocationsRandom(new AllocationTable(), 320, true);
	    }

	    if (startingTest <= 5)
	    {
		println("**** TEST 5 ****");
		testAllocationsRandom(new AllocationTable(), 32000, false);
	    }

	    if (startingTest <= 6)
	    {
		println("**** TEST 6 ****");
		testIncreasingUsableGroups(new AllocationTable(),
					   10, 100, true);
	    }

	    if (startingTest <= 7)
	    {
		println("**** TEST 7 ****");
		testLogicalLength(new AllocationTable(), 32, 10, 5, 5, true);
	    }

	    if (startingTest <= 8)
	    {
		println("**** TEST 8 ****");
		testLogicalLength
		    (new AllocationTable(), 320, 100, 10, 20, true);
	    }

	    if (startingTest <= 9)
	    {
		println("**** TEST 9 ****");
		testLogicalLength
		    (new AllocationTable(), 3200, 1000, 25, 100, true);
	    }

	    if (startingTest <= 10)
	    {
		println("**** TEST 10 ****");
		testLogicalLength
		    (new AllocationTable(), 32000, 10000, 100, 200, false);
	    }
	}
	catch (TestFailedException e)
	{
	    System.out.println("FAILED: " + e);
	}
	catch (RuntimeException e)
	{
	    System.out.println("ERROR: " + e);
	}
    }

    public void testAllocationsBasic(AllocationTable table, int numAllocations,
				     boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAllocationsBasic(numAllocations=" + numAllocations + ")");
	println("===========================================================");

	int[] slots = allocateSlots(table, numAllocations, showSlots);
	freeSlots(table, slots, showSlots);
	println("ALL PASSED!");
    }

    public void testAllocationsRandom(AllocationTable table,
				      int numAllocations,
				      boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAllocationsRandom(numAllocations=" + numAllocations +")");
	println("===========================================================");

	int[] slots = allocateSlots(table, numAllocations, showSlots);
	shuffle(slots);
	freeSlots(table, slots, showSlots);
	println("ALL PASSED!");
    }

    public void testIncreasingUsableGroups(AllocationTable table,
					   int maxGroupsPerIteration,
					   int numIterations,
					   boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testIncreasingUsableGroups(");
	println("     maxGroupsPerIteration=" + maxGroupsPerIteration);
	println("     numIterations=" + numIterations + ")");
	println("===========================================================");

	verifyEqual(false, "# allocated groups",
		    table.getNumAllocatedGroups(), 0);
	verifyEqual(false, "# allocated slots",
		    table.getNumAllocatedSlots(), 0);

	int numAllocatedGroups = 0;
	int numAllocatedSlots = 0;

	println("Allocating values...");
	for (int i = 0; i < numIterations; i++)
	{
	    verifyEqual(false, "allocate()", table.allocate(), -1);

            int increment = m_random.nextInt(maxGroupsPerIteration - 1) + 1;

	    println("Increasing # usable groups by " + increment + "...");

	    table.increaseNumUsableGroups(increment);

	    numAllocatedGroups += increment;

	    verifyEqual("# allocated groups",
			table.getNumAllocatedGroups(), numAllocatedGroups);

	    for (int j = 0; j < 32 * increment; j++)
	    {
		int index = table.allocate();

		if (showSlots)
		{
		    println(" " + numAllocatedSlots + ": " + index);
		}

		verifyEqual("allocate()", index, numAllocatedSlots);

		++numAllocatedSlots;

		verifyEqual("# allocated slots",
			    table.getNumAllocatedSlots(), numAllocatedSlots);
	    }
	}

	table.clear();
	println("ALL PASSED!");
    }

    public void testLogicalLength(AllocationTable table, int numAllocations,
				  int numRandomSingleFrees,
				  int numRandomRangeFrees,
				  int rangeSize, boolean showSlots)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAllocationsRandom(numAllocations=" + numAllocations);
	println("             numRandomSingleFrees=" + numRandomSingleFrees);
	println("             numRandomRangeFrees=" + numRandomRangeFrees);
	println("             rangeSize=" + rangeSize + ")");
	println("===========================================================");

	int[] slots = allocateSlots(table, numAllocations, showSlots);
	Arrays.sort(slots);

	freeRandomSlots(table, slots, numRandomSingleFrees, 1, showSlots);
	freeRandomSlots(table, slots, numRandomRangeFrees,
			rangeSize, showSlots);

	int lastAllocated = slots.length;
	while (lastAllocated > 0)
	{
	    lastAllocated = findLastAllocated(slots, lastAllocated - 1);
	    if (lastAllocated >= 0)
	    {
		verifyEqual("logical length",
			    table.getLogicalLength(), lastAllocated + 1);

		table.free(slots[lastAllocated]);
		slots[lastAllocated] = -1;
	    }
	}

	verifyEqual("logical length", table.getLogicalLength(), 0);

	freeSlots(table, slots, showSlots);
	println("ALL PASSED!");
    }

    private int findLastAllocated(int[] slots, int startingIndex)
    {
	int i = startingIndex;	
	while (i >= 0 && slots[i] < 0)
	{
	    --i;
	}
	return (i >= 0 ? i : -1);
    }

    private void freeRandomSlots(AllocationTable table, int[] slots,
				 int numFrees, int rangeSize,
				 boolean showSlots)
    {
	println("Freeing random values...");
	for (int i = 0; i < numFrees; i++)
	{
	    int index = m_random.nextInt(slots.length);
	    int range = m_random.nextInt(rangeSize) + 1;
	    int endIndex = Math.min(slots.length, index + range);
	    if (showSlots)
	    {
		println("[" + range + " element(s) starting at " + index +"]");
	    }
	    for (int j = index; j < endIndex; j++)
	    {
		if (slots[j] >= 0)
		{
		    if (showSlots)
		    {
			println(" " + j + ": " + slots[j]);
		    }
		    table.free(slots[j]);
		    slots[j] = -1;
		}
	    }
	}
    }

    private int[] allocateSlots(AllocationTable table, int numAllocations,
			       boolean showSlots)
	throws TestFailedException
    {
	int numGroups = (numAllocations + 31) / 32;
	int[] retval = new int[numAllocations];

	verifyEqual(false, "# allocated groups",
		    table.getNumAllocatedGroups(), 0);
	verifyEqual(false, "# allocated slots",
		    table.getNumAllocatedSlots(), 0);
	verifyEqual(false, "logical length", table.getLogicalLength(), 0);

	println("Allocating values...");
	int numAllocated = 0;
	for (int i = 0; i < numGroups; i++)
	{
	    verifyEqual(false, "allocate()", table.allocate(), -1);

	    table.increaseNumUsableGroups(1);

	    verifyEqual(false, "# allocated groups",
			table.getNumAllocatedGroups(), i + 1);

	    for (int j = 0; numAllocated < numAllocations && j < 32; j++)
	    {
		retval[numAllocated] = table.allocate();

		if (showSlots)
		{
		    println(" " + numAllocated + ": " + retval[numAllocated]);
		}

		verify(false, "allocate() != -1", retval[numAllocated] != -1);
		++numAllocated;

		verifyEqual(false, "# allocated slots",
			    table.getNumAllocatedSlots(), numAllocated);

		verifyEqual(false, "logical length",
			    table.getLogicalLength(), numAllocated);
	    }
	}

	verifyEqual(false, "# allocated slots",
		    table.getNumAllocatedSlots(), numAllocations);

	verifyEqual(false, "logical length",
		    table.getLogicalLength(), numAllocations);

	println("Checking for duplicate indices...");
	{
	    int[] slots = (int[])retval.clone();
	    Arrays.sort(slots);

	    int last = slots[0];
	    for (int i = 1; i < slots.length; i++)
	    {
		if (slots[i] == last)
		{
		    fail("Index " + last + " allocated more than once.");
		}

		last = slots[i];
	    }
	}

	println("Checking allocation map...");
	for (int i = 0; i < numAllocations; i++)
	{
	    if (!table.checkAllocated(retval[i]))
	    {
		fail("Index " + i + " is not marked as allocated.");
	    }
	}

	return retval;
    }

    private void freeSlots(AllocationTable table, int[] slots,
			   boolean showSlots)
	throws TestFailedException
    {
	println("Freeing values...");
	for (int i = 0; i < slots.length; i++)
	{
	    if (showSlots)
	    {
		println(" " + i + ": " + slots[i]);
	    }

	    if (slots[i] >= 0)
	    {
		table.free(slots[i]);
	    }
	}

	verifyEqual(false, "# allocated slots",
		    table.getNumAllocatedSlots(), 0);
	verifyEqual(false, "logical length",
		    table.getLogicalLength(), 0);
    }
}
