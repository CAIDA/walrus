// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

abstract class HeapArray
{
    ////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ////////////////////////////////////////////////////////////////////////

    // {numValuesPerElement} must be a power of 2.
    public HeapArray(int numValuesPerElement)
    {
	this(numValuesPerElement, DEFAULT_SEGMENT_SIZE);
    }

    // {numValuesPerElement} must be a power of 2.
    // {segmentSize} must be a power of 2.
    public HeapArray(int numValuesPerElement, int segmentSize)
    {
	if (numValuesPerElement <= 0)
	{
	    String msg = "numValuesPerElement must be positive";
	    throw new IllegalArgumentException(msg);
	}

	if ((numValuesPerElement & -numValuesPerElement)
	    != numValuesPerElement)
	{
	    String msg = "numValuesPerElement must be a power of 2";
	    throw new IllegalArgumentException(msg);
        }

	if (segmentSize <= 0)
	{
	    throw new IllegalArgumentException("segmentSize must be positive");
	}

	if (segmentSize < MIN_SEGMENT_SIZE)
	{
	    segmentSize = MIN_SEGMENT_SIZE;
	}

	if ((segmentSize & -segmentSize) != segmentSize)
	{
	    String msg = "segmentSize must be a power of 2";
	    throw new IllegalArgumentException(msg);
        }

	m_segmentSize = segmentSize;
	m_segmentMask = segmentSize - 1;
	m_segmentSizeBits = MiscMath.log2(m_segmentSize);
	m_segmentSizeGroups = (segmentSize * numValuesPerElement)
	    / AllocationTable.ALLOCATION_GROUP_SIZE;
	m_numValuesPerElement = numValuesPerElement;
    }

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ////////////////////////////////////////////////////////////////////////

    public boolean isEmpty()
    {
	return getNumAllocated() == 0;
    }

    public boolean checkAllocated(int index)
    {
	validateNonnegativeIndex(index);
	return m_allocationTable.checkAllocated(index);
    }

    public void free(int index)
    {
	validateNonnegativeIndex(index);
	m_allocationTable.free(index);
    }

    public int allocate()
    {
	int retval = m_allocationTable.allocate();
	if (retval == -1)
	{
	    if (DEBUG &&
		m_allocationTable.getNumAllocatedSlots()
		!= computeNumAvailableForUse())
	    {
		String msg = "HeapArray and AllocationTable "
		    + "disagree on the number of allocated slots";
		throw new InternalErrorException(msg);
	    }

	    allocateSegment();
	    m_allocationTable.increaseNumUsableGroups(m_segmentSizeGroups);

	    retval = m_allocationTable.allocate();
	    if (retval == -1)
	    {
		String msg = "AllocationTable.allocate() failed despite a "
		    + "call to increaseNumUsableGroups()";
		throw new InternalErrorException(msg);
	    }
	}

	return retval;
    }

    public void clear()
    {
	m_allocationTable.clear();
    }

    public int getLogicalLength()
    {
	return m_allocationTable.getLogicalLength();
    }

    public int getNumAllocated()
    {
	return m_allocationTable.getNumAllocatedSlots();
    }

    public int getNumFree()
    {
	return computeNumAvailableForUse()
	    - m_allocationTable.getNumAllocatedSlots();
    }

    ////////////////////////////////////////////////////////////////////////
    // PROTECTED METHODS
    ////////////////////////////////////////////////////////////////////////

    protected abstract int getNumAllocatedSegments();
    protected abstract void allocateSegment();

    protected final void validateNonnegativeIndex(int index)
    {
	if (index < 0)
	{
	    String msg = "index[" + index + "] must be nonnegative";
	    throw new IllegalArgumentException(msg);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ///////////////////////////////////////////////////////////////////////

    private int computeNumAvailableForUse()
    {
	return getNumAllocatedSegments() * m_segmentSize
	    * m_numValuesPerElement;
    }

    ////////////////////////////////////////////////////////////////////////
    // PROTECTED FIELDS
    ////////////////////////////////////////////////////////////////////////

    // These are protected rather than private (with accompanying accessors)
    // so that Java will take the hint of the "final" attribute and optimize
    // calculations.

    protected final int  m_segmentSize;
    protected final int  m_segmentMask;
    protected final int  m_segmentSizeBits;

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE CONSTANTS
    ////////////////////////////////////////////////////////////////////////

    private static final boolean DEBUG = true;

    // This must be a power of 2.
    private static final int DEFAULT_SEGMENT_SIZE = 1024;

    // This must be a power of 2.
    // This must be at least AllocationTable.ALLOCATION_GROUP_SIZE.
    private static final int MIN_SEGMENT_SIZE = 128;

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ////////////////////////////////////////////////////////////////////////

    private AllocationTable  m_allocationTable = new AllocationTable();
    private final int  m_segmentSizeGroups;
    private final int  m_numValuesPerElement;
}
