// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.*;

class ArrayPerformance
    extends AbstractTester
{
    ///////////////////////////////////////////////////////////////////////
    // MAIN
    ///////////////////////////////////////////////////////////////////////

    public static void main(String[] args)
    {
	int startingTest = parseArguments(args);
	ArrayPerformance tester = new ArrayPerformance();
	tester.testAll(startingTest);
    }

    ///////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ///////////////////////////////////////////////////////////////////////

    public ArrayPerformance()
    {
	super();
    }

    ///////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ///////////////////////////////////////////////////////////////////////

    public void testAll(int startingTest)
    {
	try
	{
	    if (startingTest == 0)
	    {
		println("\n**** TEST 0 ****");
		for (int i = 0; i < 100; i++)
		{
		    testGrowableIntArraySorting(i);
		}

		testGrowableIntArraySorting(1000);
		testGrowableIntArraySorting(100000);
	    }

	    if (startingTest <= 1)
	    {
		println("\n**** TEST 1 ****");
		for (int i = 0; i < 100; i++)
		{
		    testGrowableIntArrayInternalSorting(i);
		}

		testGrowableIntArrayInternalSorting(1000);
		testGrowableIntArrayInternalSorting(100000);
	    }

	    if (startingTest <= 2)
	    {
		println("\n**** TEST 2 ****");
		for (int i = 0; i < 100; i++)
		{
		    testGrowableIntArrayParallelSorting(i);
		}

		testGrowableIntArrayParallelSorting(1000);
		testGrowableIntArrayParallelSorting(100000);
	    }

	    if (startingTest <= 2)
	    {
		println("===============================================");
		println("Stopped testing at test 2.");
		println("Use a higher starting number than 2");
		println("to run tests 3 and beyond.");
		println("===============================================");
		System.exit(0);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		int[] sizes = { 1000000 };
		for (int i = 0; i < sizes.length; i++)
		{
		    int n = sizes[i];

		    timeGrowableIntArraySorting(n, 2);
		    timeGrowableIntArraySorting(n, 16);
		    for (int m = 256; m < 2 * n; m *= 2)
		    {
			timeGrowableIntArraySorting(n, m);
		    }
		}
	    }
	}
	catch (TestFailedException e)
	{
	    e.printStackTrace();
	    System.out.println("FAILED: " + e);
	}
	catch (RuntimeException e)
	{
	    e.printStackTrace();
	    System.out.println("ERROR: " + e);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private void timeGrowableIntArraySorting(int size, int m)
	throws TestFailedException
    {
	timeGrowableIntArraySorting
	    ("sawtooth", createSawtoothDistribution(size, m), m);
	timeGrowableIntArraySorting
	    ("random", createRandomDistribution(size, m), m);
	timeGrowableIntArraySorting
	    ("staggered", createStaggeredDistribution(size, m), m);
	timeGrowableIntArraySorting
	    ("plateau", createPlateauDistribution(size, m), m);
	timeGrowableIntArraySorting
	    ("reverse plateau", createReversePlateauDistribution(size, m), m);
	timeGrowableIntArraySorting
	    ("shuffled", createShuffledDistribution(size, m), m);
    }

    ///////////////////////////////////////////////////////////////////////
    // BOOLEAN ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testGrowableIntArraySorting(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testGrowableIntArraySorting(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	GrowableIntArray growableArray = createGrowableArray(array);
	giqsort(growableArray, 0, numValues - 1);

	checkSorted(growableArray);
	compare(growableArray, sortedArray);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    private void testGrowableIntArrayInternalSorting(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testGrowableIntArrayInternalSorting(numValues="
		+ numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	GrowableIntArray growableArray = createGrowableArray(array);
	growableArray.qsort();

	checkSorted(growableArray);
	compare(growableArray, sortedArray);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    private void testGrowableIntArrayParallelSorting(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testGrowableIntArrayParallelSorting(numValues="
		+ numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	
	int[] parallelArray = new int[numValues];

	for (int i = 0; i < numValues; i++)
	{
	    parallelArray[i] = i;
	}

	GrowableIntArray growableArray = createGrowableArray(array);
	growableArray.qsort(new IntParallelSortable(parallelArray));

	checkSorted(growableArray);
	compare(growableArray, sortedArray);

	boolean showValues = (numValues < PRINTING_THRESHOLD); 
	println("Checking parallel array...");
	for (int i = 0; i < numValues; i++)
	{
	    verifyEqual(showValues, "permuted@" + i,
			array[parallelArray[i]], growableArray.getValue(i));
	}

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    private void timeGrowableIntArraySorting(String distribution,
					     int[] array, int m)
	throws TestFailedException
    {
	int numValues = array.length;

	println();
	println("===========================================================");
	println("timeGrowableIntArraySorting(distribution=" + distribution
		+ ", numValues=" + numValues + ", m=" + m + ")");
	println("===========================================================");

	int[] working = new int[numValues];
	int[] parallel = new int[numValues];

	System.gc();
	long tSQGIC;
	{
	    GrowableIntArray growableArray = createGrowableArray(array);
	    GrowableIntCompositeSortable sortable =
		new GrowableIntCompositeSortable(growableArray, parallel);
	    long start = System.currentTimeMillis();
	    Sorter.qsort(sortable, 0, numValues - 1);
	    long end = System.currentTimeMillis();
	    tSQGIC = end - start;
	}

	System.gc();
	long tSQGI;
	{
	    GrowableIntArray growableArray = createGrowableArray(array);
	    GrowableIntSortable sortable =
		new GrowableIntSortable(growableArray);
	    long start = System.currentTimeMillis();
	    Sorter.qsort(sortable, 0, numValues - 1);
	    long end = System.currentTimeMillis();
	    tSQGI = end - start;
	}


	System.gc();
	long tQG;
	{
	    GrowableIntArray growableArray = createGrowableArray(array);
	    long start = System.currentTimeMillis();
	    giqsort(growableArray, 0, numValues - 1);
	    long end = System.currentTimeMillis();
	    tQG = end - start;
	}

	System.gc();
	long tSQIC;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    IntCompositeSortable sortable =
		new IntCompositeSortable(working, parallel);
	    long start = System.currentTimeMillis();
	    Sorter.qsort(sortable, 0, numValues - 1);
	    long end = System.currentTimeMillis();
	    tSQIC = end - start;
	}

	System.gc();
	long tSQI;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    IntSortable sortable = new IntSortable(working);
	    long start = System.currentTimeMillis();
	    Sorter.qsort(sortable, 0, numValues - 1);
	    long end = System.currentTimeMillis();
	    tSQI = end - start;
	}

	System.gc();
	long tGQIC;
	{
	    GrowableIntArray growableArray = createGrowableArray(array);
	    IntParallelSortable sortable = new IntParallelSortable(parallel);
	    long start = System.currentTimeMillis();
	    growableArray.qsort(sortable);
	    long end = System.currentTimeMillis();
	    tGQIC = end - start;
	}

	System.gc();
	long tGQNC;
	{
	    GrowableIntArray growableArray = createGrowableArray(array);
	    NullParallelSortable sortable = new NullParallelSortable();
	    long start = System.currentTimeMillis();
	    growableArray.qsort(sortable);
	    long end = System.currentTimeMillis();
	    tGQNC = end - start;
	}

	System.gc();
	long tGQI;
	{
	    GrowableIntArray growableArray = createGrowableArray(array);
	    long start = System.currentTimeMillis();
	    growableArray.qsort();
	    long end = System.currentTimeMillis();
	    tGQI = end - start;
	}

	System.gc();
	long tSIQ;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    long start = System.currentTimeMillis();
	    Sorter.iqsort(working, 0, numValues - 1);
	    long end = System.currentTimeMillis();
	    tSIQ = end - start;
	}

	System.gc();
	long tS;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    long start = System.currentTimeMillis();
	    Arrays.sort(working);
	    long end = System.currentTimeMillis();
	    tS = end - start;
	}

	println("* " + numValues + " " + m + " SQGIC " + tSQGIC);
	println("* " + numValues + " " + m + " SQGI " + tSQGI);
	println("* " + numValues + " " + m + " QG " + tQG);
	println("* " + numValues + " " + m + " SQIC " + tSQIC);
	println("* " + numValues + " " + m + " SQI " + tSQI);
	println("* " + numValues + " " + m + " GQIC " + tGQIC);
	println("* " + numValues + " " + m + " GQNC " + tGQNC);
	println("* " + numValues + " " + m + " GQI " + tGQI);
	println("* " + numValues + " " + m + " SIQ " + tSIQ);
	println("* " + numValues + " " + m + " S " + tS);

	double rSQGIC = (double)tSQGIC / (double)tS;
	double rSQGI = (double)tSQGI / (double)tS;
	double rQG = (double)tQG / (double)tS;
	double rSQIC = (double)tSQIC / (double)tS;
	double rSQI = (double)tSQI / (double)tS;
	double rGQIC = (double)tGQIC / (double)tS;
	double rGQNC = (double)tGQNC / (double)tS;
	double rGQI = (double)tGQI / (double)tS;
	double rSIQ = (double)tSIQ / (double)tS;

	println("% " + numValues + " " + m + " SQGIC " + rSQGIC);
	println("% " + numValues + " " + m + " SQGI " + rSQGI);
	println("% " + numValues + " " + m + " QG " + rQG);
	println("% " + numValues + " " + m + " SQIC " + rSQIC);
	println("% " + numValues + " " + m + " SQI " + rSQI);
	println("% " + numValues + " " + m + " GQIC " + rGQIC);
	println("% " + numValues + " " + m + " GQNC " + rGQNC);
	println("% " + numValues + " " + m + " GQI " + rGQI);
	println("% " + numValues + " " + m + " SIQ " + rSIQ);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // SORTING METHODS
    ///////////////////////////////////////////////////////////////////////

    private static final int QSORT_INSERTION_THRESHOLD = 7;
    private static final int QSORT_MEDIUM_THRESHOLD = 7;
    private static final int QSORT_LARGE_THRESHOLD = 40;

    /**
     * (NOT FOR GENERAL USE) Sorts the elements with indexes in the range
     * (start, end), inclusive, using the same implementation of Quicksort
     * as Sorter.iqsort() except specialized to GrowableIntArray.
     */
    private static void giqsort(GrowableIntArray data, int start, int end)
    {
	int n = end - start + 1;
	if (n <= 1) { return; }
	if (n < QSORT_INSERTION_THRESHOLD)
	{
	    // Perform insertion sort.
	    for (int i = start + 1; i <= end; i++)
	    {
		for (int j = i; j > start; j--)
		{
		    int dj_1 = data.getValue(j - 1);
		    int dj = data.getValue(j);
		    if (dj_1 > dj)
		    {
			data.setValue(j, dj_1);
			data.setValue(j - 1, dj);
		    }
		    else
		    {
			break;
		    }
		}
	    }
	}
	else
	{
	    int pm = start + n / 2;  // For small arrays, use middle element.
	    if (n > QSORT_MEDIUM_THRESHOLD)
	    {
		if (n > QSORT_LARGE_THRESHOLD)
		{
		    // For large arrays, use pseudomedian of 9 elements.
		    int s = n / 8;
		    int p1 = median3(data, start, start + s, start + 2 * s);
		    pm = median3(data, pm - s, pm, pm + s);
		    int pn = median3(data, end - 2 * s, end - s, end);
		    pm = median3(data, p1, pm, pn);
		}
		else
		{
		    // For medium arrays...
		    pm = median3(data, start, pm, end);
		}
	    }

	    {
		int t = data.getValue(start);
		data.setValue(start, data.getValue(pm));
		data.setValue(pm, t);
	    }

	    int dv = data.getValue(start);  // The pivot.
	    int a = start + 1;   int b = start + 1;
	    int c = end;         int d = end;

	    for (;;)
	    {
		while (b <= c)
		{
		    int db = data.getValue(b);
		    int result = (db < dv ? -1 : db == dv ? 0 : 1);
		    if (result > 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    data.setValue(b, data.getValue(a));
			    data.setValue(a, db);
			    ++a;
			}
			++b;
		    }
		}

		while (c >= b)
		{
		    int dc = data.getValue(c);
		    int result = (dc < dv ? -1 : dc == dv ? 0 : 1);
		    if (result < 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    data.setValue(c, data.getValue(d));
			    data.setValue(d, dc);
			    --d;
			}
			--c;
		    }
		}

		if (b > c) { break; }

		{
		    int t = data.getValue(b);
		    data.setValue(b, data.getValue(c));
		    data.setValue(c, t);
		}
		b++;  c--;
	    }

	    {
		int s = Math.min(a - start, b - a);
		int l = start;  int h = b - s;
		while (s > 0)
		{
		    int t = data.getValue(l);
		    data.setValue(l, data.getValue(h));
		    data.setValue(h, t);
		    l++;  h++;  --s;
		}
	    }

	    {
		int s = Math.min(d - c, end - d);
		int l = b;  int h = end - s + 1;
		while (s > 0)
		{
		    int t = data.getValue(l);
		    data.setValue(l, data.getValue(h));
		    data.setValue(h, t);
		    l++;  h++;  --s;
		}
	    }

	    giqsort(data, start, start + b - a - 1);
	    giqsort(data, end - (d - c) + 1, end);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static int median3(GrowableIntArray data, int i, int j, int k)
    {
	int di = data.getValue(i);
	int dj = data.getValue(j);
	int dk = data.getValue(k);
	return di < dj
	    ? (dj < dk ? j : di < dk ? k : i)
	    : (dj > dk ? j : di > dk ? k : i);
    }

    ///////////////////////////////////////////////////////////////////////
    // UTILITIES
    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a GrowableIntArray containing the same values as the given
     * integer array.
     */
    private GrowableIntArray createGrowableArray(int[] array)
	throws TestFailedException
    {
	GrowableIntArray retval = new GrowableIntArray();

	long start = System.currentTimeMillis();
	for (int i = 0; i < array.length; i++)
	{
	    int index = retval.append(array[i]);
	    if (VERIFY_GROWABLE_INT_ARRAY)
	    {
		verifyEqual(false, "append()", index, i);
		verifyEqual(false, "getValue()", retval.getValue(i), array[i]);
	    }
	}
	long end = System.currentTimeMillis();
	System.out.println("Appended " + array.length
			   + " elements to GrowableIntArray in "
			   + (end - start) + "ms");

	int size = retval.getNumAllocated();
	verifyEqual(false, "getNumAllocated()", size, array.length);

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the elements of the given arrays are the same at the
     * same positions.
     */
    private void compare(GrowableIntArray array, int[] sorted)
	throws TestFailedException
    {
	println("Comparing results...");
	verifyEqual(false, "length", array.getNumAllocated(), sorted.length);
	for (int i = 0; i < sorted.length; i++)
	{
	    verifyEqual(false, "array[" + i + "]",
			array.getValue(i), sorted[i]);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the elements of the given arrays are the same at the
     * same positions.
     */
    private void compare(int[] array, int[] sorted)
	throws TestFailedException
    {
	println("Comparing results...");
	verifyEqual(false, "length", array.length, sorted.length);
	for (int i = 0; i < array.length; i++)
	{
	    verifyEqual(false, "array[" + i + "]", array[i], sorted[i]);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the elements in the given array are in ascending order.
     */
    private void checkSorted(GrowableIntArray array)
	throws TestFailedException
    {
	int numValues = array.getNumAllocated();
	boolean showValues = (numValues < PRINTING_THRESHOLD); 
	println("Checking GrowableIntArray is sorted...");
	if (numValues > 0)
	{
	    if (showValues)
	    {
		println("[0: " + array.getValue(0) + "]");
	    }
	    for (int i = 1; i < numValues; i++)
	    {
		if (showValues)
		{
		    println("[" + i + ": " + array.getValue(i) + "]");
		}
		if (array.getValue(i) < array.getValue(i - 1))
		{
		    String msg = "element at position " + i
			+ " is not >= previous element";
		    fail(msg);
		}
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the elements in the given array are in ascending order.
     */
    private void checkSorted(int[] array)
	throws TestFailedException
    {
	boolean showValues = (array.length < PRINTING_THRESHOLD); 
	println("Checking array is sorted...");
	if (array.length > 0)
	{
	    if (showValues)
	    {
		println("[0: " + array[0] + "]");
	    }
	    for (int i = 1; i < array.length; i++)
	    {
		if (showValues)
		{
		    println("[" + i + ": " + array[i] + "]");
		}
		if (array[i] < array[i - 1])
		{
		    String msg = "element at position " + i
			+ " is not >= previous element";
		    fail(msg);
		}
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a new sorted array from the given array.
     */
    private int[] createSortedArray(int[] array)
    {
	int[] retval = (int[])array.clone();
	Arrays.sort(retval);
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private int[] createSawtoothDistribution(int numValues, int m)
    {
	int[] retval = new int[numValues];
	for (int i = 0; i < numValues; i++)
	{
	    retval[i] = i % m;
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private int[] createRandomDistribution(int numValues, int m)
    {
	int[] retval = new int[numValues];

	long start = System.currentTimeMillis();
	for (int i = 0; i < numValues; i++)
	{
	    retval[i] = m_random.nextInt(m);
	}
	long end = System.currentTimeMillis();
	System.out.println("Created " + numValues + " random values in "
			   + (end - start) + "ms");

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private int[] createStaggeredDistribution(int numValues, int m)
    {
	int[] retval = new int[numValues];
	for (int i = 0; i < numValues; i++)
	{
	    retval[i] = (i * m + i) % numValues;
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private int[] createPlateauDistribution(int numValues, int m)
    {
	int[] retval = new int[numValues];
	for (int i = 0; i < numValues; i++)
	{
	    retval[i] = Math.min(i, m);
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private int[] createReversePlateauDistribution(int numValues, int m)
    {
	int[] retval = new int[numValues];
	for (int i = 0; i < numValues; i++)
	{
	    retval[numValues - i - 1] = Math.min(i, m);
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private int[] createShuffledDistribution(int numValues, int m)
    {
	int[] retval = new int[numValues];

	int j = 0;
	int k = 1;
	for (int i = 0; i < numValues; i++)
	{
	    retval[i] = (m_random.nextInt(m) > 0 ? (j+=2) : (k+=2));
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    /**
     * Whether we should check basic operations of GrowableIntArray
     * with verifyEqual().
     *
     * <p>
     * Doing these checks will greatly slow things down.  Specifically,
     * createGrowableArray() will take more than 17secs rather than under
     * 170ms when populating a million values.
     * </p>
     */
    private static final boolean  VERIFY_GROWABLE_INT_ARRAY = false;

    private static final int PRINTING_THRESHOLD = 100;

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE NESTED CLASSES
    ///////////////////////////////////////////////////////////////////////

    private static class GrowableIntSortable
	implements Sorter.Sortable
    {
	public GrowableIntSortable(GrowableIntArray array)
	{
	    m_array = array;
	}

	public int compare(int i, int j)
	{
	    int a = m_array.getValue(i);
	    int b = m_array.getValue(j);
	    return a < b ? -1 : a == b ? 0 : 1;
	}

	public void swap(int i, int j)
	{
	    int t = m_array.getValue(i);
	    m_array.setValue(i, m_array.getValue(j));
	    m_array.setValue(j, t);
	}

	private GrowableIntArray  m_array;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class IntSortable
	implements Sorter.Sortable
    {
	public IntSortable(int[] array)
	{
	    m_array = array;
	}

	public int compare(int i, int j)
	{
	    int di = m_array[i];
	    int dj = m_array[j];
	    return di < dj ? -1	: di == dj ? 0 : 1;
	}

	public void swap(int i, int j)
	{
	    int t = m_array[i];
	    m_array[i] = m_array[j];
	    m_array[j] = t;
	}

	private int[]  m_array;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class GrowableIntCompositeSortable
	implements Sorter.Sortable
    {
	public GrowableIntCompositeSortable(GrowableIntArray array,
					    int[] parallel)
	{
	    m_array = array;
	    m_parallel = parallel;
	}

	public int compare(int i, int j)
	{
	    int a = m_array.getValue(i);
	    int b = m_array.getValue(j);
	    return a < b ? -1 : a == b ? 0 : 1;
	}

	public void swap(int i, int j)
	{
	    {
		int t = m_array.getValue(i);
		m_array.setValue(i, m_array.getValue(j));
		m_array.setValue(j, t);
	    }
	    {
		int t = m_parallel[i];
		m_parallel[i] = m_parallel[j];
		m_parallel[j] = t;
	    }
	}

	private GrowableIntArray  m_array;
	private int[]  m_parallel;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class IntCompositeSortable
	implements Sorter.Sortable
    {
	public IntCompositeSortable(int[] array, int[] parallel)
	{
	    m_array = array;
	    m_parallel = parallel;
	}

	public int compare(int i, int j)
	{
	    int di = m_array[i];
	    int dj = m_array[j];
	    return di < dj ? -1	: di == dj ? 0 : 1;
	}

	public void swap(int i, int j)
	{
	    {
		int t = m_array[i];
		m_array[i] = m_array[j];
		m_array[j] = t;
	    }
	    {
		int t = m_parallel[i];
		m_parallel[i] = m_parallel[j];
		m_parallel[j] = t;
	    }
	}

	private int[]  m_array;
	private int[]  m_parallel;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class NullParallelSortable
	implements GrowableIntArray.ParallelSortable
    {
	public void swap(int i, int j) { }
    }

    ///////////////////////////////////////////////////////////////////////

    private static class IntParallelSortable
	implements GrowableIntArray.ParallelSortable
    {
	public IntParallelSortable(int[] array)
	{
	    m_array = array;
	}

	public void swap(int i, int j)
	{
	    int t = m_array[i];
	    m_array[i] = m_array[j];
	    m_array[j] = t;
	}

	private int[]  m_array;
    }
}
