// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

class AllocationTable
{
    ///////////////////////////////////////////////////////////////////////
    // PUBLIC CONSTANTS
    ///////////////////////////////////////////////////////////////////////

    public static final int ALLOCATION_GROUP_SIZE = 32;

    ////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ////////////////////////////////////////////////////////////////////////

    public AllocationTable()
    {
    }

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ////////////////////////////////////////////////////////////////////////

    public boolean checkAllocated(int index)
    {
	validateNonnegativeIndex(index);
	if (index >= m_logicalLength)
	{
	    return false;
	}
	else
	{
	    int groupIndex = index / GROUP_SIZE;
	    int groupOffset = index % GROUP_SIZE;

	    if (groupIndex >= m_numAllocatedGroups)
	    {
		String msg = "groupIndex[" + groupIndex
		    + "] >= m_numAllocatedGroups ["
		    + m_numAllocatedGroups + "]";
		throw new InternalErrorException(msg);
	    }

	    return (m_allocationMap[groupIndex] & POWER2_BIT[groupOffset])
		== POWER2_BIT[groupOffset];
	}
    }

    public int allocate()
    {
	int retval = -1;

	if (m_freeList != -1)
	{
	    retval = m_freeList * GROUP_SIZE;

	    int mapNew = 0;
	    int mapOld = m_allocationMap[m_freeList];

	    // Compute the position of a free slot in this group.
	    // Also compute a new entry for the allocation map.

	    int byte0 = mapOld & 0xFF;
	    int position0 = FIND_FIRST_CLEARED_BIT[byte0];
	    if (position0 >= 0)
	    {
		retval += position0;
		mapNew = (mapOld & 0xFFFFFF00) | SET_FIRST_CLEARED_BIT[byte0];
	    }
	    else
	    {
		int byte1 = (mapOld >> 8) & 0xFF;
		int position1 = FIND_FIRST_CLEARED_BIT[byte1];
		if (position1 >= 0)
		{
		    retval += 8 + position1;
		    mapNew = (mapOld & 0xFFFF00FF)
			| (SET_FIRST_CLEARED_BIT[byte1] << 8);
		}
		else
		{
		    int byte2 = (mapOld >> 16) & 0xFF;
		    int position2 = FIND_FIRST_CLEARED_BIT[byte2];
		    if (position2 >= 0)
		    {
			retval += 16 + position2;
			mapNew = (mapOld & 0xFF00FFFF)
			    | (SET_FIRST_CLEARED_BIT[byte2] << 16);
		    }
		    else
		    {
			int byte3 = (mapOld >> 24) & 0xFF;
			int position3 = FIND_FIRST_CLEARED_BIT[byte3];
			if (position3 >= 0)
			{
			    retval += 24 + position3;
			    mapNew = (mapOld & 0x00FFFFFF)
				| (SET_FIRST_CLEARED_BIT[byte3] << 24);
			}
			else
			{
			    String msg = "no free slot in allocation map item["
				+ mapOld + "]";
			    throw new InternalErrorException(msg);
			}
		    }
		}
	    }

	    m_allocationMap[m_freeList] = mapNew;
	    if (mapNew == 0xFFFFFFFF)
	    {
		m_freeList = m_freeListNodes[m_freeList];
	    }

	    ++m_numAllocatedSlots;
	}

	if (retval >= m_logicalLength)
	{
	    m_logicalLengthCached = true;
	    m_logicalLength = retval + 1;
	}

	return retval;
    }

    // NOTE: A group represents 32 slots.
    // NOTE: {n} must be > 0.
    public void increaseNumUsableGroups(int n)
    {
	int requiredCapacity = m_numAllocatedGroups + n;
	if (requiredCapacity > m_freeListNodes.length)
	{
	    expandGroupArrays(requiredCapacity);
	}

	// Link newly-added groups to the free list.

	m_freeListNodes[requiredCapacity - 1] = m_freeList;
	m_freeList = m_numAllocatedGroups;

	for (int i = 0; i <= n - 2; i++)
	{
	    m_freeListNodes[m_numAllocatedGroups + i] =
		m_numAllocatedGroups + i + 1;
	}

	m_numAllocatedGroups = requiredCapacity;
    }

    public void free(int index)
    {
	validateNonnegativeIndex(index);
	if (index < m_logicalLength)
	{
	    int groupIndex = index / GROUP_SIZE;
	    int groupOffset = index % GROUP_SIZE;

	    if (groupIndex >= m_numAllocatedGroups)
	    {
		String msg = "groupIndex[" + groupIndex
		    + "] >= m_numAllocatedGroups ["
		    + m_numAllocatedGroups + "]";
		throw new InternalErrorException(msg);
	    }

	    int mapOld = m_allocationMap[groupIndex];
	    int bit = POWER2_BIT[groupOffset];
	    if ((mapOld & bit) == bit)
	    {
		--m_numAllocatedSlots;
		m_allocationMap[groupIndex] = mapOld & ~bit;

		if (mapOld == 0xFFFFFFFF)
		{
		    m_freeListNodes[groupIndex] = m_freeList;
		    m_freeList = groupIndex;
		}

		if (index == m_logicalLength - 1)
		{
		    m_logicalLengthCached = false;
		}
	    }
	    else
	    {
		if (DEBUG)
		{
		    System.err.println("WARNING: AllocationTable.free(): "
				       + "index " + index + " already free.");
		}
	    }
	}
    }

    public void clear()
    {
	m_freeList = -1;
	m_freeListNodes = new int[INITIAL_SIZE];
	m_allocationMap = new int[INITIAL_SIZE];
	m_logicalLengthCached = true;
	m_logicalLength = 0;
	m_numAllocatedGroups = 0;
	m_numAllocatedSlots = 0;
    }

    public int getLogicalLength()
    {
	if (!m_logicalLengthCached)
	{
	    updateLogicalLength();
	}
	return m_logicalLength;
    }

    public int getNumAllocatedGroups()
    {
	return m_numAllocatedGroups;
    }

    public int getNumAllocatedSlots()
    {
	return m_numAllocatedSlots;
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ////////////////////////////////////////////////////////////////////////

    private void updateLogicalLength()
    {
	m_logicalLengthCached = true;

	int groupIndex = m_logicalLength / GROUP_SIZE;
	while (groupIndex >= 0 && m_allocationMap[groupIndex] == 0)
	{
	    --groupIndex;
	}

	if (groupIndex >= 0)
	{
	    int offset = findLastSetBit(m_allocationMap[groupIndex]);
	    m_logicalLength = groupIndex * GROUP_SIZE + offset + 1;
	}
	else
	{
	    m_logicalLength = 0;
	}
    }

    private int findLastSetBit(int n)
    {
	int retval = -1;
	
	int byte3 = (n >> 24) & 0xFF;
	int position3 = FIND_LAST_SET_BIT[byte3];
	if (position3 >= 0)
	{
	    retval = 24 + position3;
	}
	else
	{
	    int byte2 = (n >> 16) & 0xFF;
	    int position2 = FIND_LAST_SET_BIT[byte2];
	    if (position2 >= 0)
	    {
		retval = 16 + position2;
	    }
	    else
	    {
		int byte1 = (n >> 8) & 0xFF;
		int position1 = FIND_LAST_SET_BIT[byte1];
		if (position1 >= 0)
		{
		    retval = 8 + position1;
		}
		else
		{
		    int byte0 = n & 0xFF;
		    int position0 = FIND_LAST_SET_BIT[byte0];
		    if (position0 >= 0)
		    {
			retval = position0;
		    }
		    else
		    {
			String msg =
			    "no allocated entry in allocation map item";
			throw new InternalErrorException(msg);
		    }
		}
	    }
	}

	return retval;
    }

    // Expand m_freeListNodes and m_allocationMap to at least
    // {requiredCapacity} elements.
    private void expandGroupArrays(int requiredCapacity)
    {
	if (DEBUG && m_freeListNodes.length != m_allocationMap.length)
	{
	    String msg = "lengths of freeListNodes[" + m_freeListNodes.length
		+ "] and allocationMap[" + m_allocationMap.length
		+ "] differ";
	    throw new InternalErrorException(msg);
	}

	int newLength = m_freeListNodes.length;
	while (newLength < requiredCapacity)
	{
	    newLength *= 2;
	}

	{
	    int[] oldFreeListNodes = m_freeListNodes;
	    m_freeListNodes = new int[newLength];
	    System.arraycopy(oldFreeListNodes, 0, m_freeListNodes, 0,
			     oldFreeListNodes.length);
	}

	{
	    int[] oldAllocationMap = m_allocationMap;
	    m_allocationMap = new int[newLength];
	    System.arraycopy(oldAllocationMap, 0, m_allocationMap, 0,
			     oldAllocationMap.length);
	}
    }

    private void validateNonnegativeIndex(int index)
    {
	if (index < 0)
	{
	    String msg = "index[" + index + "] must be nonnegative";
	    throw new IllegalArgumentException(msg);
	}
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE CONSTANTS
    ////////////////////////////////////////////////////////////////////////

    private static final boolean DEBUG = true;

    private static final int INITIAL_SIZE = 64;
    private static final int GROUP_SIZE = ALLOCATION_GROUP_SIZE;

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ////////////////////////////////////////////////////////////////////////

    private int  m_freeList = -1;
    private int[]  m_freeListNodes = new int[INITIAL_SIZE];
    private int[]  m_allocationMap = new int[INITIAL_SIZE];

    private boolean  m_logicalLengthCached = true;
    private int  m_logicalLength = 0;
    private int  m_numAllocatedGroups = 0;
    private int  m_numAllocatedSlots = 0;

    // The element at index i gives the value 2^i.
    private static final int[] POWER2_BIT =
    {
	0x00000001, 0x00000002, 0x00000004, 0x00000008,
	0x00000010, 0x00000020, 0x00000040, 0x00000080,
	0x00000100, 0x00000200, 0x00000400, 0x00000800,
	0x00001000, 0x00002000, 0x00004000, 0x00008000,
	0x00010000, 0x00020000, 0x00040000, 0x00080000,
	0x00100000, 0x00200000, 0x00400000, 0x00800000,
	0x01000000, 0x02000000, 0x04000000, 0x08000000,
	0x10000000, 0x20000000, 0x40000000, 0x80000000
    };

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS (Generated by class GenerateFirstBitTables)
    ////////////////////////////////////////////////////////////////////////

    // The element at index i gives the position of the lowest-positioned
    // cleared bit in the number i (the least-significant bit has position 0).
    private static final int[] FIND_FIRST_CLEARED_BIT = 
    {
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 6, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 7, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 6, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 
        0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, -1, 
    };

    // The element at index i gives the number i with the lowest-positioned
    // cleared bit in i flipped (the least-significant bit has position 0).
    private static final int[] SET_FIRST_CLEARED_BIT = 
    {
        1, 3, 3, 7, 5, 7, 7, 15, 
        9, 11, 11, 15, 13, 15, 15, 31, 
        17, 19, 19, 23, 21, 23, 23, 31, 
        25, 27, 27, 31, 29, 31, 31, 63, 
        33, 35, 35, 39, 37, 39, 39, 47, 
        41, 43, 43, 47, 45, 47, 47, 63, 
        49, 51, 51, 55, 53, 55, 55, 63, 
        57, 59, 59, 63, 61, 63, 63, 127, 
        65, 67, 67, 71, 69, 71, 71, 79, 
        73, 75, 75, 79, 77, 79, 79, 95, 
        81, 83, 83, 87, 85, 87, 87, 95, 
        89, 91, 91, 95, 93, 95, 95, 127, 
        97, 99, 99, 103, 101, 103, 103, 111, 
        105, 107, 107, 111, 109, 111, 111, 127, 
        113, 115, 115, 119, 117, 119, 119, 127, 
        121, 123, 123, 127, 125, 127, 127, 255, 
        129, 131, 131, 135, 133, 135, 135, 143, 
        137, 139, 139, 143, 141, 143, 143, 159, 
        145, 147, 147, 151, 149, 151, 151, 159, 
        153, 155, 155, 159, 157, 159, 159, 191, 
        161, 163, 163, 167, 165, 167, 167, 175, 
        169, 171, 171, 175, 173, 175, 175, 191, 
        177, 179, 179, 183, 181, 183, 183, 191, 
        185, 187, 187, 191, 189, 191, 191, 255, 
        193, 195, 195, 199, 197, 199, 199, 207, 
        201, 203, 203, 207, 205, 207, 207, 223, 
        209, 211, 211, 215, 213, 215, 215, 223, 
        217, 219, 219, 223, 221, 223, 223, 255, 
        225, 227, 227, 231, 229, 231, 231, 239, 
        233, 235, 235, 239, 237, 239, 239, 255, 
        241, 243, 243, 247, 245, 247, 247, 255, 
        249, 251, 251, 255, 253, 255, 255, 255
    };

    // The element at index i gives the position of the highest-positioned
    // set bit in the number i (the least-significant bit has position 0).
    private static final int[] FIND_LAST_SET_BIT = 
    {
        -1, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 
        4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
        5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
        5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
        7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
    };
}
