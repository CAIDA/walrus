// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

class SharedHeap
{
    public SharedHeap()
    {
	m_floatArray = new FloatArray();
	m_doubleArray = new DoubleArray();
	m_stringArray = new StringArray();
	m_float3Array = new Float3Array();
	m_double3Array = new Double3Array();
	m_objectArray = new ObjectArray();
    }

    public SharedHeap(int segmentSize)
    {
	m_floatArray = new FloatArray(segmentSize);
	m_doubleArray = new DoubleArray(segmentSize);
	m_stringArray = new StringArray(segmentSize);
	m_float3Array = new Float3Array(segmentSize);
	m_double3Array = new Double3Array(segmentSize);
	m_objectArray = new ObjectArray(segmentSize);
    }

    public FloatArray getFloatArray()
    {
	return m_floatArray;
    }

    public DoubleArray getDoubleArray()
    {
	return m_doubleArray;
    }

    public StringArray getStringArray()
    {
	return m_stringArray;
    }

    public Float3Array getFloat3Array()
    {
	return m_float3Array;
    }

    public Double3Array getDouble3Array()
    {
	return m_double3Array;
    }

    public ObjectArray getObjectArray()
    {
	return m_objectArray;
    }

    private FloatArray  m_floatArray;
    private DoubleArray  m_doubleArray;
    private StringArray  m_stringArray;
    private Float3Array  m_float3Array;
    private Double3Array  m_double3Array;
    private ObjectArray  m_objectArray;
}
