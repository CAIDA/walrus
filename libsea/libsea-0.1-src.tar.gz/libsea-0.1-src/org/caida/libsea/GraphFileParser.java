// $ANTLR 2.7.1: "file.g" -> "GraphFileParser.java"$

package org.caida.libsea;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.util.List;
import java.util.ArrayList;

public class GraphFileParser extends antlr.LLkParser
       implements GraphFileTokenTypes
 {

    public static void main(String[] args)
    {
        try
        {
            GraphFileLexer lexer =
                new GraphFileLexer(new java.io.DataInputStream(System.in));
            GraphFileParser parser = new GraphFileParser(lexer);
            parser.dumpTokens();
        }
        catch(Exception e)
        {
            System.err.println("ERROR: " + e);
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void addLink(Token token, int source, int destination)
        throws RecognitionException
    {
        int id = m_builder.addLink(source, destination);
        if (id != m_numLinksAdded)
        {
            String msg = makeCompleteLocationString(token)
                + "link ID[" + id + "] should have been " + m_numLinksAdded;
            throw new InternalErrorException(msg);
        }
        ++m_numLinksAdded;
    }

    /////////////////////////////////////////////////////////////////////////

    private void addPath(Token token)
        throws RecognitionException
    {
        int id = m_builder.addPath();
        if (id != m_numPathsAdded)
        {
            String msg = makeCompleteLocationString(token)
                + "path ID[" + id + "] should have been " + m_numPathsAdded;
            throw new InternalErrorException(msg);
        }
        ++m_numPathsAdded;
    }

    /////////////////////////////////////////////////////////////////////////

    private void addPathLink(Token token)
        throws RecognitionException, TokenStreamException
    {
        int link = parseNonnegativeInt(token, "path link");
        validateLinkID(token, link, "path link");
        m_builder.addPathLink(link);
    }

    /////////////////////////////////////////////////////////////////////////

    private EnumerationCreator addEnumeration(Token token, String name)
        throws RecognitionException
    {
        try
        {
	    EnumerationCreator retval = m_builder.addEnumeration(name);
            if (retval.getEnumerationID() != m_numEnumerationsAdded)
            {
                String msg = makeCompleteLocationString(token)
                    + "enumeration ID[" + retval.getEnumerationID()
                    + "] should have been " + m_numEnumerationsAdded;
                throw new InternalErrorException(msg);
            }
            ++m_numEnumerationsAdded;
            return retval;
        }
        catch (DuplicateObjectException e)
        {
            String msg = makeDuplicateObjectErrorString(token, "enumeration");
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void addEnumerator(Token token, String name, int value,
                               EnumerationCreator creator)
        throws RecognitionException
    {
        try
        {
	    int id = creator.addEnumerator(name, value);
            if (id != m_numEnumeratorsAdded)
            {
                String msg = makeCompleteLocationString(token)
                    + "enumerator ID[" + id + "] should have been "
	            + m_numEnumeratorsAdded;
                throw new InternalErrorException(msg);
            }
	    m_enumeratorOwner.add(new Integer(creator.getEnumerationID()));
            ++m_numEnumeratorsAdded;
        }
        catch (DuplicateObjectException e)
        {
            String msg = makeDuplicateObjectErrorString(token, "enumerator");
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void addAttributeDefinition
       (Token token, String name, ValueType type, int enumeration, String expr)
        throws RecognitionException
    {
        try
        {
            int id = m_builder.addAttributeDefinition
                (name, type, enumeration, expr);
            if (id != m_numAttributesAdded)
            {
                String msg = makeCompleteLocationString(token)
                    + "attribute definition ID[" + id
                    + "] should have been " + m_numAttributesAdded;
                throw new InternalErrorException(msg);
            }
            ++m_numAttributesAdded;
        }
        catch (DuplicateObjectException e)
        {
            String msg =
                makeDuplicateObjectErrorString(token, "attribute definition");
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private QualifierCreator addQualifier
        (Token token, String type, String name, String description)
        throws RecognitionException
    {
        try
        {
            return m_builder.addQualifier(type, name, description);
        }
        catch (DuplicateObjectException e)
        {
            String msg = makeDuplicateObjectErrorString(token, "qualifier");
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void addQualifierAttribute
        (Token token, int attribute, String alias, QualifierCreator creator)
        throws RecognitionException
    {
        try
        {
	    creator.associateAttribute(attribute, alias);
        }
        catch (DuplicateObjectException e)
        {
            String msg =
                makeDuplicateObjectErrorString(token, "qualifier attribute");
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void addFilter(Token token, String name, String expr)
        throws RecognitionException
    {
        int id = m_builder.addFilter(name, expr);
        if (id != m_numFiltersAdded)
        {
            String msg = makeCompleteLocationString(token) + "filter ID["
                + id + "] should have been " + m_numFiltersAdded;
            throw new InternalErrorException(msg);
        }
        ++m_numFiltersAdded;
    }

    /////////////////////////////////////////////////////////////////////////

    private SelectorCreator addSelector(Token token, String name)
        throws RecognitionException
    {
        SelectorCreator retval = m_builder.addSelector(name);
        if (retval.getSelectorID() != m_numSelectorsAdded)
        {
            String msg = makeCompleteLocationString(token)
                + "selector ID[" + retval.getSelectorID()
                + "] should have been " + m_numSelectorsAdded;
            throw new InternalErrorException(msg);
        }
        ++m_numSelectorsAdded;
        return retval;
    }

    /////////////////////////////////////////////////////////////////////////

    private void addSelectorMapping
        (Token token, String characteristic, int filter,
         boolean node, boolean link, boolean path, SelectorCreator creator)
        throws RecognitionException
    {
        try
        {
            creator.addSelectorMapping
                (characteristic, filter, node, link, path); 
        }
        catch (DuplicateObjectException e)
        {
            String msg =
                makeDuplicateObjectErrorString(token, "selector mapping");
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private DisplayCreator addDisplay(Token token, String name)
        throws RecognitionException
    {
        DisplayCreator retval = m_builder.addDisplay(name);
        if (retval.getDisplayID() != m_numDisplaysAdded)
        {
            String msg = makeCompleteLocationString(token)
                 + "display ID[" + retval.getDisplayID()
                 + "] should have been " + m_numDisplaysAdded;
            throw new InternalErrorException(msg);
        }
        ++m_numDisplaysAdded;
        return retval;
    }

    /////////////////////////////////////////////////////////////////////////

    private void addDisplayMapping
        (Token token, String characteristic, int attribute,
         boolean node, boolean link, boolean path, DisplayCreator creator)
        throws RecognitionException
    {
        try
        {
            creator.addDisplayMapping
                (characteristic, attribute, node, link, path); 
        }
        catch (DuplicateObjectException e)
        {
            String msg =
                makeDuplicateObjectErrorString(token, "display mapping");
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void addPresentation(Token token, String name,
                                 int display, int selector)
        throws RecognitionException
    {
        int id = m_builder.addPresentation(name, display, selector);
        if (id != m_numPresentationsAdded)
        {
            String msg = makeCompleteLocationString(token) + "presentation ID["
                + id + "] should have been " + m_numPresentationsAdded;
            throw new InternalErrorException(msg);
        }
        ++m_numPresentationsAdded;
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateNodeID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numNodes)
        {
            String msg = makePartialLocationString(token) + description
                + "[" + id + "] is outside the range of valid node IDs[<"
	        + m_numNodes + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateLinkID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numLinks)
        {
            String msg = makePartialLocationString(token) + description
                + "[" + id + "] is outside the range of valid link IDs[<"
	        + m_numLinks + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validatePathID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numPaths)
        {
            String msg = makePartialLocationString(token) + description
                + "[" + id + "] is outside the range of valid path IDs[<"
	        + m_numPaths + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateEnumerationID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numEnumerationsAdded)
        {
            String msg = makePartialLocationString(token) + description + "["
                + id + "] is outside the range of added enumeration IDs[<"
	        + m_numEnumerationsAdded + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateEnumeratorID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numEnumeratorsAdded)
        {
            String msg = makePartialLocationString(token) + description + "["
                + id + "] is outside the range of added enumerator IDs[<"
	        + m_numEnumeratorsAdded + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateAttributeID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numAttributesAdded)
        {
            String msg = makePartialLocationString(token) + description + "["
                + id + "] is outside the range of added attribute IDs[<"
	        + m_numAttributesAdded + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateFilterID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numFiltersAdded)
        {
            String msg = makePartialLocationString(token) + description
                + "[" + id + "] is outside the range of added filter IDs[<"
	        + m_numFiltersAdded + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateSelectorID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numSelectorsAdded)
        {
            String msg = makePartialLocationString(token) + description
                + "[" + id + "] is outside the range of added selector IDs[<"
	        + m_numSelectorsAdded + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validateDisplayID(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numDisplaysAdded)
        {
            String msg = makePartialLocationString(token) + description
                + "[" + id + "] is outside the range of added display IDs[<"
	        + m_numDisplaysAdded + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private void validatePresentationID
	(Token token, int id, String description)
        throws SemanticException
    {
        if (id >= m_numPresentationsAdded)
        {
            String msg = makePartialLocationString(token) + description + "["
                + id + "] is outside the range of added presentation IDs[<"
	        + m_numPresentationsAdded + "]";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private int parseNonnegativeInt(Token token, String description)
        throws SemanticException, TokenStreamException
    {
        int n = parseInt(token.getText());
        if (n < 0)
        {
            String msg = makePartialLocationString(token) + description
                + " must be nonnegative";
            throw new SemanticException(msg, getFilename(), token.getLine());
        }
        return n;
    }

    /////////////////////////////////////////////////////////////////////////

    private int parseInt(String s)
        throws TokenStreamException
    {
        try
        {
	    return Integer.parseInt(s);
        }
        catch (NumberFormatException e)
        {
	    String msg =
                "INTENAL ERROR: malformed integer literal \"" + s + "\"";
            throw new TokenStreamException(msg);
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private float parseFloat(String s)
        throws TokenStreamException
    {
        try
        {
	    return Float.parseFloat(s);
        }
        catch (NumberFormatException e)
        {
	    String msg =
                "INTERNAL ERROR: malformed float literal \"" + s + "\"";
            throw new TokenStreamException(msg);
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private double parseDouble(String s)
        throws TokenStreamException
    {
        try
        {
	    return Double.parseDouble(s);
        }
        catch (NumberFormatException e)
        {
	    String msg =
                "INTERNAL ERROR: malformed double literal \"" + s + "\"";
            throw new TokenStreamException(msg);
        }
    }

    /////////////////////////////////////////////////////////////////////////

    private String makeDuplicateObjectErrorString(Token token,
                                                  String description)
    {
        return makePartialLocationString(token)
            + "duplicate " + description + " name";
    }

    /////////////////////////////////////////////////////////////////////////

    private String makeCompleteLocationString(Token token)
    {
        return "line " + token.getLine()
            + ", column " + token.getColumn() + ": ";
    }

    /////////////////////////////////////////////////////////////////////////

    private String makePartialLocationString(Token token)
    {
        return "column " + token.getColumn() + ": ";
    }

    /////////////////////////////////////////////////////////////////////////

    private void initialize(GraphBuilder builder)
    {
        m_builder = builder;
        m_enumeratorOwner = new ArrayList();
        m_numEnumerationsAdded = 0;
        m_numEnumeratorsAdded = 0;
        m_numAttributesAdded = 0;
        m_numLinksAdded = 0;
        m_numPathsAdded = 0;
        m_numFiltersAdded = 0;	
        m_numSelectorsAdded = 0;
        m_numDisplaysAdded = 0;
        m_numPresentationsAdded = 0;
    }

    /////////////////////////////////////////////////////////////////////////

    private GraphBuilder  m_builder;
    private List  m_enumeratorOwner;

    private int  m_numNodes;
    private int  m_numLinks;
    private int  m_numPaths;
    private int  m_numPathLinks;

    private int  m_numEnumerationsAdded;
    private int  m_numEnumeratorsAdded;
    private int  m_numAttributesAdded;
    private int  m_numLinksAdded;
    private int  m_numPathsAdded;
    private int  m_numFiltersAdded;	
    private int  m_numSelectorsAdded;
    private int  m_numDisplaysAdded;
    private int  m_numPresentationsAdded;

    private MenuParser  m_presentationMenuParser =
        new MenuParser(new MenuIDValidator(MenuType.PRESENTATION),
                       new TopLevelMenuCreator(MenuType.PRESENTATION));

    private MenuParser  m_displayMenuParser =
        new MenuParser(new MenuIDValidator(MenuType.DISPLAY),
                       new TopLevelMenuCreator(MenuType.DISPLAY));

    private MenuParser  m_selectorMenuParser =
        new MenuParser(new MenuIDValidator(MenuType.SELECTOR),
                       new TopLevelMenuCreator(MenuType.SELECTOR));

    private MenuParser  m_filterMenuParser =
        new MenuParser(new MenuIDValidator(MenuType.FILTER),
                       new TopLevelMenuCreator(MenuType.FILTER));

    private MenuParser  m_attributeMenuParser =
        new MenuParser(new MenuIDValidator(MenuType.ATTRIBUTE),
                       new TopLevelMenuCreator(MenuType.ATTRIBUTE));

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE INNER CLASSES
    ///////////////////////////////////////////////////////////////////////

    private class TypeHolder
    {
        public ValueType type;
        public int enumeration;
    }

    /////////////////////////////////////////////////////////////////////////

    private class Attribute
        implements ValueConsumer
    {
        public Attribute(ValueType type, int enumeration)
        {
            m_valueType = type;
            m_enumeration = enumeration;
        }

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

        public void targetNodes()
        {
            m_objectType = ObjectType.NODE;
        }

        public void targetLinks()
        {
            m_objectType = ObjectType.LINK;
        }

        public void targetPaths()
        {
            m_objectType = ObjectType.PATH;
        }

        public ValueConsumer addValue(Token token, int id)
            throws RecognitionException
        {
            reset();
            validateObjectID(token, id);
            m_creator = m_builder.addObjectAttribute(m_objectType, id);
            return this;
        }

        ////////////////////////////////////////////////////////////////////
        // PUBLIC METHODS (interface ValueConsumer)
        ////////////////////////////////////////////////////////////////////

        public void addBooleanValue(Token token, boolean value)
            throws RecognitionException
        {
            validateValueType(token, ValueType.BOOLEAN);
	    m_creator.addBooleanValue(value);
            ++m_numValuesAdded;
        }

        public void addIntegerValue(Token token, int value)
            throws RecognitionException
        {
            validateValueType(token, ValueType.INTEGER);
	    m_creator.addIntegerValue(value);
            ++m_numValuesAdded;
        }

        public void addFloatValue(Token token, float value)
            throws RecognitionException
        {
            validateValueType(token, ValueType.FLOAT);
	    m_creator.addFloatValue(value);
            ++m_numValuesAdded;
        }

        public void addDoubleValue(Token token, double value)
            throws RecognitionException
        {
            validateValueType(token, ValueType.DOUBLE);
	    m_creator.addDoubleValue(value);
            ++m_numValuesAdded;
        }

        public void addStringValue(Token token, String value)
            throws RecognitionException
        {
            validateValueType(token, ValueType.STRING);
	    m_creator.addStringValue(value);
            ++m_numValuesAdded;
        }

        public void addFloat3Value(Token token, float x, float y, float z)
            throws RecognitionException
        {
            validateValueType(token, ValueType.FLOAT3);
	    m_creator.addFloat3Value(x, y, z);
            ++m_numValuesAdded;
        }

        public void addDouble3Value(Token token, double x, double y, double z)
            throws RecognitionException
        {
            validateValueType(token, ValueType.DOUBLE3);
	    m_creator.addDouble3Value(x, y, z);
            ++m_numValuesAdded;
        }

	public void addEnumerationValue(Token token, int enumerator)
            throws RecognitionException
        {
            validateValueType(token, ValueType.ENUMERATION);
            validateEnumeratorOwnership(token, enumerator);
	    m_creator.addEnumerationValue(enumerator);
            ++m_numValuesAdded;
        }

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

        private void validateValueType(Token token, ValueType seenType)
            throws SemanticException
        {
            if (seenType.getBaseType() != m_valueType.getBaseType())
            {
                String msg = makePartialLocationString(token)
                    + "wrong type of value for attribute: need "
                    + mapValueTypeToName(m_valueType) + " value";
                throw new SemanticException
                    (msg, getFilename(), token.getLine());
            }

            if (m_numValuesAdded > 0 && m_valueType.isBaseType())
            {
                String msg = makePartialLocationString(token)
                    + "wrong type of value for attribute: "
                    + "supplied a list of values for a scalar attribute";
                throw new SemanticException
                    (msg, getFilename(), token.getLine());
            }
        }

        private String mapValueTypeToName(ValueType type)
        {
            switch (m_valueType.getBaseType())
            {
            case ValueType._BOOLEAN: return "boolean";
            case ValueType._INTEGER: return "integer";
            case ValueType._FLOAT: return "float";
            case ValueType._DOUBLE: return "double";
            case ValueType._STRING: return "string";
            case ValueType._FLOAT3: return "float3";
            case ValueType._DOUBLE3: return "double3";
            case ValueType._ENUMERATION: return "enumeration";
            default: throw new InternalErrorException();
            }
        }

        private void validateObjectID(Token token, int id)
            throws SemanticException
        {
            switch (m_objectType.getType())
            {
            case ObjectType._NODE: validateNodeID(token, id, "node"); break;
            case ObjectType._LINK: validateLinkID(token, id, "link"); break;
            case ObjectType._PATH: validatePathID(token, id, "path"); break;
            default: throw new InternalErrorException();
            }
        }

        private void validateEnumeratorOwnership(Token token, int id)
            throws SemanticException
        {
            Integer integer = (Integer)m_enumeratorOwner.get(id);
            if (integer == null)
            {
                String msg = makeCompleteLocationString(token) +
                    "no ownership info found for " + "enumerator[" + id + "]";
                throw new InternalErrorException(msg);
            }
            int owner = integer.intValue();
            if (owner != m_enumeration)
            {
                String msg = makePartialLocationString(token) +
                    "enumerator[" + id + "] does not belong "
                    + "to the enumeration[" + m_enumeration
                    + "] of the current attribute";
                throw new SemanticException
                    (msg, getFilename(), token.getLine());
            }
        }

        private void reset()
        {
            m_creator = null;
            m_numValuesAdded = 0;
        }

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

        private ValueType  m_valueType;
        private int  m_enumeration;

        private ObjectType  m_objectType;

        private AttributeCreator  m_creator;
        private int  m_numValuesAdded;
    }

    /////////////////////////////////////////////////////////////////////////

    private class MenuIDValidator
        implements MenuType
    {
        public MenuIDValidator(int type)
        {
            m_type = type;
        }

        public void validateID(Token token, int id)
            throws RecognitionException
        {
            if (id >= 0)
            {
                switch (m_type)
                {
                case PRESENTATION:
                    validatePresentationID
                        (token, id, "presentation menu item");
                    break;
    
                case DISPLAY:
                    validateDisplayID(token, id, "display menu item");
                    break;
    
                case SELECTOR:
                    validateSelectorID(token, id, "selector menu item");
                    break;
    
                case FILTER:
                    validateFilterID(token, id, "filter menu item");
                    break;
    
                case ATTRIBUTE:
                    validateAttributeID(token, id, "attribute menu item");
                    break;
    
                default:
                    {
                        String msg = "invalid m_type[" + m_type + "]";
                        throw new InternalErrorException(msg);
                    }
                }
            }    
        }

        private int  m_type;
    }

    /////////////////////////////////////////////////////////////////////////

    private class TopLevelMenuCreator
        implements MenuType, MenuCreator
    {
        public TopLevelMenuCreator(int type)
        {
            m_type = type;
        }

        public MenuCreator addSubmenu(String label, int id)
        {
            switch (m_type)
            {
            case PRESENTATION:
                return m_builder.addPresentationSubmenu(label, id);

            case DISPLAY:
                return m_builder.addDisplaySubmenu(label, id);

            case SELECTOR:
                return m_builder.addSelectorSubmenu(label, id);

            case FILTER:
                return m_builder.addFilterSubmenu(label, id);

            case ATTRIBUTE:
                return m_builder.addAttributeSubmenu(label, id);

            default:
                {
                    String msg = "invalid m_type[" + m_type + "]";
                    throw new InternalErrorException(msg);
                }
            }
        }

        private int  m_type;
    }

    /////////////////////////////////////////////////////////////////////////

    private class MenuParser
    {
        public MenuParser(MenuIDValidator validator, MenuCreator creator)
        {
            m_validator = validator;
            m_creator = creator;
        }

        public MenuParser addSubmenu(Token token, String label, int id)
            throws RecognitionException
        {
            m_validator.validateID(token, id);
            MenuCreator submenuCreator = m_creator.addSubmenu(label, id);
            return new MenuParser(m_validator, submenuCreator);
        }

        private MenuIDValidator  m_validator;
        private MenuCreator  m_creator;
    }

    /////////////////////////////////////////////////////////////////////////

    private interface ValueConsumer
    {
        void addBooleanValue(Token token, boolean value)
            throws RecognitionException;
        void addIntegerValue(Token token, int value)
            throws RecognitionException;
        void addFloatValue(Token token, float value)
            throws RecognitionException;
        void addDoubleValue(Token token, double value)
            throws RecognitionException;
        void addStringValue(Token token, String value)
            throws RecognitionException;
        void addFloat3Value(Token token, float x, float y, float z)
            throws RecognitionException;
        void addDouble3Value(Token token, double x, double y, double z)
            throws RecognitionException;
        void addEnumerationValue(Token token, int enumerator)
            throws RecognitionException;
    }

    /////////////////////////////////////////////////////////////////////////

    private interface MenuType
    {
        int  PRESENTATION = 0;
        int  DISPLAY = 1;
        int  SELECTOR = 2;
        int  FILTER = 3;
        int  ATTRIBUTE = 4;
    }

protected GraphFileParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public GraphFileParser(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected GraphFileParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public GraphFileParser(TokenStream lexer) {
  this(lexer,1);
}

public GraphFileParser(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void file(
		GraphBuilder builder
	) throws RecognitionException, TokenStreamException {
		
		
		initialize(builder);
		
		
		graph();
		match(Token.EOF_TYPE);
	}
	
	public final void graph() throws RecognitionException, TokenStreamException {
		
		Token  name = null;
		Token  desc = null;
		Token  nn = null;
		Token  nl = null;
		Token  np = null;
		Token  npl = null;
		
		match(GRAPH_KEYWORD);
		match(LCURLY);
		{
		switch ( LA(1)) {
		case STRING:
		{
			name = LT(1);
			match(STRING);
			m_builder.setGraphName(name.getText());
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case STRING:
		{
			desc = LT(1);
			match(STRING);
			m_builder.setGraphDescription(desc.getText());
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		nn = LT(1);
		match(INT);
		match(SEMI);
		m_numNodes = parseNonnegativeInt(nn, "# nodes");
		m_builder.allocateNodes(m_numNodes);
		nl = LT(1);
		match(INT);
		match(SEMI);
		m_numLinks = parseNonnegativeInt(nl, "# links");
		m_builder.allocateLinks(m_numLinks);
		np = LT(1);
		match(INT);
		match(SEMI);
		m_numPaths = parseNonnegativeInt(np, "# paths");
		m_builder.allocatePaths(m_numPaths);
		npl = LT(1);
		match(INT);
		match(SEMI);
		m_numPathLinks = parseNonnegativeInt(npl, "# path links");
		m_builder.allocatePathLinks(m_numPathLinks);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			linkList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			pathList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			enumDefList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			attrDefList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			qualifierList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			filterList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			selectorList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			displayList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			presentationList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			menuList(m_presentationMenuParser);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			menuList(m_displayMenuParser);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			menuList(m_selectorMenuParser);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			menuList(m_filterMenuParser);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			menuList(m_attributeMenuParser);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final void linkList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			link();
			{
			_loop22:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					link();
				}
				else {
					break _loop22;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void pathList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			path();
			{
			_loop27:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					path();
				}
				else {
					break _loop27;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void enumDefList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			enumDef();
			{
			_loop37:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					enumDef();
				}
				else {
					break _loop37;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void attrDefList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			attrDef();
			{
			_loop48:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					attrDef();
				}
				else {
					break _loop48;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void qualifierList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			qualifier();
			{
			_loop67:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					qualifier();
				}
				else {
					break _loop67;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void filterList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			filter();
			{
			_loop79:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					filter();
				}
				else {
					break _loop79;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void selectorList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			selector();
			{
			_loop84:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					selector();
				}
				else {
					break _loop84;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void displayList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			display();
			{
			_loop95:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					display();
				}
				else {
					break _loop95;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void presentationList() throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			presentation();
			{
			_loop106:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					presentation();
				}
				else {
					break _loop106;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void menuList(
		MenuParser parser
	) throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			menu(parser);
			{
			_loop112:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					menu(parser);
				}
				else {
					break _loop112;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void link() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  src = null;
		Token  dest = null;
		
		start = LT(1);
		match(LCURLY);
		src = LT(1);
		match(INT);
		match(SEMI);
		dest = LT(1);
		match(INT);
		match(SEMI);
		match(RCURLY);
		
		int source = parseNonnegativeInt(src, "link source");
		int destination = parseNonnegativeInt(dest, "link destination");
		validateNodeID(src, source, "link source");
		validateNodeID(dest, destination, "link destination");
		addLink(start, source, destination);
		
	}
	
	public final void path() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		
		start = LT(1);
		match(LCURLY);
		addPath(start);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			pathLinkList();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final void pathLinkList() throws RecognitionException, TokenStreamException {
		
		Token  first = null;
		Token  rest = null;
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case INT:
		{
			first = LT(1);
			match(INT);
			addPathLink(first);
			{
			_loop33:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					rest = LT(1);
					match(INT);
					addPathLink(rest);
				}
				else {
					break _loop33;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void enumDef() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  name = null;
		
		EnumerationCreator creator = null;
		
		
		start = LT(1);
		match(LCURLY);
		name = LT(1);
		match(IDENT);
		match(SEMI);
		creator = addEnumeration(start, name.getText());
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			enumeratorList(creator);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final void enumeratorList(
		EnumerationCreator creator
	) throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			enumerator(creator);
			{
			_loop43:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					enumerator(creator);
				}
				else {
					break _loop43;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void enumerator(
		EnumerationCreator creator
	) throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  name = null;
		Token  value = null;
		
		start = LT(1);
		match(LCURLY);
		name = LT(1);
		match(IDENT);
		match(SEMI);
		value = LT(1);
		match(INT);
		match(SEMI);
		match(RCURLY);
		addEnumerator(start, name.getText(),
		parseInt(value.getText()), creator);
	}
	
	public final void attrDef() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  n = null;
		
		TypeHolder holder = null;
		String expr = null;
		Attribute attribute = null;
		
		
		start = LT(1);
		match(LCURLY);
		n = LT(1);
		match(IDENT);
		match(SEMI);
		holder=attrType();
		match(SEMI);
		{
		switch ( LA(1)) {
		case CODE:
		{
			expr=attrDefValue();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		
		String name = n.getText();
		ValueType type = holder.type;
		int enumeration = holder.enumeration;
		addAttributeDefinition(start, name, type, enumeration, expr);
		attribute = new Attribute(holder.type, holder.enumeration);
		
		attribute.targetNodes();
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			objectAttrList(attribute);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		attribute.targetLinks();
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			objectAttrList(attribute);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		attribute.targetPaths();
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			objectAttrList(attribute);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final TypeHolder  attrType() throws RecognitionException, TokenStreamException {
		TypeHolder holder;
		
		
		boolean isList = false;
		
		
		{
		switch ( LA(1)) {
		case LIST_KEYWORD:
		{
			match(LIST_KEYWORD);
			isList = true;
			break;
		}
		case BOOL_KEYWORD:
		case INT_KEYWORD:
		case FLOAT_KEYWORD:
		case DOUBLE_KEYWORD:
		case STRING_KEYWORD:
		case FLOAT3_KEYWORD:
		case DOUBLE3_KEYWORD:
		case ENUM_KEYWORD:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		holder=baseType(isList);
		return holder;
	}
	
	public final String  attrDefValue() throws RecognitionException, TokenStreamException {
		String expr;
		
		Token  c = null;
		
		c = LT(1);
		match(CODE);
		expr = c.getText();
		return expr;
	}
	
	public final void objectAttrList(
		Attribute attribute
	) throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			objectAttr(attribute);
			{
			_loop62:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					objectAttr(attribute);
				}
				else {
					break _loop62;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final TypeHolder  baseType(
		boolean isList
	) throws RecognitionException, TokenStreamException {
		TypeHolder holder;
		
		Token  n = null;
		
		holder = new TypeHolder();
		holder.enumeration = -1;
		
		
		{
		switch ( LA(1)) {
		case BOOL_KEYWORD:
		{
			match(BOOL_KEYWORD);
			holder.type =
			(isList ? ValueType.BOOLEAN_LIST : ValueType.BOOLEAN );
			break;
		}
		case INT_KEYWORD:
		{
			match(INT_KEYWORD);
			holder.type =
			(isList ? ValueType.INTEGER_LIST : ValueType.INTEGER );
			break;
		}
		case FLOAT_KEYWORD:
		{
			match(FLOAT_KEYWORD);
			holder.type =
			(isList ? ValueType.FLOAT_LIST : ValueType.FLOAT );
			break;
		}
		case DOUBLE_KEYWORD:
		{
			match(DOUBLE_KEYWORD);
			holder.type =
			(isList ? ValueType.DOUBLE_LIST : ValueType.DOUBLE );
			break;
		}
		case STRING_KEYWORD:
		{
			match(STRING_KEYWORD);
			holder.type =
			(isList ? ValueType.STRING_LIST : ValueType.STRING );
			break;
		}
		case FLOAT3_KEYWORD:
		{
			match(FLOAT3_KEYWORD);
			holder.type =
			(isList ? ValueType.FLOAT3_LIST : ValueType.FLOAT3 );
			break;
		}
		case DOUBLE3_KEYWORD:
		{
			match(DOUBLE3_KEYWORD);
			holder.type =
			(isList ? ValueType.DOUBLE3_LIST : ValueType.DOUBLE3 );
			break;
		}
		case ENUM_KEYWORD:
		{
			match(ENUM_KEYWORD);
			n = LT(1);
			match(INT);
			
			int id = parseNonnegativeInt(n, "enumeration ID");
			validateEnumerationID(n, id, "enumeration type");
			holder.enumeration = id;
			holder.type = (isList ? ValueType.ENUMERATION_LIST
			: ValueType.ENUMERATION );
			
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		return holder;
	}
	
	public final void objectAttr(
		Attribute attribute
	) throws RecognitionException, TokenStreamException {
		
		Token  n = null;
		
		ValueConsumer consumer = null;
		
		
		match(LCURLY);
		n = LT(1);
		match(INT);
		match(SEMI);
		
		int id = parseNonnegativeInt(n, "object ID");
		consumer = attribute.addValue(n, id);
		
		value(consumer);
		match(SEMI);
		match(RCURLY);
	}
	
	public final void value(
		ValueConsumer consumer
	) throws RecognitionException, TokenStreamException {
		
		
		switch ( LA(1)) {
		case TRUE_KEYWORD:
		case FALSE_KEYWORD:
		case ENUM_KEYWORD:
		case INT:
		case FLOAT:
		case DOUBLE:
		case LCURLY:
		case STRING:
		{
			scalarValue(consumer);
			break;
		}
		case LBRACKET:
		{
			listValue(consumer);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
	}
	
	public final void qualifier() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  type = null;
		Token  name = null;
		Token  desc = null;
		
		QualifierCreator creator = null;
		String description = null;
		
		
		start = LT(1);
		match(LCURLY);
		type = LT(1);
		match(IDENT);
		match(SEMI);
		name = LT(1);
		match(IDENT);
		match(SEMI);
		{
		switch ( LA(1)) {
		case STRING:
		{
			desc = LT(1);
			match(STRING);
			description = desc.getText();
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		creator = addQualifier
		(start, type.getText(), name.getText(), description);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			qualifierAttrList(creator);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final void qualifierAttrList(
		QualifierCreator creator
	) throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			qualifierAttr(creator);
			{
			_loop74:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					qualifierAttr(creator);
				}
				else {
					break _loop74;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void qualifierAttr(
		QualifierCreator creator
	) throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  n = null;
		Token  id = null;
		
		start = LT(1);
		match(LCURLY);
		n = LT(1);
		match(INT);
		match(SEMI);
		id = LT(1);
		match(IDENT);
		match(SEMI);
		match(RCURLY);
		
		int attribute = parseNonnegativeInt(n, "qualifier attribute");
		validateAttributeID(n, attribute, "qualifier attribute");
		String alias = id.getText();
		addQualifierAttribute(start, attribute, alias, creator);
		
	}
	
	public final void filter() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  name = null;
		Token  expr = null;
		
		start = LT(1);
		match(LCURLY);
		name = LT(1);
		match(STRING);
		match(SEMI);
		expr = LT(1);
		match(CODE);
		match(SEMI);
		match(RCURLY);
		addFilter(start, name.getText(), expr.getText());
	}
	
	public final void selector() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  n = null;
		
		SelectorCreator creator = null;
		
		
		start = LT(1);
		match(LCURLY);
		n = LT(1);
		match(STRING);
		match(SEMI);
		creator = addSelector(start, n.getText());
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			selectorMappingList(creator);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final void selectorMappingList(
		SelectorCreator creator
	) throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			selectorMapping(creator);
			{
			_loop90:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					selectorMapping(creator);
				}
				else {
					break _loop90;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void selectorMapping(
		SelectorCreator creator
	) throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  f = null;
		Token  c = null;
		
		boolean node = false;
		boolean link = false;
		boolean path = false;
		
		
		start = LT(1);
		match(LCURLY);
		f = LT(1);
		match(INT);
		match(SEMI);
		c = LT(1);
		match(STRING);
		match(SEMI);
		node=booleanValue();
		match(SEMI);
		link=booleanValue();
		match(SEMI);
		path=booleanValue();
		match(SEMI);
		match(RCURLY);
		
		int filter = parseNonnegativeInt(f, "filter ID");
		validateFilterID(f, filter, "selector filter");
		addSelectorMapping(start, c.getText(), filter,
		node, link, path, creator);
		
	}
	
	public final boolean  booleanValue() throws RecognitionException, TokenStreamException {
		boolean value;
		
		
		switch ( LA(1)) {
		case FALSE_KEYWORD:
		{
			match(FALSE_KEYWORD);
			value = false;
			break;
		}
		case TRUE_KEYWORD:
		{
			match(TRUE_KEYWORD);
			value = true;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		return value;
	}
	
	public final void display() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  n = null;
		
		DisplayCreator creator = null;
		
		
		start = LT(1);
		match(LCURLY);
		n = LT(1);
		match(STRING);
		match(SEMI);
		creator = addDisplay(start, n.getText());
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			displayMappingList(creator);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final void displayMappingList(
		DisplayCreator creator
	) throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case LCURLY:
		{
			displayMapping(creator);
			{
			_loop101:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					displayMapping(creator);
				}
				else {
					break _loop101;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void displayMapping(
		DisplayCreator creator
	) throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  a = null;
		Token  c = null;
		
		boolean node = false;
		boolean link = false;
		boolean path = false;
		
		
		start = LT(1);
		match(LCURLY);
		a = LT(1);
		match(INT);
		match(SEMI);
		c = LT(1);
		match(STRING);
		match(SEMI);
		node=booleanValue();
		match(SEMI);
		link=booleanValue();
		match(SEMI);
		path=booleanValue();
		match(SEMI);
		match(RCURLY);
		
		int attribute = parseNonnegativeInt(a, "attribute ID");
		validateAttributeID(a, attribute, "display attribute");
		addDisplayMapping(start, c.getText(), attribute,
		node, link, path, creator);
		
	}
	
	public final void presentation() throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  n = null;
		Token  d = null;
		Token  s = null;
		
		int selector = -1;
		
		
		start = LT(1);
		match(LCURLY);
		n = LT(1);
		match(STRING);
		match(SEMI);
		d = LT(1);
		match(INT);
		match(SEMI);
		{
		switch ( LA(1)) {
		case INT:
		{
			s = LT(1);
			match(INT);
			
			selector = parseNonnegativeInt(s, "selector ID");
			validateSelectorID(s, selector, "presentation selector");
			
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
		
		int display = parseNonnegativeInt(d, "display ID");
		validateDisplayID(d, display, "presentation display");
		addPresentation(start, n.getText(), display, selector);
		
	}
	
	public final void menu(
		MenuParser parser
	) throws RecognitionException, TokenStreamException {
		
		Token  start = null;
		Token  l = null;
		Token  n = null;
		
		MenuParser submenuParser = null;
		int id = -1;
		
		
		start = LT(1);
		match(LCURLY);
		l = LT(1);
		match(STRING);
		match(SEMI);
		{
		switch ( LA(1)) {
		case INT:
		{
			n = LT(1);
			match(INT);
			id = parseNonnegativeInt(n, "menu item");
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		submenuParser = parser.addSubmenu(start, l.getText(), id);
		{
		switch ( LA(1)) {
		case LBRACKET:
		{
			menuList(submenuParser);
			break;
		}
		case SEMI:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(SEMI);
		match(RCURLY);
	}
	
	public final void scalarValue(
		ValueConsumer consumer
	) throws RecognitionException, TokenStreamException {
		
		Token  vbf = null;
		Token  vbt = null;
		Token  vi = null;
		Token  vf = null;
		Token  vd = null;
		Token  vs = null;
		Token  ve = null;
		Token  vei = null;
		
		switch ( LA(1)) {
		case FALSE_KEYWORD:
		{
			vbf = LT(1);
			match(FALSE_KEYWORD);
			consumer.addBooleanValue(vbf, false);
			break;
		}
		case TRUE_KEYWORD:
		{
			vbt = LT(1);
			match(TRUE_KEYWORD);
			consumer.addBooleanValue(vbt, true);
			break;
		}
		case INT:
		{
			vi = LT(1);
			match(INT);
			consumer.addIntegerValue(vi, parseInt(vi.getText()));
			break;
		}
		case FLOAT:
		{
			vf = LT(1);
			match(FLOAT);
			consumer.addFloatValue(vf, parseFloat(vf.getText()));
			break;
		}
		case DOUBLE:
		{
			vd = LT(1);
			match(DOUBLE);
			consumer.addDoubleValue(vd, parseDouble(vd.getText()));
			break;
		}
		case STRING:
		{
			vs = LT(1);
			match(STRING);
			consumer.addStringValue(vs, vs.getText());
			break;
		}
		case ENUM_KEYWORD:
		{
			ve = LT(1);
			match(ENUM_KEYWORD);
			vei = LT(1);
			match(INT);
			consumer.addEnumerationValue(ve, parseInt(vei.getText()));
			break;
		}
		case LCURLY:
		{
			compositeValue(consumer);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
	}
	
	public final void listValue(
		ValueConsumer consumer
	) throws RecognitionException, TokenStreamException {
		
		
		match(LBRACKET);
		{
		switch ( LA(1)) {
		case TRUE_KEYWORD:
		case FALSE_KEYWORD:
		case ENUM_KEYWORD:
		case INT:
		case FLOAT:
		case DOUBLE:
		case LCURLY:
		case STRING:
		{
			scalarValue(consumer);
			{
			_loop120:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					scalarValue(consumer);
				}
				else {
					break _loop120;
				}
				
			} while (true);
			}
			break;
		}
		case RBRACKET:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RBRACKET);
	}
	
	public final void compositeValue(
		ValueConsumer consumer
	) throws RecognitionException, TokenStreamException {
		
		
		match(LCURLY);
		{
		switch ( LA(1)) {
		case FLOAT:
		{
			float3(consumer);
			break;
		}
		case DOUBLE:
		{
			double3(consumer);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RCURLY);
	}
	
	public final void float3(
		ValueConsumer consumer
	) throws RecognitionException, TokenStreamException {
		
		Token  f1 = null;
		Token  f2 = null;
		Token  f3 = null;
		
		f1 = LT(1);
		match(FLOAT);
		match(SEMI);
		f2 = LT(1);
		match(FLOAT);
		match(SEMI);
		f3 = LT(1);
		match(FLOAT);
		match(SEMI);
		
		float x = parseFloat(f1.getText());
		float y = parseFloat(f2.getText());
		float z = parseFloat(f3.getText());
		consumer.addFloat3Value(f1, x, y, z);
		
	}
	
	public final void double3(
		ValueConsumer consumer
	) throws RecognitionException, TokenStreamException {
		
		Token  d1 = null;
		Token  d2 = null;
		Token  d3 = null;
		
		d1 = LT(1);
		match(DOUBLE);
		match(SEMI);
		d2 = LT(1);
		match(DOUBLE);
		match(SEMI);
		d3 = LT(1);
		match(DOUBLE);
		match(SEMI);
		
		double x = parseDouble(d1.getText());
		double y = parseDouble(d2.getText());
		double z = parseDouble(d3.getText());
		consumer.addDouble3Value(d1, x, y, z);
		
	}
	
	public final void dumpTokens() throws RecognitionException, TokenStreamException {
		
		Token  tok = null;
		
		{
		_loop129:
		do {
			if (((LA(1) >= GRAPH_KEYWORD && LA(1) <= WS))) {
				tok = LT(1);
				matchNot(EOF);
				System.out.println(tok.toString());
			}
			else {
				break _loop129;
			}
			
		} while (true);
		}
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"Graph\"",
		"\"T\"",
		"\"F\"",
		"\"bool\"",
		"\"int\"",
		"\"float\"",
		"\"double\"",
		"\"string\"",
		"\"float3\"",
		"\"double3\"",
		"\"enum\"",
		"\"list\"",
		"INT",
		"FLOAT",
		"DOUBLE",
		"'{'",
		"a string",
		"';'",
		"'}'",
		"'['",
		"','",
		"']'",
		"an identifier",
		"code string",
		"ESCAPE",
		"KEYWORD",
		"NUMBER",
		"EXP",
		"ID",
		"LETTER",
		"DIGIT",
		"SHARP_COMMENT",
		"AT_COMMENT",
		"WHITESPACE",
		"WS"
	};
	
	
	}
