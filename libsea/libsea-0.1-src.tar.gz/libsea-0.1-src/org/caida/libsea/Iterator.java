// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

/**
 * A minimal interface for traversing a list, possibly multiple times, in a
 * forward direction.
 *
 * <p>
 * The underlying iteration model of this interface differs slightly from
 * that of <code>java.util.Iterator</code>.  For instance, in the latter,
 * advancing the cursor and getting the next value are both implemented by
 * the single method <code>next</code>.  In this interface, however, the two
 * functionalities are separated.  The method for advancing the cursor is
 * provided by <code>advance</code>, and it is expected that derived
 * interfaces will provide method(s) for retrieving the value at the current
 * position.
 * </p>
 *
 * <p>
 * There is another important difference to keep in mind.  In this interface,
 * a newly returned iterator will automatically be positioned at the first
 * element, assuming a non-empty list, and hence, a user may immediately
 * access that first element with any get- or set-methods without needing to
 * first call <code>advance</code>.
 * </p>
 *
 * <p>
 * The user can perform a traversal using a loop of the following form, which
 * works in all cases, even for an empty list:
 * <pre>
 *     Iterator iterator = ...;
 *     while (!iterator.atEnd())
 *     {
 *        processCurrentElement(iterator);
 *        iterator.advance();
 *     }
 * </pre>
 * </p>
 */
public interface Iterator
{
    /**
     * Indicates whether this iterator is positioned just past the last
     * element, if any.
     *
     * @return whether this iterator is positioned just past the last element.
     *      This condition is always true for an empty list.
     */
    boolean  atEnd();

    /**
     * Advances this iterator to the next unseen element, if there is one,
     * or to the position just past the last element.
     *
     * This does nothing if this iterator is already position past the last
     * element.
     */
    void     advance();

    /**
     * Repositions this iterator to the first element, if there is one.
     */
    void     rewind();
}
