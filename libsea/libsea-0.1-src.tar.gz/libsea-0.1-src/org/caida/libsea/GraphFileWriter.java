// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Date;
import java.text.DateFormat;
import java.util.Arrays;

public class GraphFileWriter
{
    ///////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ///////////////////////////////////////////////////////////////////////

    public GraphFileWriter(Writer writer, Graph graph,
			   boolean isVerbose, boolean includeHeader)
    {
	m_writer = new PrintWriter(writer);
	m_graph = graph;
	m_isVerbose = isVerbose;
	m_includeHeader = includeHeader;

	allocateMappers();
	populateNodeMapper();
    }

    ///////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ///////////////////////////////////////////////////////////////////////

    public void write()
	throws IOException
    {
	if (m_includeHeader)
	{
	    writeHeader();
	}
	writeGraph();
	m_writer.flush();
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ///////////////////////////////////////////////////////////////////////

    private void writeHeader()
    {
	DateFormat dateFormat =
	    DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);
	p("### ");
	p(dateFormat.format(new Date()));
	pln(" ###");
	pln();
    }

    private void writeGraph()
    {
	pln("Graph");
	pln("{");
	indent();
	{
	    pln("### metadata ###");
	    vp("@name="); psopt(m_graph.getName()); sln();
	    vp("@description="); psopt(m_graph.getDescription()); sln();
	    vp("@numNodes="); p(m_graph.getNumNodes()); sln();
	    vp("@numLinks="); p(m_graph.getNumLinks()); sln();
	    vp("@numPaths="); p(m_graph.getNumPaths()); sln();
	    vp("@numPathLinks="); p(m_graph.getNumPathLinks()); sln();

	    pln();
	    pln("### structural data ###");
	    vp("@links="); writeLinkList(); sln();
	    vp("@paths="); writePathList(); sln();

	    pln();
	    pln("### attribute data ###");
	    vp("@enumerations="); writeEnumerationList(); sln();
	    vp("@attributeDefinitions="); writeAttributeDefinitionList();sln();
	    vp("@qualifiers="); writeQualifierList(); sln();

	    pln();
	    pln("### visualization hints ###");
	    vp("@filters="); writeFilterList(); sln();
	    vp("@selectors="); writeSelectorList(); sln();
	    vp("@displays="); writeDisplayList(); sln();
	    vp("@presentations="); writePresentationList(); sln();

	    pln();
	    pln("### interface hints ###");
	    vp("@presentationMenus="); writePresentationMenuList(); sln();
	    vp("@displayMenus="); writeDisplayMenuList(); sln();
	    vp("@selectorMenus="); writeSelectorMenuList(); sln();
	    vp("@filterMenus="); writeFilterMenuList(); sln();
	    vp("@attributeMenus="); writeAttributeMenuList(); sln();
	}	
	unindent();
	pln("}");
    }

    private void writeLinkList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_linkMapper.addMapping(m_iterator.getObjectID());

		    p("{ ");
		    int source = m_iterator.getSource();
		    vp("@source="); p(m_nodeMapper.map(source)); s();
		    int destination = m_iterator.getDestination();
		    vp("@destination="); p(m_nodeMapper.map(destination)); s();
		    p("}");
		}

		private LinkIterator m_iterator = m_graph.getLinks();
	    }.write();
    }

    private void writePathList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_pathMapper.addMapping(m_iterator.getObjectID());

		    p("{ ");
		    vp("@pathLinks=");
		    writePathLinkList(m_iterator.getLinks()); s();
		    p("}");
		}

		private PathIterator m_iterator = m_graph.getPaths();
	    }.write();
    }

    private void writePathLinkList(final LinkIterator iterator)
    {
	new SingleLineListWriter() {
		protected boolean atEnd()
		{
		    return iterator.atEnd();
		}

		protected void advance()
		{
		    iterator.advance();
		}

		protected void writeElement()
		{
		    p(m_linkMapper.map(iterator.getObjectID()));
		}
	    }.write();
    }

    private void writeEnumerationList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_enumerationMapper.addMapping(m_iterator.getID());

		    pln("{");
		    indent();
		    {
			vp("@name="); pi(m_iterator.getName()); sln();
			vp("@enumerators=");
			writeEnumeratorList(m_iterator.getEnumerators());
			sln();
		    }
		    unindent();
		    p("}");
		}

		private EnumerationIterator m_iterator =
		    m_graph.getEnumerations();
	    }.write();
    }

    private void writeEnumeratorList(final EnumeratorIterator iterator)
    {
	new SingleLineListWriter() {
		protected boolean atEnd()
		{
		    return iterator.atEnd();
		}

		protected void advance()
		{
		    iterator.advance();
		}

		protected void writeElement()
		{
		    m_enumeratorMapper.addMapping(iterator.getID());

		    p("{ ");
		    vp("@name="); pi(iterator.getName()); s();
		    vp("@value="); p(iterator.getValue()); s();
		    p("}");
		}
	    }.write();
    }

    private void writeAttributeDefinitionList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_attributeMapper.addMapping(m_iterator.getID());

		    ValueType type = m_iterator.getType();
		    int enumeration = -1;
		    if (type.isEnumerationType())
		    {
			enumeration = m_enumerationMapper.map
			    (m_iterator.getEnumeration());
		    }

		    pln("{");
		    indent();
		    {
			vp("@name="); pi(m_iterator.getName()); sln();
			vp("@type="); writeType(type, enumeration); sln();
			vp("@default="); pcopt(m_iterator.getDefault()); sln();
			vp("@nodeValues=");
			writeAttributeList(m_nodeMapper,
					   m_iterator.getNodeAttributes());
			sln();
			vp("@linkValues=");
			writeAttributeList(m_linkMapper,
					   m_iterator.getLinkAttributes());
			sln();
			vp("@pathValues=");
			writeAttributeList(m_pathMapper,
					   m_iterator.getPathAttributes());
			sln();
		    }
		    unindent();
		    p("}");
		}

		private AttributeDefinitionIterator m_iterator =
		    m_graph.getAttributeDefinitions();
	    }.write();
    }

    private void writeAttributeList
	(final Mapper mapper, final AttributesByAttributeIterator iterator)
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return iterator.atEnd();
		}

		protected void advance()
		{
		    iterator.advance();
		}

		protected void writeElement()
		{
		    p("{ ");
		    vp("@id="); p(mapper.map(iterator.getObjectID())); s();
		    vp("@value=");
		    writeAttributeValue(iterator.getAttributeValues()); s();
		    p("}");
		}
	    }.write();
    }

    private void writeAttributeValue(final ValueIterator iterator)
    {
	if (iterator.getType().isListType())
	{
	    new SingleLineListWriter() {
		    protected boolean isDisplayRequired()
		    {
			return true;
		    }

		    protected boolean atEnd()
		    {
			return iterator.atEnd();
		    }

		    protected void advance()
		    {
			iterator.advance();
		    }

		    protected void writeElement()
		    {
			writeValue(iterator);
		    }
		}.write();
	}
	else
	{
	    if (iterator.atEnd())
	    {
		String msg = "missing non-list attribute value";
		throw new InternalErrorException(msg);
	    }
	    writeValue(iterator);
	}
    }

    private void writeValue(ValueIterator iterator)
    {
	switch (iterator.getType().getBaseType())
	{
	case ValueType._BOOLEAN: p(iterator.getBooleanValue()); break;
	case ValueType._INTEGER: p(iterator.getIntegerValue()); break;
	case ValueType._FLOAT: p(iterator.getFloatValue()); p("f"); break;
	case ValueType._DOUBLE: p(iterator.getDoubleValue()); break;
	case ValueType._STRING: ps(iterator.getStringValue()); break;

	case ValueType._FLOAT3:
	    iterator.getFloat3Value(m_float3Temporary);
	    p("{ ");
	    p(m_float3Temporary[0]); p("f; ");
	    p(m_float3Temporary[1]); p("f; ");
	    p(m_float3Temporary[2]); p("f; ");
	    p("}");
	    break;

	case ValueType._DOUBLE3:
	    iterator.getDouble3Value(m_double3Temporary);
	    p("{ ");
	    p(m_double3Temporary[0]); p("; ");
	    p(m_double3Temporary[1]); p("; ");
	    p(m_double3Temporary[2]); p("; ");
	    p("}");
	    break;

	case ValueType._ENUMERATION:
            p("enum ");
	    p(m_enumeratorMapper.map(iterator.getEnumerationValue()));
	    break;

	default: throw new InternalErrorException();
	}
    }

    private void writeQualifierList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    pln("{");
		    indent();
		    {
			vp("@type="); pi(m_iterator.getType()); sln();
			vp("@name="); pi(m_iterator.getName()); sln();
			String description = m_iterator.getDescription();
			vp("@description="); psopt(description); sln();
			vp("@attributes=");
			writeQualifierAttributeList
			    (m_iterator.getAttributes());
			sln();
		    }
		    unindent();
		    p("}");
		}

		private QualifierIterator m_iterator = m_graph.getQualifiers();
	    }.write();
    }

    private void writeQualifierAttributeList
	(final QualifierAttributeIterator iterator)
    {
	new SingleLineListWriter() {
		protected boolean atEnd()
		{
		    return iterator.atEnd();
		}

		protected void advance()
		{
		    iterator.advance();
		}

		protected void writeElement()
		{
		    p("{ ");
		    vp("@attribute=");
		    p(m_attributeMapper.map(iterator.getAttributeID())); s();
		    vp("@alias="); pi(iterator.getName()); s();
		    p("}");
		}
	    }.write();
    }

    private void writeFilterList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_filterMapper.addMapping(m_iterator.getID());

		    p("{ ");
		    vp("@name="); ps(m_iterator.getName()); s();
		    vp("@expr="); pcode(m_iterator.getExpression()); s();
		    p("}");
		}

		private FilterIterator m_iterator = m_graph.getFilters();
	    }.write();
    }

    private void writeSelectorList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_selectorMapper.addMapping(m_iterator.getID());

		    pln("{");
		    indent();
		    {
			vp("@name="); ps(m_iterator.getName()); sln();
			vp("@mappings=");
			writeSelectorMappingList
			    (m_iterator.getSelectorMappings());
			sln();
		    }
		    unindent();
		    p("}");
		}

		private SelectorIterator m_iterator = m_graph.getSelectors();
	    }.write();
    }

    private void writeSelectorMappingList
	(final SelectorMappingIterator iterator)
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return iterator.atEnd();
		}

		protected void advance()
		{
		    iterator.advance();
		}

		protected void writeElement()
		{
		    p("{ ");
		    int filter = iterator.getFilterID();
		    vp("@filter="); p(m_filterMapper.map(filter)); s();
		    vp("@characteristic=");
		    ps(iterator.getDisplayCharacteristic()); s();
		    vp("@node="); p(iterator.checkNodeInTarget()); s();
		    vp("@link="); p(iterator.checkLinkInTarget()); s();
		    vp("@path="); p(iterator.checkPathInTarget()); s();
		    p("}");
		}
	    }.write();
    }

    private void writeDisplayList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_displayMapper.addMapping(m_iterator.getID());

		    pln("{");
		    indent();
		    {
			vp("@name="); ps(m_iterator.getName()); sln();
			vp("@mappings=");
			writeDisplayMappingList
			    (m_iterator.getDisplayMappings());
			sln();
		    }
		    unindent();
		    p("}");
		}

		private DisplayIterator m_iterator = m_graph.getDisplays();
	    }.write();
    }

    private void writeDisplayMappingList(final DisplayMappingIterator iterator)
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return iterator.atEnd();
		}

		protected void advance()
		{
		    iterator.advance();
		}

		protected void writeElement()
		{
		    p("{ ");
		    int attribute = iterator.getAttributeID();
		    vp("@attribute="); p(m_attributeMapper.map(attribute));s();
		    vp("@characteristic=");
		    ps(iterator.getDisplayCharacteristic()); s();
		    vp("@node="); p(iterator.checkNodeInTarget()); s();
		    vp("@link="); p(iterator.checkLinkInTarget()); s();
		    vp("@path="); p(iterator.checkPathInTarget()); s();
		    p("}");
		}
	    }.write();
    }

    private void writePresentationList()
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return m_iterator.atEnd();
		}

		protected void advance()
		{
		    m_iterator.advance();
		}

		protected void writeElement()
		{
		    m_presentationMapper.addMapping(m_iterator.getID());

		    p("{ ");
		    vp("@name="); ps(m_iterator.getName()); s();
		    int display = m_iterator.getDisplayID();
		    vp("@display="); p(m_displayMapper.map(display)); s();
		    int selector = m_iterator.getSelectorID();		    
		    vp("@selector="); p(m_selectorMapper.map(selector)); s();
		    p("}");
		}

		private PresentationIterator m_iterator =
		    m_graph.getPresentations();
	    }.write();
    }

    private void writePresentationMenuList()
    {
	writeMenuList(m_presentationMapper,
			      m_graph.getPresentationMenu());
    }

    private void writeDisplayMenuList()
    {
	writeMenuList(m_displayMapper, m_graph.getDisplayMenu());
    }

    private void writeSelectorMenuList()
    {
	writeMenuList(m_selectorMapper, m_graph.getSelectorMenu());
    }

    private void writeFilterMenuList()
    {
	writeMenuList(m_filterMapper, m_graph.getFilterMenu());
    }

    private void writeAttributeMenuList()
    {
	writeMenuList(m_attributeMapper, m_graph.getAttributeMenu());
    }

    private void writeMenuList(final Mapper mapper,
			       final MenuIterator iterator)
    {
	new MultiLineListWriter() {
		protected boolean atEnd()
		{
		    return iterator.atEnd();
		}

		protected void advance()
		{
		    iterator.advance();
		}

		protected void writeElement()
		{
		    writeMenu(mapper, iterator);
		}
	    }.write();
    }

    private void writeMenu(final Mapper mapper, final MenuIterator iterator)
    {
	pln("{");
	indent();
	{
	    vp("@label="); ps(iterator.getLabel()); sln();
	    vp("@id=");
	    int id = iterator.getID();
	    if (id >= 0)
	    {
		p(mapper.map(id));
	    }
	    sln();
	    vp("@submenus=");
	    writeMenuList(mapper, iterator.getSubmenus());
	    sln();
	}
	unindent();
	p("}");
    }

    private void writeType(ValueType type, int enumeration)
    {
	if (type.isListType())
	{
	    p("list ");
	}

	switch (type.getBaseType())
	{
	case ValueType._BOOLEAN: p("bool"); break;
	case ValueType._INTEGER: p("int"); break;
	case ValueType._FLOAT: p("float"); break;
	case ValueType._DOUBLE: p("double"); break;
	case ValueType._STRING: p("string"); break;
	case ValueType._FLOAT3: p("float3"); break;
	case ValueType._DOUBLE3: p("double3"); break;
	case ValueType._ENUMERATION: p("enum "); p(enumeration); break;
	default: throw new InternalErrorException();
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS (formatting)
    ///////////////////////////////////////////////////////////////////////

    private void pi(String s)
    {
	p("$");
	p(s);
    }

    private void psopt(String s)
    {
	printIndentation();
	if (s != null && s.length() > 0)
	{
	    ps(s);
	}
    }

    private void pcopt(String s)
    {
	printIndentation();
	if (s != null && s.length() > 0)
	{
	    pcode(s);
	}
    }

    private void ps(String s)
    {
	printIndentation();
	m_writer.print('"');
	for (int i = 0; i < s.length(); i++)
	{
	    char c = s.charAt(i);
	    if (c == '\\')
	    {
		m_writer.print("\\\\");
	    }
	    else if (c == '"')
	    {
		m_writer.print("\\\"");
	    }
	    else if (c == '\n')
	    {
		m_writer.print("\\n");
	    }
	    else if (c == '\r')
	    {
		m_writer.print("\\r");
	    }
	    else if (c == '\t')
	    {
		m_writer.print("\\t");
	    }
	    else if (c == '\f')
	    {
		m_writer.print("\\f");
	    }
	    else if (c == '\b')
	    {
		m_writer.print("\\b");
	    }
	    else
	    {
		m_writer.print(c);
	    }
	}
	m_writer.print('"');
    }

    private void pcode(String s)
    {
	printIndentation();
	m_writer.print("||");
	for (int i = 0; i < s.length(); i++)
	{
	    char c = s.charAt(i);
	    if (c == '\\')
	    {
		m_writer.print("\\\\");
	    }
	    else if (c == '|')
	    {
		m_writer.print("\\|");
	    }
	    else if (c == '\n')
	    {
		m_writer.print("\\n");
	    }
	    else if (c == '\r')
	    {
		m_writer.print("\\r");
	    }
	    else if (c == '\t')
	    {
		m_writer.print("\\t");
	    }
	    else if (c == '\f')
	    {
		m_writer.print("\\f");
	    }
	    else if (c == '\b')
	    {
		m_writer.print("\\b");
	    }
	    else
	    {
		m_writer.print(c);
	    }
	}
	m_writer.print("||");
    }

    private void p(boolean value)
    {
	printIndentation();
	m_writer.print(value ? "T" : "F");
    }

    private void p(int n)
    {
	printIndentation();
	m_writer.print(n);
    }

    private void p(float n)
    {
	printIndentation();
	m_writer.print(n);
    }

    private void p(double n)
    {
	printIndentation();
	m_writer.print(n);
    }

    private void p(String s)
    {
	printIndentation();
	m_writer.print(s);
    }

    private void pln(boolean value)
    {
	printIndentation();
	m_writer.println(value ? "T" : "F");
    }

    private void pln(int n)
    {
	printIndentation();
	m_writer.println(n);
    }

    private void pln(float n)
    {
	printIndentation();
	m_writer.println(n);
    }

    private void pln(double n)
    {
	printIndentation();
	m_writer.println(n);
    }

    private void pln(String s)
    {
	printIndentation();
	m_writer.println(s);
	m_atLineStart = true;
    }

    private void pln()
    {
	m_writer.println();
	m_atLineStart = true;
    }

    private void vp(String s)
    {
	if (m_isVerbose)
	{
	    p(s);
	}
    }

    private void vpln(String s)
    {
	if (m_isVerbose)
	{
	    pln(s);
	}
    }

    private void vpln()
    {
	if (m_isVerbose)
	{
	    pln();
	}
    }

    private void s()
    {
	printIndentation();
	m_writer.print("; ");
    }

    private void sln()
    {
	printIndentation();
	m_writer.println(";");
	m_atLineStart = true;
    }

    private void indent()
    {
	++m_indentation;
    }

    private void unindent()
    {
	if (m_indentation == 0)
	{
	    String msg = "unmatched unindent(): indentation already zero";
	    throw new InternalErrorException(msg);
	}
	--m_indentation;
    }

    private void printIndentation()
    {
	if (m_atLineStart)
	{
	    m_atLineStart = false;
	    for (int i = 0; i < m_indentation; i++)
	    {
		m_writer.print(m_isVerbose ? "   " : " ");
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS (ID mapping)
    ///////////////////////////////////////////////////////////////////////

    private void populateNodeMapper()
    {
	NodeIterator iterator = m_graph.getNodes();
	while (!iterator.atEnd())
	{
	    m_nodeMapper.addMapping(iterator.getObjectID());
	    iterator.advance();
	}
    }

    private void allocateMappers()
    {
	m_nodeMapper = new Mapper("node", m_graph.getNodeIDRange());
	m_linkMapper = new Mapper("link", m_graph.getLinkIDRange());
	m_pathMapper = new Mapper("path", m_graph.getPathIDRange());
	m_enumerationMapper =
	    new Mapper("enumeration", m_graph.getEnumerationIDRange());
	m_enumeratorMapper =
	    new Mapper("enumerator", m_graph.getEnumeratorIDRange());
	m_attributeMapper =
	    new Mapper("attribute", m_graph.getAttributeIDRange());
	m_presentationMapper =
	    new Mapper("presentation", m_graph.getPresentationIDRange());
	m_displayMapper = new Mapper("display", m_graph.getDisplayIDRange());
	m_selectorMapper =new Mapper("selector", m_graph.getSelectorIDRange());
	m_filterMapper = new Mapper("filter", m_graph.getFilterIDRange());
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    private PrintWriter  m_writer;
    private Graph  m_graph;
    private boolean  m_isVerbose;
    private boolean  m_includeHeader;

    private int  m_indentation;
    private boolean  m_atLineStart = true;

    private Mapper  m_nodeMapper;
    private Mapper  m_linkMapper;
    private Mapper  m_pathMapper;
    private Mapper  m_enumerationMapper;
    private Mapper  m_enumeratorMapper;
    private Mapper  m_attributeMapper;
    private Mapper  m_presentationMapper;
    private Mapper  m_displayMapper;
    private Mapper  m_selectorMapper;
    private Mapper  m_filterMapper;

    private float[]  m_float3Temporary = new float[3];
    private double[]  m_double3Temporary = new double[3];

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE CLASSES
    ///////////////////////////////////////////////////////////////////////

    private static class Mapper
    {
	public Mapper(String name, int range)
	{
	    m_name = name;
	    m_range = range;
	}

	public int map(int id)
	{
	    validateID(id);

	    int retval = -1;
	    if (id < m_identityRange)
	    {
		retval = id;
	    }
	    else
	    {
		retval = m_map[id - m_identityRange];
		if (retval < 0)
		{
		    String msg = "mapping for " + m_name + " id[" + id
			+ "] not found";
		    throw new IllegalArgumentException(msg);
		}
	    }
	    return retval;
	}

	public void addMapping(int id)
	{
	    validateID(id);

	    if (id < m_identityRange)
	    {
		signalDuplicateMapping(id);
	    }
	    else
	    {
		if (m_isIdentity)
		{
		    if (id == m_identityRange)
		    {
			++m_identityRange;
		    }
		    else
		    {
			m_isIdentity = false;
			m_map = new int[m_range - m_identityRange];
			Arrays.fill(m_map, -1);

			m_map[id - m_identityRange] = m_sequenceNum;
		    }
		}
		else
		{
		    if (m_map[id - m_identityRange] >= 0)
		    {
			signalDuplicateMapping(id);
		    }
		    m_map[id - m_identityRange] = m_sequenceNum;
		}
		++m_sequenceNum;
	    }
	}

	private void signalDuplicateMapping(int id)
	{
	    String msg =
		"mapping for " + m_name + " id[" + id + "] already exists";
	    throw new IllegalArgumentException(msg);
	}

	private void validateID(int id)
	{
	    if (id < 0)
	    {
		String msg = "id[" + id + "] must be nonnegative";
		throw new IllegalArgumentException(msg);
	    }

	    if (id >= m_range)
	    {
		String msg = m_name + " id must be less than " + m_range;
		throw new IllegalArgumentException(msg);
	    }
	}

	private String  m_name;
	private int  m_range;
	private int[]  m_map;

	private boolean  m_isIdentity = true;
	private int  m_identityRange;
	private int  m_sequenceNum;
    }

    ///////////////////////////////////////////////////////////////////////

    private abstract class ListWriter
    {
	public void write()
	{
	    if (atEnd())
	    {
		if (isDisplayRequired())
		{
		    writeEmptyOpening();
		    writeEmptyClosing();
		}
	    }
	    else
	    {
		writeOpening();
		{
		    writeElement();
		    advance();
		    while (!atEnd())
		    {
			writeElementSeparator();
			writeElement();
			advance();
		    }
		}
		writeClosing();
	    }
	}

	protected boolean isDisplayRequired()
	{
	    return false;
	}

	protected void writeEmptyOpening()
	{
	    p("[");
	}

	protected void writeEmptyClosing()
	{
	    p("]");
	}

	protected abstract void writeOpening();
	protected abstract void writeClosing();
	protected abstract void writeElementSeparator();

	protected abstract boolean atEnd();
	protected abstract void advance();
	protected abstract void writeElement();
    }

    ///////////////////////////////////////////////////////////////////////

    private abstract class MultiLineListWriter
	extends ListWriter
    {
	protected void writeOpening()
	{
	    pln("[");
	    indent();
	}

	protected void writeClosing()
	{
	    unindent();
	    pln();  // Move to new line after writing last element.
	    p("]");
	}

	protected void writeElementSeparator()
	{
	    pln(",");
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private abstract class SingleLineListWriter
	extends ListWriter
    {
	protected void writeOpening()
	{
	    p("[ "); 
	}

	protected void writeClosing()
	{
	    p(" ]");
	}

	protected void writeElementSeparator()
	{
	    p(", ");
	}
    }
}


