// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.BitSet;

class IntArray
{
    ////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ////////////////////////////////////////////////////////////////////////

    public IntArray()
    {
	this(DEFAULT_SEGMENT_SIZE);
    }

    // {segmentSize} must be a power of 2.
    public IntArray(int segmentSize)
    {
	if (segmentSize <= 0)
	{
	    throw new IllegalArgumentException("segmentSize must be positive");
	}

	if (segmentSize < MIN_SEGMENT_SIZE)
	{
	    segmentSize = MIN_SEGMENT_SIZE;
	}

	if ((segmentSize & -segmentSize) != segmentSize)
	{
	    throw new IllegalArgumentException("segmentSize must be a power of 2");
        }

	m_segmentSize = segmentSize;
	m_segmentMask = segmentSize - 1;
	m_segmentSizeBits = MiscMath.log2(m_segmentSize);

	m_allocationMap = new BitSet(m_segmentSize);
    }

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ////////////////////////////////////////////////////////////////////////

    public boolean isEmpty()
    {
	return getNumAllocated() == 0;
    }

    public int getValue(int index)
    {
	validateNonnegativeIndex(index);
	if (!m_allocationMap.get(index))
	{
	    throw new UnallocatedElementException();
	}

	return getValueUnchecked(index);
    }

    public void setValue(int index, int value)
    {
	validateNonnegativeIndex(index);
	if (!m_allocationMap.get(index))
	{
	    throw new UnallocatedElementException();
	}

	setValueUnchecked(index, value);
    }

    public boolean checkAllocated(int index)
    {
	validateNonnegativeIndex(index);
	return m_allocationMap.get(index);
    }

    public void free(int index)
    {
	validateNonnegativeIndex(index);
	if (m_allocationMap.get(index))
	{
	    m_allocationMap.clear(index);
	    setValueUnchecked(index, m_freeList);
	    m_freeList = index;
	    --m_numAllocatedSlots;

	    if (index == m_logicalLength - 1)
	    {
		m_logicalLengthCached = false;
	    }
	}
	else
	{
	    if (DEBUG)
	    {
		System.err.println("WARNING: IntArray.free(" + index
				   + "): index already free");
	    }
	}
    }

    public int allocate()
    {
	int retval = -1;

	if (m_freeList != -1)
	{
	    retval = m_freeList;
	    m_freeList = getValueUnchecked(m_freeList);
	}
	else
	{
	    if (m_numAllocatedSegments == m_segments.length)
	    {
		expandSegmentsArray();
	    }

	    retval = m_numAllocatedSegments << m_segmentSizeBits;
	    int[] segment = createInitializedSegment(retval);
	    m_segments[m_numAllocatedSegments++] = segment;
	    m_freeList = retval + 1;
	}

	if (DEBUG && m_allocationMap.get(retval))
	{
	    System.err.println("INTERNAL ERROR: IntArray.allocate() => "
			       + retval + ": index already allocated.");
	    System.exit(0);
	}

	m_allocationMap.set(retval);
	++m_numAllocatedSlots;

	if (retval >= m_logicalLength)
	{
	    m_logicalLengthCached = true;
	    m_logicalLength = retval + 1;
	}

	return retval;
    }

    public void clear()
    {
	m_freeList = -1;
	m_allocationMap = new BitSet(m_segmentSize);
	m_numAllocatedSegments = 0;
	m_segments = new int[STARTING_NUM_SEGMENTS][];
	m_logicalLengthCached = true;
	m_logicalLength = 0;
	m_numAllocatedSlots = 0;
    }

    public int getLogicalLength()
    {
	if (!m_logicalLengthCached)
	{
	    updateLogicalLength();
	}
	return m_logicalLength;
    }

    public int getNumAllocated()
    {
	return m_numAllocatedSlots;
    }

    public int getNumFree()
    {
	return m_numAllocatedSegments * m_segmentSize - m_numAllocatedSlots;
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ////////////////////////////////////////////////////////////////////////

    private void updateLogicalLength()
    {
	m_logicalLengthCached = true;

	int i = m_logicalLength - 1;
	while (i >= 0 && !m_allocationMap.get(i))
	{
	    --i;
	}
	m_logicalLength = (i >= 0 ? i : 0);
    }

    private int getValueUnchecked(int index)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = index & m_segmentMask;

	return m_segments[segment][offset];
    }

    private void setValueUnchecked(int index, int value)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = index & m_segmentMask;

	m_segments[segment][offset] = value;
    }

    private void expandSegmentsArray()
    {
	int[][] oldSegments = m_segments;
	m_segments = new int[oldSegments.length * 2][];
	System.arraycopy(oldSegments, 0, m_segments, 0, oldSegments.length);
    }

    private int[] createInitializedSegment(int startingIndex)
    {
	int[] retval = new int[m_segmentSize];
	for (int i = 0; i < m_segmentSize - 1; i++)
	{
	    retval[i] = startingIndex + i + 1;
	}
	retval[m_segmentSize - 1] = -1;

	return retval;
    }

    private void validateNonnegativeIndex(int index)
    {
	if (index < 0)
	{
	    String msg = "index[" + index + "] must be nonnegative";
	    throw new IllegalArgumentException(msg);
	}
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE CONSTANTS
    ////////////////////////////////////////////////////////////////////////

    private static final boolean DEBUG = true;

    private static final int STARTING_NUM_SEGMENTS = 512;
    private static final int DEFAULT_SEGMENT_SIZE = 1024;
    private static final int MIN_SEGMENT_SIZE = 128;

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ////////////////////////////////////////////////////////////////////////

    private int  m_freeList = -1;

    // A set bit indicates an allocated element.
    private BitSet  m_allocationMap;  

    private int  m_numAllocatedSegments = 0;
    private int[][]  m_segments = new int[STARTING_NUM_SEGMENTS][];
    private final int  m_segmentSize;
    private final int  m_segmentMask;
    private final int  m_segmentSizeBits;

    private boolean  m_logicalLengthCached = true;
    private int  m_logicalLength = 0;
    private int  m_numAllocatedSlots = 0;
}
