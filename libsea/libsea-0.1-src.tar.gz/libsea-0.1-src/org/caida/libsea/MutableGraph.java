// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.Observer;

class MutableGraph
    extends CommonGraph
{
    /////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    /////////////////////////////////////////////////////////////////////////

    public MutableGraph(SharedHeap heap, OptimizationType type)
    {
	super(heap, type);
    }

    /////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    /////////////////////////////////////////////////////////////////////////

    public GraphBuilder beginConstruction()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    /////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS (Interface Graph)
    /////////////////////////////////////////////////////////////////////////

    public int getNumOutgoingLinks(int node)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getNumIncomingLinks(int node)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getNumPathLinks(int path)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public NodeIterator getNodes()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public LinkIterator getLinks()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public PathIterator getPaths()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public NodeIterator getNode(int node)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public LinkIterator getLink(int link)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public PathIterator getPath(int path)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public AttributeDefinitionIterator getAttributeDefinitions()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public AttributeDefinitionIterator getAttributeDefinition(int attribute)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public AttributeDefinitionIterator getAttributeDefinition(String name)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getNodeIDRange()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getLinkIDRange()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getPathIDRange()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getAttributeIDRange()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }    

    public ValueIterator getNodeAttribute(int node, int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public ValueIterator getLinkAttribute(int link, int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public ValueIterator getPathAttribute(int path, int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public boolean getBooleanAttribute(ObjectType type, int object,
				       int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getIntegerAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public float getFloatAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public double getDoubleAttribute(ObjectType type, int object,
				     int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public String getStringAttribute(ObjectType type, int object,
				     int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public float[] getFloat3Attribute(ObjectType type, int object,
				      int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void getFloat3Attribute(ObjectType type, int object, int attribute,
				   float[] values)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public double[] getDouble3Attribute(ObjectType type, int object,
					int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void getDouble3Attribute(ObjectType type, int object, int attribute,
				    double[] values)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getEnumerationAttribute(ObjectType type, int object,
				       int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getEvaluatedEnumerationAttribute(ObjectType type, int object,
				       int attribute)
	throws AttributeUnavailableException
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setBooleanAttribute(ObjectType type, int object, int attribute,
				    boolean value)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setIntegerAttribute(ObjectType type, int object, int attribute,
				    int value)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setFloatAttribute(ObjectType type, int object, int attribute,
				  float value)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setDoubleAttribute(ObjectType type, int object, int attribute,
				   double value)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setStringAttribute(ObjectType type, int object, int attribute,
				   String value)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setFloat3Attribute(ObjectType type, int object, int attribute,
				   float x, float y, float z)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setFloat3Attribute(ObjectType type, int object, int attribute,
				   float[] values)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setDouble3Attribute(ObjectType type, int object, int attribute,
				    double x, double y, double z)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setDouble3Attribute(ObjectType type, int object, int attribute,
				    double[] values)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setEnumerationAttribute(ObjectType type, int object,
					int attribute, String enumerator)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setEnumerationAttribute(ObjectType type, int object,
					int attribute, int enumerator)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeNodes()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeLinks()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removePaths()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeNode(int node)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeLink(int link)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removePath(int path)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeAttributeDefinitions()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeMutableAttributeDefinitions()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeAttributeDefinition(int attribute)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void removeAttributeDefinition(String name)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED METHODS
    ///////////////////////////////////////////////////////////////////////

    protected void validateAttributeExistence(int attribute)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    protected String findAttributeName(int attribute)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    protected int findAttributeID(String name)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    protected void addAttributeRemovalObserver(int attribute,
					       Observer observer)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    protected void removeAttributeRemovalObserver(int attribute,
						  Observer observer)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ///////////////////////////////////////////////////////////////////////


    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////


    ///////////////////////////////////////////////////////////////////////
    // PRIVATE INNER CLASSES
    ///////////////////////////////////////////////////////////////////////
}
