// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

public final class ValueType
{
    private static final int  LIST_TYPE_FLAG = 0x80000000;

    public static final int _BOOLEAN = 0;
    public static final int _INTEGER = 1;
    public static final int _FLOAT = 2;
    public static final int _DOUBLE = 3;
    public static final int _STRING = 4;
    public static final int _FLOAT3 = 5;
    public static final int _DOUBLE3 = 6;
    public static final int _ENUMERATION = 7;

    public static final int _BOOLEAN_LIST = _BOOLEAN | LIST_TYPE_FLAG;
    public static final int _INTEGER_LIST = _INTEGER | LIST_TYPE_FLAG;
    public static final int _FLOAT_LIST = _FLOAT | LIST_TYPE_FLAG;
    public static final int _DOUBLE_LIST = _DOUBLE | LIST_TYPE_FLAG;
    public static final int _STRING_LIST = _STRING | LIST_TYPE_FLAG;
    public static final int _FLOAT3_LIST = _FLOAT3 | LIST_TYPE_FLAG;
    public static final int _DOUBLE3_LIST = _DOUBLE3 | LIST_TYPE_FLAG;
    public static final int _ENUMERATION_LIST = _ENUMERATION | LIST_TYPE_FLAG;

    public static final ValueType BOOLEAN = new ValueType(_BOOLEAN);
    public static final ValueType INTEGER = new ValueType(_INTEGER);
    public static final ValueType FLOAT = new ValueType(_FLOAT);
    public static final ValueType DOUBLE = new ValueType(_DOUBLE);
    public static final ValueType STRING = new ValueType(_STRING);
    public static final ValueType FLOAT3 = new ValueType(_FLOAT3);
    public static final ValueType DOUBLE3 = new ValueType(_DOUBLE3);
    public static final ValueType ENUMERATION = new ValueType(_ENUMERATION);

    public static final ValueType BOOLEAN_LIST = new ValueType(_BOOLEAN_LIST);
    public static final ValueType INTEGER_LIST = new ValueType(_INTEGER_LIST);
    public static final ValueType FLOAT_LIST = new ValueType(_FLOAT_LIST);
    public static final ValueType DOUBLE_LIST = new ValueType(_DOUBLE_LIST);
    public static final ValueType STRING_LIST = new ValueType(_STRING_LIST);
    public static final ValueType FLOAT3_LIST = new ValueType(_FLOAT3_LIST);
    public static final ValueType DOUBLE3_LIST = new ValueType(_DOUBLE3_LIST);
    public static final ValueType ENUMERATION_LIST =
	new ValueType(_ENUMERATION_LIST);

    public int getType()
    {
	return m_type;
    }

    public int getBaseType()
    {
	return m_baseType;
    }

    public String getName()
    {
	if (m_isListType)
	{
	    return m_listTypeNames[m_baseType];
	}
	else
	{
	    return m_baseTypeNames[m_baseType];
	}
    }

    public String getBaseName()
    {
	return m_baseTypeNames[m_baseType];
    }

    public boolean isBaseType()
    {
	return !m_isListType;
    }

    public boolean isListType()
    {
	return m_isListType;
    }

    public boolean isEnumerationType()
    {
	return m_baseType == _ENUMERATION;
    }

    private ValueType(int type)
    {
	m_type = type;
	m_baseType = m_type & BASE_TYPE_MASK;
	m_isListType = (m_type & LIST_TYPE_FLAG) == LIST_TYPE_FLAG;
    }

    private static final int  BASE_TYPE_MASK = 0x7FFFFFFF;

    private final int  m_type;
    private final int  m_baseType;
    private final boolean  m_isListType;

    private static final String[]  m_baseTypeNames = 
    {
	"BOOLEAN", "INTEGER", "FLOAT", "DOUBLE", "STRING", "FLOAT3", "DOUBLE3",
	"ENUMERATION"
    };

    private static final String[]  m_listTypeNames = 
    {
	"BOOLEAN_LIST", "INTEGER_LIST", "FLOAT_LIST", "DOUBLE_LIST",
	"STRING_LIST", "FLOAT3_LIST", "DOUBLE3_LIST", "ENUMERATION_LIST"
    };
}
