// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

class GrowableDouble3Array
{
    ////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ////////////////////////////////////////////////////////////////////////

    public GrowableDouble3Array()
    {
	this(DEFAULT_SEGMENT_SIZE);
    }

    // {segmentSize} must be a power of 2.
    public GrowableDouble3Array(int segmentSize)
    {
	if (segmentSize < MIN_SEGMENT_SIZE)
	{
	    segmentSize = MIN_SEGMENT_SIZE;
	}

	if ((segmentSize & -segmentSize) != segmentSize)
	{
	    throw new IllegalArgumentException("segmentSize must be a power of 2");
        }

	m_segmentSize = segmentSize;
	m_segmentMask = segmentSize - 1;
	m_segmentSizeBits = MiscMath.log2(m_segmentSize);
    }

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ////////////////////////////////////////////////////////////////////////

    public boolean isEmpty()
    {
	return getNumAllocated() == 0;
    }

    public double[] getValue(int index)
    {
	if (index >= m_numAllocatedSlots)
	{
	    throw new UnallocatedElementException();
	}

	return getValueUnchecked(index);
    }

    public void getValue(int index, double[] value)
    {
	if (index >= m_numAllocatedSlots)
	{
	    throw new UnallocatedElementException();
	}

	getValueUnchecked(index, value);
    }

    public void setValue(int index, double[] value)
    {
	if (index >= m_numAllocatedSlots)
	{
	    throw new UnallocatedElementException();
	}

	setValueUnchecked(index, value);
    }

    public void setValue(int index, double x, double y, double z)
    {
	if (index >= m_numAllocatedSlots)
	{
	    throw new UnallocatedElementException();
	}

	setValueUnchecked(index, x, y, z);
    }

    public int append(double[] value)
    {
	int retval = allocateSlot();
	setValueUnchecked(retval, value);
	return retval;
    }

    public int append(double x, double y, double z)
    {
	int retval = allocateSlot();
	setValueUnchecked(retval, x, y, z);
	return retval;
    }

    public void clear()
    {
	m_numAllocatedSegments = 0;
	m_segments = new double[STARTING_NUM_SEGMENTS][];
	m_numUsableSlots = 0;
	m_numAllocatedSlots = 0;
    }

    public int getNumAllocated()
    {
	return m_numAllocatedSlots;
    }

    public int getNumFree()
    {
	return m_numAllocatedSegments * m_segmentSize - m_numAllocatedSlots;
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ////////////////////////////////////////////////////////////////////////

    private double[] getValueUnchecked(int index)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = 3 * (index & m_segmentMask);

	double[] retval = new double[3];
	retval[0] = m_segments[segment][offset];
	retval[1] = m_segments[segment][offset + 1];
	retval[2] = m_segments[segment][offset + 2];
	return retval;
    }

    private void getValueUnchecked(int index, double[] value)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = 3 * (index & m_segmentMask);

	value[0] = m_segments[segment][offset];
	value[1] = m_segments[segment][offset + 1];
	value[2] = m_segments[segment][offset + 2];
    }

    private void setValueUnchecked(int index, double[] value)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = 3 * (index & m_segmentMask);

	m_segments[segment][offset] = value[0];
	m_segments[segment][offset + 1] = value[1];
	m_segments[segment][offset + 2] = value[2];
    }

    private void setValueUnchecked(int index, double x, double y, double z)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = 3 * (index & m_segmentMask);

	m_segments[segment][offset] = x;
	m_segments[segment][offset + 1] = y;
	m_segments[segment][offset + 2] = z;
    }

    private int allocateSlot()
    {
	if (m_numAllocatedSlots == m_numUsableSlots)
	{
	    if (m_numAllocatedSegments == m_segments.length)
	    {
		expandSegmentsArray();
	    }

	    m_segments[m_numAllocatedSegments++] = new double[3*m_segmentSize];
	    m_numUsableSlots += m_segmentSize;
	}

	return m_numAllocatedSlots++;
    }

    private void expandSegmentsArray()
    {
	double[][] oldSegments = m_segments;
	m_segments = new double[oldSegments.length * 2][];
	System.arraycopy(oldSegments, 0, m_segments, 0, oldSegments.length);
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE CONSTANTS
    ////////////////////////////////////////////////////////////////////////

    private static final boolean DEBUG = true;

    private static final int STARTING_NUM_SEGMENTS = 512;
    private static final int DEFAULT_SEGMENT_SIZE = 1024;
    private static final int MIN_SEGMENT_SIZE = 128;

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ////////////////////////////////////////////////////////////////////////

    private int  m_numAllocatedSegments = 0;
    private double[][]  m_segments = new double[STARTING_NUM_SEGMENTS][];
    private final int  m_segmentSize;
    private final int  m_segmentMask;
    private final int  m_segmentSizeBits;

    private int  m_numUsableSlots = 0;
    private int  m_numAllocatedSlots = 0;
}
