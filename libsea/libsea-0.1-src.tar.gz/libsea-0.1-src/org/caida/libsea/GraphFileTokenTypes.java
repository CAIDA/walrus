// $ANTLR 2.7.1: "file.g" -> "GraphFileLexer.java"$

package org.caida.libsea;

public interface GraphFileTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int GRAPH_KEYWORD = 4;
	int TRUE_KEYWORD = 5;
	int FALSE_KEYWORD = 6;
	int BOOL_KEYWORD = 7;
	int INT_KEYWORD = 8;
	int FLOAT_KEYWORD = 9;
	int DOUBLE_KEYWORD = 10;
	int STRING_KEYWORD = 11;
	int FLOAT3_KEYWORD = 12;
	int DOUBLE3_KEYWORD = 13;
	int ENUM_KEYWORD = 14;
	int LIST_KEYWORD = 15;
	int INT = 16;
	int FLOAT = 17;
	int DOUBLE = 18;
	int LCURLY = 19;
	int STRING = 20;
	int SEMI = 21;
	int RCURLY = 22;
	int LBRACKET = 23;
	int COMMA = 24;
	int RBRACKET = 25;
	int IDENT = 26;
	int CODE = 27;
	int ESCAPE = 28;
	int KEYWORD = 29;
	int NUMBER = 30;
	int EXP = 31;
	int ID = 32;
	int LETTER = 33;
	int DIGIT = 34;
	int SHARP_COMMENT = 35;
	int AT_COMMENT = 36;
	int WHITESPACE = 37;
	int WS = 38;
}
