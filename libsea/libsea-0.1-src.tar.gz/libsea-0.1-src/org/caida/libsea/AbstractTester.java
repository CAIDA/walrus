// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.*;

class AbstractTester
{
    ///////////////////////////////////////////////////////////////////////
    // PROTECTED STATIC METHODS
    ///////////////////////////////////////////////////////////////////////

    protected static int parseArguments(String[] args)
    {
	int retval = 0;
	if (args.length > 0)
	{
	    try
	    {
		retval = Integer.parseInt(args[0]);
	    }
	    catch (NumberFormatException e)
	    {
		System.err.println("ERROR: Malformed starting test number.");
		System.exit(1);
	    }

	    if (retval < 0)
	    {
		System.err.println("ERROR: Starting test must be >= 0.");
		System.exit(1);
	    }
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ///////////////////////////////////////////////////////////////////////

    public AbstractTester() {}

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED METHODS
    ///////////////////////////////////////////////////////////////////////

    protected void printValues(int[] values)
    {
	System.out.println("[");

	for (int i = 0; i < values.length; i++)
	{
	    System.out.println("  " + i + ": " + values[i]);
	}
	
	System.out.println("]");
    }

    protected void printValues(BitSet values)
    {
	System.out.print("{ ");

	int numSet = 0;
	int length = values.length();
	for (int i = 0; i < length; i++)
	{
	    if (values.get(i))
	    {
		if (numSet > 0)
		{
		    System.out.print(", ");
		}
		++numSet;
		System.out.print(i);
	    }
	}
	
	System.out.println(" }");
    }

    ///////////////////////////////////////////////////////////////////////

    protected int[] createRandomValues(int n)
    {
	int[] retval = new int[n];

	for (int i = 0; i < n; i++)
	{
	    retval[i] = m_random.nextInt();
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    protected void shuffle(int[] array)
    {
	for (int i = 0; i < array.length; i++)
	{
	    int j = m_random.nextInt(array.length);
	    
	    int t = array[j];
	    array[j] = array[i];
	    array[i] = t;
	}
    }

    protected void reverse(int[] array)
    {
	if (array.length > 1)
	{
	    reverse(array, 0, array.length - 1);
	}
    }

    protected void reverse(int[] array, int start, int end)
    {
	if (start < 0 || start > end || end >= array.length)
	{
	    throw new IllegalArgumentException();
	}

	while (start < end)
	{
	    int t = array[start];
	    array[start] = array[end];
	    array[end] = t;

	    ++start;
	    --end;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected void verifyEqual(String s, boolean m, boolean n)
	throws TestFailedException
    {
	verifyEqual(true, s, m, n);
    }

    protected void verifyEqual(boolean show, String s, boolean m, boolean n)
	throws TestFailedException
    {
	String comparison = s + "[" + m + "] == " + n;
	if (show)
	{
	    println(comparison);
	}
	if (m != n)
	{
	    throw new TestFailedException("Verification Failed: "
					  + comparison);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected void verifyEqual(String s, int m, int n)
	throws TestFailedException
    {
	verifyEqual(true, s, m, n);
    }

    protected void verifyEqual(boolean show, String s, int m, int n)
	throws TestFailedException
    {
	verify(show, s, m, Op.EQUAL, n);
    }

    protected void verify(String s, int m, Op op, int n)
	throws TestFailedException
    {
	verify(true, s, m, op, n);
    }

    protected void verify(boolean show, String s, int m, Op op, int n)
	throws TestFailedException
    {
	String comparison = s + "[" + m + "] " + op.getName() + " " + n;
	if (show)
	{
	    println(comparison);
	}

	switch (op.getType())
	{
	case Op._EQUAL:         if (m == n) return; break;
	case Op._NOT_EQUAL:     if (m != n) return; break;
	case Op._LESS:          if (m < n)  return; break;
	case Op._LESS_EQUAL:    if (m <= n) return; break;
	case Op._GREATER:       if (m > n)  return; break;
	case Op._GREATER_EQUAL: if (m >= n) return; break;
	default: throw new InternalErrorException();
	}

	throw new TestFailedException("Verification Failed: " + comparison);
    }

    ///////////////////////////////////////////////////////////////////////

    protected void verifyEqual(String s, float m, float n)
	throws TestFailedException
    {
	verifyEqual(true, s, m, n);
    }

    protected void verifyEqual(boolean show, String s, float m, float n)
	throws TestFailedException
    {
	String comparison = s + "[" + m + "] == " + n;
	if (show)
	{
	    println(comparison);
	}
	if (m != n)
	{
	    throw new TestFailedException("Verification Failed: "
					  + comparison);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected void verifyEqual(String s, double m, double n)
	throws TestFailedException
    {
	verifyEqual(true, s, m, n);
    }

    protected void verifyEqual(boolean show, String s, double m, double n)
	throws TestFailedException
    {
	String comparison = s + "[" + m + "] == " + n;
	if (show)
	{
	    println(comparison);
	}
	if (m != n)
	{
	    throw new TestFailedException("Verification Failed: "
					  + comparison);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected void verifyEqual(String s, String m, String n)
	throws TestFailedException
    {
	verifyEqual(true, s, m, n);
    }

    protected void verifyEqual(boolean show, String s, String m, String n)
	throws TestFailedException
    {
	String comparison = s + "[\"" + m + "\"] == \"" + n + "\"";
	if (show)
	{
	    println(comparison);
	}
	if (!m.equals(n))
	{
	    throw new TestFailedException("Verification Failed: "
					  + comparison);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected void verifyIdenticalObject(String s, Object m, Object n)
	throws TestFailedException
    {
	verifyIdenticalObject(true, s, m, n);
    }

    protected void verifyIdenticalObject(boolean show, String s,
					 Object m, Object n)
	throws TestFailedException
    {
	String comparison = s + "[<" + m.hashCode()
	    + ">] == <" + n.hashCode() + ">";
	if (show)
	{
	    println(comparison);
	}
	if (m != n)
	{
	    throw new TestFailedException("Verification Failed: "
					  + comparison);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected void verify(String s, boolean value)
	throws TestFailedException
    {
	verify(true, s, value);
    }

    protected void verify(boolean show, String s, boolean value)
	throws TestFailedException
    {
	if (show)
	{
	    println(s);
	}
	if (!value)
	{
	    throw new TestFailedException("Verification Failed: " + s);
        }
    }

    ///////////////////////////////////////////////////////////////////////

    protected void fail(String s)
	throws TestFailedException
    {
	throw new TestFailedException(s);
    }

    ///////////////////////////////////////////////////////////////////////

    protected void print(boolean value)
    {
	System.out.print(value);
    }

    protected void print(int value)
    {
	System.out.print(value);
    }

    protected void print(float value)
    {
	System.out.print(value);
    }

    protected void print(double value)
    {
	System.out.print(value);
    }

    protected void print(String s)
    {
	System.out.print(s);
    }

    ///////////////////////////////////////////////////////////////////////

    protected void println()
    {
	System.out.println();
    }

    protected void println(boolean value)
    {
	System.out.println(value);
    }

    protected void println(int value)
    {
	System.out.println(value);
    }

    protected void println(float value)
    {
	System.out.println(value);
    }

    protected void println(double value)
    {
	System.out.println(value);
    }

    protected void println(String s)
    {
	System.out.println(s);
    }

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED FIELDS
    ///////////////////////////////////////////////////////////////////////

    protected Random  m_random = new Random();

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED INNER CLASSES
    ///////////////////////////////////////////////////////////////////////

    protected class NameGenerator
    {
	public NameGenerator(String prefix)
	{
	    m_prefix = prefix;
	}

	public String generate()
	{
	    ++m_sequenceNum;
	    int suffix = m_random.nextInt(Integer.MAX_VALUE);
	    return m_prefix + "_" + m_sequenceNum + "_" + suffix;
	}

	private String  m_prefix;
	private int  m_sequenceNum = 0;
    }

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED NESTED CLASSES
    ///////////////////////////////////////////////////////////////////////

    protected final static class Op
    {
	public static final int _EQUAL = 0;
	public static final int _NOT_EQUAL = 1;
	public static final int _LESS = 2;
	public static final int _LESS_EQUAL = 3;
	public static final int _GREATER = 4;
	public static final int _GREATER_EQUAL = 5;

	public static final Op EQUAL = new Op(_EQUAL);
	public static final Op NOT_EQUAL = new Op(_NOT_EQUAL);
	public static final Op LESS = new Op(_LESS);
	public static final Op LESS_EQUAL = new Op(_LESS_EQUAL);
	public static final Op GREATER = new Op(_GREATER);
	public static final Op GREATER_EQUAL = new Op(_GREATER_EQUAL);

	public int getType()
	{
	    return m_type;
	}

	public String getName()
	{
	    return m_names[m_type];
	}

	private Op(int type)
	{
	    m_type = type;
	}

	private final int  m_type;
	private static final String[]  m_names = 
	{
	    "==", "!=", "<", "<=", ">", ">="
	};
    }

    ///////////////////////////////////////////////////////////////////////

    protected static class TestFailedException
	extends Exception
    {
	public TestFailedException()
	{
	    super();
	}

	public TestFailedException(String s)
	{
	    super(s);
	}
    }
}
