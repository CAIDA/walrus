// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.*;

class HeapArrayTester
    extends AbstractTester
{
    ///////////////////////////////////////////////////////////////////////
    // MAIN
    ///////////////////////////////////////////////////////////////////////

    public static void main(String[] args)
    {
	int startingTest = parseArguments(args);
	HeapArrayTester tester = new HeapArrayTester();
	tester.testAll(startingTest);
    }

    ///////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ///////////////////////////////////////////////////////////////////////

    public HeapArrayTester()
    {
	super();
    }

    ///////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ///////////////////////////////////////////////////////////////////////

    public void testAll(int startingTest)
    {
	try
	{
	    if (startingTest == 0)
	    {
		println("\n**** TEST 0 ****");
		for (int i = 0; i < 20; i++)
		{
		    testBooleanArray(i);
		}
		testBooleanArray(500);
		testBooleanArray(5000);
	    }

	    if (startingTest <= 1)
	    {
		println("\n**** TEST 1 ****");
		for (int i = 0; i < 20; i++)
		{
		    testIntegerArray(i);
		}
		testIntegerArray(500);
		testIntegerArray(5000);
	    }

	    if (startingTest <= 2)
	    {
		println("\n**** TEST 2 ****");
		for (int i = 0; i < 20; i++)
		{
		    testFloatArray(i);
		}
		testFloatArray(500);
		testFloatArray(5000);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		for (int i = 0; i < 20; i++)
		{
		    testDoubleArray(i);
		}
		testDoubleArray(500);
		testDoubleArray(5000);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		for (int i = 0; i < 20; i++)
		{
		    testStringArray(i);
		}
		testStringArray(500);
		testStringArray(5000);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		for (int i = 0; i < 20; i++)
		{
		    testFloat3Array(i);
		}
		testFloat3Array(500);
		testFloat3Array(5000);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		for (int i = 0; i < 20; i++)
		{
		    testDouble3Array(i);
		}
		testDouble3Array(500);
		testDouble3Array(5000);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		for (int i = 0; i < 20; i++)
		{
		    testObjectArray(i);
		}
		testObjectArray(500);
		testObjectArray(5000);
	    }
	}
	catch (TestFailedException e)
	{
	    e.printStackTrace();
	    System.out.println("FAILED: " + e);
	}
	catch (RuntimeException e)
	{
	    e.printStackTrace();
	    System.out.println("ERROR: " + e);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // BOOLEAN ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testBooleanArray(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testBooleanArray(numValues=" + numValues + ")");
	println("===========================================================");

	BooleanArrayTester array = new BooleanArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // INTEGER ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testIntegerArray(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testIntegerArray(numValues=" + numValues + ")");
	println("===========================================================");

	IntegerArrayTester array = new IntegerArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // FLOAT ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testFloatArray(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testFloatArray(numValues=" + numValues + ")");
	println("===========================================================");

	FloatArrayTester array = new FloatArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // DOUBLE ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testDoubleArray(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testDoubleArray(numValues=" + numValues + ")");
	println("===========================================================");

	DoubleArrayTester array = new DoubleArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // STRING ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testStringArray(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testStringArray(numValues=" + numValues + ")");
	println("===========================================================");

	StringArrayTester array = new StringArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // FLOAT3 ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testFloat3Array(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testFloat3Array(numValues=" + numValues + ")");
	println("===========================================================");

	Float3ArrayTester array = new Float3ArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // DOUBLE3 ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testDouble3Array(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testDouble3Array(numValues=" + numValues + ")");
	println("===========================================================");

	Double3ArrayTester array = new Double3ArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // OBJECT ARRAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testObjectArray(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testObjectArray(numValues=" + numValues + ")");
	println("===========================================================");

	ObjectArrayTester array = new ObjectArrayTester(numValues);
	array.testArray();

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    private NameGenerator  m_nameGenerator = new NameGenerator("test");

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE NESTED CLASSES
    ///////////////////////////////////////////////////////////////////////

    private abstract class ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public ArrayTester(int numValues)
	{
	    m_numValues = numValues;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public void testArray()
	    throws TestFailedException
	{
	    println("Appending values...");
	    for (int i = 0; i < m_numValues; i++)
	    {
		println("[" + i + "]");
		if (i == 0)
		{
		    verifyEqual("isEmpty()", m_heapArray.isEmpty(), true);
		}
		else
		{
		    verifyEqual("isEmpty()", m_heapArray.isEmpty(), false);
		}

		verifyEqual("getNumAllocated()",
			    m_heapArray.getNumAllocated(), i);
		append(i);
	    }

	    println("Comparing appended values...");
	    for (int i = 0; i < m_numValues; i++)
	    {
		println("[" + i + "]");		
		compare(i);
	    }

	    println("Setting random values...");
	    for (int i = 0; i < m_numValues; i++)
	    {
		println("[" + i + "]");		
		setRandomValue(i);
		compare(i);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected abstract void setRandomValue(int i);
	protected abstract void compare(int i) throws TestFailedException;

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void append(int i)
	    throws TestFailedException
	{
	    int index = m_heapArray.allocate();
	    verifyEqual("allocate()", index, i);
	    setRandomValue(i);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	protected HeapArray  m_heapArray;
	protected int  m_numValues;
    }

    ///////////////////////////////////////////////////////////////////////

    private class BooleanArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public BooleanArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    boolean value = m_random.nextBoolean();
	    if (value)
	    {
		m_values.set(i);
	    }
	    else
	    {
		m_values.clear(i);
	    }
	    m_array.setValue(i, value);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    verifyEqual("getValue()", m_array.getValue(i), m_values.get(i));
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		if (m_random.nextBoolean())
		{
		    m_values.set(i);
		}
	    }
	}

	private void allocateValues()
	{
	    m_values = new BitSet(m_numValues);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private BitSet  m_values;
	private BooleanArray  m_array = new BooleanArray();
    }

    ///////////////////////////////////////////////////////////////////////

    private class IntegerArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public IntegerArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    m_values[i] = m_random.nextInt();
	    m_array.setValue(i, m_values[i]);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    verifyEqual("getValue()", m_array.getValue(i), m_values[i]);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		m_values[i] = m_random.nextInt();
	    }
	}

	private void allocateValues()
	{
	    m_values = new int[m_numValues];
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private int[]  m_values;
	private IntArray2  m_array = new IntArray2();
    }

    ///////////////////////////////////////////////////////////////////////

    private class FloatArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public FloatArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    m_values[i] = m_random.nextFloat();
	    m_array.setValue(i, m_values[i]);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    verifyEqual("getValue()", m_array.getValue(i), m_values[i]);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		m_values[i] = m_random.nextFloat();
	    }
	}

	private void allocateValues()
	{
	    m_values = new float[m_numValues];
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private float[]  m_values;
	private FloatArray  m_array = new FloatArray();
    }

    ///////////////////////////////////////////////////////////////////////

    private class DoubleArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public DoubleArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    m_values[i] = m_random.nextDouble();
	    m_array.setValue(i, m_values[i]);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    verifyEqual("getValue()", m_array.getValue(i), m_values[i]);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		m_values[i] = m_random.nextDouble();
	    }
	}

	private void allocateValues()
	{
	    m_values = new double[m_numValues];
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private double[]  m_values;
	private DoubleArray  m_array = new DoubleArray();
    }

    ///////////////////////////////////////////////////////////////////////

    private class StringArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public StringArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    m_values[i] = m_nameGenerator.generate();
	    m_array.setValue(i, m_values[i]);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    verifyEqual("getValue()", m_array.getValue(i), m_values[i]);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		m_values[i] = m_nameGenerator.generate();
	    }
	}

	private void allocateValues()
	{
	    m_values = new String[m_numValues];
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private String[]  m_values;
	private StringArray  m_array = new StringArray();
    }

    ///////////////////////////////////////////////////////////////////////

    private class Float3ArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public Float3ArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    m_xValues[i] = m_random.nextFloat();
	    m_yValues[i] = m_random.nextFloat();
	    m_zValues[i] = m_random.nextFloat();
	    m_array.setValue(i, m_xValues[i], m_yValues[i], m_zValues[i]);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    m_array.getValue(i, m_temporary);
	    verifyEqual("getValue().x", m_temporary[0], m_xValues[i]);
	    verifyEqual("getValue().y", m_temporary[1], m_yValues[i]);
	    verifyEqual("getValue().z", m_temporary[2], m_zValues[i]);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		m_xValues[i] = m_random.nextFloat();
		m_yValues[i] = m_random.nextFloat();
		m_zValues[i] = m_random.nextFloat();
	    }
	}

	private void allocateValues()
	{
	    m_xValues = new float[m_numValues];
	    m_yValues = new float[m_numValues];
	    m_zValues = new float[m_numValues];
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private float[]  m_xValues;
	private float[]  m_yValues;
	private float[]  m_zValues;

	private float[]  m_temporary = new float[3];
	private Float3Array  m_array = new Float3Array();
    }

    ///////////////////////////////////////////////////////////////////////

    private class Double3ArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public Double3ArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    m_xValues[i] = m_random.nextDouble();
	    m_yValues[i] = m_random.nextDouble();
	    m_zValues[i] = m_random.nextDouble();
	    m_array.setValue(i, m_xValues[i], m_yValues[i], m_zValues[i]);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    m_array.getValue(i, m_temporary);
	    verifyEqual("getValue().x", m_temporary[0], m_xValues[i]);
	    verifyEqual("getValue().y", m_temporary[1], m_yValues[i]);
	    verifyEqual("getValue().z", m_temporary[2], m_zValues[i]);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		m_xValues[i] = m_random.nextDouble();
		m_yValues[i] = m_random.nextDouble();
		m_zValues[i] = m_random.nextDouble();
	    }
	}

	private void allocateValues()
	{
	    m_xValues = new double[m_numValues];
	    m_yValues = new double[m_numValues];
	    m_zValues = new double[m_numValues];
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private double[]  m_xValues;
	private double[]  m_yValues;
	private double[]  m_zValues;

	private double[]  m_temporary = new double[3];
	private Double3Array  m_array = new Double3Array();
    }

    ///////////////////////////////////////////////////////////////////////

    private class ObjectArrayTester
	extends ArrayTester
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public ObjectArrayTester(int numValues)
	{
	    super(numValues);
	    m_heapArray = m_array;
	    allocateValues();
	    fillWithRandomValues();
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void setRandomValue(int i)
	{
	    m_values[i] = new Integer(m_random.nextInt());
	    m_array.setValue(i, m_values[i]);
	}

	protected void compare(int i)
	    throws TestFailedException
	{
	    verifyIdenticalObject("getValue()", m_array.getValue(i),
				  m_values[i]);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		m_values[i] = new Integer(m_random.nextInt());
	    }
	}

	private void allocateValues()
	{
	    m_values = new Object[m_numValues];
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private Object[]  m_values;
	private ObjectArray  m_array = new ObjectArray();
    }
}
