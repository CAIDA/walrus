// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

public interface Graph
{
    String   getName();
    String   getDescription();
    int      getNumNodes();
    int      getNumLinks();
    int      getNumPaths();
    int      getNumPathLinks();
    int      getNumObjects(ObjectType type);
    int      getNumOutgoingLinks(int node);
    int      getNumIncomingLinks(int node);
    int      getNumPathLinks(int path);
    NodeIterator  getNodes();
    LinkIterator  getLinks();
    PathIterator  getPaths();
    ObjectIterator  getObjects(ObjectType type);
    NodeIterator  getNode(int node);
    LinkIterator  getLink(int link);
    PathIterator  getPath(int path);
    ObjectIterator  getObject(ObjectType type, int id);
    EnumerationIterator  getEnumerations();
    EnumerationIterator  getEnumeration(int id);
    EnumerationIterator  getEnumeration(String name);
    ReadOnlyEnumeratorIterator  getEnumerators();
    ReadOnlyEnumeratorIterator  getEnumerator(int id);
    ReadOnlyEnumeratorIterator  getEnumerator(String enumeration,
					      String enumerator);
    int      resolveEnumerator(String enumeration, String enumerator);
    int      evaluateEnumerator(int id);
    int      evaluateEnumerator(String enumeration, String enumerator);
    AttributeDefinitionIterator getAttributeDefinitions();
    AttributeDefinitionIterator getAttributeDefinition(int attribute);
    AttributeDefinitionIterator getAttributeDefinition(String name);
    QualifierTypeIterator  getQualifierTypes();
    QualifierTypeIterator  getQualifierType(String name);
    QualifierIterator  getQualifiers();
    QualifierIterator  getQualifiersByType(String type);
    QualifierIterator  getQualifier(String name);
    int      resolveQualifierAttribute(String qualifier, String attribute);
    PresentationIterator  getPresentations();
    PresentationIterator  getPresentation(int id);
    DisplayIterator  getDisplays();
    DisplayIterator  getDisplay(int id);
    SelectorIterator  getSelectors();
    SelectorIterator  getSelector(int id);
    FilterIterator  getFilters();
    FilterIterator  getFilter(int id);
    MenuIterator  getPresentationMenu();
    MenuIterator  getDisplayMenu();
    MenuIterator  getSelectorMenu();
    MenuIterator  getFilterMenu();
    MenuIterator  getAttributeMenu();
    int      getNodeIDRange();
    int      getLinkIDRange();
    int      getPathIDRange();
    int      getEnumerationIDRange();
    int      getEnumeratorIDRange();
    int      getAttributeIDRange();
    int      getPresentationIDRange();
    int      getDisplayIDRange();
    int      getSelectorIDRange();
    int      getFilterIDRange();

    ValueIterator  getNodeAttribute(int node, int attribute)
	throws AttributeUnavailableException;
    ValueIterator  getLinkAttribute(int link, int attribute)
	throws AttributeUnavailableException;
    ValueIterator  getPathAttribute(int path, int attribute)
	throws AttributeUnavailableException;
    ValueIterator  getObjectAttribute(ObjectType type, int object,
                                      int attribute)
	throws AttributeUnavailableException;

    boolean  getBooleanAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException;
    int      getIntegerAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException;
    float    getFloatAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException;
    double   getDoubleAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException;
    String   getStringAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException;
    float[]  getFloat3Attribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException;
    void     getFloat3Attribute(ObjectType type, int object, int attribute,
				float[] values)
	throws AttributeUnavailableException;
    double[]  getDouble3Attribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException;
    void     getDouble3Attribute(ObjectType type, int object, int attribute,
				 double[] values)
	throws AttributeUnavailableException;
    int      getEnumerationAttribute(ObjectType type, int object,
				     int attribute)
	throws AttributeUnavailableException;
    int      getEvaluatedEnumerationAttribute(ObjectType type, int object,
					      int attribute)
	throws AttributeUnavailableException;

    void     setBooleanAttribute(ObjectType type, int object, int attribute,
                                 boolean value);
    void     setIntegerAttribute(ObjectType type, int object, int attribute,
                                 int value);
    void     setFloatAttribute(ObjectType type, int object, int attribute,
                               float value);
    void     setDoubleAttribute(ObjectType type, int object, int attribute,
				double value);
    void     setStringAttribute(ObjectType type, int object, int attribute,
                                String value);
    void     setFloat3Attribute(ObjectType type, int object, int attribute,
				float x, float y, float z);
    void     setFloat3Attribute(ObjectType type, int object, int attribute,
				float[] values);
    void     setDouble3Attribute(ObjectType type, int object, int attribute,
				 double x, double y, double z);
    void     setDouble3Attribute(ObjectType type, int object, int attribute,
				 double[] values);
    void     setEnumerationAttribute(ObjectType type, int object,
				     int attribute, String enumerator);
    void     setEnumerationAttribute(ObjectType type, int object,
				     int attribute, int enumerator);

    int      getNumBaseFilteredNodes();
    int      getNumBaseFilteredLinks();
    int      getNumBaseFilteredPaths();
    NodeIterator  getBaseFilteredNodes();
    LinkIterator  getBaseFilteredLinks();
    PathIterator  getBaseFilteredPaths();
    ObjectFilter  compileFilter(String expr);
    NodeIterator  getFurtherFilteredNodes(ObjectFilter filter);
    LinkIterator  getFurtherFilteredLinks(ObjectFilter filter);
    PathIterator  getFurtherFilteredPaths(ObjectFilter filter);
    boolean  checkNodeBaseFiltered(int node);
    boolean  checkLinkBaseFiltered(int link);
    boolean  checkPathBaseFiltered(int path);
    boolean  checkNodeFiltered(ObjectFilter filter, int node);
    boolean  checkLinkFiltered(ObjectFilter filter, int link);
    boolean  checkPathFiltered(ObjectFilter filter, int path);

    void     setNodeBaseFilter(ObjectFilter filter);
    void     setLinkBaseFilter(ObjectFilter filter);
    void     setPathBaseFilter(ObjectFilter filter);
    void     applyNodeBaseFilter();
    void     applyLinkBaseFilter();
    void     applyPathBaseFilter();
    void     clearNodeBaseFiltering();
    void     clearLinkBaseFiltering();
    void     clearPathBaseFiltering();

    void     setName(String name);
    void     setDescription(String description);

    void     removeNodes();
    void     removeLinks();
    void     removePaths();
    void     removeObjects(ObjectType type);
    void     removeNode(int node);
    void     removeLink(int link);
    void     removePath(int path);
    void     removeObject(ObjectType type, int id);
    void     removeEnumerations();
    void     removeEnumeration(String name);
    void     removeAttributeDefinitions();
    void     removeMutableAttributeDefinitions();
    void     removeAttributeDefinition(int attribute);
    void     removeAttributeDefinition(String name);
    void     removeQualifierTypes();
    void     removeQualifierType(String name);
    void     removeQualifiers();
    void     removeQualifier(String name);
    void     removeQualifiersByType(String type);
    void     removePresentations();
    void     removePresentation(int id);
    void     removeDisplays();
    void     removeDisplay(int id);
    void     removeSelectors();
    void     removeSelector(int id);
    void     removeFilters();
    void     removeFilter(int id);
    void     removePresentationMenu();
    void     removeDisplayMenu();
    void     removeSelectorMenu();
    void     removeFilterMenu();
    void     removeAttributeMenu();
}
