// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Observer;
import java.util.Observable;

class ImmutableGraph
    extends CommonGraph
{
    /////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    /////////////////////////////////////////////////////////////////////////

    public ImmutableGraph(SharedHeap heap, OptimizationType type)
    {
	super(heap, type);
    }

    /////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    /////////////////////////////////////////////////////////////////////////

    public GraphBuilder beginConstruction()
    {
	return new ImmutableGraphBuilder();
    }

    /////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS (Interface Graph)
    /////////////////////////////////////////////////////////////////////////

    public int getNumOutgoingLinks(int node)
    {
	validateObject(ObjectType.NODE, node);
	return m_nodeOutgoingStart[node + 1] - m_nodeOutgoingStart[node];
    }

    public int getNumIncomingLinks(int node)
    {
	validateObject(ObjectType.NODE, node);
	return m_nodeIncomingStart[node + 1] - m_nodeIncomingStart[node];
    }

    public int getNumPathLinks(int path)
    {
	validateObject(ObjectType.PATH, path);
	return m_pathStart[path + 1] - m_pathStart[path];
    }

    public NodeIterator getNodes()
    {
	return new NodeIteratorImpl(0, m_numNodes);
    }

    public LinkIterator getLinks()
    {
	return new LinkIteratorImpl(0, m_numLinks);
    }

    public PathIterator getPaths()
    {
	return new PathIteratorImpl(0, m_numPaths);
    }

    public NodeIterator getNode(int node)
    {
	validateObject(ObjectType.NODE, node);
	return new NodeIteratorImpl(node, node + 1);
    }

    public LinkIterator getLink(int link)
    {
	validateObject(ObjectType.LINK, link);
	return new LinkIteratorImpl(link, link + 1);
    }

    public PathIterator getPath(int path)
    {
	validateObject(ObjectType.PATH, path);
	return new PathIteratorImpl(path, path + 1);
    }

    public AttributeDefinitionIterator getAttributeDefinitions()
    {
	return new AttributeDefinitionIteratorImpl
	    (0, m_attributeDefinitions.getLogicalLength());
    }

    public AttributeDefinitionIterator getAttributeDefinition(int attribute)
    {
	validateAttributeExistence(attribute);
	return new AttributeDefinitionIteratorImpl(attribute, attribute + 1);
    }

    public AttributeDefinitionIterator getAttributeDefinition(String name)
    {
	AttributeDefinition attributeDefinition =
	    findAttributeDefinitionInstance(name);
	int attribute = attributeDefinition.getID();
	return new AttributeDefinitionIteratorImpl(attribute, attribute + 1);
    }

    public int getNodeIDRange()
    {
	return m_numNodes;
    }

    public int getLinkIDRange()
    {
	return m_numLinks;
    }

    public int getPathIDRange()
    {
	return m_numPaths;
    }

    public int getAttributeIDRange()
    {
	return m_attributeDefinitions.getLogicalLength();
    }    

    public ValueIterator getNodeAttribute(int node, int attribute)
	throws AttributeUnavailableException
    {
	validateObject(ObjectType.NODE, node);
	return getAttributeValues(ObjectType.NODE, attribute)
	    .getAttribute(node);
    }

    public ValueIterator getLinkAttribute(int link, int attribute)
	throws AttributeUnavailableException
    {
	validateObject(ObjectType.LINK, link);
	return getAttributeValues(ObjectType.LINK, attribute)
	    .getAttribute(link);
    }

    public ValueIterator getPathAttribute(int path, int attribute)
	throws AttributeUnavailableException
    {
	validateObject(ObjectType.PATH, path);
	return getAttributeValues(ObjectType.PATH, attribute)
	    .getAttribute(path);
    }

    public boolean getBooleanAttribute(ObjectType type, int object,
				       int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute).getBooleanAttribute(object);
    }

    public int getIntegerAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute).getIntegerAttribute(object);
    }

    public float getFloatAttribute(ObjectType type, int object, int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute).getFloatAttribute(object);
    }

    public double getDoubleAttribute(ObjectType type, int object,
				     int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute).getDoubleAttribute(object);
    }

    public String getStringAttribute(ObjectType type, int object,
				     int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute).getStringAttribute(object);
    }

    public float[] getFloat3Attribute(ObjectType type, int object,
				      int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute).getFloat3Attribute(object);
    }

    public void getFloat3Attribute(ObjectType type, int object, int attribute,
				   float[] values)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).getFloat3Attribute(object, values);
    }

    public double[] getDouble3Attribute(ObjectType type, int object,
					int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute).getDouble3Attribute(object);
    }

    public void getDouble3Attribute(ObjectType type, int object, int attribute,
				    double[] values)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).getDouble3Attribute(object,values);
    }

    public int getEnumerationAttribute(ObjectType type, int object,
				       int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute)
	    .getEnumerationAttribute(object);
    }

    public int getEvaluatedEnumerationAttribute(ObjectType type, int object,
						int attribute)
	throws AttributeUnavailableException
    {
	validateObject(type, object);
	return getAttributeValues(type, attribute)
	    .getEvaluatedEnumerationAttribute(object);
    }

    public void setBooleanAttribute(ObjectType type, int object, int attribute,
				    boolean value)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setBooleanAttribute(object, value);
    }

    public void setIntegerAttribute(ObjectType type, int object, int attribute,
				    int value)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setIntegerAttribute(object, value);
    }

    public void setFloatAttribute(ObjectType type, int object, int attribute,
				  float value)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setFloatAttribute(object, value);
    }

    public void setDoubleAttribute(ObjectType type, int object, int attribute,
				   double value)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setDoubleAttribute(object, value);
    }

    public void setStringAttribute(ObjectType type, int object, int attribute,
				   String value)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setStringAttribute(object, value);
    }

    public void setFloat3Attribute(ObjectType type, int object, int attribute,
				   float x, float y, float z)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setFloat3Attribute(object, x, y,z);
    }

    public void setFloat3Attribute(ObjectType type, int object, int attribute,
				   float[] values)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setFloat3Attribute(object, values);
    }

    public void setDouble3Attribute(ObjectType type, int object, int attribute,
				    double x, double y, double z)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute)
	    .setDouble3Attribute(object, x, y, z);
    }

    public void setDouble3Attribute(ObjectType type, int object, int attribute,
				    double[] values)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute).setDouble3Attribute(object,values);
    }

    public void setEnumerationAttribute(ObjectType type, int object,
					int attribute, String enumerator)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute)
	    .setEnumerationAttribute(object, enumerator);
    }

    public void setEnumerationAttribute(ObjectType type, int object,
					int attribute, int enumerator)
    {
	validateObject(type, object);
	getAttributeValues(type, attribute)
	    .setEnumerationAttribute(object, enumerator);
    }

    public void removeNodes()
    {
	throw new ImmutableDataException();
    }

    public void removeLinks()
    {
	throw new ImmutableDataException();
    }

    public void removePaths()
    {
	throw new ImmutableDataException();
    }

    public void removeNode(int node)
    {
	throw new ImmutableDataException();
    }

    public void removeLink(int link)
    {
	throw new ImmutableDataException();
    }

    public void removePath(int path)
    {
	throw new ImmutableDataException();
    }

    public void removeAttributeDefinitions()
    {
	throw new ImmutableDataException();
    }

    public void removeMutableAttributeDefinitions()
    {
	AttributeDefinitionIterator iterator = getAttributeDefinitions();
	while (!iterator.atEnd())
	{
	    if (iterator.isMutable())
	    {
		iterator.removeAttributeDefinition();
	    }
	    else
	    {
		iterator.advance();
	    }
	}
    }

    public void removeAttributeDefinition(int attribute)
    {
	AttributeDefinitionIterator iterator =
	    getAttributeDefinition(attribute);
	iterator.removeAttributeDefinition();
    }

    public void removeAttributeDefinition(String name)
    {
	AttributeDefinitionIterator iterator =
	    getAttributeDefinition(name);
	iterator.removeAttributeDefinition();
    }

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED METHODS
    ///////////////////////////////////////////////////////////////////////

    protected void validateAttributeExistence(int attribute)
    {
	if (attribute < 0)
	{
	    String msg = "attribute[" + attribute + "] must be nonnegative";
	    throw new IllegalArgumentException(msg);
	}
	if (!m_attributeDefinitions.checkAllocated(attribute))
	{
	    String msg = "attribute[" + attribute + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    protected String findAttributeName(int attribute)
    {
	AttributeDefinition attributeDefinition =
	    findAttributeDefinitionInstance(attribute);
	return attributeDefinition.getName();
    }

    protected int findAttributeID(String name)
    {
	AttributeDefinition attributeDefinition =
	    findAttributeDefinitionInstance(name);
	return attributeDefinition.getID();
    }

    protected void addAttributeRemovalObserver(int attribute,
					       Observer observer)
    {
	AttributeDefinition attributeDefinition =
	    findAttributeDefinitionInstance(attribute);
	attributeDefinition.addRemovalObserver(observer);
    }

    protected void removeAttributeRemovalObserver(int attribute,
						  Observer observer)
    {
	AttributeDefinition attributeDefinition =
	    findAttributeDefinitionInstance(attribute);
	attributeDefinition.removeRemovalObserver(observer);
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ///////////////////////////////////////////////////////////////////////

    private void removeMutableAttributeDefinition
	(AttributeDefinition attributeDefinition)
    {
	String name = attributeDefinition.getName();
	AttributeDefinition oldValue =
	    (AttributeDefinition)m_attributesMap.remove(name);
	if (oldValue == null)
	{
	    String msg = "attribute definition["
		+ attributeDefinition.getName() + "] not found";
	    throw new InternalErrorException(msg);
	}
	else
	{
	    int oldID = oldValue.getID();
	    int id = attributeDefinition.getID();
	    if (oldID != id)
	    {
		String oldName = oldValue.getName();
		String msg = "name[" + name
		    + "] maps to a different attribute definition["
		    + oldID + ": " + oldName + "] than current ["
		    + id + ": " + name + "]";
		throw new InternalErrorException(msg);
	    }
	}
	m_attributeDefinitions.free(attributeDefinition.getID());
	attributeDefinition.becomeRemoved();
    }

    private AttributeDefinition findAttributeDefinitionInstance(String name)
    {
	AttributeDefinition attributeDefinition =
	    (AttributeDefinition)m_attributesMap.get(name);
	if (attributeDefinition == null)
	{
	    String msg = "attribute[" + name + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return attributeDefinition;
    }

    private AttributeDefinition findAttributeDefinitionInstance(int attribute)
    {
	if (attribute < 0)
	{
	    String msg = "attribute[" + attribute + "] must be nonnegative.";
	    throw new IllegalArgumentException(msg);
	}

	try
	{
	    AttributeDefinition attributeDefinition = (AttributeDefinition)
		m_attributeDefinitions.getValue(attribute);
	    if (attributeDefinition == null)
	    {
		String msg = "null attribute reference in allocated slot";
		throw new InternalErrorException(msg);
	    }
	    return attributeDefinition;
	}
	catch (UnallocatedElementException e)
	{
	    String msg = "attribute[" + attribute + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    private AttributeValues getAttributeValues(ObjectType type, int attribute)
    {
	AttributeDefinition attributeDefinition =
	    findAttributeDefinitionInstance(attribute);
	return attributeDefinition.getObjectAttributeValues(type);
    }

    private AttributeValues createOptionalMutableAttributeValues
	(ValueType type, EnumerationReader reader, int maxNumObjects,
	 DefaultAttributeValues defaultValues, boolean include)
    {
	AttributeValues retval = null;
	if (include)
	{
	    if (type.isBaseType())
	    {
		retval = new MutableScalarAttributeValues
		    (type, reader, maxNumObjects);
	    }
	    else
	    {
		retval = new MutableListAttributeValues
		    (m_heap, type, reader, maxNumObjects);
	    }
	}
	else
	{
	    retval = new NoneAttributeValues
		(type, reader, maxNumObjects, defaultValues);
	}
	return retval;
    }

    private AttributeValues createOptionalMutableAttributeValues
	(AttributeBuffer buffer, int maxNumObjects,
	 DefaultAttributeValues defaultValues, boolean include)
    {
	AttributeValues retval = null;
	if (include)
	{
	    if (buffer.getType().isBaseType())
	    {
		retval = new MutableScalarAttributeValues
		    (buffer, maxNumObjects);
	    }
	    else
	    {
		retval = new MutableListAttributeValues
		    (m_heap, buffer, maxNumObjects);
	    }
	}
	else
	{
	    retval = new NoneAttributeValues
		(buffer.getType(), buffer.getEnumerationReader(),
		 maxNumObjects, defaultValues);
	}
	return retval;
    }

    private void validateObject(ObjectType type, int object)
    {
	if (object < 0)
	{
	    String msg = "object[" + object + "] must be nonnegative.";
	    throw new IllegalArgumentException(msg);
	}

	int numObjects = -1;
	switch (type.getType())
	{
	case ObjectType._NODE: numObjects = m_numNodes; break;
	case ObjectType._LINK: numObjects = m_numLinks; break;
	case ObjectType._PATH: numObjects = m_numPaths; break;
	default: throw new InternalErrorException();
	}

	if (object >= numObjects)
	{
	    String msg = "object[" + object + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    private static final boolean DEBUG_ATTRIBUTE_VALUES = true;

    private static final int FEW_ATTRIBUTES_THRESHOLD = 32;
    private static final int MIN_NUM_OBJECTS_THRESHOLD = 100;
    private static final int BINARY_SEARCH_THRESHOLD = 8;

    private int[]  m_nodeOutgoingStart;
    private int[]  m_nodeIncomingStart;
    private int[]  m_linkSource;
    private int[]  m_linkDestination;
    private int[]  m_pathStart;
    private int[]  m_pathLinks;
    private int[]  m_nodeOutgoingLinks; // Contains link IDs.
    private int[]  m_nodeIncomingLinks; // Contains link IDs.

    // Contains AttributeDefinition objects.
    private ObjectArray  m_attributeDefinitions = new ObjectArray();

    // Maps String[attribute name] -> AttributeDefinition.
    private Map  m_attributesMap = new HashMap();

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE INNER CLASSES
    ///////////////////////////////////////////////////////////////////////

    private abstract class AbstractObjectIterator
	implements ObjectIterator
    {
	public AbstractObjectIterator(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start)
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	}

	public boolean atEnd()
	{
	    return m_current == m_end;
	}

	public void advance()
	{
	    if (m_current < m_end)
	    {
		++m_current;
	    }
	}

	public void rewind()
	{
	    m_current = m_start;
	}

	public AttributesByObjectIterator getAttributes()
	{
	    int start = 0;
	    int end = m_attributeDefinitions.getLogicalLength();
	    return new AttributesByObjectIteratorImpl
		(getObjectType(), getObjectID(), start, end);
	}

	public AttributesByObjectIterator getAttribute(int attribute)
	{
	    ImmutableGraph.this.validateAttributeExistence(attribute);
	    return new AttributesByObjectIteratorImpl
		(getObjectType(), getObjectID(), attribute, attribute + 1);
	}

	public void removeObject()
	{
	    throw new ImmutableDataException();
	}

	protected void assertNotAtEnd()
	{
	    if (m_current == m_end)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	protected int  m_start;
	protected int  m_end;
	protected int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class NodeIteratorImpl
	extends AbstractObjectIterator
	implements NodeIterator
    {
	public NodeIteratorImpl(int start, int end)
	{
	    super(start, end);

	    if (end > m_numNodes)
	    {
		throw new IllegalArgumentException();
	    }
	}

	public int getObjectID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public ObjectType getObjectType()
	{
	    return ObjectType.NODE;
	}

	public LinkIterator getOutgoingLinks()
	{
	    assertNotAtEnd();
	    int start = m_nodeOutgoingStart[m_current];
	    int end = m_nodeOutgoingStart[m_current + 1];
	    return new IndirectLinkIterator(m_nodeOutgoingLinks, start, end);
	}

	public LinkIterator getIncomingLinks()
	{
	    assertNotAtEnd();
	    int start = m_nodeIncomingStart[m_current];
	    int end = m_nodeIncomingStart[m_current + 1];
	    return new IndirectLinkIterator(m_nodeIncomingLinks, start, end);
	}

	public void removeOutgoingLinks()
	{
	    throw new ImmutableDataException();
	}

	public void removeIncomingLinks()
	{
	    throw new ImmutableDataException();
	}

	public void addNode()
	{
	    throw new ImmutableDataException();
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class LinkIteratorImpl
	extends AbstractObjectIterator
	implements LinkIterator
    {
	public LinkIteratorImpl(int start, int end)
	{
	    super(start, end);

	    if (end > m_numLinks)
	    {
		throw new IllegalArgumentException();
	    }
	}

	public int getObjectID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public ObjectType getObjectType()
	{
	    return ObjectType.LINK;
	}

	public int getSource()
	{
	    assertNotAtEnd();
	    return m_linkSource[m_current];
	}

	public int getDestination()
	{
	    assertNotAtEnd();
	    return m_linkDestination[m_current];
	}

	public void setSource(int node)
	{
	    throw new ImmutableDataException();
	}

	public void setDestination(int node)
	{
	    throw new ImmutableDataException();
	}

	public void insertLink(int source, int destination)
	{
	    throw new ImmutableDataException();
	}

	public void appendLink(int source, int destination)
	{
	    throw new ImmutableDataException();
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class PathIteratorImpl
	extends AbstractObjectIterator
	implements PathIterator
    {
	public PathIteratorImpl(int start, int end)
	{
	    super(start, end);

	    if (end > m_numPaths)
	    {
		throw new IllegalArgumentException();
	    }
	}

	public int getObjectID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public ObjectType getObjectType()
	{
	    return ObjectType.PATH;
	}

	public LinkIterator getLinks()
	{
	    assertNotAtEnd();
	    int start = m_pathStart[m_current];
	    int end = m_pathStart[m_current + 1];
	    return new IndirectLinkIterator(m_pathLinks, start, end);
	}

	public void removeLinks()
	{
	    throw new ImmutableDataException();
	}

	public void addPath()
	{
	    throw new ImmutableDataException();
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class IndirectLinkIterator
	extends AbstractObjectIterator
	implements LinkIterator
    {
	public IndirectLinkIterator(int[] links, int start, int end)
	{
	    super(start, end);

	    if (end > links.length)
	    {
		throw new IllegalArgumentException();
	    }

	    m_links = links;
	}

	public int getObjectID()
	{
	    assertNotAtEnd();
	    return m_links[m_current];
	}

	public ObjectType getObjectType()
	{
	    return ObjectType.LINK;
	}

	public int getSource()
	{
	    assertNotAtEnd();
	    return m_linkSource[m_links[m_current]];
	}

	public int getDestination()
	{
	    assertNotAtEnd();
	    return m_linkDestination[m_links[m_current]];
	}

	public void setSource(int node)
	{
	    throw new ImmutableDataException();
	}

	public void setDestination(int node)
	{
	    throw new ImmutableDataException();
	}

	public void insertLink(int source, int destination)
	{
	    throw new ImmutableDataException();
	}

	public void appendLink(int source, int destination)
	{
	    throw new ImmutableDataException();
	}

	private int[]  m_links;
    }

    ///////////////////////////////////////////////////////////////////////

    private class AttributeDefinition
	extends CommonRemovableObject
    {
	public AttributeDefinition
	    (boolean isMutable, int id, String name, ValueType type, 
	     EnumerationReader reader, String defaultExpr,
	     DefaultAttributeValues defaultValues,
	     AttributeValues nodeValues, AttributeValues linkValues,
	     AttributeValues pathValues, boolean includeNodes,
	     boolean includeLinks, boolean includePaths)
	{
	    super();
	    if (type.isEnumerationType())
	    {
		if (reader == null)
		{
		    String msg = "missing EnumerationReader";
		    throw new IllegalArgumentException(msg);
		}

		if (isMutable)
		{
		    m_removalObserver = new RemovalObserver();
		    reader.addRemovalObserver(m_removalObserver);
		}
		else
		{
		    reader.becomeImmutable();
		}
	    }

	    m_isMutable = isMutable;
	    m_id = id;
	    m_name = name;
	    m_type = type;
	    m_reader = reader;
	    m_defaultExpr = defaultExpr;
	    m_defaultValues = defaultValues;
	    m_nodeAttributeValues = nodeValues;
	    m_linkAttributeValues = linkValues;
	    m_pathAttributeValues = pathValues;
	    m_includeNodes = includeNodes;
	    m_includeLinks = includeLinks;
	    m_includePaths = includePaths;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public boolean isMutable()
	{
	    return m_isMutable;
	}

	public int getID()
	{
	    return m_id;
	}

	public String getName()
	{
	    return m_name;
	}

	public ValueType getType()
	{
	    return m_type;
	}

	public int getEnumeration()
	{
	    return (m_type.isEnumerationType() ? m_reader.getID() : -1);
	}

	public String getDefaultExpr()
	{
	    return m_defaultExpr;
	}

	public DefaultAttributeValues getDefaultValues()
	{
	    return m_defaultValues;
	}

	public AttributeValues getNodeAttributeValues()
	{
	    return m_nodeAttributeValues;
	}

	public AttributeValues getLinkAttributeValues()
	{
	    return m_linkAttributeValues;
	}

	public AttributeValues getPathAttributeValues()
	{
	    return m_pathAttributeValues;
	}

	public AttributeValues getObjectAttributeValues(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return getNodeAttributeValues();
	    case ObjectType._LINK: return getLinkAttributeValues();
	    case ObjectType._PATH: return getPathAttributeValues();
	    default: throw new InternalErrorException();
	    }
	}

	public void setName(String name)
	{
	    assertMutable();
	    m_name = name;
	}

	public void setType(ValueType type, String enumeration)
	{
	    assertMutable();
	    EnumerationReader reader = 
		(type.isEnumerationType()
		 ? ImmutableGraph.this.findEnumerationReader(enumeration)
		 : null);

	    if (type != m_type
		|| (type.isEnumerationType()
		    && reader.getID() != m_reader.getID()))
	    {
		removeDefaultExpr();
		removeEnumerationObserver();
		m_type = type;
		m_reader = reader;

		if (m_type.isEnumerationType())
		{
		    m_removalObserver = new RemovalObserver();
		    m_reader.addRemovalObserver(m_removalObserver);
		}

		m_nodeAttributeValues =
		    createOptionalMutableAttributeValues
		    (m_type, m_reader,
		     m_nodeAttributeValues.getMaxNumObjects(),
		     null, m_includeNodes);

		m_linkAttributeValues =
		    createOptionalMutableAttributeValues
		    (m_type, m_reader,
		     m_linkAttributeValues.getMaxNumObjects(),
		     null, m_includeLinks);

		m_pathAttributeValues =
		    createOptionalMutableAttributeValues
		    (m_type, m_reader,
		     m_pathAttributeValues.getMaxNumObjects(),
		     null, m_includePaths);
	    }
	}

	public void setDefaultExpr(String expr)
	{
	    assertMutable();
	    m_defaultExpr = expr;
	    if (expr == null)
	    {
		m_defaultValues = null;
	    }
	    else
	    {
		try
		{
		    ExprParser parser = new ExprParser
			(m_type, m_reader, m_defaultExpr);
		    m_defaultValues = parser.parse();
		}
		catch (ParseException e)
		{
		    String msg = "error parsing default expression \"" +
			m_defaultExpr + "\": " + e.getMessage();
		    throw new IllegalArgumentException(msg);
		}
	    }

	    updateDefaultValues();
	}

	public void removeDefaultExpr()
	{
	    assertMutable();
	    m_defaultExpr = null;
	    m_defaultValues = null;

	    updateDefaultValues();
	}

	public void becomeRemoved()
	{
	    removeEnumerationObserver();
	    super.becomeRemoved();
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void removeEnumerationObserver()
	{
	    if (m_removalObserver != null)
	    {
		if (m_reader == null)
		{
		    String msg = "m_reader is null";
		    throw new InternalErrorException(msg);
		}
		m_reader.removeRemovalObserver(m_removalObserver);
		m_removalObserver = null;
	    }
	}

	private void updateDefaultValues()
	{
	    m_nodeAttributeValues.setDefaultAttributeValues(m_defaultValues);
	    m_linkAttributeValues.setDefaultAttributeValues(m_defaultValues);
	    m_pathAttributeValues.setDefaultAttributeValues(m_defaultValues);
	}

	private void assertMutable()
	{
	    if (!m_isMutable)
	    {
		String msg = "attribute[" + m_name + "] is immutable";
		throw new ImmutableDataException(msg);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private boolean  m_isMutable;
	private int  m_id;
	private String  m_name;
	private ValueType  m_type;
	private EnumerationReader  m_reader;  // may be null
	private String  m_defaultExpr;
	private DefaultAttributeValues  m_defaultValues; // may be null
	private AttributeValues  m_nodeAttributeValues;
	private AttributeValues  m_linkAttributeValues;
	private AttributeValues  m_pathAttributeValues;
	private boolean  m_includeNodes;
	private boolean  m_includeLinks;
	private boolean  m_includePaths;
	private RemovalObserver  m_removalObserver; // may be null

	////////////////////////////////////////////////////////////////////
	// PRIVATE INNER CLASSES
	////////////////////////////////////////////////////////////////////

	private class RemovalObserver
	    implements Observer
	{
	    public void update(Observable o, Object arg)
	    {
		assertNotRemoved();
		ImmutableGraph.this.removeMutableAttributeDefinition
		    (AttributeDefinition.this);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class AttributeDefinitionIteratorImpl
	implements AttributeDefinitionIterator
    {
	public AttributeDefinitionIteratorImpl(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start
		|| end > m_attributeDefinitions.getLogicalLength())
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingAttributeDefinitions();
	}

	public boolean atEnd()
	{
	    return m_attributeDefinition == null;
	}

	public void advance()
	{
	    if (m_attributeDefinition != null)
	    {
		if (m_addedAttributeDefinition || m_current == m_end - 1)
		{
		    m_attributeDefinition = null;
		}
		else
		{
		    ++m_current;
		    skipMissingAttributeDefinitions();
		}
	    }
	}

	public void rewind()
	{
	    m_addedAttributeDefinition = false;
	    m_current = m_start;
	    skipMissingAttributeDefinitions();
	}

	public boolean isMutable()
	{
	    assertNotAtEnd();
	    return m_attributeDefinition.isMutable();
	}

	public int getID()
	{
	    assertNotAtEnd();
	    if (m_current != m_attributeDefinition.getID())
	    {
		String msg = "m_current[" + m_current + "] disagrees with ID["
		    + m_attributeDefinition.getID() + "] in attribute";
		throw new InternalErrorException(msg);
	    }
	    return m_current;
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_attributeDefinition.getName();
	}

	public ValueType getType()
	{
	    assertNotAtEnd();
	    return m_attributeDefinition.getType();
	}

	public int getEnumeration()
	{
	    assertNotAtEnd();
	    return m_attributeDefinition.getEnumeration();
	}

	public String getDefault()
	{
	    assertNotAtEnd();
	    return m_attributeDefinition.getDefaultExpr();
	}

	public AttributesByAttributeIterator getAttributes()
	{
	    assertNotAtEnd();
	    return new AttributesByAttributeIteratorImpl
		(m_attributeDefinition);
	}

	public AttributesByAttributeIterator getNodeAttributes()
	{
	    assertNotAtEnd();
	    return new AttributesByAttributeIteratorImpl
		(m_attributeDefinition, true, false, false);
	}

	public AttributesByAttributeIterator getLinkAttributes()
	{
	    assertNotAtEnd();
	    return new AttributesByAttributeIteratorImpl
		(m_attributeDefinition, false, true, false);
	}

	public AttributesByAttributeIterator getPathAttributes()
	{
	    assertNotAtEnd();
	    return new AttributesByAttributeIteratorImpl
		(m_attributeDefinition, false, false, true);
	}

	public AttributesByAttributeIterator
	    getObjectAttributes(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return getNodeAttributes();
	    case ObjectType._LINK: return getLinkAttributes();
	    case ObjectType._PATH: return getPathAttributes();
	    default: throw new InternalErrorException();
	    }
	}

	public void setName(String name)
	    throws DuplicateObjectException
	{
	    assertNotAtEnd();
	    if (!m_attributeDefinition.isMutable())
	    {
		throw new ImmutableDataException();
	    }

	    String oldName = m_attributeDefinition.getName();
	    if (!name.equals(oldName))
	    {
		Object oldValue =
		    m_attributesMap.put(name, m_attributeDefinition);
		if (oldValue == null)
		{
		    m_attributeDefinition.setName(name);
		    AttributeDefinition oldNameValue =
			(AttributeDefinition)m_attributesMap.remove(oldName);
		    if (oldNameValue == null)
		    {
			String msg = "old attribute definition["
			    + oldName + "] not found";
			throw new InternalErrorException(msg);
		    }
		    else
		    {
			int oldID = oldNameValue.getID();
			int newID = m_attributeDefinition.getID();
			if (oldID != newID)
			{
			    String actualName = oldNameValue.getName();
			    String msg = "old name[" + oldName
				+ "] maps to a different attribute definition["
				+ oldID + ": " + actualName
				+ "] than current [" + newID + ": "
				+ oldName + "]";
			    throw new InternalErrorException(msg);
			}
		    }
		}
		else
		{
		    m_attributesMap.put(name, oldValue);
		    String msg = "attribute definition["
			+ name + "] already exists";
		    throw new DuplicateObjectException(msg);
		}
	    }
	}

	public void setType(ValueType type, String enumeration)
	{
	    assertNotAtEnd();
	    m_attributeDefinition.setType(type, enumeration);
	}

	public void setDefault(String expr)
	{
	    assertNotAtEnd();
	    m_attributeDefinition.setDefaultExpr(expr);
	}

	public void removeDefault()
	{
	    assertNotAtEnd();
	    m_attributeDefinition.removeDefaultExpr();
	}

	public void removeAttributes()
	{
	    throw new ImmutableDataException();
	}

	public void removeAttributeDefinition()
	{
	    assertNotAtEnd();
	    if (m_attributeDefinition.isMutable())
	    {
		ImmutableGraph.this
		    .removeMutableAttributeDefinition(m_attributeDefinition);
		m_attributeDefinition = null;
		if (!m_addedAttributeDefinition)
		{
		    ++m_current;
		    skipMissingAttributeDefinitions();
		}
	    }
	    else
	    {
		throw new ImmutableDataException();
	    }
	}

	public void addAttributeDefinition(String name, ValueType type,
					   String enumeration, String expr)
	    throws DuplicateObjectException
	{
	    String msg = "attempted to add an immutable attribute "
		+ "to an immutable graph after construction";
	    throw new ImmutableDataException(msg);
	}

	public void addMutableAttributeDefinition
	    (String name, ValueType type, String enumeration, String expr,
	     boolean node, boolean link, boolean path)
	    throws DuplicateObjectException
	{
	    EnumerationReader reader = 
		(type.isEnumerationType()
		 ? ImmutableGraph.this.findEnumerationReader(enumeration)
		 : null);

	    DefaultAttributeValues defaultValues = null;
	    if (expr != null)
	    {
		try
		{
		    ExprParser parser = new ExprParser(type, reader, expr);
		    defaultValues = parser.parse();
		}
		catch (ParseException e)
		{
		    String msg = "error parsing default expression \""
			+ expr + "\": " + e.getMessage();
		    throw new IllegalArgumentException(msg);
		}
	    }

	    AttributeValues nodeValues = createOptionalMutableAttributeValues
		(type, reader, m_numNodes, defaultValues, node);
	    AttributeValues linkValues = createOptionalMutableAttributeValues
		(type, reader, m_numLinks, defaultValues, link);
	    AttributeValues pathValues = createOptionalMutableAttributeValues
		(type, reader, m_numPaths, defaultValues, path);

	    int index = m_attributeDefinitions.allocate();
	    AttributeDefinition attributeDefinition = new AttributeDefinition
		(true, index, name, type, reader, expr, defaultValues,
		 nodeValues, linkValues, pathValues, node, link, path);

	    Object oldValue = m_attributesMap.put(name, attributeDefinition);
	    if (oldValue == null)
	    {
		m_addedAttributeDefinition = true;
		m_attributeDefinition = attributeDefinition;
		m_current = index;
		m_attributeDefinitions.setValue(index, attributeDefinition);
	    }
	    else
	    {
		m_attributesMap.put(name, oldValue);
		m_attributeDefinitions.free(index);
		attributeDefinition.becomeRemoved(); // Remove enum observer.

		String msg = "attribute definition["
		    + name + "] already exists";
		throw new DuplicateObjectException(msg);
	    }
	}

	private void skipMissingAttributeDefinitions()
	{
	    m_attributeDefinition = null;
	    while (m_current < m_end)
	    {
		if (m_attributeDefinitions.checkAllocated(m_current))
		{
		    m_attributeDefinition = (AttributeDefinition)
			m_attributeDefinitions.getValue(m_current);
		    if (m_attributeDefinition == null)
		    {
			String msg = "null attribute definition reference "
			    + "in allocated slot";
			throw new InternalErrorException(msg);
		    }
		    break;
		}
		else
		{
		    ++m_current;
		}
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_attributeDefinition == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private boolean  m_addedAttributeDefinition = false;
	private AttributeDefinition  m_attributeDefinition;

	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class AttributesByAttributeIteratorImpl
	implements AttributesByAttributeIterator
    {
	public AttributesByAttributeIteratorImpl
	    (AttributeDefinition attributeDefinition)
	{
	    this(attributeDefinition, true, true, true);
	}

	public AttributesByAttributeIteratorImpl
	    (AttributeDefinition attributeDefinition,
	     boolean includeNodes, boolean includeLinks, boolean includePaths)
	{
	    m_attributeDefinition = attributeDefinition;
	    m_attribute = attributeDefinition.getID();

	    m_attributeValues = new AttributeValues[3];
	    m_attributeValues[0] =
		attributeDefinition.getNodeAttributeValues();
	    m_attributeValues[1] =
		attributeDefinition.getLinkAttributeValues();
	    m_attributeValues[2] =
		attributeDefinition.getPathAttributeValues();

	    m_includeAttributeValues = new boolean[3];
	    m_includeAttributeValues[0] = includeNodes;
	    m_includeAttributeValues[1] = includeLinks;
	    m_includeAttributeValues[2] = includePaths;

	    m_maxNumObjects = new int[3];
	    m_maxNumObjects[0] = m_numNodes;
	    m_maxNumObjects[1] = m_numLinks;
	    m_maxNumObjects[2] = m_numPaths;

	    m_atEnd = false;
	    m_currentAttributeValues = 0;
	    m_currentObject = 0;
	    skipMissingAttributeValues();
	}

	public boolean atEnd()
	{
	    return m_atEnd;
	}

	public void advance()
	{
	    if (!m_atEnd)
	    {
		m_currentObject =
		    m_attributeValues[m_currentAttributeValues]
		    .findNextObjectWithValue(m_currentObject);

		if (m_currentObject < 0)
		{
		    ++m_currentAttributeValues;
		    m_currentObject = 0;
		    skipMissingAttributeValues();
		}
	    }
	}

	public void rewind()
	{
	    m_atEnd = false;
	    m_currentAttributeValues = 0;
	    m_currentObject = 0;
	    skipMissingAttributeValues();
	}

	public ObjectType getObjectType()
	{
	    assertNotAtEnd();
	    switch (m_currentAttributeValues)
	    {
	    case 0: return ObjectType.NODE;
	    case 1: return ObjectType.LINK;
	    case 2: return ObjectType.PATH;
	    default: throw new InternalErrorException();
	    }
	}

	public int getObjectID()
	{
	    assertNotAtEnd();
	    return m_currentObject;
	}

	public ValueIterator getAttributeValues()
	{
	    assertNotAtEnd();
	    try { return m_attributeValues[m_currentAttributeValues]
		      .getAttribute(m_currentObject); }
	    catch (AttributeUnavailableException e)
	    { e.printStackTrace();
	    throw new InternalErrorException(e.toString()); }
	}

	public void removeAttribute()
	{
	    throw new ImmutableDataException();
	}

	public void addNodeAttribute(int id)
	{
	    throw new ImmutableDataException();
	}

	public void addLinkAttribute(int id)
	{
	    throw new ImmutableDataException();
	}

	public void addPathAttribute(int id)
	{
	    throw new ImmutableDataException();
	}

	public void addObjectAttribute(ObjectType type, int id)
	{
	    throw new ImmutableDataException();
	}

	private void skipMissingAttributeValues()
	{
	    while (m_currentAttributeValues < 3)
	    {
		if (m_includeAttributeValues[m_currentAttributeValues])
		{
		    AttributeValues attributeValues = 
			m_attributeValues[m_currentAttributeValues];

		    if (m_currentObject
			< m_maxNumObjects[m_currentAttributeValues])
		    {
			if (attributeValues.hasValueFor(m_currentObject))
			{
			    break;
			}
			else
			{
			    m_currentObject = attributeValues
				.findNextObjectWithValue(m_currentObject);

			    if (m_currentObject >= 0)
			    {
				break;
			    }
			}
		    }
		}

		++m_currentAttributeValues;
		m_currentObject = 0;
	    }

	    if (m_currentAttributeValues == 3)
	    {
		m_atEnd = true;
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_atEnd)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private AttributeDefinition  m_attributeDefinition;
	private int  m_attribute;

	private boolean  m_atEnd;
	private int  m_currentAttributeValues;
	private int  m_currentObject;
	private AttributeValues[]  m_attributeValues;
	private boolean[]  m_includeAttributeValues;
	private int[]  m_maxNumObjects;
    }

    ///////////////////////////////////////////////////////////////////////

    private class AttributesByObjectIteratorImpl
	implements AttributesByObjectIterator
    {
	public AttributesByObjectIteratorImpl(ObjectType type, int object,
					      int start, int end)
	{
	    validateObject(type, object);
	    if (start < 0 || end < 0 || end < start
		|| end > m_attributeDefinitions.getLogicalLength())
	    {
		throw new IllegalArgumentException();
	    }

	    m_type = type;
	    m_object = object;
	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingAttributeValues();
	}

	public boolean atEnd()
	{
	    return m_attributeValues == null;
	}

	public void advance()
	{
	    if (m_attributeValues != null)
	    {
		m_attributeValues = null;
		if (m_current < m_end)
		{
		    ++m_current;
		    skipMissingAttributeValues();
		}
	    }
	}

	public void rewind()
	{
	    m_attributeValues = null;
	    m_current = m_start;
	    skipMissingAttributeValues();
	}

	public int getAttributeID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public String getAttributeName()
	{
	    assertNotAtEnd();
	    AttributeDefinition attributeDefinition = (AttributeDefinition)
		m_attributeDefinitions.getValue(m_current);
	    return attributeDefinition.getName();
	}

	public ValueIterator getAttributeValues()
	{
	    assertNotAtEnd();
	    try { return m_attributeValues.getAttribute(m_object); }
	    catch (AttributeUnavailableException e)
	    { e.printStackTrace();
	    throw new InternalErrorException(e.toString()); }
	}

	public void removeAttribute()
	{
	    throw new ImmutableDataException();
	}

	public void addAttribute(int attribute)
	{
	    throw new ImmutableDataException();
	}

	private void skipMissingAttributeValues()
	{
	    m_attributeValues = null;
	    while (m_current < m_end)
	    {
		if (m_attributeDefinitions.checkAllocated(m_current))
		{
		    AttributeDefinition attributeDefinition =
			(AttributeDefinition)m_attributeDefinitions
			.getValue(m_current);
		    if (attributeDefinition == null)
		    {
			String msg = "null attribute definition reference "
			    + "in allocated slot";
			throw new InternalErrorException(msg);
		    }
		    else
		    {
			AttributeValues attributeValues = attributeDefinition
			    .getObjectAttributeValues(m_type);
			if (attributeValues.hasValueFor(m_object))
			{
			    m_attributeValues = attributeValues;
			    break;
			}
		    }
		}

		++m_current;
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_attributeValues == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private ObjectType  m_type;
	private int  m_object;

	private AttributeValues  m_attributeValues;
	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class ImmutableGraphBuilder
	extends CommonGraphBuilder
    {
	public ImmutableGraphBuilder()
	{
	    super();
	}

	public void allocateNodes(int count)
	{
	    assertInConstruction();
	    if (count < 0)
	    {
		String msg = "count[" + count + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (m_haveAllocatedNodes)
	    {
		String msg = "nodes have already been allocated.";
		throw new ConstructionOrderException(msg);
	    }

	    m_haveAllocatedNodes = true;
	    m_numNodes = count;
	    m_nodeOutgoingStart = new int[count + 1];
	    m_nodeIncomingStart = new int[count + 1];
	}

	public void allocateLinks(int count)
	{
	    assertInConstruction();
	    if (count < 0)
	    {
		String msg = "count[" + count + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (m_haveAllocatedLinks)
	    {
		String msg = "links have already been allocated.";
		throw new ConstructionOrderException(msg);
	    }

	    m_haveAllocatedLinks = true;
	    m_numLinks = count;
	    m_linkSource = new int[count];
	    m_linkDestination = new int[count];
	}

	public void allocatePaths(int count)
	{
	    assertInConstruction();
	    if (count < 0)
	    {
		String msg = "count[" + count + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (m_haveAllocatedPaths)
	    {
		String msg = "paths have already been allocated.";
		throw new ConstructionOrderException(msg);
	    }

	    m_haveAllocatedPaths = true;
	    m_numPaths = count;
	    m_pathStart = new int[count + 1];
	}

	public void allocatePathLinks(int count)
	{
	    assertInConstruction();
	    if (count < 0)
	    {
		String msg = "count[" + count + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (m_haveAllocatedPathLinks)
	    {
		String msg = "links of paths have already been allocated.";
		throw new ConstructionOrderException(msg);
	    }

	    m_haveAllocatedPathLinks = true;
	    m_numPathLinks = count;
	    m_pathLinks = new int[count];
	}

	public int addLink(int source, int destination)
	{
	    assertInConstruction();
	    if (!m_haveAllocatedLinks)
	    {
		String msg = "links have not been allocated.";
		throw new ConstructionOrderException(msg);
	    }

	    if (m_numLinksAdded == m_numLinks)
	    {
		String msg = "attempted to add more links than allocated";
		throw new MisconstructionException(msg);
	    }

	    if (source < 0)
	    {
		String msg = "source[" + source + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (source >= m_numNodes)
	    {
		String msg = "source[" + source + "] references a node "
		    + "outside the allocated range of nodes";
		throw new ConstructionOrderException(msg);
	    }

	    if (destination < 0)
	    {
		String msg = "destination[" + destination
		    + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (destination >= m_numNodes)
	    {
		String msg = "destination[" + destination + "] references "
		    + "a node outside the allocated range of nodes";
		throw new ConstructionOrderException(msg);
	    }

	    m_linkSource[m_numLinksAdded] = source;
	    m_linkDestination[m_numLinksAdded] = destination;
	    return m_numLinksAdded++;
	}

	public int addPath()
	{
	    assertInConstruction();
	    if (!m_haveAllocatedPaths)
	    {
		String msg = "paths have not been allocated.";
		throw new ConstructionOrderException(msg);
	    }

	    if (m_numPathsAdded == m_numPaths)
	    {
		String msg = "attempted to add more paths than allocated";
		throw new MisconstructionException(msg);
	    }

	    m_pathStart[m_numPathsAdded] = m_numPathLinksAdded;
	    return m_numPathsAdded++;
	}

	public void addPathLink(int link)
	{
	    assertInConstruction();
	    if (!m_haveAllocatedPathLinks)
	    {
		String msg = "links of paths have not been allocated.";
		throw new ConstructionOrderException(msg);
	    }

	    if (m_numPathLinksAdded == m_numPathLinks)
	    {
		String msg =
		    "attempted to add more links to paths than allocated";
		throw new MisconstructionException(msg);
	    }

	    if (link < 0)
	    {
		String msg = "link[" + link + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (link >= m_numLinksAdded)
	    {
		String msg = "link[" + link + "] references a link that "
		    + "has yet to be added.";
		throw new ConstructionOrderException(msg);
	    }

	    m_pathLinks[m_numPathLinksAdded++] = link;
	}

	public int addAttributeDefinition(String name, ValueType type,
					  int enumeration, String expr)
	    throws DuplicateObjectException
	{
	    return addEitherAttributeDefinition
		(name, type, enumeration, expr, false, true, true, true);
	}

	public int addMutableAttributeDefinition
	    (String name, ValueType type, int enumeration, String expr,
	     boolean node, boolean link, boolean path)
	    throws DuplicateObjectException
	{
	    return addEitherAttributeDefinition
		(name, type, enumeration, expr, true, node, link, path);
	}

	public AttributeCreator addNodeAttribute(int node)
	{
	    assertInConstruction();
	    if (node < 0)
	    {
		String msg = "node[" + node + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (node >= m_numNodes)
	    {
		String msg = "node[" + node + "] references a node "
		    + "outside the allocated range of nodes";
		throw new ConstructionOrderException(msg);
	    }

	    if (m_currentAttributeDefinition == null)
	    {
		String msg =
		    "no attribute definition is currently being constructed";
		throw new MisconstructionException(msg);
	    }

	    if (!m_currentAttributeDefinition.includeNodes())
	    {
		String msg = "node attribute values were not allocated "
		    + "for current attribute definition";
		throw new MisconstructionException(msg);
	    }

	    return new AttributeCreatorImpl(ObjectType.NODE, node);
	}

	public AttributeCreator addLinkAttribute(int link)
	{
	    assertInConstruction();
	    if (link < 0)
	    {
		String msg = "link[" + link + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (link >= m_numLinksAdded)
	    {
		String msg = "link[" + link + "] references a link that "
		    + "has yet to be added.";
		throw new ConstructionOrderException(msg);
	    }

	    if (m_currentAttributeDefinition == null)
	    {
		String msg =
		    "no attribute definition is currently being constructed";
		throw new MisconstructionException(msg);
	    }

	    if (!m_currentAttributeDefinition.includeLinks())
	    {
		String msg = "link attribute values were not allocated "
		    + "for current attribute definition";
		throw new MisconstructionException(msg);
	    }

	    return new AttributeCreatorImpl(ObjectType.LINK, link);
	}

	public AttributeCreator addPathAttribute(int path)
	{
	    assertInConstruction();
	    if (path < 0)
	    {
		String msg = "path[" + path + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (path >= m_numPathsAdded)
	    {
		String msg = "path[" + path + "] references a path that "
		    + "has yet to be added.";
		throw new ConstructionOrderException(msg);
	    }

	    if (m_currentAttributeDefinition == null)
	    {
		String msg =
		    "no attribute definition is currently being constructed";
		throw new MisconstructionException(msg);
	    }

	    if (!m_currentAttributeDefinition.includePaths())
	    {
		String msg = "path attribute values were not allocated "
		    + "for current attribute definition";
		throw new MisconstructionException(msg);
	    }

	    return new AttributeCreatorImpl(ObjectType.PATH, path);
	}

	public AttributeCreator addObjectAttribute(ObjectType type, int id)
	{
	    assertInConstruction();
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return addNodeAttribute(id);
	    case ObjectType._LINK: return addLinkAttribute(id);
	    case ObjectType._PATH: return addPathAttribute(id);
	    default: throw new InternalErrorException();
	    }
	}

	public Graph endConstruction()
	{
	    endCommonConstruction();
	    endObjectConstruction();
	    endAttributeConstruction();
	    return ImmutableGraph.this;
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected void commitCurrentAttributeDefinition()
	{
	    if (m_currentAttributeDefinition != null)
	    {
		finishAddingCurrentAttributeDefinition();
		m_currentAttributeDefinition = null;
	    }
	}

	/////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	/////////////////////////////////////////////////////////////////////

	private int addEitherAttributeDefinition
	    (String name, ValueType type, int enumeration, String expr,
	     boolean isMutable, boolean node, boolean link, boolean path)
	    throws DuplicateObjectException
	{
	    assertInConstruction();
	    if (!m_attributeNames.add(name))
	    {
		String msg = "attribute definition["
		    + name + "] already exists";
		throw new DuplicateObjectException(msg);
	    }

	    EnumerationReader reader =
		(type.isEnumerationType()
		 ? ImmutableGraph.this.findEnumerationReader(enumeration)
		 : null);

	    commitCurrentAttributeDefinition();

	    int index = m_attributeDefinitions.allocate();
	    m_currentAttributeDefinition = new InterimAttributeDefinition
		(index, name, type, reader, expr, isMutable, node, link, path);

	    return index;
	}

	private void finishAddingCurrentAttributeDefinition()
	{
	    boolean isMutable = m_currentAttributeDefinition.isMutable();
	    int id = m_currentAttributeDefinition.getID();
	    String name = m_currentAttributeDefinition.getName();
	    ValueType type = m_currentAttributeDefinition.getType();
	    EnumerationReader reader =
		m_currentAttributeDefinition.getEnumerationReader();
	    String defaultExpr = m_currentAttributeDefinition.getExpr();
	    AttributeBuffer nodeAttributeBuffer = m_currentAttributeDefinition
		.getAttributeBuffer(ObjectType.NODE);
	    AttributeBuffer linkAttributeBuffer = m_currentAttributeDefinition
		.getAttributeBuffer(ObjectType.LINK);
	    AttributeBuffer pathAttributeBuffer = m_currentAttributeDefinition
		.getAttributeBuffer(ObjectType.PATH);

	    nodeAttributeBuffer.endConstruction();
	    linkAttributeBuffer.endConstruction();
	    pathAttributeBuffer.endConstruction();

	    boolean includeNodes = m_currentAttributeDefinition.includeNodes();
	    boolean includeLinks = m_currentAttributeDefinition.includeLinks();
	    boolean includePaths = m_currentAttributeDefinition.includePaths();

	    DefaultAttributeValues defaultValues = null;
	    if (defaultExpr != null)
	    {
		try
		{
		    ExprParser parser = new ExprParser
			(type, reader, defaultExpr);
		    defaultValues = parser.parse();
		}
		catch (ParseException e)
		{
		    String msg = "error parsing default expression \""
			+ defaultExpr + "\": " + e.getMessage();
		    throw new IllegalArgumentException(msg); // XXX
		}
	    }

	    AttributeValues nodeValues = createAttributeValues
		(isMutable, nodeAttributeBuffer,
		 m_numNodes, defaultValues, includeNodes);

	    AttributeValues linkValues = createAttributeValues
		(isMutable, linkAttributeBuffer,
		 m_numLinks, defaultValues, includeLinks);

	    AttributeValues pathValues = createAttributeValues
		(isMutable, pathAttributeBuffer,
		 m_numPaths, defaultValues, includePaths);

	    AttributeDefinition attributeDefinition = new AttributeDefinition
		(isMutable, id, name, type, reader, defaultExpr,
		 defaultValues, nodeValues, linkValues, pathValues,
		 includeNodes, includeLinks, includePaths);

	    m_attributeDefinitions.setValue(id, attributeDefinition);

	    Object oldValue = m_attributesMap.put(name, attributeDefinition);
	    if (oldValue != null)
	    {
		m_attributesMap.put(name, oldValue);
		String msg =
		    "attribute definition[" + name + "] already exists";
		throw new InternalErrorException(msg);
	    }
	}

	private AttributeValues createAttributeValues
	    (boolean isMutable, AttributeBuffer buffer, int maxNumObjects,
	     DefaultAttributeValues defaultValues, boolean include)
	{
	    AttributeValues retval = null;
	    if (isMutable)
	    {
		retval = createOptionalMutableAttributeValues
		    (buffer, maxNumObjects, defaultValues, include);
	    }
	    else
	    {
		retval = createImmutableAttributeValues
		    (buffer, maxNumObjects, defaultValues);
	    }
	    return retval;
	}

	private AttributeValues createImmutableAttributeValues
	    (AttributeBuffer buffer, int maxNumObjects,
	     DefaultAttributeValues defaultValues)
	{
	    AttributeValues retval = null;

	    if (maxNumObjects == 0)
	    {
		if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
		{
		    String msg = "Creating NoneAttributeValues "
			+ "(maxNumObjects == 0)...";
		    System.out.println(msg);
		}
		retval = new NoneAttributeValues
		    (buffer, maxNumObjects, defaultValues);
	    }
	    else
	    {
		int numUniqueObjects = buffer.getNumUniqueObjects();
		if (numUniqueObjects == 0)
		{
		    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
		    {
			String msg = "Creating NoneAttributeValues "
			    + "(numUniqueObjects == 0)...";
			System.out.println(msg);
		    }
		    retval = new NoneAttributeValues
			(buffer, maxNumObjects, defaultValues);
		}
		else if (numUniqueObjects == maxNumObjects)
		{
		    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
		    {
			String msg = "Creating AllAttributeValues "
			    + "(numUniqueObjects == maxNumObjects)...";
			System.out.println(msg);
		    }
		    retval = new AllAttributeValues(buffer, maxNumObjects);
		}
		else if (numUniqueObjects <= FEW_ATTRIBUTES_THRESHOLD)
		{
		    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
		    {
			String msg = "Creating ManyCompactAttributeValues "
			    + "(numUniqueObjects <= FEW_ATTRIBUTES_THRESHOLD)"
			    + "...";
			System.out.println(msg);
		    }
		    retval = new ManyCompactAttributeValues
			(buffer, maxNumObjects, defaultValues);
		}
		else if (maxNumObjects <= MIN_NUM_OBJECTS_THRESHOLD)
		{
		    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
		    {
			String msg = "Creating MostAttributeValues "
			    + "(maxNumObjects <= MIN_NUM_OBJECTS_THRESHOLD)"
			    + "...";
			System.out.println(msg);
		    }
		    retval = new MostAttributeValues
			(buffer, maxNumObjects, defaultValues);
		}
		else
		{
		    ValueType type = buffer.getType();
		    double ratio = numUniqueObjects / (double)maxNumObjects;

		    if (m_optimizationType == OptimizationType.FASTEST)
		    {
			boolean useIndexed = false;

			switch (type.getBaseType())
			{
			case ValueType._DOUBLE:
			    useIndexed = (ratio < 1.0 / 2.0);
			    break;

			case ValueType._FLOAT3:
			    useIndexed = (ratio < 2.0 / 3.0);
			    break;

			case ValueType._DOUBLE3:
			    useIndexed = (ratio < 5.0 / 6.0);
			    break;

			case ValueType._BOOLEAN:
			    //FALLTHROUGH
			case ValueType._INTEGER:
			    //FALLTHROUGH
			case ValueType._FLOAT:
			    //FALLTHROUGH
			case ValueType._STRING:
			    //FALLTHROUGH
			case ValueType._ENUMERATION:
			    // Do nothing.
			    break;
			default: throw new InternalErrorException();
			}
			
			if (useIndexed)
			{
			    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
			    {
				String msg =
				    "Creating IndexedAttributeValues "
				    + "(FASTEST)...";
				System.out.println(msg);
			    }
			    retval = new IndexedAttributeValues
				(buffer, maxNumObjects, defaultValues);
			}
			else
			{
			    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
			    {
				String msg =
				    "Creating MostAttributeValues "
				    + "(FASTEST)...";
				System.out.println(msg);
			    }
			    retval = new MostAttributeValues
				(buffer, maxNumObjects, defaultValues);
			}
		    }
		    else if (m_optimizationType == 
			     OptimizationType.SPACE_EFFICIENT)
		    {
			boolean useMany = false;
			boolean useCompact = false;

			switch (type.getBaseType())
			{
			case ValueType._ENUMERATION:
			    //FALLTHROUGH
			case ValueType._INTEGER:
			    //FALLTHROUGH
			case ValueType._FLOAT:
			    //FALLTHROUGH
			case ValueType._STRING:
			    useMany = (ratio < 31.0 / 64.0);
			    useCompact = (ratio < 31.0 / (2.0 * 64.0));
			    break;

			case ValueType._DOUBLE:
			    useMany = (ratio < 63.0 / 96.0);
			    useCompact = (ratio < 63.0 / (3.0 * 96.0));
			    break;

			case ValueType._FLOAT3:
			    useMany = (ratio < 95.0 / 128.0);
			    useCompact = (ratio < 95.0 / (4.0 * 128.0));
			    break;

			case ValueType._DOUBLE3:
			    useMany = (ratio < 191.0 / 224.0);
			    useCompact = (ratio < 191.0 / (4.0 * 224.0));
			    break;

			case ValueType._BOOLEAN:
			    // Do nothing.
			    break;
			default: throw new InternalErrorException();
			}

			if (useCompact)
			{
			    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
			    {
				String msg =
				    "Creating ManyCompactAttributeValues "
				    + "(SPACE_EFFICIENT)...";
				System.out.println(msg);
			    }
			    retval = new ManyCompactAttributeValues
				(buffer, maxNumObjects, defaultValues);
			}
			else if (useMany)
			{
			    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
			    {
				String msg =
				    "Creating ManyFastAttributeValues "
				    + "(SPACE_EFFICIENT)...";
				System.out.println(msg);
			    }
			    retval = new ManyFastAttributeValues
				(buffer, maxNumObjects, defaultValues);
			}
			else
			{
			    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
			    {
				String msg =
				    "Creating MostAttributeValues "
				    + "(SPACE_EFFICIENT)...";
				System.out.println(msg);
			    }
			    retval = new MostAttributeValues
				(buffer, maxNumObjects, defaultValues);
			}
		    }
		    else // OptimizationType.MINIMAL_SPACE
		    {
			boolean useCompact = false;

			switch (type.getBaseType())
			{
			case ValueType._ENUMERATION:
			    //FALLTHROUGH
			case ValueType._INTEGER:
			    //FALLTHROUGH
			case ValueType._FLOAT:
			    //FALLTHROUGH
			case ValueType._STRING:
			    useCompact = (ratio < 1.0 / 2.0);
			    break;

			case ValueType._DOUBLE:
			    useCompact = (ratio < 2.0 / 3.0);
			    break;

			case ValueType._FLOAT3:
			    useCompact = (ratio < 3.0 / 4.0);
			    break;

			case ValueType._DOUBLE3:
			    useCompact = (ratio < 6.0 / 7.0);
			    break;

			case ValueType._BOOLEAN:
			    // Do nothing.
			    break;
			default: throw new InternalErrorException();
			}

			if (useCompact)
			{
			    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
			    {
				String msg =
				    "Creating ManyCompactAttributeValues "
				    + "(MINIMAL_SPACE)...";
				System.out.println(msg);
			    }
			    retval = new ManyCompactAttributeValues
				(buffer, maxNumObjects, defaultValues);
			}
			else
			{
			    if (DEBUG && DEBUG_ATTRIBUTE_VALUES)
			    {
				String msg =
				    "Creating MostAttributeValues "
				    + "(MINIMAL_SPACE)...";
				System.out.println(msg);
			    }
			    retval = new MostAttributeValues
				(buffer, maxNumObjects, defaultValues);
			}
		    }
		}
	    }

	    return retval;
	}

	private void endObjectConstruction()
	{
	    if (!m_haveAllocatedNodes)
	    {
		String msg = "nodes have not been allocated.";
		throw new MisconstructionException(msg);
	    }

	    if (!m_haveAllocatedLinks)
	    {
		String msg = "links have not been allocated.";
		throw new MisconstructionException(msg);
	    }

	    if (m_numLinksAdded != m_numLinks)
	    {
		String msg = "only " + m_numLinksAdded + " of " + m_numLinks
		    + " links were added.";
		throw new MisconstructionException(msg);
	    }

	    if (!m_haveAllocatedPaths)
	    {
		String msg = "paths have not been allocated.";
		throw new MisconstructionException(msg);
	    }

	    if (m_numPathsAdded != m_numPaths)
	    {
		String msg = "only " + m_numPathsAdded + " of " + m_numPaths
		    + " paths were added.";
		throw new MisconstructionException(msg);
	    }

	    if (!m_haveAllocatedPathLinks)
	    {
		String msg = "links of paths have not been allocated.";
		throw new MisconstructionException(msg);
	    }

	    if (m_numPathLinksAdded != m_numPathLinks)
	    {
		String msg = "only " + m_numPathLinksAdded + " of "
		    + m_numPathLinks + " links of paths were added.";
		throw new MisconstructionException(msg);
	    }

	    // The following makes calculating the number of links in each
	    // path simpler.
	    m_pathStart[m_numPaths] = m_numPathLinks;

	    m_nodeOutgoingLinks = new int[m_numLinks];
	    computeLinkStart(m_nodeOutgoingStart, m_nodeOutgoingLinks,
			     m_linkSource);

	    m_nodeIncomingLinks = new int[m_numLinks];
	    computeLinkStart(m_nodeIncomingStart, m_nodeIncomingLinks,
			     m_linkDestination);
	}

	// start: will contain indexes into {links} where either the
	//        outgoing or incoming links of the nodes can be found
	// links: will contain either the outgoing or incoming links of nodes
	// nodes: contains either the source or destination of all links
	private void computeLinkStart(int[] start, int[] links, int[] nodes)
	{
	    if (start.length != m_numNodes + 1
		|| links.length != m_numLinks
		|| nodes.length != m_numLinks)
	    {
		throw new IllegalArgumentException("wrong array length");
	    }

	    Arrays.fill(start, 0);
	    if (m_numLinks > 0)
	    {
		// Calculate degree (out/in) of nodes.
		for (int i = 0; i < nodes.length; i++)
		{
		    ++start[nodes[i]];
		}

		// Convert degrees to starting indexes.
		// Store temporary counters in the links array.
		{
		    // NOTE: We also set the element at [numNodes] to make
		    //       calculating degrees simpler elsewhere in
		    //       ImmutableGraph.
		    int index = 0;
		    for (int i = 0; i < start.length; i++)
		    {
			int degree = start[i];
			if (degree > 0)
			{
			    // This value is used later during population to
			    // determine at what offset from the starting
			    // index to actually store a link ID.
			    links[index] = -degree;
			}

			start[i] = index;
			index += degree;
		    }
		}

		// Populate the list of links for each node.
		// Note that in this implementation, the order of the
		// links will be reversed, which is permitted but perhaps
		// a little undesirable.
		for (int i = 0; i < nodes.length; i++)
		{
		    int node = nodes[i];
		    int count = links[start[node]];
		    if (count >= 0)
		    {
			String msg =
			    "list count[" + count + "] is not negative";
			throw new InternalErrorException(msg);
		    }

		    links[start[node] - count - 1] = i;
		    if (count < -1)
		    {
			++links[start[node]];
		    }
		}
	    }
	}

	private void endAttributeConstruction()
	{
	    if (m_currentAttributeDefinition != null)
	    {
		finishAddingCurrentAttributeDefinition();
		m_currentAttributeDefinition = null;
	    }
	}

	/////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	/////////////////////////////////////////////////////////////////////

	private InterimAttributeDefinition  m_currentAttributeDefinition;
	private Set  m_attributeNames = new HashSet();

	/////////////////////////////////////////////////////////////////////
	// PRIVATE INNER CLASSES
	/////////////////////////////////////////////////////////////////////

	private class AttributeCreatorImpl
	    implements AttributeCreator
	{
	    public AttributeCreatorImpl(ObjectType type, int id)
	    {
		m_type = type;
		m_id = id;
		m_savedAttributeDefinition = m_currentAttributeDefinition;
		m_sequence =
		    m_currentAttributeDefinition.allocateSequence(type);
		m_attributeBuffer =
		    m_currentAttributeDefinition.getAttributeBuffer(type);

		m_attributeBuffer.registerObject(id);
	    }

	    public void addBooleanValue(boolean value)
	    {
		checkFreshness();
		m_attributeBuffer.appendBooleanValue(m_id, value);
	    }

	    public void addIntegerValue(int value)
	    {
		checkFreshness();
		m_attributeBuffer.appendIntegerValue(m_id, value);
	    }

	    public void addFloatValue(float value)
	    {
		checkFreshness();
		m_attributeBuffer.appendFloatValue(m_id, value);
	    }

	    public void addDoubleValue(double value)
	    {
		checkFreshness();
		m_attributeBuffer.appendDoubleValue(m_id, value);
	    }

	    public void addStringValue(String value)
	    {
		checkFreshness();
		m_attributeBuffer.appendStringValue(m_id, value);
	    }

	    public void addFloat3Value(float x, float y, float z)
	    {
		checkFreshness();
		m_attributeBuffer.appendFloat3Value(m_id, x, y, z);
	    }

	    public void addFloat3Value(float[] values)
	    {
		checkFreshness();
		m_attributeBuffer.appendFloat3Value(m_id, values);
	    }

	    public void addDouble3Value(double x, double y, double z)
	    {
		checkFreshness();
		m_attributeBuffer.appendDouble3Value(m_id, x, y, z);
	    }

	    public void addDouble3Value(double[] values)
	    {
		checkFreshness();
		m_attributeBuffer.appendDouble3Value(m_id, values);
	    }

	    public void addEnumerationValue(String enumerator)
	    {
		checkFreshness();
		EnumerationReader enumeration = getEnumerationReader();
		EnumeratorReader reader =
		    enumeration.getEnumeratorReader(enumerator);
		m_attributeBuffer.appendEnumerationValue(m_id, reader);
	    }

	    public void addEnumerationValue(int enumerator)
	    {
		checkFreshness();
		EnumerationReader enumeration = getEnumerationReader();
		EnumeratorReader reader =
		    enumeration.getEnumeratorReader(enumerator);
		m_attributeBuffer.appendEnumerationValue(m_id, reader);
	    }

	    private EnumerationReader getEnumerationReader()
	    {
		if (!m_currentAttributeDefinition
		    .getType().isEnumerationType())
		{
		    throw new TypeMismatchException();
		}
		return m_currentAttributeDefinition.getEnumerationReader();
	    }

	    private void checkFreshness()
	    {
		assertInConstruction();
		if (m_currentAttributeDefinition != m_savedAttributeDefinition)
		{
		    String msg = "attempted to use an AttributeCreator "
			+ "after the end of the construction of its "
			+ "attribute";
		    throw new MisconstructionException(msg);
		}

		if (m_sequence
		    != m_currentAttributeDefinition.getSequence(m_type))
		{
		    String msg = "attempted to interleave operations on "
			+ "two or more AttributeCreators while constructing "
			+ "the same attribute";
		    throw new MisconstructionException(msg);
		}
	    }

	    private ObjectType  m_type;
	    private int  m_id;
	    private InterimAttributeDefinition  m_savedAttributeDefinition;
	    private int  m_sequence;
	    private AttributeBuffer  m_attributeBuffer;
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE NESTED CLASSES & INTERFACES
    ///////////////////////////////////////////////////////////////////////

    private static class InterimAttributeDefinition
    {
	public InterimAttributeDefinition
	    (int id, String name, ValueType type,
	     EnumerationReader reader, String expr, boolean isMutable,
	     boolean includeNodes, boolean includeLinks, boolean includePaths)
	{
	    m_id = id;
	    m_name = name;
	    m_type = type;
	    m_reader = reader;
	    m_expr = expr;
	    m_isMutable = isMutable;
	    m_includeNodes = includeNodes;
	    m_includeLinks = includeLinks;
	    m_includePaths = includePaths;

	    if (type.isListType())
	    {
		m_nodeAttributes = new ListAttributeBuffer(type, reader);
		m_linkAttributes = new ListAttributeBuffer(type, reader);
		m_pathAttributes = new ListAttributeBuffer(type, reader);
	    }
	    else
	    {
		m_nodeAttributes = new ScalarAttributeBuffer(type, reader);
		m_linkAttributes = new ScalarAttributeBuffer(type, reader);
		m_pathAttributes = new ScalarAttributeBuffer(type, reader);
	    }
	}

	public int getID()
	{
	    return m_id;
	}

	public String getName()
	{
	    return m_name;
	}

	public ValueType getType()
	{
	    return m_type;
	}

	public EnumerationReader getEnumerationReader()
	{
	    return m_reader;
	}

	public String getExpr()
	{
	    return m_expr;
	}

	public boolean isMutable()
	{
	    return m_isMutable;
	}

	public boolean includeNodes()
	{
	    return m_includeNodes;
	}

	public boolean includeLinks()
	{
	    return m_includeLinks;
	}

	public boolean includePaths()
	{
	    return m_includePaths;
	}

	public int getSequence(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return m_nodeSequence;
	    case ObjectType._LINK: return m_linkSequence;
	    case ObjectType._PATH: return m_pathSequence;
	    default: throw new InternalErrorException();
	    }
	}

	public AttributeBuffer getAttributeBuffer(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return m_nodeAttributes;
	    case ObjectType._LINK: return m_linkAttributes;
	    case ObjectType._PATH: return m_pathAttributes;
	    default: throw new InternalErrorException();
	    }
	}

	public int allocateSequence(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return ++m_nodeSequence;
	    case ObjectType._LINK: return ++m_linkSequence;
	    case ObjectType._PATH: return ++m_pathSequence;
	    default: throw new InternalErrorException();
	    }
	}

	private int  m_id;
	private String  m_name;
	private ValueType  m_type;
	private EnumerationReader  m_reader;  // may be null
	private String  m_expr;               // may be null
	private boolean  m_isMutable;
	private boolean  m_includeNodes;
	private boolean  m_includeLinks;
	private boolean  m_includePaths;

	private int  m_nodeSequence;
	private int  m_linkSequence;
	private int  m_pathSequence;

	private AttributeBuffer  m_nodeAttributes;
	private AttributeBuffer  m_linkAttributes;
	private AttributeBuffer  m_pathAttributes;
    }


    ///////////////////////////////////////////////////////////////////////

    private interface DefaultAttributeValues
    {
	ValueIterator getAttribute(int object);
	boolean getBooleanAttribute(int object);
	int getIntegerAttribute(int object);
	float getFloatAttribute(int object);
	double getDoubleAttribute(int object);
	String getStringAttribute(int object);
	float[] getFloat3Attribute(int object);
	void getFloat3Attribute(int object, float[] values);
	double[] getDouble3Attribute(int object);
	void getDouble3Attribute(int object, double[] values);
	int getEnumerationAttribute(int object);
	int getEvaluatedEnumerationAttribute(int object);
    }

    ///////////////////////////////////////////////////////////////////////

    private interface AttributeValues
    {
	boolean hasValueFor(int object);
	int findNextObjectWithValue(int object);
	int getMaxNumObjects();

	ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException;

	boolean getBooleanAttribute(int object)
	    throws AttributeUnavailableException;
	int getIntegerAttribute(int object)
	    throws AttributeUnavailableException;
	float getFloatAttribute(int object)
	    throws AttributeUnavailableException;
	double getDoubleAttribute(int object)
	    throws AttributeUnavailableException;
	String getStringAttribute(int object)
	    throws AttributeUnavailableException;
	float[] getFloat3Attribute(int object)
	    throws AttributeUnavailableException;
	void getFloat3Attribute(int object, float[] values)
	    throws AttributeUnavailableException;
	double[] getDouble3Attribute(int object)
	    throws AttributeUnavailableException;
	void getDouble3Attribute(int object, double[] values)
	    throws AttributeUnavailableException;
	int getEnumerationAttribute(int object)
	    throws AttributeUnavailableException;
	int getEvaluatedEnumerationAttribute(int object)
	    throws AttributeUnavailableException;

	void setBooleanAttribute(int object, boolean value);
	void setIntegerAttribute(int object, int value);
	void setFloatAttribute(int object, float value);
	void setDoubleAttribute(int object, double value);
	void setStringAttribute(int object, String value);
	void setFloat3Attribute(int object, float x, float y, float z);
	void setFloat3Attribute(int object, float[] values);
        void setDouble3Attribute(int object, double x, double y, double z);
	void setDouble3Attribute(int object, double[] values);
	void setEnumerationAttribute(int object, String enumerator);
	void setEnumerationAttribute(int object, int enumerator);
	
	void setDefaultAttributeValues(DefaultAttributeValues defaultValues);
    }

    ///////////////////////////////////////////////////////////////////////

    private static abstract class AbstractAttributeValues
	implements AttributeValues
    {
	public AbstractAttributeValues
	    (ValueType type, EnumerationReader reader, int maxNumObjects)
	{
	    if (maxNumObjects < 0)
	    {
		String msg =
		    "maxNumObjects[" + maxNumObjects + " must be nonnegative";
		throw new IllegalArgumentException(msg);
	    }

	    if (type.isEnumerationType() && reader == null)
	    {
		String msg = "missing EnumerationReader";
		throw new IllegalArgumentException(msg);
	    }

	    m_type = type;
	    m_reader = reader;
	    m_maxNumObjects = maxNumObjects;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public int getMaxNumObjects()
	{
	    return m_maxNumObjects;
	}

	public void setDefaultAttributeValues
	    (DefaultAttributeValues defaultValues)
	{
	    m_defaultValues = defaultValues;
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected final void validateObjectID(int object)
	{
	    if (object < 0)
	    {
		String msg = "object id[" + object + "] must be nonnegative.";
		throw new IllegalArgumentException(msg);
	    }

	    if (object >= m_maxNumObjects)
	    {
		String msg = "object id[" + object + "] must be >= 0 and < "
		    + m_maxNumObjects + ".";
		throw new IndexOutOfBoundsException(msg);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED FIELDS
	////////////////////////////////////////////////////////////////////

	protected ValueType  m_type;
	protected EnumerationReader  m_reader;
	protected int  m_maxNumObjects;
	protected DefaultAttributeValues  m_defaultValues;
    }

    ///////////////////////////////////////////////////////////////////////

    private static abstract class BinArrayAttributeValues
	extends AbstractAttributeValues
    {
	public BinArrayAttributeValues(SharedHeap heap, ValueType type,
				       EnumerationReader reader,
				       int maxNumObjects)
	{
	    super(type, reader, maxNumObjects);
	    if (type.isBaseType())
	    {
		throw new IllegalArgumentException("expected list type");
	    }

	    m_heap = heap;
	    allocateBinArraySlots();
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public boolean getBooleanAttribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public int getIntegerAttribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public float getFloatAttribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public double getDoubleAttribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public String getStringAttribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public float[] getFloat3Attribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public void getFloat3Attribute(int object, float[] values)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public double[] getDouble3Attribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public void getDouble3Attribute(int object, double[] values)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public int getEnumerationAttribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public int getEvaluatedEnumerationAttribute(int object)
	    throws AttributeUnavailableException
	{ throw new TypeMismatchException(); }

	public void setBooleanAttribute(int object, boolean value)
	{ throw new TypeMismatchException(); }

	public void setIntegerAttribute(int object, int value)
	{ throw new TypeMismatchException(); }

	public void setFloatAttribute(int object, float value)
	{ throw new TypeMismatchException(); }

	public void setDoubleAttribute(int object, double value)
	{ throw new TypeMismatchException(); }

	public void setStringAttribute(int object, String value)
	{ throw new TypeMismatchException(); }

	public void setFloat3Attribute(int object, float x, float y, float z)
	{ throw new TypeMismatchException(); }

	public void setFloat3Attribute(int object, float[] values)
	{ throw new TypeMismatchException(); }

        public void setDouble3Attribute(int object,
					double x, double y, double z)
	{ throw new TypeMismatchException(); }

	public void setDouble3Attribute(int object, double[] values)
	{ throw new TypeMismatchException(); }

	public void setEnumerationAttribute(int object, String enumerator)
	{ throw new TypeMismatchException(); }

	public void setEnumerationAttribute(int object, int enumerator)
	{ throw new TypeMismatchException(); }

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	// NOTE: This assumes that m_binArray is empty to begin with.
	//       Furthermore, since we must allocate elements at a particular
	//       range of indices, m_binArray must have been newly-allocated
	//       or clear()'d, rather than simply emptied by freeing elements.
	private void allocateBinArraySlots()
	{
	    for (int i = 0; i < m_maxNumObjects; i++)
	    {
		if (m_binArray.allocate() != i)
		{
		    String msg = "IntBinArray.allocate() didn't return " + i;
		    throw new InternalErrorException(msg);
		}
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED FIELDS
	////////////////////////////////////////////////////////////////////

	protected SharedHeap  m_heap;
	protected IntBinArray  m_binArray = new IntBinArray(true);

	////////////////////////////////////////////////////////////////////
	// PROTECTED INNER CLASSES
	////////////////////////////////////////////////////////////////////

	protected class ValueIteratorImpl
	    implements ValueIterator
	{
	    // {iterator} must be the ValueIterator of m_binArray.
	    public ValueIteratorImpl(ValueIterator iterator)
	    {
		m_iterator = iterator;
	    }

	    public boolean atEnd()
	    {
		return m_iterator.atEnd();
	    }

	    public void advance()
	    {
		m_iterator.advance();
	    }

	    public void rewind()
	    {
		m_iterator.rewind();
	    }

	    public boolean isEmpty()
	    {
		return m_iterator.isEmpty();
	    }

	    public int getLength()
	    {
		return m_iterator.getLength();
	    }

	    public ValueType getType()
	    {
		return m_type;
	    }

	    public boolean getBooleanValue()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.BOOLEAN_LIST)
		{
		    throw new TypeMismatchException();
		}
		return m_iterator.getIntegerValue() != 0;
	    }

	    public int getIntegerValue()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.INTEGER_LIST)
		{
		    throw new TypeMismatchException();
		}
		return m_iterator.getIntegerValue();
	    }

	    public float getFloatValue()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.FLOAT_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		return m_heap.getFloatArray().getValue(index);
	    }

	    public double getDoubleValue()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.DOUBLE_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		return m_heap.getDoubleArray().getValue(index);
	    }

	    public String getStringValue()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.STRING_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		return m_heap.getStringArray().getValue(index);
	    }

	    public float[] getFloat3Value()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.FLOAT3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		return m_heap.getFloat3Array().getValue(index);
	    }

	    public void getFloat3Value(float[] values)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.FLOAT3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getFloat3Array().getValue(index, values);
	    }

	    public double[] getDouble3Value()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.DOUBLE3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		return m_heap.getDouble3Array().getValue(index);
	    }

	    public void getDouble3Value(double[] values)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.DOUBLE3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getDouble3Array().getValue(index, values);
	    }

	    public int getEnumerationValue()
	    {
		EnumeratorReader reader = getInitializedEnumerationAttribute();
		return reader.getID();
	    }

	    public int getEvaluatedEnumerationValue()
	    {
		EnumeratorReader reader = getInitializedEnumerationAttribute();
		return reader.getValue();
	    }

	    public void setBooleanValue(boolean value)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.BOOLEAN_LIST)
		{
		    throw new TypeMismatchException();
		}
		m_iterator.setIntegerValue(value ? 1 : 0);
	    }

	    public void setIntegerValue(int value)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.INTEGER_LIST)
		{
		    throw new TypeMismatchException();
		}
		m_iterator.setIntegerValue(value);
	    }

	    public void setFloatValue(float value)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.FLOAT_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getFloatArray().setValue(index, value);
	    }

	    public void setDoubleValue(double value)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.DOUBLE_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getDoubleArray().setValue(index, value);
	    }

	    public void setStringValue(String value)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.STRING_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getStringArray().setValue(index, value);
	    }

	    public void setFloat3Value(float x, float y, float z)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.FLOAT3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getFloat3Array().setValue(index, x, y, z);
	    }

	    public void setFloat3Value(float[] values)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.FLOAT3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getFloat3Array().setValue(index, values);
	    }

	    public void setDouble3Value(double x, double y, double z)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.DOUBLE3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getDouble3Array().setValue(index, x, y, z);
	    }

	    public void setDouble3Value(double[] values)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.DOUBLE3_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		m_heap.getDouble3Array().setValue(index, values);
	    }

	    public void setEnumerationValue(String enumerator)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.ENUMERATION_LIST)
		{
		    throw new TypeMismatchException();
		}
		EnumeratorReader value =
		    m_reader.getEnumeratorReader(enumerator);
		int index = m_iterator.getIntegerValue();
		m_heap.getObjectArray().setValue(index, value);
	    }

	    public void setEnumerationValue(int enumerator)
	    {
		assertNotAtEnd();
		if (m_type != ValueType.ENUMERATION_LIST)
		{
		    throw new TypeMismatchException();
		}
		EnumeratorReader value =
		    m_reader.getEnumeratorReader(enumerator);
		int index = m_iterator.getIntegerValue();
		m_heap.getObjectArray().setValue(index, value);
	    }

	    public void removeValue()
	    {
		assertNotAtEnd();
		int index = m_iterator.getIntegerValue();
		switch (m_type.getBaseType())
		{
		case ValueType._FLOAT:
		    m_heap.getFloatArray().free(index);
		    break;

		case ValueType._DOUBLE:
		    m_heap.getDoubleArray().free(index);
		    break;

		case ValueType._STRING:
		    m_heap.getStringArray().free(index);
		    break;

		case ValueType._FLOAT3:
		    m_heap.getFloat3Array().free(index);
		    break;

		case ValueType._DOUBLE3:
		    m_heap.getDouble3Array().free(index);
		    break;

		case ValueType._ENUMERATION:
		    m_heap.getObjectArray().free(index);
		    break;

		case ValueType._BOOLEAN:
		    //FALLTHROUGH
		case ValueType._INTEGER:
		    // Do nothing.
		    break;
		default: throw new InternalErrorException();
		}
		m_iterator.removeValue();
	    }

	    public void insertValue()
	    {
		m_iterator.insertValue();
		allocateValue();
	    }

	    public void appendValue()
	    {
		m_iterator.appendValue();
		allocateValue();
	    }

	    protected EnumeratorReader getInitializedEnumerationAttribute()
	    {
		assertNotAtEnd();
		if (m_type != ValueType.ENUMERATION_LIST)
		{
		    throw new TypeMismatchException();
		}
		int index = m_iterator.getIntegerValue();
		EnumeratorReader reader =
		    (EnumeratorReader)m_heap.getObjectArray().getValue(index);
		if (reader == null || reader.isRemoved())
		{
		    throw new UninitializedDataException();
		}
		return reader;
	    }

	    protected void allocateValue()
	    {
		int index = 0;
		switch (m_type.getBaseType())
		{
		case ValueType._FLOAT:
		    index = m_heap.getFloatArray().allocate();
		    break;

		case ValueType._DOUBLE:
		    index = m_heap.getDoubleArray().allocate();
		    break;

		case ValueType._STRING:
		    index = m_heap.getStringArray().allocate();
		    break;

		case ValueType._FLOAT3:
		    index = m_heap.getFloat3Array().allocate();
		    break;

		case ValueType._DOUBLE3:
		    index = m_heap.getDouble3Array().allocate();
		    break;

		case ValueType._ENUMERATION:
		    index = m_heap.getObjectArray().allocate();
		    break;

		case ValueType._BOOLEAN:
		    //FALLTHROUGH
		case ValueType._INTEGER:
		    // Do nothing.
		    break;
		default: throw new InternalErrorException();
		}

		// When the type is boolean, a value of 0 for `index' is
		// exactly what we want (for the default value of false).
		// When the type is integer, setting the value to zero
		// doesn't hurt anything.
		m_iterator.setIntegerValue(index);
	    }

	    protected void assertNotAtEnd()
	    {
		if (m_iterator.atEnd())
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    protected ValueIterator  m_iterator;
	}

	////////////////////////////////////////////////////////////////////

	protected class ValueCopier
	{
	    public ValueCopier(AttributeBuffer buffer)
	    {
		m_buffer = buffer;
	    }

	    // {iterator} must be an iterator of m_binArray.
	    public void copy(ValueIterator iterator, int source)
	    {
		int index = 0;
		iterator.appendValue();
		switch (m_type.getBaseType())
		{
		case ValueType._BOOLEAN:
		    index = (m_buffer.getBooleanValue(source) ? 1 : 0);
		    break;

		case ValueType._INTEGER:
		    index = m_buffer.getIntegerValue(source);
		    break;

		case ValueType._FLOAT:
		    {
			FloatArray array = m_heap.getFloatArray();
			index = array.allocate();
			array.setValue(index, m_buffer.getFloatValue(source));
		    }
		    break;

		case ValueType._DOUBLE:
		    {
			DoubleArray array = m_heap.getDoubleArray();
			index = array.allocate();
			array.setValue(index, m_buffer.getDoubleValue(source));
		    }
		    break;

		case ValueType._STRING:
		    {
			StringArray array = m_heap.getStringArray();
			index = array.allocate();
			array.setValue(index, m_buffer.getStringValue(source));
		    }
		    break;

		case ValueType._FLOAT3:
		    {
			m_buffer.getFloat3Value(source, m_floatArray);
			Float3Array array = m_heap.getFloat3Array();
			index = array.allocate();
			array.setValue(index, m_floatArray);
		    }
		    break;

		case ValueType._DOUBLE3:
		    {
			m_buffer.getDouble3Value(source, m_doubleArray);
			Double3Array array = m_heap.getDouble3Array();
			index = array.allocate();
			array.setValue(index, m_doubleArray);
		    }
		    break;

		case ValueType._ENUMERATION:
		    {
			ObjectArray array = m_heap.getObjectArray();
			index = array.allocate();
			array.setValue
			    (index, m_buffer.getEnumerationValue(source));
		    }
		    break;

		default: throw new InternalErrorException();
		}

		iterator.setIntegerValue(index);
	    }

	    private AttributeBuffer  m_buffer;
	    private float[]  m_floatArray = new float[3];
	    private double[]  m_doubleArray = new double[3];
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static class MutableListAttributeValues
	extends BinArrayAttributeValues
    {
	public MutableListAttributeValues(SharedHeap heap, ValueType type,
					  EnumerationReader reader,
					  int maxNumObjects)
	{
	    super(heap, type, reader, maxNumObjects);
	    if (type.isBaseType())
	    {
		throw new IllegalArgumentException("expected list type");
	    }
	}

	public MutableListAttributeValues(SharedHeap heap,
					  AttributeBuffer buffer,
					  int maxNumObjects)
	{
	    this(heap, buffer.getType(),
		  buffer.getEnumerationReader(), maxNumObjects);

	    // NOTE: We don't require the user to supply an initial value
	    //       for all possible objects (maxNumObjects).  Objects 
	    //       without explicit initial values will have the default
	    //       values supplied by Java (such as false for booleans,
	    //       and 0 for integers).

	    // XXX: Actually, we should probably initialize any objects
	    //      not given explicit initial values with the result of
	    //      evaluating the default expression, if given.

	    ValueCopier copier = new ValueCopier(buffer);

	    int numObjects = buffer.getNumUniqueObjects();
	    for (int i = 0; i < numObjects; i++)
	    {
		int object = buffer.getObject(i);
		ValueIterator iterator = m_binArray.getValue(object);

		int start = buffer.getValueStart(i);
		int end = start + buffer.getValueLength(i);
		for (int j = start; j < end; j++)
		{
		    copier.copy(iterator, j);
		}
	    }
	}

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    return true;
	}

	public int findNextObjectWithValue(int object)
	{
	    validateObjectID(object);
	    return (object + 1 < m_maxNumObjects ? object + 1 : -1);
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);

	    ValueIterator retval = m_binArray.getValue(object);
	    if (m_type != ValueType.INTEGER_LIST)
	    {
		retval = new ValueIteratorImpl(retval);
	    }
	    return retval;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static abstract class ArrayAttributeValues
	extends AbstractAttributeValues
    {
	public ArrayAttributeValues
	    (ValueType type, EnumerationReader reader, int maxNumObjects)
	{
	    super(type, reader, maxNumObjects);
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public boolean getBooleanAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_booleanValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getBooleanAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getBooleanAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public int getIntegerAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_integerValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getIntegerAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getIntegerAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public float getFloatAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_floatValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getFloatAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getFloatAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public double getDoubleAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_doubleValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getDoubleAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getDoubleAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public String getStringAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_stringValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getStringAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getStringAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public float[] getFloat3Attribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_floatXValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getFloat3AttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getFloat3Attribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public void getFloat3Attribute(int object, float[] values)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_floatXValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		getFloat3AttributeAtIndex(index, values);
	    }
	    else if (m_defaultValues != null)
	    {
		m_defaultValues.getFloat3Attribute(object, values);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public double[] getDouble3Attribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_doubleXValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getDouble3AttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getDouble3Attribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public void getDouble3Attribute(int object, double[] values)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_doubleXValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		getDouble3AttributeAtIndex(index, values);
	    }
	    else if (m_defaultValues != null)
	    {
		m_defaultValues.getDouble3Attribute(object, values);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public int getEnumerationAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_enumerationValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getEnumerationAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return m_defaultValues.getEnumerationAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	public int getEvaluatedEnumerationAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_enumerationValues == null || m_type.isListType())
	    {
		throw new TypeMismatchException();
	    }
	    int index = findObject(object);
	    if (index >= 0)
	    {
		return getEvaluatedEnumerationAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		return
		    m_defaultValues.getEvaluatedEnumerationAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected int findObject(int object)
	{
	    return object;
	}

	protected boolean getBooleanAttributeAtIndex(int index)
	{
	    return m_booleanValues.get(index);
	}

	protected int getIntegerAttributeAtIndex(int index)
	{
	    return m_integerValues[index];
	}

	protected float getFloatAttributeAtIndex(int index)
	{
	    return m_floatValues[index];
	}

	protected double getDoubleAttributeAtIndex(int index)
	{
	    return m_doubleValues[index];
	}

	protected String getStringAttributeAtIndex(int index)
	{
	    return m_stringValues[index];
	}

	protected float[] getFloat3AttributeAtIndex(int index)
	{
	    float[] retval = new float[3];
	    retval[0] = m_floatXValues[index];
	    retval[1] = m_floatYValues[index];
	    retval[2] = m_floatZValues[index];
	    return retval;
	}

	protected void getFloat3AttributeAtIndex(int index, float[] values)
	{
	    values[0] = m_floatXValues[index];
	    values[1] = m_floatYValues[index];
	    values[2] = m_floatZValues[index];
	}

	protected double[] getDouble3AttributeAtIndex(int index)
	{
	    double[] retval = new double[3];
	    retval[0] = m_doubleXValues[index];
	    retval[1] = m_doubleYValues[index];
	    retval[2] = m_doubleZValues[index];
	    return retval;
	}

	protected void getDouble3AttributeAtIndex(int index, double[] values)
	{
	    values[0] = m_doubleXValues[index];
	    values[1] = m_doubleYValues[index];
	    values[2] = m_doubleZValues[index];
	}

	protected int getEnumerationAttributeAtIndex(int index)
	{
	    return getEnumerationAttributeWithCheck(index);
	}

	protected int getEvaluatedEnumerationAttributeAtIndex(int index)
	{
	    return getEvaluatedEnumerationAttributeWithCheck(index);
	}

	////////////////////////////////////////////////////////////////////

	protected final int getEnumerationAttributeWithCheck(int index)
	{
	    return getInitializedEnumerationAttribute(index).getID();
	}

	protected final int
	    getEvaluatedEnumerationAttributeWithCheck(int index)
	{
	    return getInitializedEnumerationAttribute(index).getValue();
	}

	protected final EnumeratorReader
	    getInitializedEnumerationAttribute(int index)
	{
	    EnumeratorReader reader = m_enumerationValues[index];
	    if (reader == null || reader.isRemoved())
	    {
		throw new UninitializedDataException();
	    }
	    return reader;
	}

	protected final void allocateValues
	    (ValueType type, int numObjects, int numValues)
	{
	    if (type.isListType())
	    {
		m_length = new int[numObjects];
		m_start = new int[numObjects];
	    }

	    switch (type.getBaseType())
	    {
	    case ValueType._BOOLEAN:
		m_booleanValues = new BitSet(numValues);
		break;
	    case ValueType._INTEGER:
		m_integerValues = new int[numValues];
		break;
	    case ValueType._FLOAT:
		m_floatValues = new float[numValues];
		break;
	    case ValueType._DOUBLE:
		m_doubleValues = new double[numValues];
		break;
	    case ValueType._STRING:
		m_stringValues = new String[numValues];
		break;
	    case ValueType._FLOAT3:
		m_floatXValues = new float[numValues];
		m_floatYValues = new float[numValues];
		m_floatZValues = new float[numValues];
		break;
	    case ValueType._DOUBLE3:
		m_doubleXValues = new double[numValues];
		m_doubleYValues = new double[numValues];
		m_doubleZValues = new double[numValues];
		break;
	    case ValueType._ENUMERATION:
		m_enumerationValues = new EnumeratorReader[numValues];
		break;
	    default: throw new InternalErrorException();
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED FIELDS
	////////////////////////////////////////////////////////////////////

	protected BitSet  m_booleanValues;
	protected int[]  m_integerValues;
	protected float[]  m_floatValues;
	protected double[]  m_doubleValues;
	protected String[]  m_stringValues;
	protected float[]  m_floatXValues;
	protected float[]  m_floatYValues;
	protected float[]  m_floatZValues;
	protected double[]  m_doubleXValues;
	protected double[]  m_doubleYValues;
	protected double[]  m_doubleZValues;
	protected EnumeratorReader[]  m_enumerationValues;

	protected int[]  m_length;
	protected int[]  m_start;

	////////////////////////////////////////////////////////////////////
	// PROTECTED INNER CLASSES
	////////////////////////////////////////////////////////////////////

	protected abstract class AbstractValueIteratorImpl
	    implements ValueIterator
	{
	    public AbstractValueIteratorImpl(int start, int end)
	    {
		if (start < 0 || end < 0 || end < start)
		{
		    throw new IllegalArgumentException();
		}

		m_start = start;
		m_end = end;
		m_current = start;
	    }

	    public boolean atEnd()
	    {
		return m_current == m_end;
	    }

	    public void advance()
	    {
		if (m_current < m_end)
		{
		    ++m_current;
		}
	    }

	    public void rewind()
	    {
		m_current = m_start;
	    }

	    public boolean isEmpty()
	    {
		return getLength() == 0;
	    }

	    public int getLength()
	    {
		return m_end - m_start;
	    }

	    public ValueType getType()
	    {
		return m_type;
	    }

	    public boolean getBooleanValue()
	    {
		assertNotAtEnd();
		if (m_booleanValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getBooleanAttributeAtIndex(m_current);
	    }

	    public int getIntegerValue()
	    {
		assertNotAtEnd();
		if (m_integerValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getIntegerAttributeAtIndex(m_current);
	    }

	    public float getFloatValue()
	    {
		assertNotAtEnd();
		if (m_floatValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getFloatAttributeAtIndex(m_current);
	    }

	    public double getDoubleValue()
	    {
		assertNotAtEnd();
		if (m_doubleValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getDoubleAttributeAtIndex(m_current);
	    }

	    public String getStringValue()
	    {
		assertNotAtEnd();
		if (m_stringValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getStringAttributeAtIndex(m_current);
	    }

	    public float[] getFloat3Value()
	    {
		assertNotAtEnd();
		if (m_floatXValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getFloat3AttributeAtIndex(m_current);
	    }

	    public void getFloat3Value(float[] values)
	    {
		if (m_floatXValues == null)
		{
		    throw new TypeMismatchException();
		}
		ArrayAttributeValues.this
		    .getFloat3AttributeAtIndex(m_current, values);
	    }

	    public double[] getDouble3Value()
	    {
		assertNotAtEnd();
		if (m_doubleXValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getDouble3AttributeAtIndex(m_current);
	    }

	    public void getDouble3Value(double[] values)
	    {
		assertNotAtEnd();
		if (m_doubleXValues == null)
		{
		    throw new TypeMismatchException();
		}
		ArrayAttributeValues.this
		    .getDouble3AttributeAtIndex(m_current, values);
	    }

	    public int getEnumerationValue()
	    {
		assertNotAtEnd();
		if (m_enumerationValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getEnumerationAttributeAtIndex(m_current);
	    }

	    public int getEvaluatedEnumerationValue()
	    {
		assertNotAtEnd();
		if (m_enumerationValues == null)
		{
		    throw new TypeMismatchException();
		}
		return ArrayAttributeValues.this
		    .getEvaluatedEnumerationAttributeAtIndex(m_current);
	    }

	    protected void assertNotAtEnd()
	    {
		if (m_current == m_end)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    protected int  m_start;
	    protected int  m_end;
	    protected int  m_current;
	}

	////////////////////////////////////////////////////////////////////

	protected final class ValueCopier
	{
	    public ValueCopier(AttributeBuffer buffer)
	    {
		m_buffer = buffer;
	    }

	    public void copy(int target, int source)
	    {
		switch (m_type.getBaseType())
		{
		case ValueType._BOOLEAN:
		    if (m_buffer.getBooleanValue(source))
		    {
			m_booleanValues.set(target);
		    }
		    else
		    {
			m_booleanValues.clear(target);
		    }
		    break;

		case ValueType._INTEGER:
		    m_integerValues[target] = m_buffer.getIntegerValue(source);
		    break;

		case ValueType._FLOAT:
		    m_floatValues[target] = m_buffer.getFloatValue(source);
		    break;

		case ValueType._DOUBLE:
		    m_doubleValues[target] = m_buffer.getDoubleValue(source);
		    break;

		case ValueType._STRING:
		    m_stringValues[target] = m_buffer.getStringValue(source);
		    break;

		case ValueType._FLOAT3:
		    m_buffer.getFloat3Value(source, m_floatArray);
		    m_floatXValues[target] = m_floatArray[0];
		    m_floatYValues[target] = m_floatArray[1];
		    m_floatZValues[target] = m_floatArray[2];
		    break;

		case ValueType._DOUBLE3:
		    m_buffer.getDouble3Value(source, m_doubleArray);
		    m_doubleXValues[target] = m_doubleArray[0];
		    m_doubleYValues[target] = m_doubleArray[1];
		    m_doubleZValues[target] = m_doubleArray[2];
		    break;

		case ValueType._ENUMERATION:
		    m_enumerationValues[target] =
			m_buffer.getEnumerationValue(source);
		    break;

		default: throw new InternalErrorException();
		}
	    }

	    private AttributeBuffer  m_buffer;
	    private float[]  m_floatArray = new float[3];
	    private double[]  m_doubleArray = new double[3];
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static class MutableScalarAttributeValues
	extends ArrayAttributeValues
    {
	public MutableScalarAttributeValues
	    (ValueType type, EnumerationReader reader, int maxNumObjects)
	{
	    super(type, reader, maxNumObjects);

	    if (m_type.isListType())
	    {
		throw new IllegalArgumentException("expected non-list type");
	    }

	    allocateValues(m_type, maxNumObjects, maxNumObjects);
	}

	public MutableScalarAttributeValues(AttributeBuffer buffer,
					    int maxNumObjects)
	{
	    this(buffer.getType(), buffer.getEnumerationReader(),
		 maxNumObjects);

	    // NOTE: We don't require the user to supply an initial value
	    //       for all possible objects (maxNumObjects).  Objects 
	    //       without explicit initial values will have the default
	    //       values supplied by Java (such as false for booleans,
	    //       and 0 for integers).

	    // XXX: Actually, we should probably initialize any objects
	    //      not given explicit initial values with the result of
	    //      evaluating the default expression, if given.

	    int numObjects = buffer.getNumUniqueObjects();
	    ValueCopier copier = new ValueCopier(buffer);
	    for (int i = 0; i < numObjects; i++)
	    {
		int target = buffer.getObject(i);
		int start = buffer.getValueStart(i);
		copier.copy(target, start);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    return true;
	}

	public int findNextObjectWithValue(int object)
	{
	    validateObjectID(object);
	    return (object + 1 < m_maxNumObjects ? object + 1 : -1);
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    return new MutableValueIteratorImpl(object, object + 1);
	}

	public void setBooleanAttribute(int object, boolean value)
	{
	    validateObjectID(object);
	    if (m_booleanValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    if (value)
	    {
		m_booleanValues.set(object);
	    }
	    else
	    {
		m_booleanValues.clear(object);
	    }
	}

	public void setIntegerAttribute(int object, int value)
	{
	    validateObjectID(object);
	    if (m_integerValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_integerValues[object] = value;
	}

	public void setFloatAttribute(int object, float value)
	{
	    validateObjectID(object);
	    if (m_floatValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_floatValues[object] = value;
	}

	public void setDoubleAttribute(int object, double value)
	{
	    validateObjectID(object);
	    if (m_doubleValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_doubleValues[object] = value;
	}

	public void setStringAttribute(int object, String value)
	{
	    validateObjectID(object);
	    if (m_stringValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_stringValues[object] = value;
	}

	public void setFloat3Attribute(int object, float x, float y, float z)
	{
	    validateObjectID(object);
	    if (m_floatXValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_floatXValues[object] = x;
	    m_floatYValues[object] = y;
	    m_floatZValues[object] = z;
	}

	public void setFloat3Attribute(int object, float[] values)
	{
	    validateObjectID(object);
	    if (m_floatXValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_floatXValues[object] = values[0];
	    m_floatYValues[object] = values[1];
	    m_floatZValues[object] = values[2];
	}

        public void setDouble3Attribute(int object, double x, double y,
					double z)
	{
	    validateObjectID(object);
	    if (m_doubleXValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_doubleXValues[object] = x;
	    m_doubleYValues[object] = y;
	    m_doubleZValues[object] = z;
	}

	public void setDouble3Attribute(int object, double[] values)
	{
	    validateObjectID(object);
	    if (m_doubleXValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_doubleXValues[object] = values[0];
	    m_doubleYValues[object] = values[1];
	    m_doubleZValues[object] = values[2];
	}

	public void setEnumerationAttribute(int object, String enumerator)
	{
	    validateObjectID(object);
	    if (m_enumerationValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    EnumeratorReader reader = m_reader.getEnumeratorReader(enumerator);
	    m_enumerationValues[object] = reader;
	}

	public void setEnumerationAttribute(int object, int enumerator)
	{
	    validateObjectID(object);
	    if (m_enumerationValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    EnumeratorReader reader = m_reader.getEnumeratorReader(enumerator);
	    m_enumerationValues[object] = reader;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE INNER CLASSES
	////////////////////////////////////////////////////////////////////

	private class MutableValueIteratorImpl
	    extends AbstractValueIteratorImpl
	{
	    public MutableValueIteratorImpl(int start, int end)
	    {
		super(start, end);
		if (end > m_maxNumObjects)
		{
		    throw new IllegalArgumentException();
		}
	    }

	    public void setBooleanValue(boolean value)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setBooleanAttribute(m_current, value);
	    }

	    public void setIntegerValue(int value)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setIntegerAttribute(m_current, value);
	    }

	    public void setFloatValue(float value)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setFloatAttribute(m_current, value);
	    }

	    public void setDoubleValue(double value)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setDoubleAttribute(m_current, value);
	    }

	    public void setStringValue(String value)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setStringAttribute(m_current, value);
	    }

	    public void setFloat3Value(float x, float y, float z)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setFloat3Attribute(m_current, x, y, z);
	    }

	    public void setFloat3Value(float[] values)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setFloat3Attribute(m_current, values);
	    }

	    public void setDouble3Value(double x, double y, double z)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setDouble3Attribute(m_current, x, y, z);
	    }

	    public void setDouble3Value(double[] values)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setDouble3Attribute(m_current, values);
	    }

	    public void setEnumerationValue(String enumerator)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setEnumerationAttribute(m_current, enumerator);
	    }

	    public void setEnumerationValue(int enumerator)
	    {
		assertNotAtEnd();
		MutableScalarAttributeValues.this
		    .setEnumerationAttribute(m_current, enumerator);
	    }

	    public void removeValue()
	    {
		String msg =
		    "attempted to remove a value from a non-list attribute";
		throw new TypeMismatchException(msg);
	    }

	    public void insertValue()
	    {
		String msg =
		    "attempted to insert a value into a non-list attribute";
		throw new TypeMismatchException(msg);
	    }

	    public void appendValue()
	    {
		String msg =
		    "attempted to append a value to a non-list attribute";
		throw new TypeMismatchException(msg);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static abstract class ImmutableAttributeValues
	extends ArrayAttributeValues
    {
	public ImmutableAttributeValues
	    (ValueType type, EnumerationReader reader, int maxNumObjects)
	{
	    super(type, reader, maxNumObjects);
	}

	public void setBooleanAttribute(int object, boolean value)
	{ throw new ImmutableDataException(); }

	public void setIntegerAttribute(int object, int value)
	{ throw new ImmutableDataException(); }

	public void setFloatAttribute(int object, float value)
	{ throw new ImmutableDataException(); }

	public void setDoubleAttribute(int object, double value)
	{ throw new ImmutableDataException(); }

	public void setStringAttribute(int object, String value)
	{ throw new ImmutableDataException(); }

	public void setFloat3Attribute(int object, float x, float y, float z)
	{ throw new ImmutableDataException(); }

	public void setFloat3Attribute(int object, float[] values)
	{ throw new ImmutableDataException(); }

        public void setDouble3Attribute(int object,
					double x, double y, double z)
	{ throw new ImmutableDataException(); }

	public void setDouble3Attribute(int object, double[] values)
	{ throw new ImmutableDataException(); }

	public void setEnumerationAttribute(int object, String enumerator)
	{ throw new ImmutableDataException(); }

	public void setEnumerationAttribute(int object, int enumerator)
	{ throw new ImmutableDataException(); }

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected final ValueIterator getAttributeAtIndex(int index)
	{
	    ValueIterator retval;
	    if (m_type.isBaseType())
	    {
		retval = new ImmutableValueIteratorImpl(index, index + 1);
	    }
	    else
	    {
		int start = m_start[index];
		int end = start + m_length[index];
		retval = new ImmutableValueIteratorImpl(start, end);
	    }
	    return retval;
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED INNER CLASSES
	////////////////////////////////////////////////////////////////////

	protected class ImmutableValueIteratorImpl
	    extends AbstractValueIteratorImpl
	{
	    public ImmutableValueIteratorImpl(int start, int end)
	    {
		super(start, end);
	    }

	    public void setBooleanValue(boolean value)
	    { throw new ImmutableDataException(); }

	    public void setIntegerValue(int value)
	    { throw new ImmutableDataException(); }

	    public void setFloatValue(float value)
	    { throw new ImmutableDataException(); }

	    public void setDoubleValue(double value)
	    { throw new ImmutableDataException(); }

	    public void setStringValue(String value)
	    { throw new ImmutableDataException(); }

	    public void setFloat3Value(float x, float y, float z)
	    { throw new ImmutableDataException(); }

	    public void setFloat3Value(float[] value)
	    { throw new ImmutableDataException(); }

	    public void setDouble3Value(double x, double y, double z)
	    { throw new ImmutableDataException(); }

	    public void setDouble3Value(double[] value)
	    { throw new ImmutableDataException(); }

	    public void setEnumerationValue(String enumerator)
	    { throw new ImmutableDataException(); }

	    public void setEnumerationValue(int enumerator)
	    { throw new ImmutableDataException(); }

	    public void removeValue()
	    { throw new ImmutableDataException(); }

	    public void insertValue()
	    { throw new ImmutableDataException(); }

	    public void appendValue()
	    { throw new ImmutableDataException(); }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static class AllAttributeValues
	extends ImmutableAttributeValues
    {
	public AllAttributeValues(AttributeBuffer buffer, int maxNumObjects)
	{
	    super(buffer.getType(), buffer.getEnumerationReader(),
		  maxNumObjects);

	    int numObjects = buffer.getNumUniqueObjects();
	    if (numObjects != maxNumObjects)
	    {
		String msg = "numObjects[" + numObjects +
		    "] must equal maxNumObjects[" + maxNumObjects + "]";
		throw new IllegalArgumentException(msg);
	    }

	    int numValues = buffer.getNumValues();
	    allocateValues(m_type, maxNumObjects, numValues);

	    ValueCopier copier = new ValueCopier(buffer);
	    if (m_type.isBaseType())
	    {
		if (numValues != maxNumObjects)
		{
		    String msg = "numValues[" + numValues
			+ "] must equal maxNumObjects["
			+ maxNumObjects + "]";
		    throw new IllegalArgumentException(msg);
		}

		for (int i = 0; i < numObjects; i++)
		{
		    int target = buffer.getObject(i);
		    int start = buffer.getValueStart(i);
		    copier.copy(target, start);
		}
	    }
	    else
	    {
		for (int i = 0; i < numValues; i++)
		{
		    copier.copy(i, i);
		}

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);
		    m_start[object] = buffer.getValueStart(i);
		    m_length[object] = buffer.getValueLength(i);
		}
	    }
	}

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    return true;
	}

	public int findNextObjectWithValue(int object)
	{
	    validateObjectID(object);
	    return (object + 1 < m_maxNumObjects ? object + 1 : -1);
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    return getAttributeAtIndex(object);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static class NoneAttributeValues
	extends ImmutableAttributeValues
    {
	public NoneAttributeValues(AttributeBuffer buffer, int maxNumObjects,
				   DefaultAttributeValues defaultValues)
	{
	    super(buffer.getType(), buffer.getEnumerationReader(),
		  maxNumObjects);

	    m_defaultValues = defaultValues;
	    allocateValues(m_type, 0, 0);
	}

	public NoneAttributeValues
	    (ValueType type, EnumerationReader reader,
	     int maxNumObjects, DefaultAttributeValues defaultValues)
	{
	    super(type, reader, maxNumObjects);

	    m_defaultValues = defaultValues;
	    allocateValues(m_type, 0, 0);
	}

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    return m_defaultValues != null;
	}

	public int findNextObjectWithValue(int object)
	{
	    validateObjectID(object);
	    return (m_defaultValues == null || object + 1 == m_maxNumObjects
		    ? -1 : object + 1);
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);
	    if (m_defaultValues == null)
	    {
		throw new AttributeUnavailableException();
	    }
	    return m_defaultValues.getAttribute(object);
	}

	protected int findObject(int object)
	{
	    return -1;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static class MostAttributeValues
	extends ImmutableAttributeValues
    {
	public MostAttributeValues(AttributeBuffer buffer, int maxNumObjects,
				   DefaultAttributeValues defaultValues)
	{
	    super(buffer.getType(), buffer.getEnumerationReader(),
		  maxNumObjects);

	    m_cacheMap = new BitSet(maxNumObjects);
	    m_defaultValues = defaultValues;

	    int numObjects = buffer.getNumUniqueObjects();
	    if (numObjects >= maxNumObjects)
	    {
		String msg = "numObjects[" + numObjects +
		    "] must be < maxNumObjects[" + maxNumObjects + "]";
		throw new IllegalArgumentException(msg);
	    }

	    int numValues = buffer.getNumValues();

	    ValueCopier copier = new ValueCopier(buffer);
	    if (m_type.isBaseType())
	    {
		if (numValues >= maxNumObjects)
		{
		    String msg = "numValues[" + numValues
			+ "] must be < maxNumObjects["
			+ maxNumObjects + "]";
		    throw new IllegalArgumentException(msg);
		}

		allocateValues(m_type, maxNumObjects, maxNumObjects);

		for (int i = 0; i < numObjects; i++)
		{
		    int target = buffer.getObject(i);
		    int start = buffer.getValueStart(i);
		    copier.copy(target, start);
		    m_cacheMap.set(target);
		}
	    }
	    else
	    {
		allocateValues(m_type, maxNumObjects, numValues);

		for (int i = 0; i < numValues; i++)
		{
		    copier.copy(i, i);
		}

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);
		    m_start[object] = buffer.getValueStart(i);
		    m_length[object] = buffer.getValueLength(i);
		    m_cacheMap.set(object);
		}
	    }
	}

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    return m_defaultValues != null || m_cacheMap.get(object);
	}

	public int findNextObjectWithValue(int object)
	{
	    validateObjectID(object);

	    if (m_defaultValues == null)
	    {
		for (++object; object < m_maxNumObjects; object++)
		{
		    if (m_cacheMap.get(object))
		    {
			return object;
		    }
		}
		return -1;
	    }
	    else
	    {
		return (object + 1 < m_maxNumObjects ? object + 1 : -1);
	    }
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);

	    ValueIterator retval;
	    if (m_cacheMap.get(object))
	    {
		retval = getAttributeAtIndex(object);
	    }
	    else if (m_defaultValues != null)
	    {
		retval = m_defaultValues.getAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	    return retval;
	}

	protected int findObject(int object)
	{
	    return (m_cacheMap.get(object) ? object : -1);
	}

	private BitSet  m_cacheMap;
    }

    ///////////////////////////////////////////////////////////////////////

    private static abstract class AbstractManyAttributeValues
	extends ImmutableAttributeValues
    {
	public AbstractManyAttributeValues
	    (ValueType type, EnumerationReader reader, int maxNumObjects)
	{
	    super(type, reader, maxNumObjects);
	}

	public int findNextObjectWithValue(int object)
	{
	    validateObjectID(object);

	    int retval = -1;
	    if (object + 1 < m_maxNumObjects)
	    {
		if (m_defaultValues == null)
		{
		    int position = findObjectOrNext(object + 1);
		    if (position < m_objects.length)
		    {
			retval = m_objects[position];
		    }
		}
		else
		{
		    retval = object + 1;
		}
	    }
	    return retval;
	}

	protected int findObjectOrNext(int object)
	{
	    int retval = privateFindObject(object);
	    if (retval < 0)
	    {
		retval = -(retval + 1);
	    }
	    return retval;
	}

	// Same contract as findObject() except that on failure, the
	// return value equals {-n - 1}, where 0 <= n <= m_objects.length
	// is the index where the object should have been--note how this may
	// equal m_objects.length.
	protected int privateFindObject(int object)
	{
	    int retval = -1;
	    if (m_useBinarySearch)
	    {
		retval = Arrays.binarySearch(m_objects, object);
	    }
	    else
	    {
		retval = -m_objects.length - 1;
		for (int i = 0; i < m_objects.length; i++)
		{
		    if (m_objects[i] == object)
		    {
			retval = i;
			break;
		    }
		    else if (m_objects[i] > object)
		    {
			retval = -i - 1;
			break;
		    }
		}
	    }
	    return retval;
	}

	protected int[]  m_objects;
	protected boolean  m_useBinarySearch;
    }


    ///////////////////////////////////////////////////////////////////////

    private static class ManyFastAttributeValues
	extends AbstractManyAttributeValues
    {
	public ManyFastAttributeValues(AttributeBuffer buffer,
				       int maxNumObjects,
				       DefaultAttributeValues defaultValues)
	{
	    super(buffer.getType(), buffer.getEnumerationReader(),
		  maxNumObjects);

	    m_overriddenMap = new BitSet(maxNumObjects);
	    m_defaultValues = defaultValues;

	    buffer.sort();
	    int numObjects = buffer.getNumUniqueObjects();
	    if (numObjects >= maxNumObjects)
	    {
		String msg = "numObjects[" + numObjects +
		    "] must be < maxNumObjects[" + maxNumObjects + "]";
		throw new IllegalArgumentException(msg);
	    }

	    m_objects = new int[numObjects];
	    m_useBinarySearch = (numObjects > BINARY_SEARCH_THRESHOLD);

	    int numValues = buffer.getNumValues();

	    ValueCopier copier = new ValueCopier(buffer);
	    if (m_type.isBaseType())
	    {
		if (numValues != numObjects)
		{
		    String msg = "numValues[" + numValues
			+ "] must equal numObjects[" + numObjects + "]";
		    throw new IllegalArgumentException(msg);
		}

		allocateValues(m_type, numObjects, numObjects);

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);
		    int start = buffer.getValueStart(i);

		    m_objects[i] = object;
		    copier.copy(i, start);
		    m_overriddenMap.set(object);
		}
	    }
	    else
	    {
		allocateValues(m_type, numObjects, numValues);

		for (int i = 0; i < numValues; i++)
		{
		    copier.copy(i, i);
		}

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);

		    m_objects[i] = object;
		    m_start[i] = buffer.getValueStart(i);
		    m_length[i] = buffer.getValueLength(i);
		    m_overriddenMap.set(object);
		}
	    }
	}

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    return m_defaultValues != null || m_overriddenMap.get(object);
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);

	    ValueIterator retval;
	    if (m_overriddenMap.get(object))
	    {
		int index = findOverriddenObject(object);
		retval = getAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		retval = m_defaultValues.getAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	    return retval;
	}

	protected int findObject(int object)
	{
	    int retval = -1;
	    if (m_overriddenMap.get(object))
	    {
		retval = findOverriddenObject(object);
	    }
	    return retval;
	}

	private int findOverriddenObject(int object)
	{
	    int retval = privateFindObject(object);
	    if (retval < 0)
	    {
		String msg = "overridden object[" + object + "] not found";
		throw new InternalErrorException(msg);
	    }
	    return retval;
	}

	private BitSet  m_overriddenMap;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ManyCompactAttributeValues
	extends AbstractManyAttributeValues
    {
	public ManyCompactAttributeValues(AttributeBuffer buffer,
					  int maxNumObjects,
					  DefaultAttributeValues defaultValues)
	{
	    super(buffer.getType(), buffer.getEnumerationReader(),
		  maxNumObjects);

	    m_defaultValues = defaultValues;

	    buffer.sort();
	    int numObjects = buffer.getNumUniqueObjects();
	    if (numObjects >= maxNumObjects)
	    {
		String msg = "numObjects[" + numObjects +
		    "] must be < maxNumObjects[" + maxNumObjects + "]";
		throw new IllegalArgumentException(msg);
	    }

	    m_objects = new int[numObjects];
	    m_useBinarySearch = (numObjects > BINARY_SEARCH_THRESHOLD);

	    int numValues = buffer.getNumValues();

	    ValueCopier copier = new ValueCopier(buffer);
	    if (m_type.isBaseType())
	    {
		if (numValues != numObjects)
		{
		    String msg = "numValues[" + numValues
			+ "] must equal numObjects[" + numObjects + "]";
		    throw new IllegalArgumentException(msg);
		}

		allocateValues(m_type, numObjects, numObjects);

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);
		    int start = buffer.getValueStart(i);

		    m_objects[i] = object;
		    copier.copy(i, start);
		}
	    }
	    else
	    {
		allocateValues(m_type, numObjects, numValues);

		for (int i = 0; i < numValues; i++)
		{
		    copier.copy(i, i);
		}

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);

		    m_objects[i] = object;
		    m_start[i] = buffer.getValueStart(i);
		    m_length[i] = buffer.getValueLength(i);
		}
	    }
	}

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    if (m_defaultValues != null)
	    {
		return true;
	    }
	    else
	    {
		return privateFindObject(object) >= 0;
	    }
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);

	    ValueIterator retval;
	    int index = privateFindObject(object);
	    if (index >= 0)
	    {
		retval = getAttributeAtIndex(index);
	    }
	    else if (m_defaultValues != null)
	    {
		retval = m_defaultValues.getAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	    return retval;
	}

	protected int findObject(int object)
	{
	    return privateFindObject(object);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    // This uses m_start to do its indexing for base-type elements.  Since
    // m_start is not allocated by ImmutableAttributeValues for base types,
    // this allocates m_start itself.
    //
    // For list-type elements, this uses m_start and m_length as usual except
    // that m_start is set to -1 for objects which were never populated
    // (m_start is >= 0 for objects which were populated but nonetheless
    // have an empty list of values).
    private static class IndexedAttributeValues
	extends ImmutableAttributeValues
    {
	public IndexedAttributeValues(AttributeBuffer buffer,
				      int maxNumObjects,
				      DefaultAttributeValues defaultValues)
	{
	    super(buffer.getType(), buffer.getEnumerationReader(),
		  maxNumObjects);

	    if (m_type == ValueType.BOOLEAN
		|| m_type == ValueType.INTEGER
		|| m_type == ValueType.STRING)
	    {
		String msg = "inappropriate type for IndexedAttributeValues";
		throw new IllegalArgumentException(msg);
	    }

	    m_defaultValues = defaultValues;

	    int numObjects = buffer.getNumUniqueObjects();
	    if (numObjects >= maxNumObjects)
	    {
		String msg = "numObjects[" + numObjects +
		    "] must be < maxNumObjects[" + maxNumObjects + "]";
		throw new IllegalArgumentException(msg);
	    }

	    int numValues = buffer.getNumValues();

	    allocateValues(m_type, maxNumObjects, numValues);

	    ValueCopier copier = new ValueCopier(buffer);
	    for (int i = 0; i < numValues; i++)
	    {
		copier.copy(i, i);
	    }

	    if (m_type.isBaseType())
	    {
		if (numValues >= maxNumObjects)
		{
		    String msg = "numValues[" + numValues
			+ "] must be < maxNumObjects["
			+ maxNumObjects + "]";
		    throw new IllegalArgumentException(msg);
		}

		m_start = new int[maxNumObjects];
		Arrays.fill(m_start, -1);

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);
		    int start = buffer.getValueStart(i);
		    m_start[object] = start;
		}
	    }
	    else
	    {
		Arrays.fill(m_start, -1);

		for (int i = 0; i < numObjects; i++)
		{
		    int object = buffer.getObject(i);
		    m_start[object] = buffer.getValueStart(i);
		    m_length[object] = buffer.getValueLength(i);
		}
	    }
	}

	public boolean hasValueFor(int object)
	{
	    validateObjectID(object);
	    return m_defaultValues != null || m_start[object] >= 0;
	}

	public int findNextObjectWithValue(int object)
	{
	    validateObjectID(object);

	    if (m_defaultValues == null)
	    {
		for (++object; object < m_maxNumObjects; object++)
		{
		    if (m_start[object] >= 0)
		    {
			return object;
		    }
		}
		return -1;
	    }
	    else
	    {
		return (object + 1 < m_maxNumObjects ? object + 1 : -1);
	    }
	}

	public ValueIterator getAttribute(int object)
	    throws AttributeUnavailableException
	{
	    validateObjectID(object);

	    ValueIterator retval = null;
	    int start = m_start[object];
	    if (start >= 0)
	    {
		int length = (m_type.isBaseType() ? 1 : m_length[object]);
		int end = start + length;
		retval = new ImmutableValueIteratorImpl(start, end);
	    }
	    else if (m_defaultValues != null)
	    {
		retval = m_defaultValues.getAttribute(object);
	    }
	    else
	    {
		throw new AttributeUnavailableException();
	    }
	    return retval;
	}

	protected int findObject(int object)
	{
	    return m_start[object];
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private interface AttributeBuffer
    {
	ValueType getType();
	EnumerationReader getEnumerationReader();
	int getNumUniqueObjects();
	int getNumValues();
	int getObject(int index);
	int getValueStart(int index);
	int getValueLength(int index);
	void sort();

	boolean getBooleanValue(int index);
	int getIntegerValue(int index);
	float getFloatValue(int index);
	double getDoubleValue(int index);
	String getStringValue(int index);
	float[] getFloat3Value(int index);
	void getFloat3Value(int index, float[] values);
	double[] getDouble3Value(int index);
	void getDouble3Value(int index, double[] values);
	EnumeratorReader getEnumerationValue(int index);

	void registerObject(int id);
	void appendBooleanValue(int object, boolean value);
	void appendIntegerValue(int object, int value);
	void appendFloatValue(int object, float value);
	void appendDoubleValue(int object, double value);
	void appendStringValue(int object, String value);
	void appendFloat3Value(int object, float x, float y, float z);
	void appendFloat3Value(int object, float[] values);
	void appendDouble3Value(int object, double x, double y, double z);
	void appendDouble3Value(int object, double[] values);
	void appendEnumerationValue(int object, EnumeratorReader value);
	void endConstruction();
    }

    ///////////////////////////////////////////////////////////////////////

    private static abstract class AbstractAttributeBuffer
	implements AttributeBuffer
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public AbstractAttributeBuffer(ValueType type,
				       EnumerationReader reader)
	{
	    m_type = type;
	    m_reader = reader;
	    switch (type.getBaseType())
	    {
	    case ValueType._BOOLEAN:
		m_booleanValues = new GrowableBooleanArray();
		break;
	    case ValueType._INTEGER:
		m_integerValues = new GrowableIntArray();
		break;
	    case ValueType._FLOAT:
		m_floatValues = new GrowableFloatArray();
		break;
	    case ValueType._DOUBLE:
		m_doubleValues = new GrowableDoubleArray();
		break;
	    case ValueType._STRING:
		m_stringValues = new GrowableStringArray();
		break;
	    case ValueType._FLOAT3:
		m_float3Values = new GrowableFloat3Array();
		break;
	    case ValueType._DOUBLE3:
		m_double3Values = new GrowableDouble3Array();
		break;
	    case ValueType._ENUMERATION:
		if (reader == null)
		{
		    String msg = "missing EnumerationReader";
		    throw new IllegalArgumentException(msg);
		}
		m_enumerationValues = new GrowableObjectArray();
		break;
	    default: throw new InternalErrorException();
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public ValueType getType()
	{
	    return m_type;
	}

	public EnumerationReader getEnumerationReader()
	{
	    return m_reader;
	}

	public int getNumUniqueObjects()
	{
	    return m_objects.getNumAllocated();
	}

	public int getNumValues()
	{
	    return m_numValues;
	}

	public int getObject(int index)
	{
	    validateObjectIndex(index);
	    return m_objects.getValue(index);
	}

	public boolean getBooleanValue(int index)
	{
	    validateValueIndex(index);
	    if (m_booleanValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_booleanValues.getValue(index);
	}

	public int getIntegerValue(int index)
	{
	    validateValueIndex(index);
	    if (m_integerValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_integerValues.getValue(index);
	}

	public float getFloatValue(int index)
	{
	    validateValueIndex(index);
	    if (m_floatValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_floatValues.getValue(index);
	}

	public double getDoubleValue(int index)
	{
	    validateValueIndex(index);
	    if (m_doubleValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_doubleValues.getValue(index);
	}

	public String getStringValue(int index)
	{
	    validateValueIndex(index);
	    if (m_stringValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_stringValues.getValue(index);
	}

	public float[] getFloat3Value(int index)
	{
	    validateValueIndex(index);
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_float3Values.getValue(index);
	}

	public void getFloat3Value(int index, float[] values)
	{
	    validateValueIndex(index);
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_float3Values.getValue(index, values);
	}

	public double[] getDouble3Value(int index)
	{
	    validateValueIndex(index);
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_double3Values.getValue(index);
	}

	public void getDouble3Value(int index, double[] values)
	{
	    validateValueIndex(index);
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_double3Values.getValue(index, values);
	}

	public EnumeratorReader getEnumerationValue(int index)
	{
	    validateValueIndex(index);
	    if (m_enumerationValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return (EnumeratorReader)m_enumerationValues.getValue(index);
	}

	public void appendBooleanValue(int object, boolean value)
	{
	    validateNonnegative(object);
	    if (m_booleanValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_booleanValues.append(value);
	    ++m_numValues;
	}

	public void appendIntegerValue(int object, int value)
	{
	    validateNonnegative(object);
	    if (m_integerValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_integerValues.append(value);
	    ++m_numValues;
	}

	public void appendFloatValue(int object, float value)
	{
	    validateNonnegative(object);
	    if (m_floatValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_floatValues.append(value);
	    ++m_numValues;
	}

	public void appendDoubleValue(int object, double value)
	{
	    validateNonnegative(object);
	    if (m_doubleValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_doubleValues.append(value);
	    ++m_numValues;
	}

	public void appendStringValue(int object, String value)
	{
	    validateNonnegative(object);
	    if (m_stringValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_stringValues.append(value);
	    ++m_numValues;
	}

	public void appendFloat3Value(int object, float x, float y, float z)
	{
	    validateNonnegative(object);
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_float3Values.append(x, y, z);
	    ++m_numValues;
	}

	public void appendFloat3Value(int object, float[] values)
	{
	    validateNonnegative(object);
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_float3Values.append(values);
	    ++m_numValues;
	}

	public void appendDouble3Value(int object, double x, double y,
				       double z)
	{
	    validateNonnegative(object);
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_double3Values.append(x, y, z);
	    ++m_numValues;
	}

	public void appendDouble3Value(int object, double[] values)
	{
	    validateNonnegative(object);
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_double3Values.append(values);
	    ++m_numValues;
	}

	public void appendEnumerationValue(int object, EnumeratorReader value)
	{
	    validateNonnegative(object);
	    if (m_enumerationValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    appendObject(object);
	    m_enumerationValues.append(value);
	    ++m_numValues;
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	////////////////////////////////////////////////////////////////////

	protected abstract void appendObject(int object);

	protected void validateObjectIndex(int index)
	{
	    if (index < 0 || index >= m_objects.getNumAllocated())
	    {
		String msg = "object index[" + index + "] must be >= 0 and < "
		    + m_objects.getNumAllocated();
		throw new IllegalArgumentException(msg);
	    }
	}

	protected void validateValueIndex(int index)
	{
	    if (index < 0 || index >= m_numValues)
	    {
		String msg = "value index[" + index + "] must be >= 0 and < "
		    + m_numValues;
		throw new IllegalArgumentException(msg);
	    }
	}

	protected void validateNonnegative(int object)
	{
	    if (object < 0)
	    {
		String msg = "object[" + object + "] must be >= 0";
		throw new IllegalArgumentException(msg);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PROTECTED FIELDS
	////////////////////////////////////////////////////////////////////

	protected ValueType  m_type;
	protected EnumerationReader  m_reader;  // may be null

	protected GrowableIntArray  m_objects = new GrowableIntArray();

	protected int  m_numValues;
	protected GrowableBooleanArray  m_booleanValues;
	protected GrowableIntArray  m_integerValues;
	protected GrowableFloatArray  m_floatValues;
	protected GrowableDoubleArray  m_doubleValues;
	protected GrowableStringArray  m_stringValues;
	protected GrowableFloat3Array  m_float3Values;
	protected GrowableDouble3Array  m_double3Values;
	protected GrowableObjectArray  m_enumerationValues;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ScalarAttributeBuffer
	extends AbstractAttributeBuffer
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public ScalarAttributeBuffer(ValueType type, EnumerationReader reader)
	{
	    super(type, reader);
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public int getValueStart(int index)
	{
	    validateObjectIndex(index);
	    return index;
	}

	public int getValueLength(int index)
	{
	    validateObjectIndex(index);
	    return 1;
	}

	public void registerObject(int id)
	{
	    validateNonnegative(id);
	    if (m_registeredObject != -1)
	    {
		String msg = "scalar-valued object[" + m_registeredObject
		    + "] was not given a value";
		throw new MisconstructionException(msg);
	    }
	    m_registeredObject = id;
	}

	public void sort()
	{
	    if (m_isUnderConstruction)
	    {
		String msg =
		    "attempted to sort data which is still under construction";
		throw new MisconstructionException(msg);
	    }

	    if (!m_isSorted)
	    {
		m_isSorted = true;
		m_objects.qsort(createParallelSortable());
	    }
	}

	public void endConstruction()
	{
	    m_isUnderConstruction = false;
	    if (m_registeredObject != -1)
	    {
		String msg = "scalar-valued object[" + m_registeredObject
		    + "] was not given a value";
		throw new MisconstructionException(msg);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	protected void appendObject(int object)
	{
	    if (m_seenObjects.get(object))
	    {
		String msg = "appended more than one value for "
		    + "scalar-valued object[" + object + "]";
		throw new MisconstructionException(msg);
	    }
	    m_seenObjects.set(object);

	    if (object == m_registeredObject)
	    {
		// Indicate that we've appended a value for the 
		// registered object, which helps in verifying that all
		// registered objects were given a value.
		m_registeredObject = -1;
	    }
	    else
	    {
		if (m_registeredObject == -1)
		{
		    String msg = "attempted to append a value for an object["
			+ object + "] which isn't registered";
		    throw new MisconstructionException(msg);
		}
		else
		{
		    String msg = "attempted to append a value for an object["
			+ object + "] different from the registered object["
			+ m_registeredObject + "]";
		    throw new MisconstructionException(msg);
		}
	    }

	    m_objects.append(object);

	    if (object < m_previousObject)
	    {
		m_isSorted = false;
	    }
	    m_previousObject = object;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private GrowableIntArray.ParallelSortable createParallelSortable()
	{
	    GrowableIntArray.ParallelSortable retval = null;
	    switch (m_type.getBaseType())
	    {
	    case ValueType._BOOLEAN:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    boolean iv = m_booleanValues.getValue(i);
			    boolean jv = m_booleanValues.getValue(j);
			    m_booleanValues.setValue(i, jv);
			    m_booleanValues.setValue(j, iv);
			}
		    };
		break;

	    case ValueType._INTEGER:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    int iv = m_integerValues.getValue(i);
			    int jv = m_integerValues.getValue(j);
			    m_integerValues.setValue(i, jv);
			    m_integerValues.setValue(j, iv);
			}
		    };
		break;

	    case ValueType._FLOAT:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    float iv = m_floatValues.getValue(i);
			    float jv = m_floatValues.getValue(j);
			    m_floatValues.setValue(i, jv);
			    m_floatValues.setValue(j, iv);
			}
		    };
		break;

	    case ValueType._DOUBLE:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    double iv = m_doubleValues.getValue(i);
			    double jv = m_doubleValues.getValue(j);
			    m_doubleValues.setValue(i, jv);
			    m_doubleValues.setValue(j, iv);
			}
		    };
		break;

	    case ValueType._STRING:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    String iv = m_stringValues.getValue(i);
			    String jv = m_stringValues.getValue(j);
			    m_stringValues.setValue(i, jv);
			    m_stringValues.setValue(j, iv);
			}
		    };
		break;

	    case ValueType._FLOAT3:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    m_float3Values.getValue(i, m_iv);
			    m_float3Values.getValue(j, m_jv);
			    m_float3Values.setValue(i, m_jv);
			    m_float3Values.setValue(j, m_iv);
			}

			private float[]  m_iv = new float[3];
			private float[]  m_jv = new float[3];
		    };
		break;

	    case ValueType._DOUBLE3:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    m_double3Values.getValue(i, m_iv);
			    m_double3Values.getValue(j, m_jv);
			    m_double3Values.setValue(i, m_jv);
			    m_double3Values.setValue(j, m_iv);
			}

			private double[]  m_iv = new double[3];
			private double[]  m_jv = new double[3];
		    };
		break;

	    case ValueType._ENUMERATION:
		retval = new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    Object iv = m_enumerationValues.getValue(i);
			    Object jv = m_enumerationValues.getValue(j);
			    m_enumerationValues.setValue(i, jv);
			    m_enumerationValues.setValue(j, iv);
			}
		    };
		break;

	    default: throw new InternalErrorException();
	    }
	    return retval;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private boolean  m_isSorted = true;
	private boolean  m_isUnderConstruction = true;
	private BitSet  m_seenObjects = new BitSet();
	private int  m_registeredObject = -1;
	private int  m_previousObject = -1;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ListAttributeBuffer
	extends AbstractAttributeBuffer
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public ListAttributeBuffer(ValueType type, EnumerationReader reader)
	{
	    super(type, reader);
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public int getValueStart(int index)
	{
	    validateObjectIndex(index);
	    return m_start.getValue(index);
	}

	public int getValueLength(int index)
	{
	    validateObjectIndex(index);
	    return m_length.getValue(index);
	}

	public void registerObject(int id)
	{
	    validateNonnegative(id);
	    if (m_seenObjects.get(id))
	    {
		String msg =
		    "attempted to register object[" + id + "] more than once";
		throw new MisconstructionException(msg);
	    }
	    m_seenObjects.set(id);

	    m_currentIndex = m_objects.append(id);
	    m_start.append(m_numValues);
	    m_length.append(0);

	    if (id < m_registeredObject)
	    {
		m_isSorted = false;
	    }
	    m_registeredObject = id;
	}

	public void sort()
	{
	    if (m_isUnderConstruction)
	    {
		String msg =
		    "attempted to sort data which is still under construction";
		throw new MisconstructionException(msg);
	    }

	    if (!m_isSorted)
	    {
		m_isSorted = true;
		m_objects.qsort(new GrowableIntArray.ParallelSortable() {
			public void swap(int i, int j)
			{
			    {
				int iv = m_start.getValue(i);
				int jv = m_start.getValue(j);
				m_start.setValue(i, jv);
				m_start.setValue(j, iv);
			    }
			    {
				int iv = m_length.getValue(i);
				int jv = m_length.getValue(j);
				m_length.setValue(i, jv);
				m_length.setValue(j, iv);
			    }
			}
		    });
	    }
	}

	public void endConstruction()
	{
	    m_isUnderConstruction = false;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	protected void appendObject(int object)
	{
	    if (object != m_registeredObject)
	    {
		if (m_registeredObject == -1)
		{
		    String msg = "attempted to append a value for an object["
			+ object + "] which isn't registered";
		    throw new MisconstructionException(msg);
		}
		else
		{
		    String msg = "attempted to append a value for an object["
			+ object + "] different from the registered object["
			+ m_registeredObject + "]";
		    throw new MisconstructionException(msg);
		}
	    }

	    m_length.setValue(m_currentIndex,
			       m_length.getValue(m_currentIndex) + 1);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private boolean  m_isSorted = true;
	private boolean  m_isUnderConstruction = true;
	private BitSet  m_seenObjects = new BitSet();
	private int  m_registeredObject = -1;
	private int  m_currentIndex;

	private GrowableIntArray  m_start = new GrowableIntArray();
	private GrowableIntArray  m_length = new GrowableIntArray();
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ParseException extends Exception
    {
	public ParseException() { super(); }
	public ParseException(String s) { super(s); }
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ExprParser
    {
	public ExprParser
	    (ValueType type, EnumerationReader reader, String expr)
	{
	    m_type = type;
	    m_reader = reader;
	    m_expr = expr;
	    m_lexer = new ExprTokenBuffer(new ExprLexer(expr));
	    m_buffer = new DefaultValuesBuffer(type, reader);
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public DefaultAttributeValues parse()
	    throws ParseException
	{
	    parseExpression();

	    // XXX: It is rather wasteful of memory to use a whole
	    //      DefaultValuesBuffer to represent default values,
	    //      especially for scalar values.  Doing it this way,
	    //      however, is a justifiable expedient.
	    return new DefaultValuesBufferAdapter(m_buffer);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void parseExpression()
	    throws ParseException
	{
	    switch (m_lexer.getLA())
	    {
	    case ExprToken.EOF:
		{
		    String error = "syntax error: missing expression";
		    parseError(m_lexer.getNextToken(), error);
		}
		break;

	    case ExprToken.BOOL:
		//FALLTHROUGH
	    case ExprToken.INT:
		//FALLTHROUGH
	    case ExprToken.FLOAT:
		//FALLTHROUGH
	    case ExprToken.DOUBLE:
		//FALLTHROUGH
	    case ExprToken.STRING:
		assertBaseTypeExpression();
		parseScalar();
		break;

	    case ExprToken.LBRACKET:
		assertListTypeExpression();
		parseList();
		break;

	    case ExprToken.LCURLY:
		assertBaseTypeExpression();
		if (m_type.getBaseType() == ValueType._FLOAT3)
		{
		    parseFloat3();
		}
		else
		{
		    parseDouble3();
		}
		break;

	    case ExprToken.SHARP:
		assertBaseTypeExpression();
		parseEnumeration();
		break;

	    default:
		{
		    String error = "syntax error: token is not the start "
			+ "of any valid expression";
		    parseError(m_lexer.getNextToken(), error);
		}
		break;
	    }
	}

	private void parseScalar()
	    throws ParseException
	{
	    ExprToken token = m_lexer.getNextToken();
	    switch (token.getType())
	    {
	    case ExprToken.BOOL:
		assertBaseType(token, ValueType.BOOLEAN);
		m_buffer.appendBooleanValue(token.getBooleanValue());
		break;

	    case ExprToken.INT:
		assertBaseType(token, ValueType.INTEGER);
		m_buffer.appendIntegerValue(token.getIntegerValue());
		break;

	    case ExprToken.FLOAT:
		assertBaseType(token, ValueType.FLOAT);
		m_buffer.appendFloatValue(token.getFloatValue());
		break;

	    case ExprToken.DOUBLE:
		assertBaseType(token, ValueType.DOUBLE);
		m_buffer.appendDoubleValue(token.getDoubleValue());
		break;

	    case ExprToken.STRING:
		assertBaseType(token, ValueType.STRING);
		m_buffer.appendStringValue(token.getStringValue());
		break;

	    default: throw new RuntimeException();
	    }
	}

	private void parseList()
	    throws ParseException
	{
	    match(ExprToken.LBRACKET);
	    if (m_lexer.getLA() == ExprToken.EOF)
	    {
		String error = "syntax error: incomplete list: missing "
		    + "elements and closing ']'";
		parseError(m_lexer.getNextToken(), error);
	    }
	    else if (m_lexer.getLA() != ExprToken.RBRACKET)
	    {
		parseListElement();
		while (m_lexer.getLA() == ExprToken.COMMA)
		{
		    match(ExprToken.COMMA);
		    parseListElement();
		}
	    }
	    match(ExprToken.RBRACKET);
	}

	private void parseListElement()
	    throws ParseException
	{
	    switch (m_lexer.getLA())
	    {
	    case ExprToken.BOOL:
		//FALLTHROUGH
	    case ExprToken.INT:
		//FALLTHROUGH
	    case ExprToken.FLOAT:
		//FALLTHROUGH
	    case ExprToken.DOUBLE:
		//FALLTHROUGH
	    case ExprToken.STRING:
		parseScalar();
		break;

	    case ExprToken.LCURLY:
		if (m_type.getBaseType() == ValueType._FLOAT3)
		{
		    parseFloat3();
		}
		else
		{
		    parseDouble3();
		}
		break;

	    case ExprToken.SHARP:
		parseEnumeration();
		break;

	    default:
		{
		    String error = "syntax error: incomplete or malformed "
			+ "list: expected list element";
		    parseError(m_lexer.getNextToken(), error);
		}
		break;
	    }
	}

	private void parseFloat3()
	    throws ParseException
	{
	    match(ExprToken.LCURLY);
	    float x = parseTupleComponent(ExprToken.FLOAT).getFloatValue();
	    match(ExprToken.COMMA);
	    float y = parseTupleComponent(ExprToken.FLOAT).getFloatValue();
	    match(ExprToken.COMMA);
	    float z = parseTupleComponent(ExprToken.FLOAT).getFloatValue();
	    match(ExprToken.RCURLY);

	    m_buffer.appendFloat3Value(x, y, z);
	}

	private void parseDouble3()
	    throws ParseException
	{
	    match(ExprToken.LCURLY);
	    double x = parseTupleComponent(ExprToken.DOUBLE).getDoubleValue();
	    match(ExprToken.COMMA);
	    double y = parseTupleComponent(ExprToken.DOUBLE).getDoubleValue();
	    match(ExprToken.COMMA);
	    double z = parseTupleComponent(ExprToken.DOUBLE).getDoubleValue();
	    match(ExprToken.RCURLY);

	    m_buffer.appendDouble3Value(x, y, z);
	}

	private ExprToken parseTupleComponent(int requiredType)
	    throws ParseException
	{
	    ExprToken retval = m_lexer.getNextToken();
	    int type = retval.getType();
	    if (type == ExprToken.FLOAT || type == ExprToken.DOUBLE)
	    {
		if (type != requiredType)
		{
		    String found = (type == ExprToken.FLOAT
				    ? ValueType.FLOAT.getName()
				    : ValueType.DOUBLE.getName());
		    String required = (requiredType == ExprToken.FLOAT
				       ? ValueType.FLOAT.getName()
				       : ValueType.DOUBLE.getName());
		    String error = "type mismatch: encountered value of type "
			+ found + "; expected " + required;
		    parseError(retval, error);
		}
	    }
	    else
	    {
		String error = "syntax error: malformed tuple: "
		    + "missing component of type "
		    + ValueType.FLOAT.getName() + " or "
		    + ValueType.DOUBLE.getName();
		parseError(retval, error);
	    }
	    return retval;
	}

	private void parseEnumeration()
	    throws ParseException
	{
	    match(ExprToken.SHARP);

	    if (m_lexer.getLA() != ExprToken.IDENT)
	    {
		String error = "syntax error: missing enumeration name";
		parseError(m_lexer.getNextToken(), error);
	    }
	    ExprToken enumerationToken = match(ExprToken.IDENT);
	    String enumerationName = enumerationToken.getStringValue();
	    if (!enumerationName.equals(m_reader.getName()))
	    {
		String error = "type mismatch: found enumeration `"
		    + enumerationName + "'; expected `" + m_reader.getName()
		    + "'";
		parseError(enumerationToken, error);
	    }

	    match(ExprToken.COLON);

	    if (m_lexer.getLA() != ExprToken.IDENT)
	    {
		String error = "syntax error: missing enumerator name";
		parseError(m_lexer.getNextToken(), error);
	    }
	    ExprToken enumeratorToken = match(ExprToken.IDENT);
	    String enumeratorName = enumeratorToken.getStringValue();
	    try
	    {
		EnumeratorReader reader =
		    m_reader.getEnumeratorReader(enumeratorName);
		m_buffer.appendEnumerationValue(reader);
	    }
	    catch (ObjectNotFoundException e)
	    {
		String error = "enumerator `" + enumeratorName
		    + "' not found in enumeration `" + enumerationName + "'";
		parseError(enumeratorToken, error);
	    }
	}

	private ExprToken match(int type)
	    throws ParseException
	{
	    ExprToken retval = m_lexer.getNextToken();
	    if (retval.getType() != type)
	    {
		String error = "syntax error: found token "
		    + retval.getTypeName() + "; expected "
		    + ExprToken.getTypeName(type);
		parseError(retval, error);
	    }
	    return retval;
	}

	private void assertBaseType(ExprToken token, ValueType type)
	    throws ParseException
	{
	    if (type.getType() != m_type.getBaseType())
	    {
		String error = "type mismatch: encountered value of type "
		    + type.getName() + "; expected " + m_type.getBaseName();
		parseError(token, error);
	    }
	}

	private void assertBaseTypeExpression()
	    throws ParseException
	{
	    if (!m_type.isBaseType())
	    {
		String error = "type mismatch: encountered list value; "
		    + "expected scalar value";
		parseError(m_lexer.getNextToken(), error);
	    }
	}

	private void assertListTypeExpression()
	    throws ParseException
	{
	    if (!m_type.isListType())
	    {
		String error = "type mismatch: encountered scalar value; "
		    + "expected list value";
		parseError(m_lexer.getNextToken(), error);
	    }
	}

	private void parseError(ExprToken token, String error)
	    throws ParseException
	{
	    String msg = "index " + token.getStartingIndex() + ": " + error;
	    throw new ParseException(msg);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private ValueType  m_type;
	private EnumerationReader  m_reader;
	private String  m_expr;
	private ExprTokenBuffer  m_lexer;
	private DefaultValuesBuffer  m_buffer;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ExprTokenBuffer
    {
	public ExprTokenBuffer(ExprLexer lexer)
	{
	    m_lexer = lexer;
	}

	public int getLA()
	    throws ParseException
	{
	    if (m_token == null)
	    {
		m_token = m_lexer.getNextToken();
	    }
	    return m_token.getType();
	}

	public ExprToken getNextToken()
	    throws ParseException
	{
	    ExprToken retval = m_token;
	    if (retval == null)
	    {
		retval = m_lexer.getNextToken();
	    }
	    m_token = null;
	    return retval;
	}

	public void pushback(ExprToken token)
	{
	    m_token = token;
	}

	private ExprLexer  m_lexer;
	private ExprToken  m_token;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ExprLexer
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public ExprLexer(String expr)
	{
	    m_expr = expr;
	    m_length = expr.length();
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public ExprToken getNextToken()
	    throws ParseException
	{
	    ExprToken retval = null;
	    advanceWhitespaceStar();
	    m_startingIndex = m_index;
	    if (m_index == m_length)
	    {
		retval = makeToken(ExprToken.EOF);
	    }
	    else
	    {
		char c = getChar();
		switch (c)
		{
		case '[':
		    retval = makeToken(ExprToken.LBRACKET);
		    ++m_index;
		    break;

		case ']':
		    retval = makeToken(ExprToken.RBRACKET);
		    ++m_index;
		    break;

		case '{':
		    retval = makeToken(ExprToken.LCURLY);
		    ++m_index;
		    break;

		case '}':
		    retval = makeToken(ExprToken.RCURLY);
		    ++m_index;
		    break;

		case ',':
		    retval = makeToken(ExprToken.COMMA);
		    ++m_index;
		    break;

		case '#':
		    retval = makeToken(ExprToken.SHARP);
		    ++m_index;
		    break;

		case ':':
		    retval = makeToken(ExprToken.COLON);
		    ++m_index;
		    break;

		    // Numeric tokens:
		    //      int: (\-)?[0-9]+
		    //    float: (\-)?[0-9]+\.[0-9]+((e|E)(+|-)?[0-9]+)?f
		    //   double: (\-)?[0-9]+\.[0-9]+((e|E)(+|-)?[0-9]+)?
		case '-':
		    ++m_index;
		    if (m_index == m_length
			|| !Character.isDigit(getChar()))
		    {
			String msg = "index " + m_index
			    + ": malformed numeric literal: missing "
			    + "digits after negative sign";
			throw new ParseException(msg);
		    }
		    //FALLTHROUGH
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
		    ++m_index;
		    advanceDigitStar();
		    if (m_index == m_length || getChar() != '.')
		    {
			retval = acceptInteger();
		    }
		    else
		    {
			retval = matchFloatingPointNumber();
		    }
		    break;

		case '"':
		    retval = matchString();
		    break;

		default:
		    if (c == '_' || (c >= 'a' && c <= 'z')
			|| (c >= 'A' && c <= 'Z'))
		    {
			retval = matchIdentifier();
		    }
		    else
		    {
			String msg = "index " + m_index
			    + ": character '" + getChar()
			    + "' is not the valid starting character "
			    + "of any token";
			throw new ParseException(msg);
		    }
		    break;
		}
	    }
	    return retval;
	}

	// Assumes m_index is positioned at the decimal point of a potential
	// floating-point literal.
	private ExprToken matchFloatingPointNumber()
	    throws ParseException
	{
	    ExprToken retval = null;
	    ++m_index;
	    if (m_index == m_length || !Character.isDigit(getChar()))
	    {
		String msg = "index " + m_index
		    + ": malformed numeric literal: "
		    + "missing digits after decimal point";
		throw new ParseException(msg);
	    }

	    ++m_index;
	    advanceDigitStar();
	    if (m_index == m_length)
	    {
		retval = acceptDouble();
	    }
	    else
	    {
		if (getChar() == 'e' || getChar() == 'E')
		{
		    ++m_index;
		    if (m_index == m_length
			|| (getChar() != '+'
			    && getChar() != '-'
			    && !Character.isDigit(getChar())))
		    {
			String msg = "index " + m_index
			    + ": malformed numeric literal: "
			    + "missing exponent";
			throw new ParseException(msg);
		    }

		    if (getChar() == '+' || getChar() == '-')
		    {
			++m_index;
			if (m_index == m_length
			    || !Character.isDigit(getChar()))
			{
			    String msg = "index " + m_index
				+ ": malformed numeric literal: "
				+ "missing exponent";
			    throw new ParseException(msg);
			}
		    }

		    advanceDigitStar();
		}

		if (m_index == m_length)
		{
		    retval = acceptDouble();
		}
		else
		{
		    if (getChar() == 'f')
		    {
			// NOTE: We must call acceptFloat() prior to advancing
			//       m_index, as we don't want the 'f' to be
			//       thought a part of the token text.
			retval = acceptFloat();
			++m_index;
		    }
		    else
		    {
			retval = acceptDouble();
		    }
		}
	    }
	    return retval;
	}

	// Assumes m_index is positioned at the opening double quote.
	private ExprToken matchString()
	    throws ParseException
	{
	    m_stringBuffer.setLength(0);

	    ++m_index;
	    boolean isComplete = false;
	    while (!isComplete && m_index < m_length)
	    {
		char c = getChar();
		if (c == '"')
		{
		    isComplete = true;
		    ++m_index;
		}
		else if (c == '\n')
		{
		    String msg = "index " + m_index
			+ ": encountered unescaped newline in string";
		    throw new ParseException(msg);
		}
		else if (c == '\\')
		{
		    ++m_index;
		    if (m_index == m_length)
		    {
			String msg = "index " + m_index
			    + ": premature end of string";
			throw new ParseException(msg);
		    }

		    c = getChar();
		    if (c == '\\')
		    {
			m_stringBuffer.append('\\');
		    }
		    else if (c == '"')
		    {
			m_stringBuffer.append('"');
		    }
		    else if (c == 'n')
		    {
			m_stringBuffer.append('\n');
		    }
		    else if (c == 'r')
		    {
			m_stringBuffer.append('\r');
		    }
		    else if (c == 't')
		    {
			m_stringBuffer.append('\t');
		    }
		    else if (c == 'f')
		    {
			m_stringBuffer.append('\f');
		    }
		    else if (c == 'b')
		    {
			m_stringBuffer.append('\b');
		    }
		    else
		    {
			String msg = "index " + m_index
			    + ": invalid escape sequence";
			throw new ParseException(msg);
		    }
		    ++m_index;
		}
		else
		{
		    m_stringBuffer.append(c);
		    ++m_index;
		}
	    }

	    if (!isComplete)
	    {
		String msg = "index " + m_index + ": premature end of string";
		throw new ParseException(msg);
	    }

	    ExprToken retval = makeToken(ExprToken.STRING);
	    retval.setStringValue(m_stringBuffer.toString());
	    return retval;
	}

	// Assumes m_index is positioned at the first character of identifier.
	private ExprToken matchIdentifier()
	    throws ParseException
	{
	    ++m_index;
	    while (m_index < m_length)
	    {
		char c = getChar();
		if (c == '_' || (c >= '0' && c <= '9')
		    || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
		{
		    ++m_index;
		}
		else
		{
		    break;
		}
	    }

	    ExprToken retval = null;
	    String id = m_expr.substring(m_startingIndex, m_index);
	    if (id.equals("true"))
	    {
		retval = makeToken(ExprToken.BOOL);
		retval.setBooleanValue(true);
	    }
	    else if (id.equals("false"))
	    {
		retval = makeToken(ExprToken.BOOL);
		retval.setBooleanValue(false);
	    }
	    else
	    {
		retval = makeToken(ExprToken.IDENT);
		retval.setStringValue(id);
	    }
	    return retval;
	}

	private ExprToken acceptInteger()
	{
	    try
	    {
		ExprToken retval = makeToken(ExprToken.INT);
		String text = m_expr.substring(m_startingIndex, m_index);
		retval.setIntegerValue(Integer.parseInt(text));
		return retval;
	    }
	    catch (NumberFormatException e)
	    {
		throw new InternalErrorException(e.toString());
	    }
	}

	private ExprToken acceptFloat()
	{
	    try
	    {
		ExprToken retval = makeToken(ExprToken.FLOAT);
		String text = m_expr.substring(m_startingIndex, m_index);
		retval.setFloatValue(Float.parseFloat(text));
		return retval;
	    }
	    catch (NumberFormatException e)
	    {
		throw new InternalErrorException(e.toString());
	    }
	}

	private ExprToken acceptDouble()
	{
	    try
	    {
		ExprToken retval = makeToken(ExprToken.DOUBLE);
		String text = m_expr.substring(m_startingIndex, m_index);
		retval.setDoubleValue(Double.parseDouble(text));
		return retval;
	    }
	    catch (NumberFormatException e)
	    {
		throw new InternalErrorException(e.toString());
	    }
	}

	private void advanceWhitespaceStar()
	{
	    while (m_index < m_length && Character.isWhitespace(getChar()))
	    {
		++m_index;
	    }
	}

	private void advanceDigitStar()
	{
	    while (m_index < m_length && Character.isDigit(getChar()))
	    {
		++m_index;
	    }
	}

	private char getChar()
	{
	    return m_expr.charAt(m_index);
	}

	private ExprToken makeToken(int type)
	{
	    return new ExprToken(type, m_startingIndex, m_index);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private StringBuffer  m_stringBuffer = new StringBuffer();
	private String  m_expr;
	private int  m_length;
	private int  m_index;
	private int  m_startingIndex;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class ExprToken
    {
	////////////////////////////////////////////////////////////////////
	// PUBLIC CONSTANTS
	////////////////////////////////////////////////////////////////////

	public static final int NONE = -1;
	public static final int EOF = 0;
	public static final int IDENT = 1;	
	public static final int BOOL = 2;
	public static final int INT = 3;
	public static final int FLOAT = 4;
	public static final int DOUBLE = 5;
	public static final int STRING = 6;
	public static final int LBRACKET = 7;
	public static final int RBRACKET = 8;
	public static final int LCURLY = 9;
	public static final int RCURLY = 10;
	public static final int COMMA = 11;
	public static final int SHARP = 12;
	public static final int COLON = 13;

	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public ExprToken(int type, int startingIndex, int endingIndex)
	{
	    m_type = type;
	    m_startingIndex = startingIndex;
	    m_endingIndex = endingIndex;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public int getType()
	{
	    return m_type;
	}

	public String getTypeName()
	{
	    return m_typeNames[m_type];
	}

	public static String getTypeName(int type)
	{
	    return m_typeNames[type];
	}

	public int getStartingIndex()
	{
	    return m_startingIndex;
	}

	// Position one past the last character making up the token.
	public int getEndingIndex()
	{
	    return m_endingIndex;
	}

	public boolean getBooleanValue()
	{
	    return m_booleanValue;
	}

	public int getIntegerValue()
	{
	    return m_integerValue;
	}

	public float getFloatValue()
	{
	    return m_floatValue;
	}

	public double getDoubleValue()
	{
	    return m_doubleValue;
	}

	public String getStringValue()
	{
	    return m_stringValue;
	}

	public void setBooleanValue(boolean value)
	{
	    m_booleanValue = value;
	}

	public void setIntegerValue(int value)
	{
	    m_integerValue = value;
	}

	public void setFloatValue(float value)
	{
	    m_floatValue = value;
	}

	public void setDoubleValue(double value)
	{
	    m_doubleValue = value;
	}

	public void setStringValue(String value)
	{
	    m_stringValue = value;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private static final String[]  m_typeNames = {
	    "EOF", "IDENT", "BOOL", "INT", "FLOAT", "DOUBLE", "STRING",
	    "'['", "']'", "'{'", "'}'", "','", "'#'", "':'"
	};

	private int  m_type;
	private int  m_startingIndex;
	private int  m_endingIndex;
	private boolean  m_booleanValue;
	private int  m_integerValue;
	private float  m_floatValue;
	private double  m_doubleValue;
	private String  m_stringValue;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class DefaultValuesBufferAdapter
	implements DefaultAttributeValues
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public DefaultValuesBufferAdapter(DefaultValuesBuffer buffer)
	{
	    m_buffer = buffer;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public ValueIterator getAttribute(int object)
	{
	    return new ValueIteratorImpl();
	}

	public boolean getBooleanAttribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getBooleanValue(0);
	}

	public int getIntegerAttribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getIntegerValue(0);
	}

	public float getFloatAttribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getFloatValue(0);
	}

	public double getDoubleAttribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getDoubleValue(0);
	}

	public String getStringAttribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getStringValue(0);
	}

	public float[] getFloat3Attribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getFloat3Value(0);
	}

	public void getFloat3Attribute(int object, float[] values)
	{
	    assertScalarType();
	    m_buffer.getFloat3Value(0, values);
	}

	public double[] getDouble3Attribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getDouble3Value(0);
	}

	public void getDouble3Attribute(int object, double[] values)
	{
	    assertScalarType();
	    m_buffer.getDouble3Value(0, values);
	}

	public int getEnumerationAttribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getEnumerationValue(0).getID();
	}

	public int getEvaluatedEnumerationAttribute(int object)
	{
	    assertScalarType();
	    return m_buffer.getEnumerationValue(0).getValue();
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void assertScalarType()
	{
	    if (!m_buffer.getType().isBaseType())
	    {
		throw new TypeMismatchException();
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private DefaultValuesBuffer  m_buffer;

	////////////////////////////////////////////////////////////////////
	// PRIVATE INNER CLASSES
	////////////////////////////////////////////////////////////////////

	private class ValueIteratorImpl
	    extends ImmutableAbstractValueIterator
	{
	    public ValueIteratorImpl()
	    {
		super();
		m_end = m_buffer.getNumValues();
	    }

	    public boolean atEnd()
	    {
		return m_current == m_end;
	    }

	    public void advance()
	    {
		if (m_current < m_end)
		{
		    ++m_current;
		}
	    }

	    public void rewind()
	    {
		m_current = 0;
	    }

	    public boolean isEmpty()
	    {
		return m_end == 0;
	    }

	    public int getLength()
	    {
		return m_end;
	    }

	    public ValueType getType()
	    {
		return m_buffer.getType();
	    }

	    public boolean getBooleanValue()
	    {
		assertNotAtEnd();
		return m_buffer.getBooleanValue(m_current);
	    }

	    public int getIntegerValue()
	    {
		assertNotAtEnd();
		return m_buffer.getIntegerValue(m_current);
	    }

	    public float getFloatValue()
	    {
		assertNotAtEnd();
		return m_buffer.getFloatValue(m_current);
	    }

	    public double getDoubleValue()
	    {
		assertNotAtEnd();
		return m_buffer.getDoubleValue(m_current);
	    }

	    public String getStringValue()
	    {
		assertNotAtEnd();
		return m_buffer.getStringValue(m_current);
	    }

	    public float[] getFloat3Value()
	    {
		assertNotAtEnd();
		return m_buffer.getFloat3Value(m_current);
	    }

	    public void getFloat3Value(float[] values)
	    {
		assertNotAtEnd();
		m_buffer.getFloat3Value(m_current, values);
	    }

	    public double[] getDouble3Value()
	    {
		assertNotAtEnd();
		return m_buffer.getDouble3Value(m_current);
	    }

	    public void getDouble3Value(double[] values)
	    {
		assertNotAtEnd();
		m_buffer.getDouble3Value(m_current, values);
	    }

	    public int getEnumerationValue()
	    {
		assertNotAtEnd();
		return m_buffer.getEnumerationValue(m_current).getID();
	    }

	    public int getEvaluatedEnumerationValue()
	    {
		assertNotAtEnd();
		return m_buffer.getEnumerationValue(m_current).getValue();
	    }

	    private void assertNotAtEnd()
	    {
		if (m_current == m_end)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    private int  m_current;
	    private int  m_end;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static class DefaultValuesBuffer
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public DefaultValuesBuffer(ValueType type,
				   EnumerationReader reader)
	{
	    m_type = type;
	    m_reader = reader;
	    switch (type.getBaseType())
	    {
	    case ValueType._BOOLEAN:
		m_booleanValues = new GrowableBooleanArray();
		break;
	    case ValueType._INTEGER:
		m_integerValues = new GrowableIntArray();
		break;
	    case ValueType._FLOAT:
		m_floatValues = new GrowableFloatArray();
		break;
	    case ValueType._DOUBLE:
		m_doubleValues = new GrowableDoubleArray();
		break;
	    case ValueType._STRING:
		m_stringValues = new GrowableStringArray();
		break;
	    case ValueType._FLOAT3:
		m_float3Values = new GrowableFloat3Array();
		break;
	    case ValueType._DOUBLE3:
		m_double3Values = new GrowableDouble3Array();
		break;
	    case ValueType._ENUMERATION:
		if (reader == null)
		{
		    String msg = "missing EnumerationReader";
		    throw new IllegalArgumentException(msg);
		}
		m_enumerationValues = new GrowableObjectArray();
		break;
	    default: throw new InternalErrorException();
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public ValueType getType()
	{
	    return m_type;
	}

	public EnumerationReader getEnumerationReader()
	{
	    return m_reader;
	}

	public int getNumValues()
	{
	    return m_numValues;
	}

	public boolean getBooleanValue(int index)
	{
	    validateValueIndex(index);
	    if (m_booleanValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_booleanValues.getValue(index);
	}

	public int getIntegerValue(int index)
	{
	    validateValueIndex(index);
	    if (m_integerValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_integerValues.getValue(index);
	}

	public float getFloatValue(int index)
	{
	    validateValueIndex(index);
	    if (m_floatValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_floatValues.getValue(index);
	}

	public double getDoubleValue(int index)
	{
	    validateValueIndex(index);
	    if (m_doubleValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_doubleValues.getValue(index);
	}

	public String getStringValue(int index)
	{
	    validateValueIndex(index);
	    if (m_stringValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_stringValues.getValue(index);
	}

	public float[] getFloat3Value(int index)
	{
	    validateValueIndex(index);
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_float3Values.getValue(index);
	}

	public void getFloat3Value(int index, float[] values)
	{
	    validateValueIndex(index);
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_float3Values.getValue(index, values);
	}

	public double[] getDouble3Value(int index)
	{
	    validateValueIndex(index);
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    return m_double3Values.getValue(index);
	}

	public void getDouble3Value(int index, double[] values)
	{
	    validateValueIndex(index);
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_double3Values.getValue(index, values);
	}

	public EnumeratorReader getEnumerationValue(int index)
	{
	    validateValueIndex(index);
	    if (m_enumerationValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    return (EnumeratorReader)m_enumerationValues.getValue(index);
	}

	public void appendBooleanValue(boolean value)
	{
	    if (m_booleanValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_booleanValues.append(value);
	    ++m_numValues;
	}

	public void appendIntegerValue(int value)
	{
	    if (m_integerValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_integerValues.append(value);
	    ++m_numValues;
	}

	public void appendFloatValue(float value)
	{
	    if (m_floatValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_floatValues.append(value);
	    ++m_numValues;
	}

	public void appendDoubleValue(double value)
	{
	    if (m_doubleValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_doubleValues.append(value);
	    ++m_numValues;
	}

	public void appendStringValue(String value)
	{
	    if (m_stringValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_stringValues.append(value);
	    ++m_numValues;
	}

	public void appendFloat3Value(float x, float y, float z)
	{
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_float3Values.append(x, y, z);
	    ++m_numValues;
	}

	public void appendFloat3Value(float[] values)
	{
	    if (m_float3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_float3Values.append(values);
	    ++m_numValues;
	}

	public void appendDouble3Value(double x, double y, double z)
	{
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_double3Values.append(x, y, z);
	    ++m_numValues;
	}

	public void appendDouble3Value(double[] values)
	{
	    if (m_double3Values == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_double3Values.append(values);
	    ++m_numValues;
	}

	public void appendEnumerationValue(EnumeratorReader value)
	{
	    if (m_enumerationValues == null)
	    {
		throw new TypeMismatchException();
	    }
	    m_enumerationValues.append(value);
	    ++m_numValues;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void validateValueIndex(int index)
	{
	    if (index < 0 || index >= m_numValues)
	    {
		String msg = "value index[" + index + "] must be >= 0 and < "
		    + m_numValues;
		throw new IllegalArgumentException(msg);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private ValueType  m_type;
	private EnumerationReader  m_reader;  // may be null

	private int  m_numValues;
	private GrowableBooleanArray  m_booleanValues;
	private GrowableIntArray  m_integerValues;
	private GrowableFloatArray  m_floatValues;
	private GrowableDoubleArray  m_doubleValues;
	private GrowableStringArray  m_stringValues;
	private GrowableFloat3Array  m_float3Values;
	private GrowableDouble3Array  m_double3Values;
	private GrowableObjectArray  m_enumerationValues;
    }
}
