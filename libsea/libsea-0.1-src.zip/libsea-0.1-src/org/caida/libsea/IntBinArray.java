// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.*;

/**
 * A class for managing a large collection of independently varying lists of
 * integers.
 *
 * <p>
 * Bin-arrays are a compact way of storing a large collection of lists while
 * allowing modifications in O(1) time. They share many of the characteristics
 * of a collection of doubly-linked lists and are applicable to many of the
 * situations where such a collection would be used.  Bin-arrays are most
 * useful, however, when dealing with a large amount of data, and when using
 * a minimal amount of memory is more important than having extremely fast
 * lookups, insertions, or deletions.  NOTE: Bin-arrays differ in a very
 * important way from doubly-linked lists, in that the purpose of the former
 * is to manage a <em>collection</em> of lists.
 * </p>
 *
 * <p>
 * NOTE: This class is not thread safe.  Also, it is not safe in general to
 * modify a single list through several concurrently active iterators
 * (even with modifications interleaved rather than happening at the same
 * time).  It is fine, of course, to modify a single list through several
 * sequentially active iterators.  Also, if a list is being modified through
 * an iterator, then it is not safe in general for any other iterator to be
 * active on the same list.
 * </p>
 *
 * @see <a href="http://www.caida.org/~youngh/binarrays/binarrays.html>
 *      Bin-arrays documentation</a>
 */
class IntBinArray
{
    ////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ////////////////////////////////////////////////////////////////////////

    /**
     * Constructor using the default segment size.
     *
     * @param isOrdered whether the stored lists are ordered.  Stored lists
     *                  are either all ordered or all unordered.  This
     *                  property can't be changed after an instance of this
     *                  is created.
     */
    public IntBinArray(boolean isOrdered)
    {
	this(isOrdered, DEFAULT_SEGMENT_SIZE);
    }

    /**
     * Constructor taking a segment size.
     *
     * @param isOrdered whether the stored lists are ordered.  Stored lists
     *                  are either all ordered or all unordered.  This
     *                  property can't be changed after an instance of this
     *                  is created.
     * @param segmentSize the number of elements that can fit within an
     *                  allocation segment.  Conceptually, internal arrays
     *                  used to store list data are extended as needed by
     *                  appending segments whose capacity is this many
     *                  elements each.  The term "element" as used here
     *                  doesn't necessarily correspond to a single list item.
     *                  NOTE: The segment size must be a power of two.
     */
    public IntBinArray(boolean isOrdered, int segmentSize)
    {
	if (segmentSize < MIN_SEGMENT_SIZE)
	{
	    segmentSize = MIN_SEGMENT_SIZE;
	}

	if ((segmentSize & -segmentSize) != segmentSize)
	{
	    throw new
		IllegalArgumentException("segmentSize must be a power of 2");
        }

	m_segmentSize = segmentSize;
	m_segmentMask = segmentSize - 1;
	m_segmentSizeBits = MiscMath.log2(m_segmentSize);

	m_isOrdered = isOrdered;

	clear();
    }

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ////////////////////////////////////////////////////////////////////////

    /**
     * Returns an iterator over the list at the given index.
     *
     * @param index the index of an allocated list
     * @return an iterator over the given list
     * @exception UnallocatedElementException
     *             if index does not specify an allocated list
     */
    public ValueIterator getValue(int index)
    {
	validateHandleIndexArgument(index);
	if (!m_allocationMap[HANDLE].get(index))
	{
	    throw new UnallocatedElementException();
	}

	return new ValueIteratorImpl(index, m_relaxRemovalSemantics);
    }

    /**
     * Returns whether there exists an allocated list at the given index.
     *
     * @param index an index at which to check for an allocated list
     * @return whether a list is allocated at the given index
     * @see #allocate()
     * @see #free(int)
     */
    public boolean checkAllocated(int index)
    {
	validateHandleIndexArgument(index);
	return m_allocationMap[HANDLE].get(index);
    }

    /**
     * Returns the index of a newly allocated empty list.
     *
     * @return the index of a newly allocated empty list.  This always
     *         succeeds, barring total exhaustion of heap memory.
     * @see #free(int)
     * @see #checkAllocated(int)
     */
    public int allocate()
    {
	int retval = allocateElement(HANDLE);
	setFirstValueUnchecked(HANDLE, retval, -1);
	return retval;
    }

    /**
     * Frees an allocated list, including all its elements.
     *
     * This does nothing if there is no allocated list at the given index.
     * There is no need to remove the elements of a list prior to freeing
     * it.
     *
     * @param index the index of an allocated list to free
     * @see #allocate()
     * @see #checkAllocated(int)
     */
    public void free(int index)
    {
	validateHandleIndexArgument(index);
	if (m_allocationMap[HANDLE].get(index))
	{
	    int handle = getFirstValueUnchecked(HANDLE, index);
	    if (handle != -1)
	    {
		int binType = handle & HANDLE_TYPE_MASK;
		int binIndex = handle >>> HANDLE_INDEX_SHIFT;

		if (binType == BIN4)
		{
		    int binLastIndex = getBin4PreviousIndex(binIndex);

		    int nextIndex = binIndex;
		    while (nextIndex != binLastIndex)
		    {
			binIndex = nextIndex;
			nextIndex = getBin4Next(nextIndex);
			freeElement(BIN4, binIndex);
		    }

		    freeElement(BIN4, binLastIndex);
		}
		else
		{
		    freeElement(binType, binIndex);
		}
	    }
	    freeElement(HANDLE, index);
	}
	else if (DEBUG)
	{
	    System.err.println("WARNING: IntBinArray.free("
			       + index + "): index already free");
	}
    }

    /**
     * Frees all allocated lists in bulk quickly.
     *
     * This is far more efficient than freeing each allocated list in turn.
     */
    public void clear()
    {
	m_freeList = new int[5];
	Arrays.fill(m_freeList, -1);

	m_allocationMap = new BitSet[5];
	m_allocationMap[0] = new BitSet();
	m_allocationMap[1] = new BitSet();
	m_allocationMap[2] = new BitSet();
	m_allocationMap[3] = new BitSet();
	m_allocationMap[4] = new BitSet();

	m_numAllocatedSlots = new int[5];
	m_numAllocatedSegments = new int[5];

	m_segments = new int[5][][];
	m_segments[0] = new int[STARTING_NUM_SEGMENTS][];
	m_segments[1] = new int[STARTING_NUM_SEGMENTS][];
	m_segments[2] = new int[STARTING_NUM_SEGMENTS][];
	m_segments[3] = new int[STARTING_NUM_SEGMENTS][];
	m_segments[4] = new int[STARTING_NUM_SEGMENTS][];
    }

    /**
     * Returns the total number of allocated lists.
     */
    public int getNumAllocated()
    {
	return m_numAllocatedSlots[HANDLE];
    }

    ////////////////////////////////////////////////////////////////////////
    // DEBUGGING AND TESTING METHODS
    ////////////////////////////////////////////////////////////////////////

    /**
     * Changes the behavior of <code>removeValue</code> in any future
     * <code>ValueIterator</code> such that removing the last element
     * repositions the iterator at the next-to-last element rather than
     * at the position off the end of the list.
     *
     * This is for testing purposes only.
     *
     * @see #ValueIterator.removeValue()
     */
    public void relaxRemovalSemantics()
    {
	m_relaxRemovalSemantics = true;
    }

    /**
     * Checks that all list structures are well-formed, that all allocated
     * lists and elements are reachable, and that no memory has leaked.
     *
     * Runtime will typically be proportional to the amount of allocated
     * data, and hence this will usually take a while.
     *
     * @exception InvariantFailedException if any inconsistencies are found
     * @see #checkListInvariants()
     * @see #checkForMemoryLeaks()
     */
    public void checkEverything()
    {
	checkListInvariants();
	checkForMemoryLeaks();
    }

    /**
     * Checks that all structures representing allocated lists are well-formed
     * and that allocated lists, and all elements in those lists, are
     * reachable.
     *
     * @exception InvariantFailedException if any inconsistencies are found
     */
    public void checkListInvariants()
    {
	int length = m_allocationMap[HANDLE].length();
	for (int i = 0; i < length; i++)
	{
	    if (checkAllocated(i))
	    {
		checkListInvariants(i);
	    }
	}
    }

    /**
     * Checks that all structures representing the given allocated list are
     * well-formed and that the list and its elements are reachable.
     *
     * @param index the index of an allocated list to check
     * @exception InvariantFailedException if any inconsistencies are found
     */
    public void checkListInvariants(int index)
    {
	validateHandleIndexArgument(index);
	int handle = getFirstValueUnchecked(HANDLE, index);
	if (handle != -1 && extractHandleType(handle) == BIN4)
	{
	    int firstBinIndex = extractHandleIndex(handle);
	    int firstSegmentIndex = computeSegment(firstBinIndex);
	    int firstStartingOffset = computeBin4Offset(firstBinIndex);
	    int firstPrevious =
		getBin4Previous(firstSegmentIndex, firstStartingOffset);
	    int firstOccupancy =
		getBin4Occupancy(firstSegmentIndex, firstStartingOffset);

	    int lastBinIndex = extractIndex(firstPrevious);
	    int lastSegmentIndex = computeSegment(lastBinIndex);
	    int lastStartingOffset = computeBin4Offset(lastBinIndex);
	    int length = getBin4Next(lastSegmentIndex, lastStartingOffset);

	    if (lastBinIndex == firstBinIndex)
	    {
		if (length != 4)
		{
		    String msg = "ERROR: checkListInvariants(" + index
			+ "): single-bin list doesn't have "
			+ "length set to 4.";
		    throw new InvariantFailedException(msg);
		}

		if (firstOccupancy != 4)
		{
		    String msg = "ERROR: checkListInvariants(" + index
			+ "): single-bin list doesn't have "
			+ "occupancy set to 4.";
		    throw new InvariantFailedException(msg);
		}
	    }
	    else
	    {
		// In addition to checking that the previous- and next-link
		// fields are valid in each element, check that the
		// occupancies of any two adjacent elements never add up
		// to less than 5.  This should never happen because such
		// a pair of occupancies would cause the two elements to be
		// merged during a removal operation.

		int count = firstOccupancy;
		int previousIndex;
		int previousOccupancy;
		int currentBinPosition = 0;
		int currentIndex = firstBinIndex;
		int currentSegmentIndex = firstSegmentIndex;
		int currentStartingOffset = firstStartingOffset;
		int currentOccupancy = firstOccupancy;

		while (currentIndex != lastBinIndex)
		{
		    previousIndex = currentIndex;

		    ++currentBinPosition;
		    currentIndex = getBin4Next(currentSegmentIndex,
					       currentStartingOffset);
		    currentSegmentIndex = computeSegment(currentIndex);
		    currentStartingOffset = computeBin4Offset(currentIndex);

		    int currentPreviousIndex =
			getBin4PreviousIndex(currentSegmentIndex,
					     currentStartingOffset);
		    if (currentPreviousIndex != previousIndex)
		    {
			String msg = "ERROR: checkListInvariants(" + index
			    + "): bin " + currentIndex + " at position "
			    + currentBinPosition
			    + " doesn't have its previous-link field ["
			    + currentPreviousIndex + "] pointing to the "
			    + "previous bin [" + previousIndex + "].";
			throw new InvariantFailedException(msg);
		    }

		    previousOccupancy = currentOccupancy;
		    currentOccupancy = getBin4Occupancy(currentSegmentIndex,
							currentStartingOffset);
		    if (previousOccupancy + currentOccupancy <= 4)
		    {
			String msg = "ERROR: checkListInvariants("
			    + index + "): bin " + (currentBinPosition - 1)
			    + " and bin " + currentBinPosition
			    + " have combined occupancy "
			    + (previousOccupancy + currentOccupancy)
			    + " which is not > 4.";
			throw new InvariantFailedException(msg);
		    }

		    count += currentOccupancy;
		}

		if (count != length)
		{
		    String msg = "ERROR: checkListInvariants("
			+ index + "): sum of occupancies [" + count
			+ "] doesn't add up to list length [" + length + "].";
		    throw new InvariantFailedException(msg);
		}
	    }
	}
    }

    /**
     * Checks for any memory leaks in the internal list structures
     * representing allocated lists.
     *
     * Several checks are performed.  First, this checks that each allocation
     * element is either allocated or on the appropriate free list, and that
     * no element appears more than once in a free list.  Second, this checks
     * that certain statistics, such as the number of allocated lists, are
     * accurate.  Third, this checks that all allocated lists, and all elements
     * in those lists, are marked as allocated and are reachable.
     *
     * @exception InvariantFailedException if any inconsistencies are found
     * @see #checkAllocationTableForConsistency()
     * @see #checkForReachability()
     */
    public void checkForMemoryLeaks()
    {
        checkAllocationTableForConsistency();
	checkForReachability();
    }

    /**
     * Checks that each available slot is either allocated or free, but not
     * both, and that the recorded number of allocated slots is accurate.
     *
     * @exception InvariantFailedException if any inconsistencies are found
     * @see #checkAllocationTableForConsistency(int)
     */
    public void checkAllocationTableForConsistency()
    {
	checkNumAllocatedSegments();
	checkAllocationTableForConsistency(BIN1);
	checkAllocationTableForConsistency(BIN2);
	checkAllocationTableForConsistency(BIN3);
	checkAllocationTableForConsistency(BIN4);
	checkAllocationTableForConsistency(HANDLE);
    }

    /**
     * Checks that each bin marked as allocated is in fact reachable through
     * some handle.
     *
     * @exception InvariantFailedException if any inconsistencies are found
     */
    public void checkForReachability()
    {
	BitSet[] reachableMap = new BitSet[4];
	for (int i = 0; i < 4; i++)
	{
	    reachableMap[i] = new BitSet();
	}

	int length = m_allocationMap[HANDLE].length();
	for (int i = 0; i < length; i++)
	{
	    populateReachabilityMap(reachableMap, i);
	}

	compareReachability(BIN1, reachableMap[BIN1]);
	compareReachability(BIN2, reachableMap[BIN2]);
	compareReachability(BIN3, reachableMap[BIN3]);
	compareReachability(BIN4, reachableMap[BIN4]);
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ////////////////////////////////////////////////////////////////////////

    /**
     * Checks that each available slot of a given bin type is either allocated
     * or free, but not both, and that the recorded number of allocated slots
     * is accurate.
     *
     * @param type the type of bin elements to check
     * @exception InvariantFailedException if any inconsistencies are found
     * @see #checkAllocationTableForConsistency(int)
     */
    private void checkAllocationTableForConsistency(int type)
    {
	if (DEBUG)
	{
	    validateBinType("checkAllocationTableForConsistency", type);
	}

	int numAllocatedSlots = 0;
	BitSet freeMap = computeFreeElementsMap(type);
	int length = Math.max(m_allocationMap[type].length(),
			      freeMap.length());

	for (int i = 0; i < length; i++)
	{
	    boolean freeMapEntry = freeMap.get(i);
	    boolean allocationMapEntry = m_allocationMap[type].get(i);

	    if (allocationMapEntry)
	    {
		++numAllocatedSlots;
	    }

	    if (freeMapEntry == allocationMapEntry)
	    {
		if (freeMapEntry)
		{
		    String msg =
			"ERROR: checkAllocationTableForConsistency(): "
			+ "logical index " + i + " of type " + type
			+ " is marked both as allocated and free.";
		    throw new InvariantFailedException(msg);
		}
		else
		{
		    String msg =
			"ERROR: checkAllocationTableForConsistency(): "
			+ "logical index " + i + " of type " + type
			+ " is marked neither as allocated nor free.";
		    throw new InvariantFailedException(msg);
		}
	    }
	}

	if (numAllocatedSlots != m_numAllocatedSlots[type])
	{
	    String msg =
		"ERROR: checkAllocationTableForConsistency(): "
		+ "the number of elements marked as allocated ["
		+ numAllocatedSlots + "] differs from the recorded "
		+ "number [" + m_numAllocatedSlots[type] + "].";
	    throw new InvariantFailedException(msg);
	}
    }

    /**
     * Checks that the given reachability map matches the allocation map
     * of the given type of bin elements.
     *
     * @param type the type of bin elements to check
     * @param reachableMap a BitSet in which each reachable bin of the given
     *           type is represented by a set bit at the corresponding
     *           logical index
     * @exception InvariantFailedException if any inconsistencies are found
     */
    private void compareReachability(int type, BitSet reachableMap)
    {
	if (DEBUG) { validateBinType("compareReachability", type);	}

	int length = Math.max(m_allocationMap[type].length(),
			      reachableMap.length());

	for (int i = 0; i < length; i++)
	{
	    boolean reachableMapEntry = reachableMap.get(i);
	    boolean allocationMapEntry = m_allocationMap[type].get(i);

	    if (reachableMapEntry != allocationMapEntry)
	    {
		if (reachableMapEntry)
		{
		    String msg = "ERROR: compareReachability(): "
			+ "index " + i + " of type " + type
			+ " is reachable but not marked as allocated.";
		    throw new InvariantFailedException(msg);
		}
		else
		{
		    String msg = "ERROR: compareReachability(): "
			+ "index " + i + " of type " + type
			+ " is allocated but not reachable.";
		    throw new InvariantFailedException(msg);
		}
	    }
	}
    }

    /**
     * Populates the given BitSet with information about bin elements
     * reachable at the given handle index, which need not be that of an
     * allocated handle.
     *
     * @param reachableMap a BitSet to populate with information about
     *           bin elements reachable at the given handle index.  A
     *           reachable element is represented by a set bit at the
     *           corresponding logical index.
     * @param handleIndex the index of a list whose elements this examines
     *           for reachability.  Nothing is done if this index does not
     *           specify an allocated handle.
     * @exception InvariantFailedException if any inconsistencies are found
     */
    private void populateReachabilityMap(BitSet[] reachableMap,
					 int handleIndex)
    {
	if (DEBUG)
	{
	    validateBinIndex("populateReachabilityMap", handleIndex);
	}

	if (checkAllocated(handleIndex))
	{
	    int handle = getFirstValueUnchecked(HANDLE, handleIndex);
	    if (handle != -1)
	    {
		int binIndex = extractHandleIndex(handle);
		int binType = extractHandleType(handle);

		if (binIndex < 0)
		{
		    String msg = "ERROR: populateReachabilityMap(): "
			+ "bin index " + binIndex + " in handle is not >= 0.";
		    throw new InvariantFailedException(msg);
		}

		if (m_allocationMap[binType].get(binIndex))
		{
		    if (reachableMap[binType].get(binIndex))
		    {
			String msg = "ERROR: populateReachabilityMap(): "
			    + "bin index " + binIndex + " of type " + binType
			    + " is reachable via more than one handle.";
			throw new InvariantFailedException(msg);
		    }

		    reachableMap[binType].set(binIndex);
		}
		else
		{
		    String msg = "ERROR: populateReachabilityMap(): "
			+ "bin index " + binIndex + " of type " + binType
			+ " is not marked as allocated.";
		    throw new InvariantFailedException(msg);
		}

		if (binType == BIN4)
		{
		    int lastBinIndex = getBin4PreviousIndex(binIndex);
		    int currentBinIndex = binIndex;

		    while (currentBinIndex != lastBinIndex)
		    {
			currentBinIndex = getBin4Next(currentBinIndex);
			if (m_allocationMap[BIN4].get(currentBinIndex))
			{
			    if (reachableMap[BIN4].get(currentBinIndex))
			    {
				String msg =
				    "ERROR: populateReachabilityMap(): "
				    + "BIN4 index " + currentBinIndex
				    + " is reachable in more than one way.";
				throw new InvariantFailedException(msg);
			    }

			    reachableMap[BIN4].set(currentBinIndex);
			}
			else
			{
			    String msg =
				"ERROR: populateReachabilityMap(): "
				+ "BIN4 index " + currentBinIndex
				+ " is not marked as allocated.";
			    throw new InvariantFailedException(msg);
			}
		    }
		}
	    }
	}
    }

    /**
     * Checks that the recorded number of segments allocated for each bin
     * type is accurate.
     *
     * Specifically, this checks that <code>m_numAllocatedSegments[i]</code>
     * accurately reflects the number of segments actually allocated to
     * <code>m_segments[i]</code>.
     * If <code>n == m_numAllocatedSegments[i]</code>, then
     * <code>m_segments[i][0]</code> to <code>m_segments[i][n-1]</code>
     * will point to allocated segments.
     *
     * @exception InvariantFailedException if any inconsistencies are found
     */
    private void checkNumAllocatedSegments()
    {
	for (int i = 0; i < 5; i++)
	{
	    int numAllocatedSegments = m_numAllocatedSegments[i];

	    if (numAllocatedSegments < 0
		|| numAllocatedSegments > m_segments[i].length)
	    {
		String msg = "ERROR: checkNumAllocatedSegments(): "
		    + "m_numAllocatedSegments[" + i + "], which equals "
		    + numAllocatedSegments + ", is not >= 0 and <= "
		    + m_segments[i].length + ".";
		throw new InvariantFailedException(msg);
	    }

	    for (int j = 0; j < numAllocatedSegments; j++)
	    {
		if (m_segments[i][j] == null)
		{
		    String msg = "ERROR: checkNumAllocatedSegments(): "
			+ "m_segments[" + i + "][" + j + "] should point "
			+ "to a segment but is null.";
		    throw new InvariantFailedException(msg);
		}
	    }

	    for (int j = numAllocatedSegments; j < m_segments[i].length; j++)
	    {
		if (m_segments[i][j] != null)
		{
		    String msg = "ERROR: checkNumAllocatedSegments(): "
			+ "m_segments[" + i + "][" + j + "] should be null "
			+ "but points to some object.";
		    throw new InvariantFailedException(msg);
		}
	    }
	}
    }

    /**
     * Returns a BitSet in which each element of the given bin type that
     * is on the corresponding free list is represented by a set bit at
     * the corresponding logical index.
     *
     * @param type the type of bin elements to examine
     * @return a BitSet in which each element of the given type on the
     *         corresponding free list is represented by a set bit at the
     *         corresponding logical index
     * @exception InvariantFailedException if any inconsistencies are found
     */
    private BitSet computeFreeElementsMap(int type)
    {
	if (DEBUG) { validateBinType("computeFreeElementsMap", type); }

	BitSet retval = new BitSet();
	int freeList = m_freeList[type];

	while (freeList != -1)
	{
	    if (retval.get(freeList))
	    {
		String msg = "ERROR: computeFreeElementsMap(): "
		    + "logical index " + freeList + " occurs twice in the "
		    + "free list.";
		throw new InvariantFailedException(msg);
	    }
	    else if (m_allocationMap[type].get(freeList))
	    {
		String msg = "ERROR: computeFreeElementsMap(): "
		    + "allocated element at logical index " + freeList
		    + " appears in the free list.";
		throw new InvariantFailedException(msg);
	    }
	    else
	    {
		int segmentIndex = computeSegment(freeList);
		if (segmentIndex < 0
		    || segmentIndex >= m_numAllocatedSegments[type])
		{
		    String msg = "ERROR: computeFreeElementsMap(): "
			+ "logical index " + freeList + " on the free list "
			+ "implies an invalid segmentIndex [" + segmentIndex
			+ "], which must be >= 0 and < "
			+ m_numAllocatedSegments[type] + ".";
		    throw new InvariantFailedException(msg);
		}
		else
		{
		    retval.set(freeList);
		    freeList = getFirstValueUnchecked(type, freeList);
		}
	    }
	}

	return retval;
    }

    /**
     * Returns the data stored at the given segment index and offset in the
     * BIN4 array.
     *
     * @param segmentIndex the index of the segment containing the data
     * @param offset the offset within the segment where the data can be found
     * @return the value at the given segment index and offset
     * @see #setBin4Data(int, int, int)
     * @see #getBin4Previous(int)
     * @see #getBin4Next(int)
     */
    private int getBin4Data(int segmentIndex, int offset)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("getBin4Data", segmentIndex, offset);
	    validateBin4DataOffset("getBin4Data", offset);
	}

	return m_segments[BIN4][segmentIndex][offset];
    }

    /**
     * Stores data at the given segment index and offset in the BIN4 array.
     *
     * @param segmentIndex
     *          the index of the segment where the data should be stored
     * @param offset
     *          the offset within the segment where the data should be stored
     * @param value the value to store at the given location
     * @see #getBin4Data(int, int)
     * @see #setBin4Previous(int)
     * @see #setBin4Next(int)
     */
    private void setBin4Data(int segmentIndex, int offset, int value)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("setBin4Data", segmentIndex, offset);
	    validateBin4DataOffset("setBin4Data", offset);
	}

	m_segments[BIN4][segmentIndex][offset] = value;
    }

    /**
     * Returns the whole value in the previous-link field of the BIN4 element
     * at the given logical index.
     *
     * <p>
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This returns a value which is a composite of the two
     * pieces of information.
     * </p>
     *
     * <p>
     * The preceding BIN4 element of the first BIN4 element in a list is the
     * last BIN4 element in the same list.
     * </p>
     *
     * @param binIndex the logical index of the BIN4 element to examine
     * @return the whole value in the previous-link field of the BIN4 element
     *         at the given logical index
     * @see #getBin4Previous(int, int)
     * @see #getBin4PreviousIndex(int)
     * @see #extractIndex(int)
     * @see #extractOccupancy(int)
     */
    private int getBin4Previous(int binIndex)
    {
	if (DEBUG) { validateBinIndex("getBin4Previous", binIndex); }

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	return getBin4Previous(segment, offset);
    }

    /**
     * Returns the logical index of the BIN4 element preceding the one
     * specified by the given logical index in a list.
     *
     * The preceding BIN4 element of the first BIN4 element in a list is the
     * last BIN4 element in the same list.
     *
     * @param binIndex the logical index of the BIN4 element to examine
     * @return the logical index of the BIN4 element preceding the one
     *         specified by the given logical index
     * @see #getBin4PreviousIndex(int, int)
     * @see #getBin4Previous(int)
     */
    private int getBin4PreviousIndex(int binIndex)
    {
	if (DEBUG) { validateBinIndex("getBin4PreviousIndex", binIndex); }

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	return getBin4PreviousIndex(segment, offset);
    }

    /**
     * Returns the number of user data elements currently occupying the BIN4
     * element at the given logical index.
     *
     * @param binIndex the logical index of the BIN4 element to examine
     * @return the number of user data elements occupying the BIN4 element
     *         at the given location
     * @see #getBin4Occupancy(int, int)
     * @see #getBin4Previous(int)
     */
    private int getBin4Occupancy(int binIndex)
    {
	if (DEBUG) { validateBinIndex("getBin4Occupancy", binIndex); }

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	return getBin4Occupancy(segment, offset);
    }

    /**
     * Returns the value in the next-link field of the BIN4 element at the
     * given logical index.
     *
     * The next-link field of the last BIN4 element in a list contains the
     * length of the list.  In all other cases, the field contains the
     * logical index of the BIN4 element following the given one in the list.
     *
     * @param binIndex the logical index of the BIN4 element to examine
     * @return the value in the next-link field of the BIN4 element
     *         at the given logical index
     * @see #getBin4Next(int, int)
     */
    private int getBin4Next(int binIndex)
    {
	if (DEBUG) { validateBinIndex("getBin4Next", binIndex); }

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	return getBin4Next(segment, offset);
    }

    /**
     * Sets the whole value in the previous-link field of the BIN4 element
     * at the given logical index.
     *
     * <p>
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This sets the composite value.
     * </p>
     *
     * <p>
     * The preceding BIN4 element of the first BIN4 element in a list must be
     * the last BIN4 element in the same list.
     * </p>
     *
     * @param binIndex the logical index of the BIN4 element to change
     * @param previousIndex the logical index of the BIN4 element preceding
     *         the one at the given location
     * @param occupancy the number of user data elements occupying the BIN4
     *         element at the given location
     * @see #setBin4Previous(int, int, int, int)
     * @see #setBin4PreviousIndex(int, int)
     * @see #setBin4Occupancy(int, int)
     */
    private void setBin4Previous(int binIndex, int previousIndex,
				 int occupancy)
    {
	if (DEBUG)
	{
	    validateBinIndex("setBin4Previous", binIndex);
	    validateBinIndex("setBin4Previous", previousIndex);
	    validateOccupancy("setBin4Previous", occupancy);
	}

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	setBin4Previous(segment, offset, previousIndex, occupancy);
    }

    /**
     * Changes the component of the value in the previous-link field of the
     * BIN4 element at the given logical index which specifies the logical
     * index of the preceding BIN4 element.
     *
     * <p>
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This leaves the occupancy value unchanged.
     * </p>
     *
     * <p>
     * The preceding BIN4 element of the first BIN4 element in a list must be
     * the last BIN4 element in the same list.
     * </p>
     *
     * @param binIndex the logical index of the BIN4 element to change
     * @param previousIndex the logical index of the BIN4 element preceding
     *         the one at the given location
     * @see #setBin4PreviousIndex(int, int, int)
     * @see #setBin4Previous(int, int, int)
     */
    private void setBin4PreviousIndex(int binIndex, int previousIndex)
    {
	if (DEBUG)
	{
	    validateBinIndex("setBin4PreviousIndex", binIndex);
	    validateBinIndex("setBin4PreviousIndex", previousIndex);
	}

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	setBin4PreviousIndex(segment, offset, previousIndex);
    }

    /**
     * Changes the component of the value in the previous-link field of the
     * BIN4 element at the given logical index which specifies the number of
     * user data elements occupying the BIN4 element.
     *
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This leaves the index value unchanged.
     *
     * @param binIndex the logical index of the BIN4 element to change
     * @param occupancy the number of user data elements occupying the BIN4
     *         element at the given location
     * @see #setBin4Occupancy(int, int, int)
     * @see #setBin4Previous(int, int, int)
     */
    private void setBin4Occupancy(int binIndex, int occupancy)
    {
	if (DEBUG)
	{
	    validateBinIndex("setBin4Occupancy", binIndex);
	    validateOccupancy("setBin4Occupancy", occupancy);
	}

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	setBin4Occupancy(segment, offset, occupancy);
    }

    /**
     * Sets the value in the next-link field of the BIN4 element at the
     * given logical index.
     *
     * The next-link field of the last BIN4 element in a list must contain
     * the length of the list.  In all other cases, the field should contain
     * the logical index of the BIN4 element following the given one in the
     * list.
     *
     * @param binIndex the logical index of the BIN4 element to change
     * @param nextIndex the logical index of the BIN4 element following
     *         the one at the given location, or the length of the list,
     *         if modifying the last BIN4 element on a list
     * @see #setBin4Next(int, int, int)
     */
    private void setBin4Next(int binIndex, int nextIndex)
    {
	if (DEBUG)
	{
	    validateBinIndex("setBin4Next", binIndex);
	    validateNextBinIndex("setBin4Next", nextIndex);
	}

	int segment = computeSegment(binIndex);
	int offset = computeBin4Offset(binIndex);

	setBin4Next(segment, offset, nextIndex);
    }

    /**
     * Returns the whole value in the previous-link field of the BIN4 element
     * at the given segment index and offset.
     *
     * <p>
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This returns a value which is a composite of the two
     * pieces of information.
     * </p>
     *
     * <p>
     * The preceding BIN4 element of the first BIN4 element in a list is the
     * last BIN4 element in the same list.
     * </p>
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to examine
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to examine
     * @return the whole value in the previous-link field of the BIN4 element
     *         at the given location
     * @see #getBin4Previous(int)
     * @see #getBin4PreviousIndex(int, int)
     * @see #extractIndex(int)
     * @see #extractOccupancy(int)
     */
    private int getBin4Previous(int segmentIndex, int startingOffset)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("getBin4Previous", segmentIndex,
					 startingOffset);
	}

	return m_segments[BIN4][segmentIndex][startingOffset+BIN4_PREV_OFFSET];
    }

    /**
     * Returns the logical index of the BIN4 element preceding the one
     * specified by the given segment index and offset.
     *
     * The preceding BIN4 element of the first BIN4 element in a list is the
     * last BIN4 element in the same list.
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to examine
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to examine
     * @return the logical index of the BIN4 element preceding the one
     *         at the given location
     * @see #getBin4PreviousIndex(int)
     * @see #getBin4Previous(int, int)
     */
    private int getBin4PreviousIndex(int segmentIndex, int startingOffset)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("getBin4PreviousIndex", segmentIndex,
					 startingOffset);
	}

	int previous = getBin4Previous(segmentIndex, startingOffset);
	return extractIndex(previous);
    }

    /**
     * Returns the number of user data elements currently occupying the BIN4
     * element at the given segment index and offset.
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to examine
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to examine
     * @return the number of user data elements occupying the BIN4 element
     *         at the given location
     * @see #getBin4Occupancy(int)
     * @see #getBin4Previous(int, int)
     */
    private int getBin4Occupancy(int segmentIndex, int startingOffset)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("getBin4Occupancy", segmentIndex,
					 startingOffset);
	}

	int previous = getBin4Previous(segmentIndex, startingOffset);
	return extractOccupancy(previous);
    }

    /**
     * Returns the value in the next-link field of the BIN4 element at the
     * given segment index and offset.
     *
     * The next-link field of the last BIN4 element in a list contains the
     * length of the list.  In all other cases, the field contains the
     * logical index of the BIN4 element following the given one in the list.
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to examine
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to examine
     * @return the value in the next-link field of the BIN4 element
     *         at the given location
     * @see #getBin4Next(int)
     */
    private int getBin4Next(int segmentIndex, int startingOffset)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("getBin4Next", segmentIndex,
					 startingOffset);
	}

	return m_segments[BIN4][segmentIndex][startingOffset+BIN4_NEXT_OFFSET];
    }

    /**
     * Sets the whole value in the previous-link field of the BIN4 element
     * at the given segment index and offset.
     *
     * <p>
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This sets the composite value.
     * </p>
     *
     * <p>
     * The preceding BIN4 element of the first BIN4 element in a list must be
     * the last BIN4 element in the same list.
     * </p>
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to change
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to change
     * @param previousIndex the logical index of the BIN4 element preceding
     *         the one at the given location
     * @param occupancy the number of user data elements occupying the BIN4
     *         element at the given location
     * @see #setBin4Previous(int, int, int)
     * @see #setBin4PreviousIndex(int, int, int)
     * @see #setBin4Occupancy(int, int, int)
     */
    private void setBin4Previous(int segmentIndex, int startingOffset,
				 int previousIndex, int occupancy)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("setBin4Previous", segmentIndex,
					 startingOffset);
	    validateBinIndex("setBin4Previous", previousIndex);
	    validateOccupancy("setBin4Previous", occupancy);
	}

	m_segments[BIN4][segmentIndex][startingOffset + BIN4_PREV_OFFSET]
	    = constructPrevious(previousIndex, occupancy);
    }

    /**
     * Changes the component of the value in the previous-link field of the
     * BIN4 element at the given segment index and offset which specifies
     * the logical index of the preceding BIN4 element.
     *
     * <p>
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This leaves the occupancy value unchanged.
     * </p>
     *
     * <p>
     * The preceding BIN4 element of the first BIN4 element in a list must be
     * the last BIN4 element in the same list.
     * </p>
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to change
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to change
     * @param previousIndex the logical index of the BIN4 element preceding
     *         the one at the given location
     * @see #setBin4PreviousIndex(int, int)
     * @see #setBin4Previous(int, int, int, int)
     */
    private void setBin4PreviousIndex(int segmentIndex, int startingOffset,
				      int previousIndex)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("setBin4PreviousIndex", segmentIndex,
					 startingOffset);
	    validateBinIndex("setBin4PreviousIndex", previousIndex);
	}

	int occupancy = getBin4Occupancy(segmentIndex, startingOffset);
	setBin4Previous(segmentIndex, startingOffset,
			previousIndex, occupancy);
    }

    /**
     * Changes the component of the value in the previous-link field of the
     * BIN4 element at the given segment index and offset which specifies
     * the number of user data elements occupying the BIN4 element.
     *
     * NOTE: The previous-link field stores both the occupancy of the BIN4
     * element and the index of the BIN4 element preceding the given one in
     * the list.  This leaves the index value unchanged.
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to change
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to change
     * @param occupancy the number of user data elements occupying the BIN4
     *         element at the given location
     * @see #setBin4Occupancy(int, int)
     * @see #setBin4Previous(int, int, int, int)
     */
    private void setBin4Occupancy(int segmentIndex, int startingOffset,
				  int occupancy)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("setBin4Occupancy", segmentIndex,
					 startingOffset);
	    validateOccupancy("setBin4Occupancy", occupancy);
	}

	int previousIndex = getBin4PreviousIndex(segmentIndex, startingOffset);
	setBin4Previous(segmentIndex, startingOffset,
			previousIndex, occupancy);
    }

    /**
     * Sets the value in the next-link field of the BIN4 element at the
     * given segment index and offset.
     *
     * The next-link field of the last BIN4 element in a list must contain
     * the length of the list.  In all other cases, the field should contain
     * the logical index of the BIN4 element following the given one in the
     * list.
     *
     * @param segmentIndex
     *         the index of the segment containing the BIN4 element to change
     * @param startingOffset
     *         the offset within a segment of the start of the data of the
     *         BIN4 element to change
     * @param nextIndex the logical index of the BIN4 element following
     *         the one at the given location, or the length of the list,
     *         if modifying the last BIN4 element on a list
     * @see #setBin4Next(int, int)
     */
    private void setBin4Next(int segmentIndex, int startingOffset,
			     int nextIndex)
    {
	if (DEBUG)
	{
	    validateBin4SegmentAndOffset("setBin4Next", segmentIndex,
					 startingOffset);
	    validateNextBinIndex("setBin4Next", nextIndex);
	}

	m_segments[BIN4][segmentIndex][startingOffset + BIN4_NEXT_OFFSET]
	    = nextIndex;
    }

    /**
     * Returns the first integer contained in the bin of the given type
     * at the given logical index, without checking whether the bin is
     * allocated, which it need not be.
     *
     * @param type the type of bin to examine.  This must be one of
     *          BIN1, ..., BIN4, HANDLE.
     * @param index the logical index of the bin to examine
     * @return the first integer contained in the bin at the given location
     * @see #setFirstValueUnchecked(int, int, int)
     */
    private int getFirstValueUnchecked(int type, int index)
    {
	if (DEBUG)
	{
	    validateBinType("getFirstValueUnchecked", type);
	    validateBinIndex("getFirstValueUnchecked", index);
	}

	int segment = computeSegment(index);
	int offset = computeOffset(type, index);

	return m_segments[type][segment][offset];
    }

    /**
     * Changes the first integer contained in the bin of the given type
     * at the given logical index, without checking whether the bin is
     * allocated, which it need not be.
     *
     * @param type the type of bin to change.  This must be one of
     *          BIN1, ..., BIN4, HANDLE.
     * @param index the logical index of the bin to change
     * @param value the integer to store at the first position in the bin
     * @see #getFirstValueUnchecked(int, int, int)
     */
    private void setFirstValueUnchecked(int type, int index, int value)
    {
	if (DEBUG)
	{
	    validateBinType("setFirstValueUnchecked", type);
	    validateBinIndex("setFirstValueUnchecked", index);
	}

	int segment = computeSegment(index);
	int offset = computeOffset(type, index);

	m_segments[type][segment][offset] = value;
    }

    /**
     * Returns the logical index of a newly allocated uninitialized bin of
     * the given type.
     *
     * Barring complete exhaustion of the Java heap, this always succeeds.
     * 
     * @param type the type of bin to allocate.  This must be one of
     *          BIN1, ..., BIN4, HANDLE.
     * @return the logical index of the newly allocated bin
     * @see #freeElement(int, int)
     */
    private int allocateElement(int type)
    {
	if (DEBUG) { validateBinType("allocateElement", type); }

	int retval = -1;

	if (m_freeList[type] != -1)
	{
	    retval = m_freeList[type];
	    m_freeList[type] = getFirstValueUnchecked(type, retval);
	}
	else
	{
	    if (m_numAllocatedSegments[type] == m_segments[type].length)
	    {
		expandSegmentsArray(type);
	    }

	    retval = m_numAllocatedSegments[type] << m_segmentSizeBits;
	    m_segments[type][m_numAllocatedSegments[type]] =
		createFreeListSegment(type, retval);
	    ++m_numAllocatedSegments[type];
	    m_freeList[type] = retval + 1;
	}

	if (DEBUG && m_allocationMap[type].get(retval))
	{
	    System.err.println("ERROR: IntBinArray.allocate() => "
			       + retval + ": index already allocated.");
	    System.exit(0);
	}

	m_allocationMap[type].set(retval);
	++m_numAllocatedSlots[type];
	return retval;
    }

    /**
     * Deallocates a currently allocated bin of the given type at the given
     * logical index.
     *
     * @param type the type of bin to deallocate.  This must be one of
     *          BIN1, ..., BIN4, HANDLE.
     * @param index the logical index of a currently allocated bin of the
     *          given type
     * @see #allocateElement(int, int)
     */
    private void freeElement(int type, int index)
    {
	if (DEBUG)
	{
	    validateBinType("freeElement", type);
	    validateBinIndex("freeElement", index);
	}

	m_allocationMap[type].clear(index);
	setFirstValueUnchecked(type, index, m_freeList[type]);
	m_freeList[type] = index;
	--m_numAllocatedSlots[type];
    }

    /**
     * Doubles the internal array used to store references to segments
     * containing bins of the given type.
     *
     * @param type the type of the bins contained in the segments of the array
     *          to expand.  This must be one of BIN1, ..., BIN4, HANDLE.
     * @see #m_segments
     */
    private void expandSegmentsArray(int type)
    {
	if (DEBUG) { validateBinType("expandSegmentsArray", type); }

	int[][] oldSegments = m_segments[type];
	m_segments[type] = new int[oldSegments.length * 2][];
	System.arraycopy(oldSegments, 0, m_segments[type], 0,
			 oldSegments.length);
    }

    /**
     * Returns a newly allocated array which can hold
     * <code>m_segmentSize</code> number of bins of the given type and in
     * which the bin elements are linked together, as if on a free list,
     * assuming that the first bin will have the given logical index.
     *
     * The bin elements are linked together on a free list, with the first
     * bin element pointing to the second, the second pointing to the third,
     * and so on, until the last element, which terminates the list with the
     * value -1.
     *
     * @param type the type of bins which will be stored in the returned
     *         array
     * @param startingIndex the logical index which the first bin element
     *         in the returned array will have once the array is linked
     *         into m_segments[type]
     * @return an array which can hold <code>m_segmentSize</code> number
     *         of bins of the given type
     * @see #m_segments
     * @see #m_segmentSize
     */
    private int[] createFreeListSegment(int type, int startingIndex)
    {
	if (DEBUG)
	{
	    validateBinType("createFreeListSegments", type);
	    validateBinIndex("createFreeListSegments", startingIndex);
	}

	int dataSize = ELEMENT_TOTAL_SIZE[type];

	int[] retval = new int[dataSize * m_segmentSize];
	for (int i = 0, n = 0; i < m_segmentSize - 1; i++, n += dataSize)
	{
	    retval[n] = startingIndex + i + 1;
	}
	retval[dataSize * (m_segmentSize - 1)] = -1;

	return retval;
    }

    /**
     * Returns the index component of a composite value retrieved from the
     * previous-link field of a BIN4 element.
     *
     * <p>
     * The previous-link field stores both the occupancy of a BIN4
     * element and the logical index of the preceding BIN4 element.
     * </p>
     *
     * <p>
     * NOTE: The previous-link field of the first bin in a list points to
     * the last bin in the same list.
     * </p>
     *
     * @param previous the composite value retrieved from a previous-link
     *          field whose previous-bin logical index is to be extracted
     * @return the logical index of the preceding BIN4 element stored in
     *          the given composite value
     * @see #extractOccupancy(int)
     * @see #constructPrevious(int, int)
     * @see #getBin4PreviousIndex(int)
     * @see #getBin4PreviousIndex(int, int)
     * @see #getBin4Previous(int)
     * @see #getBin4Previous(int, int)
     */
    private int extractIndex(int previous)
    {
	return previous >>> BIN4_PREV_INDEX_SHIFT;
    }

    /**
     * Returns the occupancy component of a composite value retrieved from the
     * previous-link field of a BIN4 element.
     *
     * <p>
     * The previous-link field stores both the occupancy (the number of
     * user data elements currently occupying a bin) of a BIN4 element and
     * the logical index of the preceding BIN4 element.
     * </p>
     *
     * @param previous the composite value retrieved from a previous-link
     *          field whose occupancy is to be extracted
     * @return the occupancy component of the given composite value
     * @see #extractIndex(int)
     * @see #constructPrevious(int, int)
     * @see #getBin4Occupancy(int)
     * @see #getBin4Occupancy(int, int)
     * @see #getBin4Previous(int)
     * @see #getBin4Previous(int, int)
     */
    private int extractOccupancy(int previous)
    {
	return (previous & BIN4_PREV_COUNT_MASK) + 1;
    }

    /**
     * Returns a composite value suitable for storage in the previous-link
     * field of a BIN4 element as constructed from the given logical index
     * and occupancy.
     *
     * The previous-link field stores both the occupancy (the number of
     * user data elements currently occupying a bin) of a BIN4 element and
     * the logical index of the BIN4 element preceding some BIN4 element
     * of interest.
     *
     * @param index the logical index of the BIN4 element preceding some
     *          BIN4 element of interest
     * @param occupancy the number of user data elements occupying some
     *          BIN4 element of interest
     * @return a composite value constructed from the given index and
     *          occupancy in the format required for values in the
     *          previous-link field of BIN4 elements
     * @see #extractIndex(int)
     * @see #extractOccupancy(int)
     * @see #setBin4Previous(int, int, int)
     * @see #setBin4Previous(int, int, int, int)
     * @see #setBin4PreviousIndex(int, int)
     * @see #setBin4PreviousIndex(int, int, int)
     * @see #setBin4Occupancy(int, int)
     * @see #setBin4Occupancy(int, int, int)
     */
    private int constructPrevious(int index, int occupancy)
    {
	if (DEBUG)
	{ 
	    validateBinIndex("constructPrevious", index);
	    validateOccupancy("constructPrevious", occupancy);
	}

	return (index << BIN4_PREV_INDEX_SHIFT) | (occupancy - 1);
    }

    /**
     * Returns the bin-type component of a composite value retrieved from the
     * handles array, <code>m_segments[HANDLE]</code>.
     *
     * A handle is a composite of a bin type (one of BIN1, ..., BIN4) and
     * a logical index, and serves as a tagged pointer to a bin element.
     *
     * @param handle the composite value whose bin-type component is to be
     *         extracted
     * @return the bin-type component of the given handle
     * @see #m_segments
     * @see #extractHandleIndex(int)
     * @see #constructHandle(int, int)
     */
    private int extractHandleType(int handle)
    {
	return handle & HANDLE_TYPE_MASK;
    }

    /**
     * Returns the index component of a composite value retrieved from the
     * handles array, <code>m_segments[HANDLE]</code>.
     *
     * A handle is a composite of a bin type (one of BIN1, ..., BIN4) and
     * a logical index, and serves as a tagged pointer to a bin element.
     *
     * @param handle the composite value whose index component is to be
     *         extracted
     * @return the index component of the given handle
     * @see #m_segments
     * @see #extractHandleType(int)
     * @see #constructHandle(int, int)
     */
    private int extractHandleIndex(int handle)
    {
	return handle >>> HANDLE_INDEX_SHIFT;
    }

    /**
     * Returns a composite value suitable for storage in the handles array,
     * <code>m_segments[HANDLE]</code>, as constructed from the given bin
     * type and logical index.
     *
     * A handle is a composite of a bin type (one of BIN1, ..., BIN4) and
     * a logical index, and serves as a tagged pointer to a bin element.
     *
     * @param type the bin type component for the constructed handle
     * @param index the logical index component for the constructed handle
     * @return a handle value constructed from the given bin type and index
     * @see #m_segments
     * @see #extractHandleType(int)
     * @see #extractHandleIndex(int)
     */
    private int constructHandle(int type, int index)
    {
	if (DEBUG)
	{ 
	    validateBinType("constructHandle", type);
	    validateBinIndex("constructHandle", index);
	}

	return (index << HANDLE_INDEX_SHIFT) | type;
    }

    /**
     * Returns the offset within a segment of a handle value with the given
     * logical index.
     *
     * @param index the logical index of a handle value (a value in the
     *         <code>m_segments[HANDLE]</code> array)
     * @return the offset within a segment of a handle value with the given
     *         logical index
     * @see #computeOffset(int, int)
     */
    private int computeHandleOffset(int index)
    {
	if (DEBUG) { validateBinIndex("computeHandleOffset", index); }
	return index & m_segmentMask;
    }

    /**
     * Returns the starting offset within a segment of a BIN1 element with
     * the given logical index.
     *
     * @param index the logical index of a BIN1 element
     * @return the offset within a segment of the first integer of the
     *        BIN1 element with the given logical index
     * @see #computeOffset(int, int)
     */
    private int computeBin1Offset(int index)
    {
	if (DEBUG) { validateBinIndex("computeBin1Offset", index); }
	return index & m_segmentMask;
    }

    /**
     * Returns the starting offset within a segment of a BIN2 element with
     * the given logical index.
     *
     * @param index the logical index of a BIN2 element
     * @return the offset within a segment of the first integer of the
     *        BIN2 element with the given logical index
     * @see #computeOffset(int, int)
     */
    private int computeBin2Offset(int index)
    {
	if (DEBUG) { validateBinIndex("computeBin2Offset", index); }
	return 2 * (index & m_segmentMask);
    }

    /**
     * Returns the starting offset within a segment of a BIN3 element with
     * the given logical index.
     *
     * @param index the logical index of a BIN3 element
     * @return the offset within a segment of the first integer of the
     *        BIN3 element with the given logical index
     * @see #computeOffset(int, int)
     */
    private int computeBin3Offset(int index)
    {
	if (DEBUG) { validateBinIndex("computeBin3Offset", index); }
	return 3 * (index & m_segmentMask);
    }

    /**
     * Returns the starting offset within a segment of a BIN4 element with
     * the given logical index.
     *
     * @param index the logical index of a BIN4 element
     * @return the offset within a segment of the first integer of the
     *        BIN4 element with the given logical index
     * @see #computeOffset(int, int)
     */
    private int computeBin4Offset(int index)
    {
	if (DEBUG) { validateBinIndex("computeBin4Offset", index); }
	return 6 * (index & m_segmentMask);
    }

    /**
     * Returns the segment index of a bin element with the given logical index.
     *
     * The bin element of interest may be of type BIN1, ..., BIN4, or HANDLE;
     * that is, any type stored in <code>m_segments</code>.
     *
     * @param index the logical index of a bin element
     * @return the index of the segment containing the data of the bin
     *       element with the given logical index
     * @see #m_segments
     * @see #computeOffset(int, int)
     */
    private int computeSegment(int index)
    {
	if (DEBUG) { validateBinIndex("computeSegment", index); }
	return index >>> m_segmentSizeBits;
    }

    /**
     * Returns the starting offset within a segment of a bin element with
     * the given type and logical index.
     *
     * The value type must be one of BIN1, ..., BIN4, or HANDLE.
     *
     * @param type the type of a bin element
     * @param index the logical index of a bin element
     * @return the offset within a segment of the first integer of the
     *        bin element with the given type and logical index
     * @see #m_segments
     * @see #computeSegment(int)
     */
    private int computeOffset(int type, int index)
    {
	if (DEBUG)
	{
	    validateBinType("computeOffset", type);
	    validateBinIndex("computeOffset", index);
	}

	return ELEMENT_TOTAL_SIZE[type] * (index & m_segmentMask);
    }
    /**
     * Checks that the given handle index, passed as an argument to a public
     * method, is at least minimally valid, that is, nonnegative.
     *
     * @param index the handle index to check for validity
     * @exception IllegalArgumentException if the handle index is negative
     */
    private void validateHandleIndexArgument(int index)
    {
	if (index < 0)
	{
	    String msg = "index [" + index + "] must be >= 0";
	    throw new IllegalArgumentException(msg);
	}
    }

    /**
     * Checks that the given bin type is within the allowed range of values;
     * namely, that it is BIN1, ..., BIN4, or HANDLE.
     *
     * @param caller a String, for use in messages, containing the name of
     *          the function requesting validation
     * @param type the bin type to check for validity
     * @exception InvariantFailedException if the bin type is not one of the
     *         valid types
     */
    private void validateBinType(String caller, int type)
    {
	if (type < TYPE_FIRST || type > TYPE_LAST)
	{
	    String msg = "ERROR: " + caller + "(): bin type must be between "
		+ TYPE_FIRST + " and " + TYPE_LAST + " inclusive.";
	    throw new InvariantFailedException(msg);
	}
    }

    /**
     * Checks that the given occupancy value, representing the number of
     * user data elements occupying a BIN4 element, is between 1 and 4.
     *
     * @param caller a String, for use in messages, containing the name of
     *          the function requesting validation
     * @param occupancy the occupancy to check for validity
     * @exception InvariantFailedException if the occupancy is negative
     *         or larger than 4
     */
    private void validateOccupancy(String caller, int occupancy)
    {
	if (occupancy <= 0 || occupancy > 4)
	{
	    String msg = "ERROR: " + caller + "(): occupancy ["
		+ occupancy + "] is not between 1 and 4.";
	    throw new InvariantFailedException(msg);
	}
    }

    /**
     * Checks that the given logical index of a bin element is at least
     * minimally valid, that is, nonnegative.
     *
     * @param caller a String, for use in messages, containing the name of
     *          the function requesting validation
     * @param binIndex the logical index to check for validity
     * @exception InvariantFailedException if the bin index is negative
     * @see #validateBin4SegmentAndOffset(String, int, int)
     */
    private void validateBinIndex(String caller, int binIndex)
    {
	if (binIndex < 0)
	{
	    String msg = "ERROR: " + caller + "(): bin index "
		+ binIndex + " is not >= 0.";
	    throw new InvariantFailedException(msg);
	}
    }

    /**
     * Checks that the given logical index, assumed to be for use in the
     * next-link field of a BIN4 element, of a bin element is at least
     * minimally valid, that is, nonnegative.
     *
     * Although this method is similar to <code>validateBinIndex</code>,
     * it is needed because the next-link field is used in two different
     * ways.  In the case where the field contains the list length, we
     * must perform a differnt kind of validation, or simply refrain from
     * validating.  Hence, <code>validateBinIndex</code> is allowed to
     * perform more extensive checking than this method may, and hence we
     * need to distinguish between the two.
     *
     * @param caller a String, for use in messages, containing the name of
     *          the function requesting validation
     * @param binIndex the logical index to check for validity
     * @exception InvariantFailedException if the bin index is negative
     * @see #validateBinIndex(String, int)
     * @see #validateBin4SegmentAndOffset(String, int, int)
     */
    private void validateNextBinIndex(String caller, int binIndex)
    {
	validateBinIndex(caller, binIndex);
    }

    /**
     * Checks that the given offset within a segment is the location of a
     * potential user data element in a BIN4 element rather than the location
     * of the previous-link or next-link value.
     *
     * @param caller a String, for use in messages, containing the name of
     *          the function requesting validation
     * @param offset
     *         the offset within a segment containing BIN4 elements.  This
     *         value must be minimally valid, that is, be nonnegative.
     * @exception InvariantFailedException if the offset is to the
     *         previous-link or next-link field of a BIN4 element rather than
     *         to a data field
     * @see #validateBin4SegmentAndOffset(String, int, int)
     */
    private void validateBin4DataOffset(String caller, int offset)
    {
	int position = offset % ELEMENT_TOTAL_SIZE[BIN4];
	if (position == BIN4_PREV_OFFSET)
	{
	    String msg = "ERROR: " + caller + "(): given offset is to the "
		+ "previous-link field rather than to data.";
	    throw new InvariantFailedException(msg);
	}
	else if (position == BIN4_NEXT_OFFSET)
	{
	    String msg = "ERROR: " + caller + "(): given offset is to the "
		+ "next-link field rather than to data.";
	    throw new InvariantFailedException(msg);
	}
    }

    /**
     * Checks that the given segmentIndex and startingOffset for a BIN4
     * element are at least valid indices into their respective arrays,
     * though they may still be invalid at a higher level for some particular
     * purpose.
     *
     * @param caller a String, for use in messages, containing the name of
     *          the function requesting validation
     * @param segment
     *         the index of a segment containing some BIN4 element
     * @param offset
     *         the offset within the given segment of some data of some
     *         BIN4 element.  This value need not specify the starting offset.
     * @exception InvariantFailedException if either the segment or the offset
     *         is negative or larger than allowed
     * @see #validateBinIndex(String, int)
     */
    private void validateBin4SegmentAndOffset(String caller, int segment,
					      int offset)
    {
	if (segment < 0 || segment >= m_numAllocatedSegments[BIN4])
	{
	    String msg = "ERROR: " + caller + "(): "
		+ "failed to have 0 <= segment ["
		+ segment + "] < " + m_numAllocatedSegments[BIN4];
	    throw new InvariantFailedException(msg);
	}

	int segmentLength = m_segments[BIN4][segment].length;
	if (offset < 0 || offset >= segmentLength)
	{
	    String msg = "ERROR: " + caller + "(): "
		+ "failed to have 0 <= offset ["
		+ offset + "] < " + segmentLength;
	    throw new InvariantFailedException(msg);
	}
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE CONSTANTS
    ////////////////////////////////////////////////////////////////////////

    /**
     * A flag indicating whether certain debugging assertions and tests
     * should be enabled.
     *
     * A non-beta version for release should most likely have this turned off.
     */
    private static final boolean DEBUG = true;

    /**
     * The maximum number of segments which the arrays for each bin type
     * should be able to hold initially without needing resizing.
     *
     * Since resizing the arrays holding references to segments isn't
     * too expensive to do, there really isn't any critical tradeoff
     * involved, and just about any value that's not too small is fine.
     */
    private static final int STARTING_NUM_SEGMENTS = 32;

    /**
     * The number of bin elements each allocated segment should be able to
     * hold, to be used if the user doesn't supply a number to a constructor.
     *
     * @see #segmentSize
     */
    private static final int DEFAULT_SEGMENT_SIZE = 1024;

    /**
     * The minimum number of bin elements each allocated segment should be 
     * able to hold, to be used as the lower bound for any user-supplied
     * segment size in a constructor.
     *
     * @see #segmentSize
     */
    private static final int MIN_SEGMENT_SIZE = 128;

    /**
     * A constant recording the lowest numeric value taken in the bin type
     * enumeration, and thus providing a way to check the validity of a type
     * argument.
     *
     * @see #BIN1
     */
    private static final int TYPE_FIRST = 0;

    /**
     * A constant recording the highest numeric value taken in the bin type
     * enumeration, and thus providing a way to check the validity of a type
     * argument.
     *
     * @see #HANDLE
     */
    private static final int TYPE_LAST = 4;

    /**
     * An enumeration making it less error-prone to refer to the array
     * in <code>m_segments</code> containing BIN1 elements.
     *
     * NOTE: This must have the value 0 in order for indexing to work in
     * certain parts of the code.
     *
     * @see #m_segments
     */
    private static final int BIN1 = 0;

    /**
     * An enumeration making it less error-prone to refer to the array
     * in <code>m_segments</code> containing BIN2 elements.
     *
     * NOTE: This must have the value 1 in order for indexing to work in
     * certain parts of the code.
     *
     * @see #m_segments
     */
    private static final int BIN2 = 1;

    /**
     * An enumeration making it less error-prone to refer to the array
     * in <code>m_segments</code> containing BIN3 elements.
     *
     * NOTE: This must have the value 2 in order for indexing to work in
     * certain parts of the code.
     *
     * @see #m_segments
     */
    private static final int BIN3 = 2;

    /**
     * An enumeration making it less error-prone to refer to the array
     * in <code>m_segments</code> containing BIN4 elements.
     *
     * NOTE: This must have the value 3 in order for indexing to work in
     * certain parts of the code.
     *
     * @see #m_segments
     */
    private static final int BIN4 = 3;

    /**
     * An enumeration making it less error-prone to refer to the array
     * in <code>m_segments</code> containing handles (tagged pointers to
     * elements in the BIN1, ..., BIN4 arrays).
     *
     * NOTE: This must have the value 4 in order for indexing to work in
     * certain parts of the code.
     *
     * @see #m_segments
     */
    private static final int HANDLE = 4;

    /**
     * A constant specifying the number of bits to right shift a handle
     * value in order to extract its index component.
     *
     * @see #m_segments
     */
    private static final int HANDLE_INDEX_SHIFT = 2;

    /**
     * A constant specifying the bit mask to apply to a handle value
     * in order to extract its bin-type component.
     *
     * @see #m_segments
     */
    private static final int HANDLE_TYPE_MASK = 0x3;

    /**
     * A constant specifying the number of bits to right shift a value
     * retrieved from the previous-link field of a BIN4 element in order
     * to extract the index component.
     *
     * @see #m_segments
     */
    private static final int BIN4_PREV_INDEX_SHIFT = 2;

    /**
     * A constant specifying the bit mask to apply to a value retrieved
     * from the previous-link field of a BIN4 element in order to extract
     * the occupancy component.
     *
     * @see #m_segments
     */
    private static final int BIN4_PREV_COUNT_MASK = 0x3;

    /**
     * A constant specifying the offset from the starting offset of a BIN4
     * element where the previous-link field can be found.
     *
     * NOTE: This value must be at least 4, since certain code assume that
     * data elements are at offsets 0 to 3.
     *
     * @see #m_segments
     */
    private static final int BIN4_PREV_OFFSET = 4;

    /**
     * A constant specifying the offset from the starting offset of a BIN4
     * element where the next-link field can be found.
     *
     * NOTE: This value must be at least 4, since certain code assume that
     * data elements are at offsets 0 to 3.
     *
     * @see #m_segments
     */
    private static final int BIN4_NEXT_OFFSET = 5;

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ////////////////////////////////////////////////////////////////////////

    /**
     * An array indexed by bin types and specifying the total number of
     * integers (counting user data and administrative data) taken up by
     * an element of a given bin type.
     *
     * @see #m_segments
     */
    private static final int[]  ELEMENT_TOTAL_SIZE = new int[5];
    static 
    {
	ELEMENT_TOTAL_SIZE[BIN1] = 1;
	ELEMENT_TOTAL_SIZE[BIN2] = 2;
	ELEMENT_TOTAL_SIZE[BIN3] = 3;
	ELEMENT_TOTAL_SIZE[BIN4] = 6;
	ELEMENT_TOTAL_SIZE[HANDLE] = 1;
    }

    /**
     * An array indexed by bin types and specifying the total number of
     * integers of user data that can be stored in an element of a given
     * bin type.
     *
     * @see #m_segments
     */
    private static final int[]  ELEMENT_USER_SIZE = new int[4];
    static 
    {
	ELEMENT_USER_SIZE[BIN1] = 1;
	ELEMENT_USER_SIZE[BIN2] = 2;
	ELEMENT_USER_SIZE[BIN3] = 3;
	ELEMENT_USER_SIZE[BIN4] = 4;
    }

    /**
     * The number of bin elements each allocated segment should be able to
     * hold.
     *
     * <p>
     * Note that this is the number of bin elements and not the number of
     * integers.  A bin element may consist of several consecutive integers.
     * </p>
     *
     * <p>
     * NOTE: This value must be a power of two.  Also, the minimum segment
     * size should neither be too small nor too large.  If it is too small,
     * then there will be a large number of segments, and hence a large
     * number of heap-allocated arrays, increasing the overhead.  If it is
     * too large, then a large part of each segment may go unused, wasting
     * a lot of memory.  Hence, an actual segment size should balance waste
     * due to overhead and waste due to internal fragmentation, based upon
     * expected use.
     * </p>
     *
     * @see #DEFAULT_SEGMENT_SIZE
     * @see #MIN_SEGMENT_SIZE
     */
    private final int  m_segmentSize;

    /**
     * A bit mask derived from <code>m_segmentSize</code> which when applied
     * to a logical index yields the starting offset of a bin element at that
     * index.
     *
     * @see #m_segmentSize
     * @see #m_segmentSizeBits
     * @see #m_segments
     */
    private final int  m_segmentMask;

    /**
     * A value derived from <code>m_segmentSize</code> which specifies the
     * number of bits to right shift a logical index in order to calculate
     * the segment index of a bin element at that index.
     *
     * @see #m_segmentSize
     * @see #m_segmentMask
     * @see #m_segments
     */
    private final int  m_segmentSizeBits;

    /**
     * An array indexed by bin types where each element gives the logical
     * index of the first bin element on the corresponding free list, or
     * -1 in the case of an empty free list.
     *
     * The elements on the free list are singly-linked, with the first
     * integer value in each bin serving as the next-link field, and with
     * the list terminated by a -1 link value.
     *
     * @see #m_segments
     */
    private int[]  m_freeList;

    // A set bit indicates an allocated element.

    /**
     * An array indexed by bin types where each element is a bit map showing
     * which bin elements (logical indices) of a given bin type are allocated.
     *
     * A set bit at a given index indicates an allocated element at the same
     * logical index.
     *
     * @see #m_freeList
     * @see #m_segments
     */
    private BitSet[]  m_allocationMap;

    /**
     * An array indexed by bin types where each element shows how many
     * bin elements of a given type are currently allocated.
     *
     * @see #m_allocationMap
     * @see #m_segments
     */
    private int[]  m_numAllocatedSlots;

    /**
     * An array indexed by bin types where each element shows how many
     * segments have been allocated to the array in m_segments for a
     * given bin type.
     *
     * That is, if <code>n == m_numAllocatedSegments[i]</code>, then
     * <code>m_segments[i][0]</code> to <code>m_segments[i][n-1]</code>
     * will have references to allocated segments (vs. null).
     *
     * @see #m_numAllocatedSlots
     * @see #m_segments
     */
    private int[]  m_numAllocatedSegments;

    /**
     * An array indexed by bin types where each element is a further array
     * of segments, the latter finally containing the bin elements of a
     * given bin type.
     *
     * <p>
     * This array is at the heart of this class.  All five arrays described
     * in the <a href="http://www.caida.org/~youngh/binarrays/binarrays.html>
     * Bin-arrays documentation</a> are ultimately stored here.  The internal
     * structure of this array is as follows.  In the first-level array,
     * there is a one-to-one correspondence between the elements and the five
     * bin types, namely BIN1, ..., BIN4, and HANDLE.  All data for a given
     * bin type are stored, directly or indirectly, in the structures
     * referenced by the corresponding entry in the top-level array; so,
     * for example, all data for the bin type BIN1 are reachable through
     * <code>m_segments[BIN1]</code>.
     * </p>
     *
     * <p>
     * The structures referenced by the first-level array are also arrays,
     * the second-level arrays.  The purpose of the second-level arrays is
     * to introduce another level of indirection so that we can easily
     * support arrays that grow arbitrarily.  The technique is to replace
     * a single array with an array of arrays.  This works a lot like
     * virtual memory in an operating system.  In virtual memory, a linear
     * address space is divided into equal-sized pages, and pages are
     * committed as additional space is needed.  Here, we divide an array
     * (which conceptually holds all data of a given bin type) into
     * equal-sized segments.  Each segment is large enough to hold
     * <code>m_segmentSize</code> number of bin elements of a single bin
     * type.  Note that because a segment holds <em>bin</em> elements,
     * and because bin elements of different types take up different
     * amounts of space, the segments of different bin types are physically
     * of different sizes, although the segments of a single bin type are
     * all of the same size.  Also note that, for some bin type
     * <code>t</code>, all segments in <code>m_segments[t]</code> hold
     * only elements of type <code>t</code>; bin elements aren't intermixed
     * in any way.  Just as in the case of virtual memory, we allocate more
     * segments when more space is needed, and add them to the end of the
     * appropriate second-level array.  When all the slots in the second-level
     * array are taken, we resize the second-level array.  Because of the
     * aggregation of data into segments, the second-level array, which only
     * points to segments, will not be large, and therefore, resizing it will
     * not be expensive.  Consider, for example, the case where segments
     * each hold 1024 bin elements.  Then even when storing a million bin
     * elements, the length of the corresponding second-level array will only
     * be around one thousand.
     * </p>
     *
     * <p>
     * In summary, <code>m_segments</code> consists of three levels of arrays.
     * The top-level array segregates data by type.  The second-level array
     * segregates data by segment.  And the third-level array, a segment,
     * finally contains user data.
     * </p>
     *
     * <p>
     * All references to bin elements are given in terms of a logical index.
     * The logical index is the position a bin element has in a conceptually
     * contiguous array containing all data of a given bin type, where each
     * bin element as a whole occupies one position.  The logical indices
     * of each bin type start independently at zero.  To actually access a
     * bin element, we must translate a logical index into a segment index
     * and a starting offset within that segment.  That is, given a logical
     * index of type <code>t</code>, we must calculate the segment index
     * <code>s</code> and the starting offset <code>o</code> such that the
     * first integer of the bin element is found at
     * <code>m_segments[t][s][o]</code>.
     * </p>
     */
    private int[][][]  m_segments;

    /**
     * A flag indicating whether user data elements in lists
     * (the abstraction provided by <code>IntBinArray</code>) are ordered.
     *
     * The choice is made in a constructor and can't be changed thereafter.
     * Also note that either all lists are ordered or all lists are unordered;
     * the choice is not available per list.  Finally, an "ordered" list is
     * different than a "sorted" list.  People standing in line are ordered
     * but not necessarily sorted.
     */
    private final boolean  m_isOrdered;

    /**
     * A flag specifying whether <code>ValueIterator.removeValue</code>
     * should have an alternate behavior which is more useful for testing
     * the proper removal of last elements.
     * 
     * The ordinary, and correct, behavior when the last element is removed
     * is for the iterator to advance to the position just off the end of the
     * list (that is, atEnd() should become true).  The alternate behavior is
     * for the iterator to back up one position to the next-to-last element.
     * This latter behavior makes it easier to observe and verify that the
     * code for removing the last element on a list is working properly.
     *
     * @see #relaxRemovalSemantics()
     * @see #ValueIterator.removeValue
     */
    private boolean  m_relaxRemovalSemantics = false;

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC NESTED CLASSES
    ////////////////////////////////////////////////////////////////////////

    /**
     * An exception indicating an internal error or inconsistency, or a
     * failure of some precondition, postcondition, or invariant to hold.
     */
    public class InvariantFailedException extends RuntimeException
    {
	public InvariantFailedException() { super(); }
	public InvariantFailedException(String s) { super(s); }
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE INNER CLASSES
    ////////////////////////////////////////////////////////////////////////

    private class ValueIteratorImpl extends AbstractValueIterator
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public ValueIteratorImpl(int index)
	{
	    this(index, false);
	}

	public ValueIteratorImpl(int index, boolean relaxRemovalSemantics)
	{
	    validateHandleIndexArgument(index);
	    m_handleIndex = index;
	    getAndParseHandle();
	    m_atEnd = isEmpty();
	    RELAX_REMOVAL_SEMANTICS = relaxRemovalSemantics;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public boolean atEnd()
	{
	    return m_atEnd;
	}

	public void advance()
	{
	    if (!m_atEnd)
	    {
		if (m_currentOffset < m_lastOffset)
		{
		    ++m_currentOffset;
		}
		else
		{
		    if (m_binType == BIN4
			&& m_binCurrentIndex != m_binLastIndex)
		    {
			m_binCurrentIndex =
			    getBin4Next(m_segmentIndex, m_startingOffset);
			parseBin4BinCurrentIndex();
		    }
		    else
		    {
			if (!RELAX_REMOVAL_SEMANTICS)
			{
			    m_atEnd = true;
			}
		    }
		}
	    }
	}

	public void rewind()
	{
	    if (!isEmpty())
	    {
		m_atEnd = false;
		getAndParseHandle();
	    }
	}

	public boolean isEmpty()
	{
	    return m_binType == -1;
	}

	public int getLength()
	{
	    switch (m_binType)
	    {
	    case BIN1: return 1;
	    case BIN2: return 2;
	    case BIN3: return 3;

	    case BIN4:
		if (m_binCurrentIndex == m_binLastIndex)
		{
		    return getBin4Next(m_segmentIndex, m_startingOffset);
		}
		else
		{
		    return getBin4Next(m_binLastIndex);
		}

	    case -1: return 0;
	    default: throw new RuntimeException();
	    }
	}

	public ValueType getType()
	{
	    return ValueType.INTEGER;
	}

	public int getIntegerValue()
	{
	    if (m_atEnd)
	    {
		throw new IndexOutOfBoundsException();
	    }

	    if (DEBUG && m_binType == BIN4)
	    {
		return getBin4Data(m_segmentIndex, m_currentOffset);
	    }
	    else
	    {
		return m_segments[m_binType][m_segmentIndex][m_currentOffset];
	    }
	}

	public void setIntegerValue(int value)
	{
	    if (m_atEnd)
	    {
		throw new IndexOutOfBoundsException();
	    }

	    if (DEBUG && m_binType == BIN4)
	    {
		setBin4Data(m_segmentIndex, m_currentOffset, value);
	    }
	    else
	    {
		m_segments[m_binType][m_segmentIndex][m_currentOffset] = value;
	    }
	}

	public void removeValue()
	{
	    if (m_atEnd)
	    {
		throw new IndexOutOfBoundsException();
	    }
	    else
	    {
		if (RELAX_REMOVAL_SEMANTICS)
		{
		    if (m_binType == BIN1)
		    {
			m_atEnd = true;
		    }
		}
		else
		{
		    if (atLastElement())
		    {
			m_atEnd = true;
		    }
		}

		switch (m_binType)
		{
		case BIN1: removeBin1Value(); break;
		case BIN2: removeBin2Value(); break;
		case BIN3: removeBin3Value(); break;
		case BIN4:
		    if (m_isOrdered)
		    {
			removeOrderedBin4Value();
		    }
		    else
		    {
			removeUnorderedBin4Value();
		    }
		    break;

		case -1:
		    // Since m_atEnd will be true when m_binType equals -1,
		    // this case should never happen.
		    throw new RuntimeException();
		default: throw new RuntimeException();
		}
	    }
	}

	public void insertValue()
	{
	    if (m_atEnd)
	    {
		m_atEnd = false;
		appendValue();
	    }
	    else
	    {
		if (m_isOrdered)
		{
		    switch (m_binType)
		    {
		    case BIN1: insertBin1Value(); break;
		    case BIN2: insertBin2Value(); break;
		    case BIN3: insertBin3Value(); break;
		    case BIN4: insertOrderedBin4Value(); break;
		    case -1: allocateBinAndParseHandle(BIN1); break;
		    default: throw new RuntimeException();
		    }
		}
		else
		{
		    appendValue();
		}
	    }
	}

	public void appendValue()
	{
	    if (m_atEnd)
	    {
		m_atEnd = false;
	    }

	    switch (m_binType)
	    {
	    case BIN1: appendBin1Value(); break;
	    case BIN2: appendBin2Value(); break;
	    case BIN3: appendBin3Value(); break;
	    case BIN4: appendBin4Value(); break;
	    case -1: allocateBinAndParseHandle(BIN1); break;
	    default: throw new RuntimeException();
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

        private boolean atLastElement()
        {
            if (m_binType == -1)
            {
                return false;
            }
            else
            {
                if (m_currentOffset < m_lastOffset)
                {
                    return false;
                }
                else 
                {
                    return (m_binType != BIN4) ? true
                        : (m_binCurrentIndex == m_binLastIndex);
                }
            }
        }

	private void removeBin1Value()
	{
	    freeElement(BIN1, m_binCurrentIndex);
	    setAndParseHandle(-1);
	}

	private void removeBin2Value()
	{
	    int offset = (m_currentOffset == m_startingOffset
			  ? m_lastOffset : m_startingOffset);
	    int value = m_segments[BIN2][m_segmentIndex][offset];

	    freeElement(BIN2, m_binCurrentIndex);
	    allocateBinAndParseHandle(BIN1);
	    m_segments[BIN1][m_segmentIndex][m_startingOffset] = value;
	}

	private void removeBin3Value()
	{
	    int oldBinCurrentIndex = m_binCurrentIndex;
	    int oldSegmentIndex = m_segmentIndex;
	    int oldStartingOffset = m_startingOffset;
	    int oldCurrentOffset = m_currentOffset;
		    
	    allocateBinAndParseHandle(BIN2);

	    int firstOffset;
	    int secondOffset;

	    if (oldCurrentOffset == oldStartingOffset)
	    {
		firstOffset = oldStartingOffset + 1;
		secondOffset = oldStartingOffset + 2;
	    }
	    else if (oldCurrentOffset == oldStartingOffset + 1)
	    {
		firstOffset = oldStartingOffset;
		secondOffset = oldStartingOffset + 2;
		m_currentOffset = m_lastOffset;
	    }
	    else
	    {
		firstOffset = oldStartingOffset;
		secondOffset = oldStartingOffset + 1;
		m_currentOffset = m_lastOffset;
	    }

	    m_segments[BIN2][m_segmentIndex][m_startingOffset] = 
		m_segments[BIN3][oldSegmentIndex][firstOffset];
	    m_segments[BIN2][m_segmentIndex][m_lastOffset] = 
		m_segments[BIN3][oldSegmentIndex][secondOffset];

	    freeElement(BIN3, oldBinCurrentIndex);
	}

	private void removeOrderedBin4Value()
	{
	    if (getLength() == 4)
	    {
		removeBin4ValueByDemotion();
	    }
	    else
	    {
		removeOrderedBin4ValueByDeletion();
	    }
	}

	// NOTE: There must be more than one bin in this list.
	private void removeOrderedBin4ValueByDeletion()
	{
	    int previousIndex =
		getBin4PreviousIndex(m_segmentIndex, m_startingOffset);
	    int nextIndex = getBin4Next(m_segmentIndex, m_startingOffset);

	    int occupancy = m_lastOffset - m_startingOffset + 1;
	    if (occupancy == 1)
	    {
		unlinkAndFreeCurrentBin4(previousIndex, nextIndex);
	    }
	    else
	    {
		boolean wasMerged = false;

		if (previousIndex != m_binLastIndex)
		{
		    int previousSegmentIndex = computeSegment(previousIndex);
		    int previousStartingOffset =
			computeBin4Offset(previousIndex);
		    int previousOccupancy =
			getBin4Occupancy(previousSegmentIndex,
					 previousStartingOffset);

		    // NOTE: The following is actually always >= 4.
		    if (previousOccupancy + occupancy - 1 <= 4)
		    {
			wasMerged = true;
			mergeCurrentWithLeftBin4(previousIndex,
						 previousSegmentIndex,
						 previousStartingOffset,
						 previousOccupancy, nextIndex);
		    }
		}

		if (!wasMerged && m_binCurrentIndex != m_binLastIndex)
		{
		    int nextSegmentIndex = computeSegment(nextIndex);
		    int nextStartingOffset = computeBin4Offset(nextIndex);
		    int nextOccupancy = getBin4Occupancy(nextSegmentIndex,
							 nextStartingOffset);

		    // NOTE: The following is actually always >= 4.
		    if (nextOccupancy + occupancy - 1 <= 4)
		    {
			wasMerged = true;
			mergeCurrentWithRightBin4(nextIndex, nextSegmentIndex,
						  nextStartingOffset,
						  nextOccupancy);
		    }
		}

		if (!wasMerged)
		{
		    adjustListLength(-1);
		    setBin4Occupancy(m_segmentIndex, m_startingOffset,
				     occupancy - 1);

		    if (m_currentOffset == m_lastOffset)
		    {
			m_currentOffset = --m_lastOffset;
			advance();
		    }
		    else
		    {
			for (int i = m_currentOffset; i < m_lastOffset; i++)
			{
			    setBin4Data(m_segmentIndex, i,
					getBin4Data(m_segmentIndex, i + 1));
			}

			--m_lastOffset;
		    }
		}
	    }

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void unlinkAndFreeCurrentBin4(int previousIndex, int nextIndex)
	{
	    if (DEBUG)
	    {
		validateBinIndex("unlinkAndFreeCurrentBin4", previousIndex);
		validateNextBinIndex("unlinkAndFreeCurrentBin4", nextIndex);
	    }

	    int oldBinCurrentIndex = m_binCurrentIndex;

	    if (previousIndex == m_binLastIndex) // Unlinking the first bin?
	    {
		m_binCurrentIndex = nextIndex;
		parseBin4BinCurrentIndex();

		setBin4PreviousIndex(m_segmentIndex, m_startingOffset,
				     previousIndex);

		int handle = constructHandle(BIN4, nextIndex);
		setFirstValueUnchecked(HANDLE, m_handleIndex, handle);

		adjustListLength(-1);
	    }
	    else if (m_binCurrentIndex == m_binLastIndex)
	    {
		m_binCurrentIndex = previousIndex;
		m_binLastIndex = previousIndex;

		parseBin4BinCurrentIndex();
		m_currentOffset = m_lastOffset;

		setBin4Next(m_segmentIndex, m_startingOffset, nextIndex - 1);
		setBin4PreviousIndex(getHandleBinIndex(), previousIndex);
	    }
	    else
	    {
		setBin4Next(previousIndex, nextIndex);

		m_binCurrentIndex = nextIndex;
		parseBin4BinCurrentIndex();

		setBin4PreviousIndex(m_segmentIndex, m_startingOffset,
				     previousIndex);
		adjustListLength(-1);
	    }

	    freeElement(BIN4, oldBinCurrentIndex);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	// Remove element at m_currentOffset, and append remaining elements
	// in current bin to the previous bin.  Then unlink and free current
	// bin.
	private void mergeCurrentWithLeftBin4(int previousIndex,
					      int previousSegmentIndex,
					      int previousStartingOffset,
					      int previousOccupancy,
					      int nextIndex)
	{
	    if (DEBUG)
	    {
		String caller = "mergeCurrentWithLeftBin4";
		validateBinIndex(caller, previousIndex);
		validateBin4SegmentAndOffset(caller, previousSegmentIndex,
					     previousStartingOffset);
		validateOccupancy(caller, previousOccupancy);
		validateNextBinIndex(caller, nextIndex);
	    }

	    int occupancy = m_lastOffset - m_startingOffset + 1;

	    int previousLastOffset =
		previousStartingOffset + previousOccupancy - 1;

	    for (int i = m_startingOffset; i <= m_lastOffset; i++)
	    {
		if (i != m_currentOffset)
		{
		    setBin4Data(previousSegmentIndex, ++previousLastOffset,
				getBin4Data(m_segmentIndex, i));
		}
	    }

	    // The new previous occupancy will always be 4.
	    if (DEBUG && previousOccupancy + occupancy - 1 != 4)
	    {
		String msg = "ERROR: mergeCurrentWithLeftBin4(): "
		    + "new previous occupancy != 4";
		throw new InvariantFailedException(msg);
	    }

	    setBin4Occupancy(previousSegmentIndex, previousStartingOffset, 4);

	    if (m_binCurrentIndex == m_binLastIndex)
	    {
		m_binLastIndex = previousIndex;
		setBin4Next(previousSegmentIndex, previousStartingOffset,
			    nextIndex - 1);
		setBin4PreviousIndex(getHandleBinIndex(), previousIndex);
	    }
	    else
	    {
		setBin4Next(previousSegmentIndex, previousStartingOffset,
			    nextIndex);
		setBin4PreviousIndex(nextIndex, previousIndex);
		adjustListLength(-1);
	    }

	    freeElement(BIN4, m_binCurrentIndex);

	    int oldPosition = m_currentOffset - m_startingOffset;
	    boolean deletedLastElement = (m_currentOffset == m_lastOffset);

	    m_binCurrentIndex = previousIndex;
	    m_segmentIndex = previousSegmentIndex;
	    m_startingOffset = previousStartingOffset;
	    m_lastOffset = previousLastOffset;

	    if (deletedLastElement)
	    {
		if (DEBUG && previousOccupancy + oldPosition - 1 != 3)
		{
		    String msg = "ERROR: mergeCurrentWithLeftBin4(): "
			+ "new position != 3";
		    throw new InvariantFailedException(msg);
		}

		m_currentOffset = m_startingOffset + 3;
		advance();
	    }
	    else
	    {
		m_currentOffset =
		    m_startingOffset + previousOccupancy + oldPosition;
	    }

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	// Remove element at m_currentOffset, and append all elements in
	// next bin to the current bin.  Then unlink and free next bin.
	private void mergeCurrentWithRightBin4(int nextIndex,
					       int nextSegmentIndex,
					       int nextStartingOffset,
					       int nextOccupancy)
	{
	    if (DEBUG)
	    {
		String caller = "mergeCurrentWithRightBin4";
		validateBinIndex(caller, nextIndex);
		validateBin4SegmentAndOffset(caller, nextSegmentIndex,
					     nextStartingOffset);
		validateOccupancy(caller, nextOccupancy);
	    }

	    int occupancy = m_lastOffset - m_startingOffset + 1;

	    if (m_currentOffset < m_lastOffset)
	    {
		for (int i = m_currentOffset; i < m_lastOffset; i++)
		{
		    setBin4Data(m_segmentIndex, i,
				getBin4Data(m_segmentIndex, i + 1));
		}
	    }

	    int nextLastOffset = nextStartingOffset + nextOccupancy - 1;
	    for (int i = m_lastOffset, j = nextStartingOffset;
		 j <= nextLastOffset; i++, j++)
	    {
		setBin4Data(m_segmentIndex, i,
			    getBin4Data(nextSegmentIndex, j));
	    }

	    m_lastOffset += nextOccupancy - 1;

	    // The new next occupancy will always be 4.
	    if (DEBUG && nextOccupancy + occupancy - 1 != 4)
	    {
		String msg = "ERROR: mergeCurrentWithRightBin4(): "
		    + "new next occupancy != 4";
		throw new InvariantFailedException(msg);
	    }

	    setBin4Occupancy(m_segmentIndex, m_startingOffset, 4);

	    int nextNextIndex =
		getBin4Next(nextSegmentIndex, nextStartingOffset);

	    if (nextIndex == m_binLastIndex)
	    {
		m_binLastIndex = m_binCurrentIndex;
		setBin4Next(m_segmentIndex, m_startingOffset, nextNextIndex-1);
		setBin4PreviousIndex(getHandleBinIndex(),m_binCurrentIndex);
	    }
	    else
	    {
		setBin4Next(m_segmentIndex, m_startingOffset, nextNextIndex);
		setBin4PreviousIndex(nextNextIndex, m_binCurrentIndex);
		adjustListLength(-1);
	    }

	    freeElement(BIN4, nextIndex);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void removeUnorderedBin4Value()
	{
	    // There are a number of cases to handle.
	    // We must keep in mind the following questions:
	    //
	    //  1. Is there just one bin in this list?
	    //  2. Are we removing the last element?
	    //  3. Is there just one element in the last bin?
	    //
	    // NOTE: Don't forget to the update the previous-link
	    //       of the first bin if you remove the last bin.

	    int segmentIndex = computeSegment(m_binLastIndex);
	    int startingOffset = computeBin4Offset(m_binLastIndex);

	    int length = getBin4Next(segmentIndex, startingOffset);
	    if (length == 4)
	    {
		removeBin4ValueByDemotion();
	    }
	    else
	    {
		removeUnorderedBin4ValueByDeletion(segmentIndex,
						   startingOffset, length);
	    }
	}

	// NOTE: There must be just one bin in this list.
	private void removeBin4ValueByDemotion()
	{
	    int oldBinCurrentIndex = m_binCurrentIndex;
	    int oldSegmentIndex = m_segmentIndex;
	    int oldStartingOffset = m_startingOffset;
	    int oldCurrentOffset = m_currentOffset;
		    
	    allocateBinAndParseHandle(BIN3);

	    int firstOffset;
	    int secondOffset;
	    int thirdOffset;

	    if (oldCurrentOffset == oldStartingOffset)
	    {
		firstOffset = oldStartingOffset + 1;
		secondOffset = oldStartingOffset + 2;
		thirdOffset = oldStartingOffset + 3;
	    }
	    else if (oldCurrentOffset == oldStartingOffset + 1)
	    {
		firstOffset = oldStartingOffset;
		m_currentOffset = m_startingOffset + 1;
		secondOffset = oldStartingOffset + 2;
		thirdOffset = oldStartingOffset + 3;
	    }
	    else if (oldCurrentOffset == oldStartingOffset + 2)
	    {
		firstOffset = oldStartingOffset;
		secondOffset = oldStartingOffset + 1;
		m_currentOffset = m_startingOffset + 2;
		thirdOffset = oldStartingOffset + 3;
	    }
	    else
	    {
		firstOffset = oldStartingOffset;
		secondOffset = oldStartingOffset + 1;
		thirdOffset = oldStartingOffset + 2;
		m_currentOffset = m_startingOffset + 2;
	    }

	    m_segments[BIN3][m_segmentIndex][m_startingOffset] = 
		getBin4Data(oldSegmentIndex, firstOffset);
	    m_segments[BIN3][m_segmentIndex][m_startingOffset + 1] = 
		getBin4Data(oldSegmentIndex, secondOffset);
	    m_segments[BIN3][m_segmentIndex][m_startingOffset + 2] = 
		getBin4Data(oldSegmentIndex, thirdOffset);

	    freeElement(BIN4, oldBinCurrentIndex);
	}

	// NOTE: There must be more than one bin in this list.
	private void removeUnorderedBin4ValueByDeletion(int segmentIndex,
							int startingOffset,
							int length)
	{
	    if (DEBUG)
	    {
		String caller = "removeUnorderedBin4ValueByDeletion";
		validateBin4SegmentAndOffset(caller, segmentIndex,
					     startingOffset);
		if (length < 0)
		{
		    String msg = 
			"ERROR: removeUnorderedBin4ValueByDeletion(): "
			+ "length [" + length + "] must be nonnegative.";
		    throw new InvariantFailedException(msg);
		}
	    }

	    int lastPrevious = getBin4Previous(segmentIndex, startingOffset);
	    int lastOccupancy = extractOccupancy(lastPrevious);

	    int lastLastOffset = startingOffset + lastOccupancy - 1;

	    // Were we requested to remove the last element?
	    boolean isRemovingLastElement =
		(m_binCurrentIndex == m_binLastIndex
		 && m_currentOffset == lastLastOffset);

	    if (!isRemovingLastElement)
	    {
		int lastValue = getBin4Data(segmentIndex, lastLastOffset);
		setBin4Data(m_segmentIndex, m_currentOffset, lastValue);
	    }

	    if (lastOccupancy == 1)
	    {
		// Since the last bin has an occupancy of 1, there must
		// be at least one additional bin in this list.  Hence
		// we needn't worry about checking whether previousBinIndex
		// actually gives a valid bin distinct from the last bin.

		freeElement(BIN4, m_binLastIndex);

		int previousBinIndex = extractIndex(lastPrevious);
		int previousSegmentIndex = computeSegment(previousBinIndex);
		int previousStartingOffset =
		    computeBin4Offset(previousBinIndex);

		m_binLastIndex = previousBinIndex;
		setBin4PreviousIndex(getHandleBinIndex(), previousBinIndex);
		setBin4Next(previousSegmentIndex,
			    previousStartingOffset, length - 1);

		if (isRemovingLastElement)
		{
		    m_binCurrentIndex = previousBinIndex;
		    m_segmentIndex = previousSegmentIndex;
		    m_startingOffset = previousStartingOffset;

		    // NOTE: Since the occupancy of this bin is 1, the
		    //       invariants require that the occupancy of the
		    //       previous bin be 4.  Hence, we may calculate
		    //       m_lastOffset as follows without worry.
		    m_lastOffset = previousStartingOffset + 3;
		    m_currentOffset = m_lastOffset;
		}
	    }
	    else
	    {
		if (isRemovingLastElement)
		{
		    m_currentOffset = --m_lastOffset;
		}

		setBin4Occupancy(segmentIndex, startingOffset,
				 lastOccupancy - 1);
		setBin4Next(segmentIndex, startingOffset, length - 1);
	    }

	    // NOTE: We should not advance() here since a new value has
	    //       replaced the old value at the current iterator position,
	    //       and the user has not yet seen this new value.  This
	    //       behavior ensures that the user sees, or potentially
	    //       sees, each value in the list exactly once, regardless
	    //       of any removals.

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void insertBin1Value()
	{
	    int value =	m_segments[BIN1][m_segmentIndex][m_startingOffset];

	    freeElement(BIN1, m_binCurrentIndex);
	    allocateBinAndParseHandle(BIN2);

	    // The old element becomes the new second element.
	    m_segments[BIN2][m_segmentIndex][m_lastOffset] = value;
	}

	private void insertBin2Value()
	{
	    int firstPosition =	(m_currentOffset == m_startingOffset) ? 1 : 0;

	    int firstValue =m_segments[BIN2][m_segmentIndex][m_startingOffset];
	    int secondValue = m_segments[BIN2][m_segmentIndex][m_lastOffset];

	    freeElement(BIN2, m_binCurrentIndex);
	    allocateBinAndParseHandle(BIN3);

	    m_segments[BIN3][m_segmentIndex]
		[m_startingOffset + firstPosition] = firstValue;
	    m_segments[BIN3][m_segmentIndex][m_lastOffset] = secondValue;

	    if (firstPosition == 0)
	    {
		++m_currentOffset; // Position at 2nd element.
	    }
	}

	private void insertBin3Value()
	{
	    int oldBinCurrentIndex = m_binCurrentIndex;
	    int oldSegmentIndex = m_segmentIndex;
	    int oldStartingOffset = m_startingOffset;
	    int oldCurrentOffset = m_currentOffset;
		    
	    allocateBinAndParseHandle(BIN4);

	    int firstOffset;
	    int secondOffset;

	    if (oldCurrentOffset == oldStartingOffset)
	    {
		firstOffset = m_startingOffset + 1;
		secondOffset = m_startingOffset + 2;
	    }
	    else if (oldCurrentOffset == oldStartingOffset + 1)
	    {
		firstOffset = m_startingOffset;
		m_currentOffset = m_startingOffset + 1;
		secondOffset = m_startingOffset + 2;
	    }
	    else
	    {
		firstOffset = m_startingOffset;
		secondOffset = m_startingOffset + 1;
		m_currentOffset = m_startingOffset + 2;
	    }

	    setBin4Data(m_segmentIndex, firstOffset, m_segments[BIN3]
			[oldSegmentIndex][oldStartingOffset]);
	    setBin4Data(m_segmentIndex, secondOffset, m_segments[BIN3]
			[oldSegmentIndex][oldStartingOffset + 1]);
	    setBin4Data(m_segmentIndex, m_lastOffset, m_segments[BIN3]
			[oldSegmentIndex][oldStartingOffset + 2]);

	    freeElement(BIN3, oldBinCurrentIndex);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void insertOrderedBin4Value()
	{
	    int currentOccupancy = m_lastOffset - m_startingOffset + 1;
	    if (currentOccupancy < 4)
	    {
		insertIntoCurrentOrderedBin4();
	    }
	    else
	    {
		boolean completedInsertion = false;

		int previousIndex =
		    getBin4PreviousIndex(m_segmentIndex, m_startingOffset);

		if (previousIndex != m_binLastIndex)
		{
		    int previousSegmentIndex = computeSegment(previousIndex);
		    int previousStartingOffset =
			computeBin4Offset(previousIndex);

		    int previousOccupancy = 
			getBin4Occupancy(previousSegmentIndex,
					 previousStartingOffset);

		    if (previousOccupancy < 4)
		    {
			completedInsertion = true;
			insertIntoPreviousOrderedBin4(previousIndex,
						      previousSegmentIndex,
						      previousStartingOffset,
						      previousOccupancy);
		    }
		}

		if (!completedInsertion && m_binCurrentIndex != m_binLastIndex)
		{
		    int nextIndex =
			getBin4Next(m_segmentIndex, m_startingOffset);

		    int nextSegmentIndex = computeSegment(nextIndex);
		    int nextStartingOffset = computeBin4Offset(nextIndex);

		    int nextOccupancy =
			getBin4Occupancy(nextSegmentIndex, nextStartingOffset);

		    if (nextOccupancy < 4)
		    {
			completedInsertion = true;
			insertIntoNextOrderedBin4(nextIndex,
						  nextSegmentIndex,
						  nextStartingOffset,
						  nextOccupancy);
		    }
		}

		if (!completedInsertion)
		{
		    insertIntoSplitOrderedBin4();
		}
	    }
	}

	private void insertIntoCurrentOrderedBin4()
	{
	    int occupancy = m_lastOffset - m_startingOffset + 1;

	    for (int i = m_lastOffset; i >= m_currentOffset; i--)
	    {
		setBin4Data(m_segmentIndex, i + 1,
			    getBin4Data(m_segmentIndex, i));
	    }

	    ++m_lastOffset;
	    setBin4Occupancy(m_segmentIndex, m_startingOffset, occupancy + 1);
	    adjustListLength(1);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void insertIntoPreviousOrderedBin4(int previousBinIndex,
						   int previousSegmentIndex,
						   int previousStartingOffset,
						   int previousOccupancy)
	{
	    if (DEBUG)
	    {
		String caller = "insertIntoPreviousOrderedBin4";
		validateBinIndex(caller, previousBinIndex);
		validateBin4SegmentAndOffset(caller, previousSegmentIndex,
					     previousStartingOffset);
		validateOccupancy(caller, previousOccupancy);
	    }

	    int position = m_currentOffset - m_startingOffset;
	    if (position == 0)
	    {
		m_binCurrentIndex = previousBinIndex;
		m_segmentIndex = previousSegmentIndex;
		m_startingOffset = previousStartingOffset;
		m_lastOffset = previousStartingOffset + previousOccupancy;
		m_currentOffset = m_lastOffset;
	    }
	    else
	    {
		setBin4Data(previousSegmentIndex,
			    previousStartingOffset + previousOccupancy,
			    getBin4Data(m_segmentIndex, m_startingOffset));

		if (position >= 2)
		{
		    setBin4Data(m_segmentIndex, m_startingOffset,
				getBin4Data(m_segmentIndex,
					    m_startingOffset + 1));

		    if (position == 3)
		    {
			setBin4Data(m_segmentIndex, m_startingOffset + 1,
				    getBin4Data(m_segmentIndex,
						m_startingOffset + 2));
		    }
		}

		--m_currentOffset;
	    }

	    setBin4Occupancy(previousSegmentIndex, previousStartingOffset,
			     previousOccupancy + 1);
	    adjustListLength(1);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void insertIntoNextOrderedBin4(int nextIndex,
					       int nextSegmentIndex,
					       int nextStartingOffset,
					       int nextOccupancy)
	{
	    if (DEBUG)
	    {
		String caller = "insertIntoNextOrderedBin4";
		validateBinIndex(caller, nextIndex);
		validateBin4SegmentAndOffset(caller, nextSegmentIndex,
					     nextStartingOffset);
		validateOccupancy(caller, nextOccupancy);
	    }


	    // Make room at the beginning of the next bin by shifting all
	    // of its elements as far right as possible.

	    for (int i = 1; i <= nextOccupancy; i++)
	    {
		int source = nextStartingOffset + nextOccupancy - i;
		int destination = nextStartingOffset + 4 - i;

		setBin4Data(nextSegmentIndex, destination,
			    getBin4Data(nextSegmentIndex, source));
	    }

	    // Fill up the next bin with as many of the trailing elements
	    // of this bin as will fit.  This loop is complicated by the
	    // fact that the element at m_currentOffset counts as two
	    // elements, once for the actual value and twice for the
	    // to-be-inserted value.
	    //
	    // The purpose of nextCurrentOffset is twofold.  First, it makes
	    // it possible to determine in which bin, either the current or
	    // next, to insert the new element.  Second, in the case where
	    // the new element should be inserted into the next bin, it holds
	    // the offset of the new element.

	    int nextCurrentOffset = -1;
	    for (int i = m_lastOffset,
		     j = nextStartingOffset + 3 - nextOccupancy;
		 j >= nextStartingOffset;
		 i--, j--)
	    {
		setBin4Data(nextSegmentIndex, j,
			    getBin4Data(m_segmentIndex, i));

		if (i == m_currentOffset && j > nextStartingOffset)
		{
		    nextCurrentOffset = --j;
		}
	    }

	    setBin4Occupancy(nextSegmentIndex, nextStartingOffset, 4);

	    if (DEBUG && m_lastOffset - m_startingOffset + 1 != 4)
	    {
		String msg = "ERROR: insertIntoNextOrderedBin4(): "
		    + "current occupancy != 4";
		throw new InvariantFailedException(msg);
	    }

	    int occupancy = 4;

	    if (nextCurrentOffset == -1)
	    {
		// The new current offset is still in the current bin.

		int newOccupancy = occupancy - (4 - nextOccupancy) + 1;
		setBin4Occupancy(m_segmentIndex, m_startingOffset,
				 newOccupancy);

		m_lastOffset = m_startingOffset + newOccupancy - 1;

		// Make room in current bin for new element at m_currentOffset.
		for (int i = m_lastOffset - 1; i >= m_currentOffset; i--)
		{
		    setBin4Data(m_segmentIndex, i + 1,
				getBin4Data(m_segmentIndex, i));
		}
	    }
	    else
	    {
		// The new current offset is in the next bin.

		setBin4Occupancy(m_segmentIndex, m_startingOffset,
				 occupancy - (4 - nextOccupancy - 1));

		m_binCurrentIndex = nextIndex;
		m_segmentIndex = nextSegmentIndex;
		m_startingOffset = nextStartingOffset;
		m_lastOffset = nextStartingOffset + 3;
		m_currentOffset = nextCurrentOffset;
	    }

	    adjustListLength(1);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void insertIntoSplitOrderedBin4()
	{
	    int oldBinCurrentIndex = m_binCurrentIndex;
	    int oldSegmentIndex = m_segmentIndex;
	    int oldStartingOffset = m_startingOffset;

	    int position = m_currentOffset - m_startingOffset;
	    if (position == 0)
	    {
		int previousIndex =
		    getBin4PreviousIndex(m_segmentIndex, m_startingOffset);

		allocateBin4AndParseBinCurrentIndex(previousIndex,
						    oldBinCurrentIndex, 1);

		setBin4PreviousIndex(oldSegmentIndex, oldStartingOffset,
				     m_binCurrentIndex);

		if (previousIndex == m_binLastIndex)
		{
		    setAndParseHandle(BIN4, m_binCurrentIndex);
		}
		else
		{
		    setBin4Next(previousIndex, m_binCurrentIndex);
		}
	    }
	    else
	    {
		int nextIndex = getBin4Next(m_segmentIndex, m_startingOffset);

		allocateBin4AndParseBinCurrentIndex(oldBinCurrentIndex,
						    nextIndex, 4);

		setBin4Next(oldSegmentIndex, oldStartingOffset,
			    m_binCurrentIndex);

		if (oldBinCurrentIndex == m_binLastIndex)
		{
		    m_binLastIndex = m_binCurrentIndex;
		    setBin4PreviousIndex(getHandleBinIndex(),
					 m_binCurrentIndex);
		}
		else
		{
		    setBin4PreviousIndex(nextIndex, m_binCurrentIndex);
		}

		m_currentOffset = m_startingOffset + position - 1;

		int i = oldStartingOffset + 1;
		for (int j = m_startingOffset; j <= m_lastOffset; j++)
		{
		    if (j != m_currentOffset)
		    {
			setBin4Data(m_segmentIndex, j,
				    getBin4Data(oldSegmentIndex, i++));
		    }
		}

		setBin4Occupancy(oldSegmentIndex, oldStartingOffset, 1);
	    }

	    adjustListLength(1);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void appendBin1Value()
	{
	    int value = m_segments[BIN1][m_segmentIndex][m_startingOffset];

	    freeElement(BIN1, m_binCurrentIndex);
	    allocateBinAndParseHandle(BIN2);

	    m_segments[BIN2][m_segmentIndex][m_currentOffset++] = value;
	}

	private void appendBin2Value()
	{
	    int firstValue =m_segments[BIN2][m_segmentIndex][m_startingOffset];
	    int secondValue = m_segments[BIN2][m_segmentIndex][m_lastOffset];

	    freeElement(BIN2, m_binCurrentIndex);
	    allocateBinAndParseHandle(BIN3);

	    m_segments[BIN3][m_segmentIndex][m_currentOffset++] = firstValue;
	    m_segments[BIN3][m_segmentIndex][m_currentOffset++] = secondValue;
	}

	private void appendBin3Value()
	{
	    int firstValue =m_segments[BIN3][m_segmentIndex][m_startingOffset];
	    int secondValue =
		m_segments[BIN3][m_segmentIndex][m_startingOffset + 1];
	    int thirdValue = m_segments[BIN3][m_segmentIndex][m_lastOffset];
		    
	    freeElement(BIN3, m_binCurrentIndex);
	    allocateBinAndParseHandle(BIN4);

	    setBin4Data(m_segmentIndex, m_currentOffset++, firstValue);
	    setBin4Data(m_segmentIndex, m_currentOffset++, secondValue);
	    setBin4Data(m_segmentIndex, m_currentOffset++, thirdValue);

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void appendBin4Value()
	{
	    if (m_binCurrentIndex != m_binLastIndex)
	    {
		m_binCurrentIndex = m_binLastIndex;
		parseBin4BinCurrentIndex();
	    }

	    int occupancy = m_lastOffset - m_startingOffset + 1;
	    if (occupancy < 4)
	    {
		m_currentOffset = ++m_lastOffset;
		setBin4Occupancy(m_segmentIndex, m_startingOffset,
				 occupancy + 1);
		adjustListLength(1);
	    }
	    else
	    {
		int oldSegmentIndex = m_segmentIndex;
		int oldStartingOffset = m_startingOffset;

		int length = getBin4Next(m_segmentIndex, m_startingOffset);
		allocateBin4AndParseBinCurrentIndex(m_binLastIndex,
						    length + 1, 1);
		
		setBin4Next(oldSegmentIndex, oldStartingOffset,
			    m_binCurrentIndex);

		m_binLastIndex = m_binCurrentIndex;
		setBin4PreviousIndex(getHandleBinIndex(), m_binLastIndex);
	    }

	    if (DEBUG)
	    {
		verifyBin4StateConsistency();
	    }
	}

	private void allocateBin4AndParseBinCurrentIndex(int previousIndex,
							 int nextIndex,
							 int occupancy)
	{
	    if (DEBUG)
	    {
		String caller = "allocateBin4AndParseBinCurrentIndex";
		validateBinIndex(caller, previousIndex);
		validateNextBinIndex(caller, nextIndex);
		validateOccupancy(caller, occupancy);
	    }

	    m_binCurrentIndex = allocateElement(BIN4);

	    m_segmentIndex = computeSegment(m_binCurrentIndex);
	    m_startingOffset = computeBin4Offset(m_binCurrentIndex);
	    m_lastOffset = m_startingOffset + occupancy - 1;
	    m_currentOffset = m_startingOffset;

	    setBin4Previous(m_segmentIndex, m_startingOffset,
			    previousIndex, occupancy);
	    setBin4Next(m_segmentIndex, m_startingOffset, nextIndex);
	}

	private void allocateBinAndParseHandle(int type)
	{
	    if (DEBUG) { validateBinType("allocateBinAndParseHandle", type); }

	    m_binType = type;
	    m_binCurrentIndex = allocateElement(type);

	    m_segmentIndex = computeSegment(m_binCurrentIndex);
	    m_startingOffset = computeOffset(type, m_binCurrentIndex);
	    m_lastOffset = m_startingOffset + ELEMENT_USER_SIZE[type] - 1;
	    m_currentOffset = m_startingOffset;

	    if (type == BIN4)
	    {
		m_binLastIndex = m_binCurrentIndex;

		setBin4Previous(m_segmentIndex, m_startingOffset,
				m_binCurrentIndex, 4);

		// Since this is the last, as well as the first, bin of
		// this list, the 'next' link field holds the list size.
		setBin4Next(m_segmentIndex, m_startingOffset, 4);
	    }

	    int handle = constructHandle(type, m_binCurrentIndex);
	    setFirstValueUnchecked(HANDLE, m_handleIndex, handle);
	}

	private void getAndParseHandle()
	{
	    parseHandle(getFirstValueUnchecked(HANDLE, m_handleIndex));
	}

	private void setAndParseHandle(int handle)
	{
	    setFirstValueUnchecked(HANDLE, m_handleIndex, handle);
	    parseHandle(handle);
	}

	private void setAndParseHandle(int type, int binIndex)
	{
	    if (DEBUG)
	    {
		validateBinType("setAndParseHandle", type);
		validateBinIndex("setAndParseHandle", binIndex);
	    }

	    int handle = constructHandle(type, binIndex);
	    setFirstValueUnchecked(HANDLE, m_handleIndex, handle);
	    parseHandle(handle);
	}

	private void parseHandle(int handle)
	{
	    if (handle == -1)
	    {
		m_binType = -1;
	    }
	    else
	    {
		m_binType = extractHandleType(handle);
		m_binCurrentIndex = extractHandleIndex(handle);
		m_segmentIndex = computeSegment(m_binCurrentIndex);
		m_startingOffset = computeOffset(m_binType, m_binCurrentIndex);
		m_currentOffset = m_startingOffset;

		if (m_binType == BIN4)
		{
		    int previous =
			getBin4Previous(m_segmentIndex, m_startingOffset);

		    m_binLastIndex = extractIndex(previous);

		    int occupancy = extractOccupancy(previous);
		    m_lastOffset = m_startingOffset + occupancy - 1;
		}
		else
		{
		    m_lastOffset =
			m_startingOffset + ELEMENT_USER_SIZE[m_binType] - 1;
		}
	    }
	}

	// {m_binCurrentIndex} is assumed to be the index of a BIN4 element.
	private void parseBin4BinCurrentIndex()
	{
	    m_segmentIndex = computeSegment(m_binCurrentIndex);
	    m_startingOffset = computeBin4Offset(m_binCurrentIndex);
	    m_currentOffset = m_startingOffset;

	    int occupancy = getBin4Occupancy(m_segmentIndex, m_startingOffset);
	    m_lastOffset = m_startingOffset + occupancy - 1;
	}

	private void adjustListLength(int delta)
	{
	    int segmentIndex;
	    int startingOffset;

	    if (m_binCurrentIndex == m_binLastIndex)
	    {
		segmentIndex = m_segmentIndex;
		startingOffset = m_startingOffset;
	    }
	    else
	    {
		segmentIndex = computeSegment(m_binLastIndex);
		startingOffset = computeBin4Offset(m_binLastIndex);
	    }

	    int length = getBin4Next(segmentIndex, startingOffset);
	    setBin4Next(segmentIndex, startingOffset, length + delta);
	}

	private int getHandleBinIndex()
	{
	    int handle = getFirstValueUnchecked(HANDLE, m_handleIndex);
	    return extractHandleIndex(handle);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private final boolean RELAX_REMOVAL_SEMANTICS;

	private int  m_handleIndex;
	private int  m_binType;
	private int  m_binCurrentIndex;
	private int  m_binLastIndex;
	private int  m_segmentIndex;
	private int  m_startingOffset;
	private int  m_lastOffset;
	private int  m_currentOffset;
	private boolean  m_atEnd;

	////////////////////////////////////////////////////////////////////
	// DEBUGGING & TESTING METHODS
	////////////////////////////////////////////////////////////////////

	private void verifyBin4StateConsistency()
	{
	    if (m_segmentIndex < 0
		|| m_segmentIndex >= m_numAllocatedSegments[BIN4])
	    {
		String msg = "ERROR: failed to have 0 <= "
		    + "m_segmentIndex [" + m_segmentIndex + "] < "
		    + m_numAllocatedSegments[BIN4];
		throw new InvariantFailedException(msg);
	    }

	    int segmentLength = m_segments[BIN4][m_segmentIndex].length;

	    if (m_startingOffset < 0 || m_startingOffset >= segmentLength)
	    {
		String msg = "ERROR: failed to have 0 <= "
		    + "m_startingOffset [" + m_startingOffset + "] < "
		    + segmentLength;
		throw new InvariantFailedException(msg);
	    }

	    if (m_lastOffset < 0 || m_lastOffset >= segmentLength)
	    {
		String msg = "ERROR: failed to have 0 <= "
		    + "m_lastOffset [" + m_lastOffset + "] < "
		    + segmentLength;
		throw new InvariantFailedException(msg);
	    }

	    if (m_currentOffset < 0 || m_currentOffset >= segmentLength)
	    {
		String msg = "ERROR: failed to have 0 <= "
		    + "m_currentOffset [" + m_currentOffset + "] < "
		    + segmentLength;
		throw new InvariantFailedException(msg);
	    }

	    if ((m_startingOffset % ELEMENT_TOTAL_SIZE[BIN4]) != 0)
	    {
		String msg = "ERROR: m_startingOffset ["
		    + m_startingOffset + "] is not on "
		    + "a ELEMENT_TOTAL_SIZE[BIN4] boundary";
		throw new InvariantFailedException(msg);
	    }

	    if (m_lastOffset < m_startingOffset ||
		m_lastOffset > m_startingOffset + 3)
	    {
		String msg = "ERROR: m_lastOffset ["
		    + m_lastOffset + "] is not in the "
		    + "range [" + m_startingOffset + ", " +
		    + (m_startingOffset + 3) + "]";
		throw new InvariantFailedException(msg);
	    }

	    if (m_currentOffset < m_startingOffset ||
		m_currentOffset > m_lastOffset)
	    {
		if (m_currentOffset >= m_startingOffset
		    && m_currentOffset
		    <= m_startingOffset + ELEMENT_TOTAL_SIZE[BIN4] - 1)
		{
		    int position = m_currentOffset % ELEMENT_TOTAL_SIZE[BIN4];
		    if (position == BIN4_PREV_OFFSET)
		    {
			String msg = "ERROR: m_currentOffset points "
			    + "to the previous-link field rather than to data";
			throw new InvariantFailedException(msg);
		    }
		    else if (position == BIN4_NEXT_OFFSET)
		    {
			String msg = "ERROR: m_currentOffset points "
			    + "to the next-link field rather than to data";
			throw new InvariantFailedException(msg);
		    }
		}

		String msg = "ERROR: m_currentOffset ["
		    + m_currentOffset + "] is not in the "
		    + "range [" + m_startingOffset + ", "
		    + (m_startingOffset + 3) + "]";
		throw new InvariantFailedException(msg);
	    }
	}

	private void dumpState()
	{
	    System.out.println("==========================================");
	    System.out.println("IntBinArray [" + Integer.toHexString
			       (IntBinArray.this.hashCode()) + "]");
	    System.out.println("------------------------------------------");
	    System.out.println("m_handleIndex = " + m_handleIndex);
	    System.out.println("m_binType = " + m_binType);
	    System.out.println("m_binCurrentIndex = " + m_binCurrentIndex);
	    System.out.println("m_binLastIndex = " + m_binLastIndex);
	    System.out.println("m_segmentIndex = " + m_segmentIndex);
	    System.out.println("m_startingOffset = " + m_startingOffset);
	    System.out.println("m_lastOffset = " + m_lastOffset);
	    System.out.println("m_currentOffset = " + m_currentOffset);

	    if (m_binType == BIN4)
	    {
		System.out.println();
		int occupancy =
		    getBin4Occupancy(m_segmentIndex, m_startingOffset);
		int previousIndex =
		    getBin4PreviousIndex(m_segmentIndex, m_startingOffset);
		int nextIndex = getBin4Next(m_segmentIndex, m_startingOffset);

		System.out.println("occupancy = " + occupancy);
		System.out.println("previousIndex = " + previousIndex);
		System.out.println("nextIndex = " + nextIndex);
	    }

	    System.out.println("==========================================");
	}
    }
}
