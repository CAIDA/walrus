// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.Arrays;
import java.util.BitSet;
import java.util.Map;
import java.util.HashMap;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.IOException;

class GraphBuilderTester
    extends AbstractTester
{
    ///////////////////////////////////////////////////////////////////////
    // PUBLIC INTERFACES
    ///////////////////////////////////////////////////////////////////////

    public interface GraphBuilderFactory
    {
	public GraphBuilder makeGraphBuilder();
    }

    ///////////////////////////////////////////////////////////////////////
    // MAIN
    ///////////////////////////////////////////////////////////////////////

    public static void main(String[] args)
    {
	int startingTest = 0;
	boolean isMutable = false;
	OptimizationType  optimization = null;

	if (args.length > 0)
	{
	    try
	    {
		startingTest = Integer.parseInt(args[args.length - 1]);
	    }
	    catch (NumberFormatException e)
	    {
		System.err.println("ERROR: Malformed starting test number '"
				   + args[args.length - 1] + "'");
		printUsage();
		System.exit(1);
	    }

	    if (startingTest < 0)
	    {
		System.err.println("ERROR: Starting test must be >= 0.");
		printUsage();
		System.exit(1);
	    }

	    if (args.length > 1)
	    {
		if (args[0].equals("mutable"))
		{
		    isMutable = true;
		}
		else if (args[0].equals("immutable"))
		{
		    isMutable = false;
		}
		else
		{
		    System.err.println("ERROR: Unknown graph type '"
				       + args[0] + "'");
		    printUsage();
		    System.exit(1);
		}

		if (args.length == 3)
		{
		    if (args[1].equals("fastest"))
		    {
			optimization = OptimizationType.FASTEST;
		    }
		    else if (args[1].equals("space-efficient"))
		    {
			optimization = OptimizationType.SPACE_EFFICIENT;
		    }
		    else if (args[1].equals("minimal-space"))
		    {
			optimization = OptimizationType.MINIMAL_SPACE;
		    }
		    else
		    {
			System.err.println("ERROR: Unknown optimization type '"
					   + args[1] + "'");
			printUsage();
			System.exit(1);
		    }
		}
		else if (args.length > 3)
		{
		    System.err.println("ERROR: Too many arguments.");
		    printUsage();
		    System.exit(1);
		}
	    }
	}

	GraphBuilderTester tester =
	    new GraphBuilderTester(makeFactory(isMutable, optimization));
	tester.testAll(startingTest);
    }

    ///////////////////////////////////////////////////////////////////////

    private static GraphBuilderFactory makeFactory
	(boolean isMutable, final OptimizationType optimization)
    {
	if (isMutable)
	{
	    if (optimization == null)
	    {
		System.out.println("*** Mutable graph, default optimization");
		return new GraphBuilderFactory() {
			public GraphBuilder makeGraphBuilder()
			{ return GraphFactory.makeMutableGraph(); }
		    };
	    }
	    else
	    {
		System.out.println("*** Mutable graph, "
				   + optimization.getName());
		return new GraphBuilderFactory() {
			public GraphBuilder makeGraphBuilder()
			{ return GraphFactory.makeMutableGraph(optimization); }
		    };
	    }
	}
	else
	{
	    if (optimization == null)
	    {
		System.out.println("*** Immutable graph, "
				   + "default optimization");
		return new GraphBuilderFactory() {
			public GraphBuilder makeGraphBuilder()
			{ return GraphFactory.makeImmutableGraph(); }
		    };
	    }
	    else
	    {
		System.out.println("*** Immutable graph, "
				   + optimization.getName());
		return new GraphBuilderFactory() {
			public GraphBuilder makeGraphBuilder()
			{ return GraphFactory
			      .makeImmutableGraph(optimization); }
		    };
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private static void printUsage()
    {
	System.err.println
	    ("Usage:");
	System.err.println
	    ("  GraphBuilderTester <starting-test>");
	System.err.println
	    ("  GraphBuilderTester <graph-type> <starting-test>");
	System.err.println
	    ("  GraphBuilderTester <graph-type> <optimization> <starting-test>");
	System.err.println();
	System.err.println
	    ("where <starting-test> is an integer >= 0,");
	System.err.println
	    ("      <graph-type> is 'mutable' or 'immutable' (default),");
	System.err.println
	    ("  and <optimization> is 'fastest', 'space-efficient', "
	     + "or 'minimal-space'.");
    }

    ///////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ///////////////////////////////////////////////////////////////////////

    public GraphBuilderTester(GraphBuilderFactory factory)
    {
	super();
	m_factory = factory;
    }

    ///////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ///////////////////////////////////////////////////////////////////////

    public void testAll(int startingTest)
    {
	try
	{
	    if (startingTest == 0)
	    {
		println("\n**** TEST 0 ****");
		testNameDescription();
	    }

	    if (startingTest <= 1)
	    {
		println("\n**** TEST 1 ****");
		for (int i = 0; i < 10; i++)
		{
		    testNodeAllocation(i);
		}

		testNodeAllocation(100);
	    }

	    if (startingTest <= 2)
	    {
		println("\n**** TEST 2 ****");
		for (int i = 0; i < 10; i++)
		{
		    testLinkAllocation(10, i);
		}

		testLinkAllocation(1, 100);
		testLinkAllocation(2, 100);
		testLinkAllocation(10, 100);
		testLinkAllocation(100, 500);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		for (int i = 0; i < 10; i++)
		{
		    testPathAllocation(5, i, 5);
		}

		testPathAllocation(5, 5, 1);
		testPathAllocation(10, 100, 50);
	    }

	    if (startingTest <= 4)
	    {
		println("\n**** TEST 4 ****");
		for (int i = 1; i < 10; i++)
		{
		    testEnumerationAllocation(i, 10);
		}
	    }

	    if (startingTest <= 5)
	    {
		println("\n**** TEST 5 ****");
		for (int i = 0; i < 10; i++)
		{
		    testAttributeDefinitionAllocation(i, 20);
		}
	    }

	    if (startingTest <= 6)
	    {
		println("\n**** TEST 6 ****");
		testMutableAttributeValueAllocation(0, 0, 0, 20, 0, 10);
		testMutableAttributeValueAllocation(10, 0, 0, 20, 0, 10);
		testMutableAttributeValueAllocation(10, 10, 0, 20, 0, 10);
		testMutableAttributeValueAllocation(10, 0, 10, 20, 0, 10);
		testMutableAttributeValueAllocation(10, 10, 10, 20, 0, 10);

		for (int i = 7; i < 1000; i *= 2)
		{
		    int nodes = i + m_random.nextInt(i / 2) - i / 4;
		    int links = i + m_random.nextInt(i / 2) - i / 4;
		    int paths = i + m_random.nextInt(i / 2) - i / 4;

		    testMutableAttributeValueAllocation
			(nodes, links, paths, 100, 0, 10);
		}

		testMutableAttributeValueAllocation
		    (1000, 1000, 1000, 100, 0, 10);
	    }

	    if (startingTest <= 7)
	    {
		println("\n**** TEST 7 ****");
		float[] occupancies = new float[]
		    { 0.0f, 0.1f, 0.2f, 0.3f, 0.4f, 0.5f,
		      0.6f, 0.7f, 0.8f, 0.9f, 1.0f };

		testImmutableAttributeValueAllocation
		    (0, 0, 0, 20, 0, 10, occupancies);
		testImmutableAttributeValueAllocation
		    (10, 0, 0, 20, 0, 10, occupancies);
		testImmutableAttributeValueAllocation
		    (10, 10, 0, 20, 0, 10, occupancies);
		testImmutableAttributeValueAllocation
		    (10, 0, 10, 20, 0, 10, occupancies);
		testImmutableAttributeValueAllocation
		    (10, 10, 10, 20, 0, 10, occupancies);

		for (int i = 7; i < 1000; i *= 2)
		{
		    int nodes = i + m_random.nextInt(i / 2) - i / 4;
		    int links = i + m_random.nextInt(i / 2) - i / 4;
		    int paths = i + m_random.nextInt(i / 2) - i / 4;

		    testImmutableAttributeValueAllocation
			(nodes, links, paths, 100, 0, 10, occupancies);
		}

		testImmutableAttributeValueAllocation
		    (1000, 1000, 1000, 100, 0, 10, occupancies);
	    }

	    if (startingTest <= 8)
	    {
		println("\n**** TEST 8 ****");
		testQualifierAllocation(1, 1, 1, 10);
		testQualifierAllocation(100, 1, 1, 100);
		testQualifierAllocation(1, 100, 1, 100);
		testQualifierAllocation(5, 10, 10, 100);
		testQualifierAllocation(25, 50, 10, 1000);
	    }

	    if (startingTest <= 9)
	    {
		println("\n**** TEST 9 ****");
		for (int i = 0; i < 10; i++)
		{
		    testDisplayAllocation(i, i, 20);
		}

		testDisplayAllocation(1, 0, 5);
		testDisplayAllocation(50, 20, 100);
		testDisplayAllocation(100, 100, 1000);
	    }

	    if (startingTest <= 10)
	    {
		println("\n**** TEST 10 ****");
		for (int i = 0; i < 10; i++)
		{
		    testFilterAllocation(i);
		}

		testFilterAllocation(50);
		testFilterAllocation(500);
	    }

	    if (startingTest <= 11)
	    {
		println("\n**** TEST 11 ****");
		for (int i = 0; i < 10; i++)
		{
		    testSelectorAllocation(i, i, 20);
		}

		testSelectorAllocation(1, 0, 5);
		testSelectorAllocation(50, 20, 100);
		testSelectorAllocation(100, 100, 1000);
	    }

	    if (startingTest <= 12)
	    {
		println("\n**** TEST 12 ****");
		for (int i = 0; i < 10; i++)
		{
		    testPresentationAllocation(i, 10, 10);
		}

		testPresentationAllocation(50, 10, 10);
		testPresentationAllocation(500, 50, 50);
	    }

	    if (startingTest <= 13)
	    {
		{
		    MenuProbability probability =
			new MenuProbability(5, 20, 15, 0.2f);
		    testMenuAllocation(probability, 20, 20, 20, 20, 20);
		}

		{
		    MenuProbability probability =
			new MenuProbability(5, 10, 10, 0.8f);
		    testMenuAllocation(probability, 20, 20, 20, 20, 20);
		}
	    }
	}
	catch (TestFailedException e)
	{
	    e.printStackTrace();
	    System.out.println("FAILED: " + e);
	}
	catch (RuntimeException e)
	{
	    e.printStackTrace();
	    System.out.println("ERROR: " + e);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // NAME & DESCRIPTION TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testNameDescription()
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testNameDescription()");
	println("===========================================================");

	String name = "Test Graph";
	String description = "A nice test graph.";

	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.setGraphName(name);
	builder.setGraphDescription(description);
	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);
	Graph graph = builder.endConstruction();

	verifyEqual("getName()", graph.getName(), name);
	verifyEqual("getDescription()", graph.getDescription(), description);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // NODE TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testNodeAllocation(int numNodes)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testNodeAllocation(numNodes=" + numNodes + ")");
	println("===========================================================");

	Graph graph = createGraphWithNumNodes(numNodes);
	checkNumObjects(graph, numNodes, 0, 0);

	// Test Graph.getNode(int), except where having to do with links.
	for (int i = 0; i < numNodes; i++)
	{
	    NodeIterator iterator = graph.getNode(i);
	    verifyEqual("getObjectType()", iterator.getObjectType(),
			ObjectType.NODE);
	    verifyEqual("getObjectID()", iterator.getObjectID(), i);

	    verify(false, "getNode().atEnd() == false", !iterator.atEnd());
	    iterator.advance();
	    verify(false, "getNode().atEnd() == true", iterator.atEnd());
	}

	println("ALL PASSED!");
    }

    private Graph createGraphWithNumNodes(int n)
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(n);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);
	return builder.endConstruction();
    }

    ///////////////////////////////////////////////////////////////////////
    // LINK TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testLinkAllocation(int numNodes, int numLinks)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testLinkAllocation(numNodes=" + numNodes + ", numLinks="
		+ numLinks + ")");
	println("===========================================================");

	Graph graph = null;
	int[] sources = null;
	int[] destinations = null;
	{
	    Object[] data = createGraphWithNumNodesLinks(numNodes, numLinks);
	    graph = (Graph)data[0];
	    sources = (int[])data[1];
	    destinations = (int[])data[2];
	}

	checkNumObjects(graph, numNodes, numLinks, 0);
	checkLinkData(graph, numNodes, numLinks, sources, destinations);
	checkNodeLinkData(graph, numNodes, numLinks, sources, destinations);

	println("ALL PASSED!");
    }

    /**
     * Adds the given number of links between random pairs of nodes to the
     * graph.
     *
     * Returns {Graph graph, int[numLinks] source, int[numLinks] destination}.
     */
    private Object[] createGraphWithNumNodesLinks(int numNodes, int numLinks)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(numNodes);
	builder.allocateLinks(numLinks);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	int[] sources = new int[numLinks];
	int[] destinations = new int[numLinks];
	addLinks(builder, numNodes, numLinks, sources, destinations);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[3];
	retval[0] = graph;
	retval[1] = sources;
	retval[2] = destinations;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that nodes contain valid link data.
     */
    private void checkNodeLinkData(Graph graph, int numNodes, int numLinks,
				   int[] sources, int[] destinations)
	throws TestFailedException
    {
	int[] numOutgoing = computeHistogram(numNodes, sources);
	int[] numIncoming = computeHistogram(numNodes, destinations);

	// Test Graph.getNum{Outgoing,Incoming}Links(int).
	for (int i = 0; i < numNodes; i++)
	{
	    verifyEqual("getNumOutgoingLinks()",
			graph.getNumOutgoingLinks(i), numOutgoing[i]);
	    verifyEqual("getNumIncomingLinks()",
			graph.getNumIncomingLinks(i), numIncoming[i]);
	}

	checkNodeLinkListConsistency(graph, numNodes, numLinks,
				     numOutgoing, numIncoming);
	checkNodeLinkListCompleteness(graph, numLinks, sources, destinations);
    }

    /**
     * Tests that the outgoing links of a node originate at that node,
     * that incoming links end at that node, that no link is repeated
     * in any one node's list of incoming or outgoing links, and that
     * each list of links has the correct number of elements.
     */
    private void checkNodeLinkListConsistency
	(Graph graph, int numNodes, int numLinks,
	 int[] numOutgoing, int[] numIncoming)
	throws TestFailedException
    {
	NodeIterator nodeIterator = graph.getNodes();
	while (!nodeIterator.atEnd())
	{
	    int nodeID = nodeIterator.getObjectID();
	    validateNodeID(numNodes, nodeID);

	    {
		int numSeen = 0;
		BitSet seenMap = new BitSet(numLinks);

		LinkIterator iterator = nodeIterator.getOutgoingLinks();
		while (!iterator.atEnd())
		{
		    int id = iterator.getObjectID();
		    validateLinkID(numLinks, id);

		    if (seenMap.get(id))
		    {
			String msg =
			    "link[" + id + "] repeated in outgoing list";
			fail(msg);
		    }
		    seenMap.set(id);

		    verifyEqual("link.getSource()",
				iterator.getSource(), nodeID);

		    ++numSeen;
		    iterator.advance();
		}

		verifyEqual("# outgoing links",
			    numSeen, numOutgoing[nodeID]);
	    }

	    {
		int numSeen = 0;
		BitSet seenMap = new BitSet(numLinks);

		LinkIterator iterator = nodeIterator.getIncomingLinks();
		while (!iterator.atEnd())
		{
		    int id = iterator.getObjectID();
		    validateLinkID(numLinks, id);

		    if (seenMap.get(id))
		    {
			String msg =
			    "link[" + id + "] repeated in incoming list";
			fail(msg);
		    }
		    seenMap.set(id);

		    verifyEqual("link.getDestination()",
				iterator.getDestination(), nodeID);

		    ++numSeen;
		    iterator.advance();
		}

		verifyEqual("# incoming links",
			    numSeen, numIncoming[nodeID]);
	    }

	    nodeIterator.advance();
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the lists of outgoing and incoming links contain exactly
     * the links that were added to the graph.
     *
     * This assumes that checkNodeLinkListConsistency() has run successfully.
     */
    private void checkNodeLinkListCompleteness
	(Graph graph, int numLinks, int[] sources, int[] destinations)
	throws TestFailedException
    {
	for (int i = 0; i < numLinks; i++)
	{
	    checkNodeHasOutgoingLink(graph, sources[i], destinations[i]);
	    checkNodeHasIncomingLink(graph, sources[i], destinations[i]);
	}
    }

    /**
     * Checks that the from-node has a link in its outgoing links list
     * to the to-node.
     */
    private void checkNodeHasOutgoingLink(Graph graph,
					  int fromNode, int toNode)
	throws TestFailedException
    {
	LinkIterator iterator = graph.getNode(fromNode).getOutgoingLinks();
	while (!iterator.atEnd())
	{
	    if (iterator.getDestination() == toNode)
	    {
		println("outgoing: " + fromNode + " => " + toNode);
		return;
	    }
	    iterator.advance();
	}
	String msg = "missing outgoing link to node[" + toNode
	    + "] from node[" + fromNode + "]";
	fail(msg);
    }

    /**
     * Checks that the to-node has a link in its incoming links list
     * from the to-node.
     */
    private void checkNodeHasIncomingLink(Graph graph,
					  int fromNode, int toNode)
	throws TestFailedException
    {
	LinkIterator iterator = graph.getNode(toNode).getIncomingLinks();
	while (!iterator.atEnd())
	{
	    if (iterator.getSource() == fromNode)
	    {
		println("incoming: " + toNode + " <= " + fromNode);
		return;
	    }
	    iterator.advance();
	}
	String msg = "missing incoming link from node[" + fromNode
	    + "] to node[" + toNode + "]";
	fail(msg);
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the graph contains the given links, using Graph.getLinks().
     */
    private void checkLinkData(Graph graph, int numNodes, int numLinks,
			       int[] sources, int[] destinations)
	throws TestFailedException
    {
	{
	    println("Testing Graph.getLinks()...");
	    int numSeen = 0;
	    BitSet seenMap = new BitSet(numLinks);
	    LinkIterator iterator = graph.getLinks();
	    while (!iterator.atEnd())
	    {
		checkLink(iterator, numNodes, numLinks, sources, destinations);

		int id = iterator.getObjectID();
		if (seenMap.get(id))
		{
		    String msg = "link [" + id + "] repeated in list";
		    fail(msg);
		}
		seenMap.set(id);

		++numSeen;
		iterator.advance();
	    }

	    verifyEqual("# populated links", numSeen, numLinks);
	}

	println("Testing Graph.getLink(int)...");
	for (int i = 0; i < numLinks; i++)
	{
	    LinkIterator iterator = graph.getLink(i);
	    checkLink(iterator, numNodes, numLinks, sources, destinations);

	    verify(false, "getLink().atEnd() == false", !iterator.atEnd());
	    iterator.advance();
	    verify(false, "getLink().atEnd() == true", iterator.atEnd());
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the given link contains valid data.
     */
    private void checkLink(LinkIterator iterator, int numNodes, int numLinks,
			   int[] sources, int[] destinations)
	throws TestFailedException
    {
	int id = iterator.getObjectID();
	int source = iterator.getSource();
	int destination = iterator.getDestination();

	validateLinkID(numLinks, id);
	validateNodeID(numNodes, source);
	validateNodeID(numNodes, destination);

	verifyEqual(false, "getObjectType()", iterator.getObjectType(),
		    ObjectType.LINK);

	verifyEqual("link source", source, sources[id]);
	verifyEqual("link destination", destination, destinations[id]);
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of links between random pairs of nodes to the
     * graph.
     */
    private void addLinks(GraphBuilder builder, int numNodes, int numLinks,
			  int[] sources, int[] destinations)
	throws TestFailedException
    {
	for (int i = 0; i < numLinks; i++)
	{
	    int source = m_random.nextInt(numNodes);
	    int destination = m_random.nextInt(numNodes);
	    int link = builder.addLink(source, destination);
	    verifyEqual("addLink()", link, i);
	    sources[i] = source;
	    destinations[i] = destination;
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PATH TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testPathAllocation(int numNodes, int numPaths,
				    int maxNumPathLinks)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testPathAllocation(numNodes=" + numNodes + ", numPaths="
		+ numPaths + ", maxNumPathLinks=" + maxNumPathLinks + ")");
	println("===========================================================");

	Graph graph = null;
	IntBinArray paths = null;
	int numPathLinks = 0;
	{
	    Object[] data = createGraphWithNumNodesLinksPaths
		(numNodes, numPaths, maxNumPathLinks);
	    graph = (Graph)data[0];
	    paths = (IntBinArray)data[1];
	    numPathLinks = ((Integer)data[2]).intValue();
	}

	checkNumObjects(graph, numNodes, numNodes * numNodes, numPaths);
	verifyEqual("getNumPathLinks()", 
		    graph.getNumPathLinks(), numPathLinks);

	checkPathLinkData(graph, numPaths, paths);

	println("ALL PASSED!");
    }

    /**
     * Creates a full-mesh graph from the given number of nodes, and adds
     * the given number of paths, with each path including a random number
     * of links up to the given maximum.
     *
     * Returns {Graph graph, IntBinArray paths, Integer numPathLinks}.
     */
    private Object[] createGraphWithNumNodesLinksPaths
	(int numNodes, int numPaths, int maxNumPathLinks)
	throws TestFailedException
    {
	int totalNumPathLinks = 0;
	int[] numPathLinks = new int[numPaths];
	for (int i = 0; i < numPaths; i++)
	{
	    int n = m_random.nextInt(maxNumPathLinks + 1);
	    numPathLinks[i] = n;
	    totalNumPathLinks += n;
	}

	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(numNodes);
	builder.allocateLinks(numNodes * numNodes);
	builder.allocatePaths(numPaths);
	builder.allocatePathLinks(totalNumPathLinks);

	IntBinArray pathLinks =
	    addPaths(builder, numNodes, numPaths, numPathLinks);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[3];
	retval[0] = graph;
	retval[1] = pathLinks;
	retval[2] = new Integer(totalNumPathLinks);
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds links to yield a full-mesh and then adds the given number of
     * paths with the given number of random path links in each.
     */
    private IntBinArray addPaths(GraphBuilder builder, int numNodes,
				 int numPaths, int[] numPathLinks)
	throws TestFailedException
    {
	int[][] linkMatrix = new int[numNodes][numNodes];
	for (int i = 0; i < numNodes; i++)
	{
	    for (int j = 0; j < numNodes; j++)
	    {
		linkMatrix[i][j] = builder.addLink(i, j);
	    }
	}

	IntBinArray retval = new IntBinArray(true);
	for (int i = 0; i < numPaths; i++)
	{
	    {
		int index = retval.allocate();
		verifyEqual(false, "IntBinArray.allocate()", index, i);
	    }

	    int path = builder.addPath();
	    verifyEqual("addPath()", path, i);

	    ValueIterator links = retval.getValue(i);
	    int currentNode = m_random.nextInt(numNodes);
	    int numPathLinksLeft = numPathLinks[i];
	    while (numPathLinksLeft > 0)
	    {
		int nextNode = m_random.nextInt(numNodes);
		int link = linkMatrix[currentNode][nextNode];

		builder.addPathLink(link);

		links.appendValue();
		links.setIntegerValue(link);

		currentNode = nextNode;
		--numPathLinksLeft;
	    }
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that each path has exactly the links added to it.
     */
    private void checkPathLinkData(Graph graph, int numPaths,
				   IntBinArray paths)
	throws TestFailedException
    {
	{
	    println("Testing Graph.getPaths()...");
	    int numSeen = 0;
	    BitSet seenMap = new BitSet(numPaths);
	    PathIterator iterator = graph.getPaths();
	    while (!iterator.atEnd())
	    {
		checkPath(iterator, numPaths, paths);

		int id = iterator.getObjectID();
		if (seenMap.get(id))
		{
		    String msg = "path [" + id + "] repeated in list";
		    fail(msg);
		}
		seenMap.set(id);

		++numSeen;
		iterator.advance();
	    }

	    verifyEqual("# populated paths", numSeen, numPaths);
	}

	println("Testing Graph.getPath(int)...");
	for (int i = 0; i < numPaths; i++)
	{
	    PathIterator iterator = graph.getPath(i);
	    checkPath(iterator, numPaths, paths);

	    verify(false, "getLink().atEnd() == false", !iterator.atEnd());
	    iterator.advance();
	    verify(false, "getLink().atEnd() == true", iterator.atEnd());
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the given path contains valid data.
     */
    private void checkPath(PathIterator iterator, int numPaths,
			   IntBinArray paths)
	throws TestFailedException
    {
	verifyEqual(false, "getObjectType()", iterator.getObjectType(),
		    ObjectType.PATH);

	int id = iterator.getObjectID();
	validatePathID(numPaths, id);

	println("checkPath(" + id + ")...");

	LinkIterator linkIterator = iterator.getLinks();
	ValueIterator valueIterator = paths.getValue(id);

	int position = 0;
	boolean more = true;
	while (more)
	{
	    int linkAtEnd = (linkIterator.atEnd() ? 0x0 : 0x2);
	    int valueAtEnd = (valueIterator.atEnd() ? 0x0 : 0x1);
	    int state = (linkAtEnd | valueAtEnd);
	    switch (state)
	    {
	    case 0: // linkAtEnd && valueAtEnd
		more = false;
		break;

	    case 1: // !linkAtEnd && valueAtEnd
		{
		    String msg = "found extraneous links in path[" + id
			+ "] at position " + position;
		    println("ERROR: " + msg);
		    while (!linkIterator.atEnd())
		    {
			println("\t+@" + position + ": "
				+ linkIterator.getObjectID());
			linkIterator.advance();
			++position;
		    }
		    fail(msg);
		}

	    case 2: // linkAtEnd && !valueAtEnd
		{
		    String msg = "missing links in path[" + id
			+ "] at position " + position;
		    println("ERROR: " + msg);
		    while (!valueIterator.atEnd())
		    {
			println("\t-@" + position + ": "
				+ valueIterator.getIntegerValue());
			valueIterator.advance();
			++position;
		    }
		    fail(msg);
		}

	    case 3: // !linkAtEnd && !valueAtEnd
		{
		    int foundID = linkIterator.getObjectID();
		    int expectedID = valueIterator.getIntegerValue();
		    println("link@" + position + ": found: " + foundID
			    + "  expected: " + expectedID);

		    if (foundID != expectedID)
		    {
			String msg = "found link[" + foundID
			    + "] doesn't match expected link[" + expectedID
			    + "] in path[" + id + "] at position " + position;
			println("ERROR: " + msg);

			println("Links, starting at point of divergence:");
			while (!linkIterator.atEnd() || !valueIterator.atEnd())
			{
			    print("\t@" + position + ": ");

			    if (linkIterator.atEnd())
			    {
				print("found: ---");
			    }
			    else
			    {
				int link = linkIterator.getObjectID();
				print("found: " + link);
				linkIterator.advance();
			    }

			    if (valueIterator.atEnd())
			    {
				println("  expected: ---");
			    }
			    else
			    {
				int link = valueIterator.getIntegerValue();
				println("  expected: " + link);
				valueIterator.advance();
			    }

			    ++position;
			}

			fail(msg);
		    }
		}
		break;

	    default:
		throw new InternalErrorException();
	    }

	    linkIterator.advance();
	    valueIterator.advance();
	    ++position;
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // ENUMERATION TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testEnumerationAllocation(int numEnumerations,
					   int maxNumEnumerators)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testEnumerationAllocation(numEnumerations=" + numEnumerations
		+ ", maxNumEnumerators=" + maxNumEnumerators + ")");
	println("===========================================================");

	Graph graph = null;
	Enumeration[] enumerations = null;
	Enumerator[] enumerators = null;
	int numEnumerators = 0;
	{
	    Object[] data = createGraphWithEnumerations
		(numEnumerations, maxNumEnumerators);
	    graph = (Graph)data[0];
	    enumerations = (Enumeration[])data[1];
	    enumerators = (Enumerator[])data[2];
	    numEnumerators = ((Integer)data[3]).intValue();
	}

	checkEnumerationData(graph, numEnumerations, enumerations);
	checkEnumeratorData(graph, numEnumerations, numEnumerators,
			    enumerations, enumerators);
	checkEnumeratorOwnership(graph, numEnumerations, numEnumerators,
				 enumerations, enumerators);
	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all enumerations were populated properly, excluding
     * enclosed enumerators, which are checked elsewhere.
     */
    private void checkEnumerationData(Graph graph, int numEnumerations,
				      Enumeration[] enumerations)
	throws TestFailedException
    {
	{
	    println("Testing Graph.getEnumerations()...");
	    BitSet seenMap = new BitSet(numEnumerations);
	    EnumerationIterator iterator = graph.getEnumerations();
	    while (!iterator.atEnd())
	    {
		verify(false, "isMutable() == true", iterator.isMutable());

		int id = iterator.getID();
		validateEnumerationID(numEnumerations, id);

		println("[" + id + "]");
		if (seenMap.get(id))
		{
		    String msg = "enumeration id[" + id + "] repeated in list";
		    fail(msg);
		}
		seenMap.set(id);

		verifyEqual("getName()", iterator.getName(),
			    enumerations[id].name);
		iterator.advance();
	    }

	    for (int i = 0; i < numEnumerations; i++)
	    {
		if (!seenMap.get(i))
		{
		    String msg = "enumeration id[" + i + "] not seen in list";
		    fail(msg);
		}
	    }
	}

	{
	    println("Testing Graph.getEnumeration(int id)...");
	    for (int i = 0; i < numEnumerations; i++)
	    {
		println("[" + i + "]");
		EnumerationIterator iterator = graph.getEnumeration(i);
		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(),
			    enumerations[i].name);
	    }
	}

	{
	    println("Testing Graph.getEnumeration(String name)...");
	    for (int i = 0; i < numEnumerations; i++)
	    {
		String name = enumerations[i].name;
		println("[" + i + ", \"" + name + "\"]");

		EnumerationIterator iterator = graph.getEnumeration(name);
		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(), name);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all enumerators were populated properly.
     */
    private void checkEnumeratorData
	(Graph graph, int numEnumerations, int numEnumerators,
	 Enumeration[] enumerations, Enumerator[] enumerators)
	throws TestFailedException
    {
	{
	    println("Testing Graph.getEnumerators()...");

	    BitSet seenMap = new BitSet(numEnumerators);
	    ReadOnlyEnumeratorIterator iterator = graph.getEnumerators();
	    while (!iterator.atEnd())
	    {
		int id = iterator.getID();
		validateEnumeratorID(numEnumerators, id);

		println("[" + id + "]");
		if (seenMap.get(id))
		{
		    String msg = "enumerator id[" + id + "] repeated in list";
		    fail(msg);
		}
		seenMap.set(id);

		verifyEqual("getName()", iterator.getName(),
			    enumerators[id].name);
		verifyEqual("getValue()", iterator.getValue(),
			    enumerators[id].value);
		verifyEqual("getEnumeration()", iterator.getEnumeration(),
			    enumerators[id].enumeration);

		iterator.advance();
	    }

	    for (int i = 0; i < numEnumerators; i++)
	    {
		if (!seenMap.get(i))
		{
		    String msg = "enumerator id[" + i + "] not seen in list";
		    fail(msg);
		}
	    }
	}

	{
	    println("Testing Graph.getEnumerator(int id)...");
	    for (int i = 0; i < numEnumerators; i++)
	    {
		println("[" + i + "]");
		ReadOnlyEnumeratorIterator iterator = graph.getEnumerator(i);
		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(),
			    enumerators[i].name);
		verifyEqual("getValue()", iterator.getValue(),
			    enumerators[i].value);
		verifyEqual("getEnumeration()", iterator.getEnumeration(),
			    enumerators[i].enumeration);
	    }
	}

	{
	    println("Testing Graph.getEnumerator(String enumeration, "
		    + "String enumerator)...");
	    for (int i = 0; i < numEnumerations; i++)
	    {
		String enumerationName = enumerations[i].name;
		println("[" + i + ", \"" + enumerationName + "\"]");

		Enumerator enumerator = enumerations[i].enumerators;
		while (enumerator != null)
		{
		    println("[" + i + ":" + enumerator.id + "]");
		    ReadOnlyEnumeratorIterator iterator =
			graph.getEnumerator(enumerationName, enumerator.name);
		    verify(false, "iterator.atEnd() == false",
			   !iterator.atEnd());
		    verifyEqual("getID()", iterator.getID(), enumerator.id);
		    verifyEqual("getName()", iterator.getName(),
				enumerator.name);
		    verifyEqual("getValue()", iterator.getValue(),
				enumerator.value);
		    verifyEqual("getEnumeration()", iterator.getEnumeration(),
				enumerator.enumeration);

		    enumerator = enumerator.next;
		}
	    }
	}

	{
	    println("Testing Graph.resolveEnumerator(String enumeration, "
		    + "String enumerator)...");
	    for (int i = 0; i < numEnumerations; i++)
	    {
		String enumerationName = enumerations[i].name;
		println("[" + i + ", \"" + enumerationName + "\"]");

		Enumerator enumerator = enumerations[i].enumerators;
		while (enumerator != null)
		{
		    println("[" + i + ":" + enumerator.id + "]");
		    int id = graph.resolveEnumerator(enumerationName,
						     enumerator.name);
		    verifyEqual("resolveEnumerator()", id, enumerator.id);

		    enumerator = enumerator.next;
		}
	    }
	}

	{
	    println("Testing Graph.evaluateEnumerator(int enumerator)...");
	    for (int i = 0; i < numEnumerators; i++)
	    {
		println("[" + i + "]");
		int value = graph.evaluateEnumerator(i);
		verifyEqual("evaluateEnumerator()", value,
			    enumerators[i].value);
	    }
	}

	{
	    println("Testing Graph.evaluateEnumerator(String enumeration, "
		    + "String enumerator)...");
	    for (int i = 0; i < numEnumerations; i++)
	    {
		String enumerationName = enumerations[i].name;
		println("[" + i + ", \"" + enumerationName + "\"]");

		Enumerator enumerator = enumerations[i].enumerators;
		while (enumerator != null)
		{
		    println("[" + i + ":" + enumerator.id + "]");
		    int value = graph.evaluateEnumerator(enumerationName,
							 enumerator.name);
		    verifyEqual("evaluateEnumerator()", value,
				enumerator.value);

		    enumerator = enumerator.next;
		}
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that enumerations contain exactly the enumerators added to them.
     */
    private void checkEnumeratorOwnership
	(Graph graph, int numEnumerations, int numEnumerators,
	 Enumeration[] enumerations, Enumerator[] enumerators)
	throws TestFailedException
    {
	println("Testing enumerator ownership...");

	for (int i = 0; i < numEnumerators; i++)
	{
	    enumerators[i].seen = false;
	}

	for (int i = 0; i < numEnumerations; i++)
	{
	    println("[" + i + ", \"" + enumerations[i].name + "\"]");

	    EnumeratorIterator iterator =
		graph.getEnumeration(i).getEnumerators();
	    while (!iterator.atEnd())
	    {
		verifyEqual("getEnumeration()", iterator.getEnumeration(), i);

		int id = iterator.getID();
		verify("enumerators[" + id + "].seen = false",
		       !enumerators[id].seen);
		enumerators[id].seen = true;

		iterator.advance();
	    }
	}

	for (int i = 0; i < numEnumerators; i++)
	{
	    if (!enumerators[i].seen)
	    {
		String msg = "enumerator[id=" + i + ", name=\""
		    + enumerators[i].name + "\"] of enumeration[" +
		    enumerators[i].enumeration + "] not seen in list";
		fail(msg);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of enumerations, with each containing at most
     * the given number of enumerators, to the graph.
     *
     * Returns {Graph, Enumeration[], Enumerator[], Integer numEnumerators}.
     */
    private Object[] createGraphWithEnumerations(int numEnumerations,
						 int maxNumEnumerators)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	Object[] addRetval =
	    addEnumerations(builder, numEnumerations, maxNumEnumerators);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[4];
	retval[0] = graph;
	retval[1] = addRetval[0];
	retval[2] = addRetval[1];
	retval[3] = addRetval[2];
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of enumerations to the graph.
     *
     * Returns {Enumeration[] enumerations, Enumerator[] enumerators,
     * Integer numEnumerators}.
     */
    private Object[] addEnumerations(GraphBuilder builder, int numEnumerations,
				     int maxNumEnumerators)
	throws TestFailedException
    {
	Enumeration[] enumerations = new Enumeration[numEnumerations];
	GrowableObjectArray enumerators = new GrowableObjectArray();
	int totalNumEnumerators = 0;

	for (int i = 0; i < numEnumerations; i++)
	{
	    Enumeration enumeration =
		addEnumeration(builder, 0, maxNumEnumerators);

	    verifyEqual("enumeration ID", enumeration.id, i);
	    enumerations[i] = enumeration;

	    Enumerator enumerator = enumeration.enumerators;
	    while (enumerator != null)
	    {
		verifyEqual("enumerator ID", enumerator.id,
			    totalNumEnumerators);
		++totalNumEnumerators;
		enumerators.append(enumerator);

		enumerator = enumerator.next;
	    }
	}

	Object[] retval = new Object[3];
	retval[0] = enumerations;
	retval[1] = deriveEnumeratorArray(enumerators);
	retval[2] = new Integer(totalNumEnumerators);
	return retval;
    }

    /**
     * Adds an enumeration with a random number of enumerators, between
     * minNumEnumerators and maxNumEnumerators, inclusive, to the graph.
     *
     * The caller should check that the ID of the added enumeration and
     * of the enclosed enumerators match expectations.
     */
    private Enumeration addEnumeration(GraphBuilder builder,
				       int minNumEnumerators,
				       int maxNumEnumerators)
	throws TestFailedException
    {
	String enumerationName = m_nameGenerator.generate();
	EnumerationCreator creator = null;
	try
	{
	    creator = builder.addEnumeration(enumerationName);
	}
	catch (DuplicateObjectException e)
	{
	    e.printStackTrace();
	    String msg = "addEnumeration(\"" + enumerationName
		+ "\") threw DuplicateObjectException";
	    fail(msg);
	}

	Enumeration retval =
	    new Enumeration(creator.getEnumerationID(), enumerationName);

	int numEnumerators = minNumEnumerators
	    + m_random.nextInt(maxNumEnumerators - minNumEnumerators + 1);
	for (int i = 0; i < numEnumerators; i++)
	{
	    String name = m_nameGenerator.generate();
	    int value = m_random.nextInt();
	    int id = -1;
	    try
	    {
		id = creator.addEnumerator(name, value);
	    }
	    catch (DuplicateObjectException e)
	    {
		e.printStackTrace();
		String msg = "addEnumerator(\"" + name
		    + "\") threw DuplicateObjectException";
		fail(msg);
	    }

	    retval.addEnumerator(id, name, value);
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Returns an {Enumerator[]} containing the data in {array}.
     */
    private Enumerator[] deriveEnumeratorArray(GrowableObjectArray array)
    {
	int n = array.getNumAllocated();
	Enumerator[] retval = new Enumerator[n];
	for (int i = 0; i < n; i++)
	{
	    retval[i] = (Enumerator)array.getValue(i);
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // ATTRIBUTE DEFINITION TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testAttributeDefinitionAllocation(int numAttributes,
						   int numEnumerations)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testAttributeDefinitionAllocation(numAttributes="
		+ numAttributes + ", numEnumerations=" + numEnumerations +")");
	println("===========================================================");

	Graph graph = null;
	AttributeDefinition[] attributes = null;
	{
	    Object[] data = createGraphWithAttributeDefinitions
		(numAttributes, numEnumerations);
	    graph = (Graph)data[0];
	    attributes = (AttributeDefinition[])data[1];
	}

	checkAttributeDefinitionData(graph, numAttributes, numEnumerations,
				     attributes);
	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all attributes were populated properly, excluding
     * attribute values, which are checked elsewhere.
     */
    private void checkAttributeDefinitionData
	(Graph graph, int numAttributes, int numEnumerations,
	 AttributeDefinition[] attributes)
	throws TestFailedException
    {
	{
	    println("Testing Graph.getAttributeDefinitions()...");
	    BitSet seenMap = new BitSet(numAttributes);
	    AttributeDefinitionIterator iterator =
		graph.getAttributeDefinitions();
	    while (!iterator.atEnd())
	    {
		int id = iterator.getID();
		validateAttributeID(numAttributes, id);

		println("[" + id + "]");
		if (seenMap.get(id))
		{
		    String msg = "attribute id[" + id + "] repeated in list";
		    fail(msg);
		}
		seenMap.set(id);

		verifyEqual("getName()", iterator.getName(),
			    attributes[id].name);
		verifyEqual("getType()", iterator.getType(),
			    attributes[id].type);
		verifyEqual("getEnumeration()", iterator.getEnumeration(),
			    attributes[id].enumeration);
		if (false) {
		verifyEqual("getDefault()", iterator.getDefault(),
			    attributes[id].expr); }
		verifyEqual("isMutable()", iterator.isMutable(),
			    attributes[id].isMutable);

		iterator.advance();
	    }

	    for (int i = 0; i < numAttributes; i++)
	    {
		if (!seenMap.get(i))
		{
		    String msg = "attribute id[" + i + "] not seen in list";
		    fail(msg);
		}
	    }
	}

	{
	    println("Testing Graph.getAttributeDefinition(int id)...");
	    for (int i = 0; i < numAttributes; i++)
	    {
		println("[" + i + "]");
		AttributeDefinitionIterator iterator =
		    graph.getAttributeDefinition(i);
		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(),
			    attributes[i].name);
		verifyEqual("getType()", iterator.getType(),
			    attributes[i].type);
		verifyEqual("getEnumeration()", iterator.getEnumeration(),
			    attributes[i].enumeration);
		if (false) {
		verifyEqual("getDefault()", iterator.getDefault(),
			    attributes[i].expr); }
		verifyEqual("isMutable()", iterator.isMutable(),
			    attributes[i].isMutable);
	    }
	}

	{
	    println("Testing Graph.getAttributeDefinition(String name)...");
	    for (int i = 0; i < numAttributes; i++)
	    {
		String name = attributes[i].name;
		println("[" + i + ", \"" + name + "\"]");

		AttributeDefinitionIterator iterator =
		    graph.getAttributeDefinition(name);
		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(),
			    attributes[i].name);
		verifyEqual("getType()", iterator.getType(),
			    attributes[i].type);
		verifyEqual("getEnumeration()", iterator.getEnumeration(),
			    attributes[i].enumeration);
		if (false) {
		verifyEqual("getDefault()", iterator.getDefault(),
			    attributes[i].expr); }
		verifyEqual("isMutable()", iterator.isMutable(),
			    attributes[i].isMutable);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of attribute definitions to the graph.
     *
     * Returns {Graph, AttributeDefinition[]}.
     */
    private Object[] createGraphWithAttributeDefinitions
	(int numAttributes, int numEnumerations)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	for (int i = 0; i < numEnumerations; i++)
	{
	    String enumerationName = m_nameGenerator.generate();
	    try
	    {
		EnumerationCreator creator =
		    builder.addEnumeration(enumerationName);
		verifyEqual("getEnumerationID()",
			    creator.getEnumerationID(), i);
	    }
	    catch (DuplicateObjectException e)
	    {
		e.printStackTrace();
		String msg = "addEnumeration(\"" + enumerationName
		    + "\") threw DuplicateObjectException";
		fail(msg);
	    }
	}

	AttributeDefinition[] attributes =
	    addAttributeDefinitions(builder, numAttributes, numEnumerations);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[2];
	retval[0] = graph;
	retval[1] = attributes;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of attribute definitions, with each having
     * a random type, to the graph.
     */
    private AttributeDefinition[] addAttributeDefinitions
	(GraphBuilder builder, int numAttributes, int numEnumerations)
	throws TestFailedException
    {
	AttributeDefinition[] retval = new AttributeDefinition[numAttributes];

	for (int i = 0; i < numAttributes; i++)
	{
	    m_typeGenerator.generateAny(numEnumerations);
	    ValueType type = m_typeGenerator.getType();
	    int enumeration = m_typeGenerator.getEnumeration();
	    boolean isMutable = m_random.nextBoolean();
	    String name = m_nameGenerator.generate();
	    int id = -1;

	    try
	    {
		if (isMutable)
		{
		    id = builder.addMutableAttributeDefinition
			(name, type, enumeration, null, true, true, true);
		}
		else
		{
		    id = builder.addAttributeDefinition
			(name, type, enumeration, null);
		}
	    }
	    catch (DuplicateObjectException e)
	    {
		e.printStackTrace();
		String msg = "addAttributeDefinition(\"" + name
		    + "\") threw DuplicateObjectException";
		fail(msg);
	    }

	    verifyEqual("addAttributeDefinition()", id, i);
	    retval[i] = new AttributeDefinition
		(id, name, type, enumeration, null, isMutable);
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // MUTABLE ATTRIBUTE VALUE TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testMutableAttributeValueAllocation
	(int numNodes, int numLinks, int numPaths, int numEnumerators,
	 int minNumListValues, int maxNumListValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testMutableAttributeValueAllocation(numNodes=" + numNodes
		+ ", numLinks=" + numLinks + ", numPaths=" + numPaths
		+ ", numEnumerators=" + numEnumerators
		+ ", minNumListValues=" + minNumListValues
		+ ", maxNumListValues=" + maxNumListValues + ")");
	println("===========================================================");

	Graph graph = null;
	AttributeDefinition[] attributes = null;
	{
	    Object[] data = createGraphWithMutableAttributeValues
		(numNodes, numLinks, numPaths, numEnumerators,
		 minNumListValues, maxNumListValues);
	    graph = (Graph)data[0];
	    attributes = (AttributeDefinition[])data[1];
	}

	checkAttributeValuesByAttribute(graph, attributes);
	checkAttributeValuesByObject
	    (graph, numNodes, numLinks, numPaths, attributes);
	checkAttributeValuesByGraph
	    (graph, numNodes, numLinks, numPaths, attributes);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with a mutable attribute definition for each possible
     * attribute type, and populates those attributes.
     *
     * Returns {Graph, AttributeDefinition[]}.
     */
    private Object[] createGraphWithMutableAttributeValues
	(int numNodes, int numLinks, int numPaths, int numEnumerators,
	 int minNumListValues, int maxNumListValues)
	throws TestFailedException
    {
	if (numLinks > 0 && numNodes == 0)
	{
	    throw new IllegalArgumentException("need nodes for links");
	}

	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(numNodes);
	builder.allocateLinks(numLinks);
	builder.allocatePaths(numPaths);
	builder.allocatePathLinks(0);

	for (int i = 0; i < numLinks; i++)
	{
	    int id = builder.addLink(0, 0);
	    verifyEqual("addLink()", id, i);
	}

	for (int i = 0; i < numPaths; i++)
	{
	    int id = builder.addPath();
	    verifyEqual("addPath()", id, i);
	}

	Enumeration enumeration =
	    addEnumeration(builder, numEnumerators, numEnumerators);

	verifyEqual("enumeration ID", enumeration.id, 0);

	AttributeDefinition[] attributes = addMutableAttributeDefinitions
	    (builder, numNodes, numLinks, numPaths, enumeration,
	     minNumListValues, maxNumListValues);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[2];
	retval[0] = graph;
	retval[1] = attributes;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds a mutable attribute definition for each possible value type,
     * with each attribute containing random values for each object type,
     * to the graph.
     */
    private AttributeDefinition[] addMutableAttributeDefinitions
	(GraphBuilder builder, int numNodes, int numLinks, int numPaths,
	 Enumeration enumeration, int minNumListValues, int maxNumListValues)
	throws TestFailedException
    {
	int numTypes = m_typeGenerator.getNumTypes();
	AttributeDefinition[] retval = new AttributeDefinition[numTypes];
	for (int i = 0; i < numTypes; i++)
	{
	    ValueType type = m_typeGenerator.getTypeByNumber(i);
	    int enumerationID =
		(type.isEnumerationType() ? enumeration.id : -1);
	    String name = m_nameGenerator.generate();
	    int id = -1;

	    try
	    {
		id = builder.addMutableAttributeDefinition
		    (name, type, enumerationID, null, true, true, true);
	    }
	    catch (DuplicateObjectException e)
	    {
		e.printStackTrace();
		String msg = "addAttributeDefinition(\"" + name
		    + "\") threw DuplicateObjectException";
		fail(msg);
	    }

	    verifyEqual("addAttributeDefinition()", id, i);
	    retval[i] = new AttributeDefinition
		(id, name, type, enumerationID, null, true);

	    retval[i].nodeValues = addAttributeValues
		(builder, ObjectType.NODE, numNodes, numNodes,
		 minNumListValues, maxNumListValues, type, enumeration);

	    retval[i].linkValues = addAttributeValues
		(builder, ObjectType.LINK, numLinks, numLinks,
		 minNumListValues, maxNumListValues, type, enumeration);

	    retval[i].pathValues = addAttributeValues
		(builder, ObjectType.PATH, numPaths, numPaths,
		 minNumListValues, maxNumListValues, type, enumeration);
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // IMMUTABLE ATTRIBUTE VALUE TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testImmutableAttributeValueAllocation
	(int numNodes, int numLinks, int numPaths, int numEnumerators,
	 int minNumListValues, int maxNumListValues, float[] occupancies)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testImmutableAttributeValueAllocation(numNodes=" + numNodes
		+ ", numLinks=" + numLinks + ", numPaths=" + numPaths
		+ ", numEnumerators=" + numEnumerators
		+ ", minNumListValues=" + minNumListValues
		+ ", maxNumListValues=" + maxNumListValues + ")");
	println("===========================================================");

	Graph graph = null;
	AttributeDefinition[] attributes = null;
	{
	    Object[] data = createGraphWithImmutableAttributeValues
		(numNodes, numLinks, numPaths, numEnumerators,
		 minNumListValues, maxNumListValues, occupancies);
	    graph = (Graph)data[0];
	    attributes = (AttributeDefinition[])data[1];
	}

	if (false)
	{
	    println("-------------------------------------------------------");
	    writeGraph(graph, true, false);
	    println("-------------------------------------------------------");
	}

	checkAttributeValuesByAttribute(graph, attributes);
	checkAttributeValuesByObject
	    (graph, numNodes, numLinks, numPaths, attributes);
	checkAttributeValuesByGraph
	    (graph, numNodes, numLinks, numPaths, attributes);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with an immutable attribute definition for each possible
     * attribute type and for a few selected occupancies, and populates those
     * attributes.
     *
     * Returns {Graph, AttributeDefinition[]}.
     */
    private Object[] createGraphWithImmutableAttributeValues
	(int numNodes, int numLinks, int numPaths, int numEnumerators,
	 int minNumListValues, int maxNumListValues, float[] occupancies)
	throws TestFailedException
    {
	if (numLinks > 0 && numNodes == 0)
	{
	    throw new IllegalArgumentException("need nodes for links");
	}

	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(numNodes);
	builder.allocateLinks(numLinks);
	builder.allocatePaths(numPaths);
	builder.allocatePathLinks(0);

	for (int i = 0; i < numLinks; i++)
	{
	    int id = builder.addLink(0, 0);
	    verifyEqual("addLink()", id, i);
	}

	for (int i = 0; i < numPaths; i++)
	{
	    int id = builder.addPath();
	    verifyEqual("addPath()", id, i);
	}

	Enumeration enumeration =
	    addEnumeration(builder, numEnumerators, numEnumerators);

	verifyEqual("enumeration ID", enumeration.id, 0);

	AttributeDefinition[] attributes = addImmutableAttributeDefinitions
	    (builder, numNodes, numLinks, numPaths, enumeration,
	     minNumListValues, maxNumListValues, occupancies);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[2];
	retval[0] = graph;
	retval[1] = attributes;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds an immutable attribute definition for each possible value type,
     * with each attribute containing random values for each object type,
     * to the graph.
     */
    private AttributeDefinition[] addImmutableAttributeDefinitions
	(GraphBuilder builder, int numNodes, int numLinks, int numPaths,
	 Enumeration enumeration, int minNumListValues, int maxNumListValues,
	 float[] occupancies)
	throws TestFailedException
    {
	int numOccupancies = occupancies.length;
	int[] nodeOccupancies = new int[numOccupancies];
	int[] linkOccupancies = new int[numOccupancies];
	int[] pathOccupancies = new int[numOccupancies];
	generateOccupancies(numNodes, numLinks, numPaths,
			    nodeOccupancies, linkOccupancies, pathOccupancies,
			    occupancies);

	int numTypes = m_typeGenerator.getNumTypes();
	int numAttributes = numOccupancies * numTypes;
	AttributeDefinition[] retval = new AttributeDefinition[numAttributes];
	int currentAttribute = 0;
	for (int i = 0; i < numTypes; i++)
	{
	    ValueType type = m_typeGenerator.getTypeByNumber(i);
	    int enumerationID =
		(type.isEnumerationType() ? enumeration.id : -1);

	    println("[" + type.getName() + "]");

	    for (int j = 0; j < numOccupancies; j++)
	    {
		println("[occupancy: " + (j + 1) + "/" + numOccupancies
			+ " (" + occupancies[j] + ")]");

		String name = m_nameGenerator.generate();
		int id = -1;

		println("[attribute name: " + name + "]");

		try
		{
		    id = builder.addAttributeDefinition
			(name, type, enumerationID, null);
		}
		catch (DuplicateObjectException e)
		{
		    e.printStackTrace();
		    String msg = "addAttributeDefinition(\"" + name
			+ "\") threw DuplicateObjectException";
		    fail(msg);
		}

		verifyEqual("addAttributeDefinition()", id, currentAttribute);
		retval[currentAttribute] = new AttributeDefinition
		    (id, name, type, enumerationID, null, false);

		println("occupancies:"
			+ " node=" + nodeOccupancies[j]	+ "/" + numNodes
			+ " link=" + linkOccupancies[j] + "/" + numLinks
			+ " path=" + pathOccupancies[j] + "/" + numPaths);

		retval[currentAttribute].nodeValues = addAttributeValues
		    (builder, ObjectType.NODE, numNodes, nodeOccupancies[j],
		     minNumListValues, maxNumListValues, type, enumeration);

		retval[currentAttribute].linkValues = addAttributeValues
		    (builder, ObjectType.LINK, numLinks, linkOccupancies[j],
		     minNumListValues, maxNumListValues, type, enumeration);

		retval[currentAttribute].pathValues = addAttributeValues
		    (builder, ObjectType.PATH, numPaths, pathOccupancies[j],
		     minNumListValues, maxNumListValues, type, enumeration);

		++currentAttribute;
	    }
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Fills arrays specifying the wanted number of attribute values for
     * each object type, as determined by an array specifying the required
     * occupancies in percentage (0.0 to 1.0) of the total number of objects
     * of each type.
     */
    private void generateOccupancies
	(int numNodes, int numLinks, int numPaths,
	 int[] nodeOccupancies, int[] linkOccupancies, int[] pathOccupancies,
	 float[] occupancies)
    {
	for (int i = 0; i < occupancies.length; i++)
	{
	    nodeOccupancies[i] = (int)(numNodes * occupancies[i]);
	    linkOccupancies[i] = (int)(numLinks * occupancies[i]);
	    pathOccupancies[i] = (int)(numPaths * occupancies[i]);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // ATTRIBUTE VALUE TESTING UTILITIES
    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all attribute values were populated properly,
     * as determined by iterating over the attribute definitions
     * to find the attribute values.
     */
    private void checkAttributeValuesByAttribute
	(Graph graph, AttributeDefinition[] attributes)
	throws TestFailedException
    {
	println("Checking attribute values by attribute...");
	int numAttributes = attributes.length;

	BitSet seenMap = new BitSet(numAttributes);
	AttributeDefinitionIterator iterator =
	    graph.getAttributeDefinitions();
	while (!iterator.atEnd())
	{
	    int id = iterator.getID();
	    validateAttributeID(numAttributes, id);

	    println("[" + id + "]");
	    if (seenMap.get(id))
	    {
		String msg = "attribute[" + id + "] repeated in list";
		fail(msg);
	    }
	    seenMap.set(id);

	    println("\t--- node values ---");
	    attributes[id].nodeValues.checkAttributeValues
		(iterator.getNodeAttributes());

	    println("\t--- link values ---");
	    attributes[id].linkValues.checkAttributeValues
		(iterator.getLinkAttributes());

	    println("\t--- path values ---");
	    attributes[id].pathValues.checkAttributeValues
		(iterator.getPathAttributes());

	    iterator.advance();
	}

	for (int i = 0; i < numAttributes; i++)
	{
	    if (!seenMap.get(i))
	    {
		String msg = "attribute[" + i + "] not seen in list";
		fail(msg);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all attribute values were populated properly,
     * as determined by iterating over the objects to find the
     * attribute values.
     */
    private void checkAttributeValuesByObject
	(Graph graph, int numNodes, int numLinks, int numPaths,
	 AttributeDefinition[] attributes)
	throws TestFailedException
    {
	println("Checking attribute values by object...");

	IntBinArray nodeAttributes = createIntBinArray(numNodes, false);
	IntBinArray linkAttributes = createIntBinArray(numLinks, false);
	IntBinArray pathAttributes = createIntBinArray(numPaths, false);
	extractAttributesMap
	    (attributes, nodeAttributes, linkAttributes, pathAttributes);

	for (int i = 0; i < numNodes; i++)
	{
	    println("[node " + i + "]");
	    AttributesByObjectIterator iterator =
		graph.getNode(i).getAttributes();
	    checkAttributeValuesBySingleObject(ObjectType.NODE, i, attributes,
					       iterator, nodeAttributes);
	}

	for (int i = 0; i < numLinks; i++)
	{
	    println("[link " + i + "]");
	    AttributesByObjectIterator iterator =
		graph.getLink(i).getAttributes();
	    checkAttributeValuesBySingleObject(ObjectType.LINK, i, attributes,
					       iterator, linkAttributes);
	}

	for (int i = 0; i < numPaths; i++)
	{
	    println("[path " + i + "]");
	    AttributesByObjectIterator iterator =
		graph.getPath(i).getAttributes();
	    checkAttributeValuesBySingleObject(ObjectType.PATH, i, attributes,
					       iterator, pathAttributes);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all attribute values of the given object were populated
     * properly, as determined by iterating over the attribute values via the
     * object.
     */
    private void checkAttributeValuesBySingleObject
	(ObjectType type, int object, AttributeDefinition[] attributes,
	 AttributesByObjectIterator iterator, IntBinArray objectAttributes)
	throws TestFailedException
    {
	int numAttributes = attributes.length;
	BitSet attributesMap = new BitSet(numAttributes);

	{
	    ValueIterator valueIterator = objectAttributes.getValue(object);
	    while (!valueIterator.atEnd())
	    {
		int attribute = valueIterator.getIntegerValue();
		if (attributesMap.get(attribute))
		{
		    String msg = "attribute[" + attribute
			+ "] repeated in IntBinArray list of object["
			+ object + "]";
		    throw new InternalErrorException(msg);
		}
		attributesMap.set(attribute);
		valueIterator.advance();
	    }
	}

	BitSet seenMap = new BitSet(numAttributes);
	while (!iterator.atEnd())
	{
	    int attribute = iterator.getAttributeID();
	    validateAttributeID(numAttributes, attribute);

	    if (seenMap.get(attribute))
	    {
		String msg = "attribute[" + attribute + "] repeated in list";
		fail(msg);
	    }
	    seenMap.set(attribute);

	    if (!attributesMap.get(attribute))
	    {
		String msg = type.getName() + "[" + object
		    + "] lists an attribute[" + attribute
		    + "] for which it was not given any values";
	    }
	    attributesMap.clear(attribute);

	    AttributeValues attributeValues =
		attributes[attribute].getAttributeValues(type);
	    attributeValues.checkObjectValues(object,
					      iterator.getAttributeValues());

	    iterator.advance();
	}

	for (int i = 0; i < numAttributes; i++)
	{
	    if (attributesMap.get(i))
	    {
		String msg = "attribute[" + i + "] not seen in list";
		fail(msg);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all attribute values were populated properly,
     * as determined by accessing the attribute values directly through
     * the methods in Graph.
     */
    private void checkAttributeValuesByGraph
	(Graph graph, int numNodes, int numLinks, int numPaths,
	 AttributeDefinition[] attributes)
	throws TestFailedException
    {
	println("Checking attribute values by direct access in graph...");

	println("Testing list Graph.getObjectAttribute()...");
	int numAttributes = attributes.length;
	for (int i = 0; i < numAttributes; i++)
	{
	    println("[attribute " + i + "]");
	    checkAttributeValuesByGraphForAttribute
		(graph, ObjectType.NODE, numNodes, attributes[i], i);
	    checkAttributeValuesByGraphForAttribute
		(graph, ObjectType.LINK, numLinks, attributes[i], i);
	    checkAttributeValuesByGraphForAttribute
		(graph, ObjectType.PATH, numPaths, attributes[i], i);
	}

	println("Testing scalar Graph.get_X_Attribute()...");
	for (int i = 0; i < numAttributes; i++)
	{
	    println("[attribute " + i + "]");
	    if (attributes[i].type.isBaseType())
	    {
		checkScalarAttributeValuesByGraphForAttribute
		    (graph, ObjectType.NODE, numNodes, attributes[i], i);
		checkScalarAttributeValuesByGraphForAttribute
		    (graph, ObjectType.LINK, numLinks, attributes[i], i);
		checkScalarAttributeValuesByGraphForAttribute
		    (graph, ObjectType.PATH, numPaths, attributes[i], i);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all attribute values were populated properly for the
     * objects of the given type that have values for the given attribute,
     * as determined by accessing the attribute values directly through
     * the methods in Graph.
     */
    private void checkAttributeValuesByGraphForAttribute
	(Graph graph, ObjectType type, int numObjects,
	 AttributeDefinition attributeDefinition, int attribute)
	throws TestFailedException
    {
	println("[" + type.getName() + "]");
	AttributeValues attributeValues =
	    attributeDefinition.getAttributeValues(type);

	BitSet allocationMap = attributeValues.getAllocationMap();
	for (int i = 0; i < numObjects; i++)
	{
	    if (allocationMap.get(i))
	    {
		try
		{
		    ValueIterator iterator =
			graph.getObjectAttribute(type, i, attribute);
		    attributeValues.checkObjectValues(i, iterator);
		}
		catch (AttributeUnavailableException e)
		{
		    String msg = type.getName() + "[" + i
			+ "] is missing values for attribute[" + attribute
			+ "]: " + e.toString();
		    fail(msg);
		}
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all scalar attribute values were populated properly for
     * the objects of the given type that have values for the given attribute,
     * as determined by accessing the attribute values directly through
     * the methods in Graph.
     */
    private void checkScalarAttributeValuesByGraphForAttribute
	(Graph graph, ObjectType type, int numObjects,
	 AttributeDefinition attributeDefinition, int attribute)
	throws TestFailedException
    {
	println("[" + type.getName() + "]");
	ValueType valueType = attributeDefinition.type;
	AttributeValues attributeValues =
	    attributeDefinition.getAttributeValues(type);

	BitSet allocationMap = attributeValues.getAllocationMap();
	for (int i = 0; i < numObjects; i++)
	{
	    if (allocationMap.get(i))
	    {
		ValueIterator iterator = new AttributeValueIterator
		    (graph, type, i, valueType, attribute);
		attributeValues.checkObjectValues(i, iterator);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Finds the set of attributes for which each given node, link, or
     * path has values, and stores this information in the corresponding
     * IntBinArray object.
     */
    private void extractAttributesMap
	(AttributeDefinition[] attributes, IntBinArray nodeAttributes,
	 IntBinArray linkAttributes, IntBinArray pathAttributes)
    {
	for (int i = 0; i < attributes.length; i++)
	{
	    AttributeDefinition attributeDefinition = attributes[i];
	    int id = attributeDefinition.id;
	    {
		BitSet map = attributeDefinition.nodeValues.getAllocationMap();
		extractPartialAttributesMap(id, map, nodeAttributes);
	    }
	    {
		BitSet map = attributeDefinition.linkValues.getAllocationMap();
		extractPartialAttributesMap(id, map, linkAttributes);
	    }
	    {
		BitSet map = attributeDefinition.pathValues.getAllocationMap();
		extractPartialAttributesMap(id, map, pathAttributes);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Appends the given attribute ID to the list of every object that
     * has a value for the attribute as determined by the given
     * allocation map of the attribute.
     */
    private void extractPartialAttributesMap(int attribute,
					     BitSet allocationMap,
					     IntBinArray attributesMap)
    {
	int numObjects = attributesMap.getNumAllocated();
	for (int i = 0; i < numObjects; i++)
	{
	    if (allocationMap.get(i))
	    {
		ValueIterator iterator = attributesMap.getValue(i);
		iterator.appendValue();
		iterator.setIntegerValue(attribute);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of random values to the attribute definition
     * currently being constructed (as determined by the GraphBuilder
     * parameter).
     */
    private AttributeValues addAttributeValues
	(GraphBuilder builder, ObjectType objectType, int maxNumObjects,
	 int numObjects, int minNumListValues, int maxNumListValues,
	 ValueType type, Enumeration enumeration)
	throws TestFailedException
    {
	BitSet objects = new BitSet();
	int[] length = new int[maxNumObjects];
	{
	    int[] objectIDs = selectRandomSubset(maxNumObjects, numObjects);
	    for (int i = 0; i < numObjects; i++)
	    {
		objects.set(objectIDs[i]);

		int n = (type.isBaseType() ? 1
			 : minNumListValues + m_random.nextInt
			 (maxNumListValues - minNumListValues + 1));
		length[objectIDs[i]] = n;
	    }
	}

	print("Objects with values: ");
	printObjectsWithValues(objects, length);

	return new AttributeValues(builder, objectType, type, enumeration,
				   objects, length, maxNumObjects);
    }

    /**
     * Prints out information about allocated objects and their number of
     * attribute values, according to the given parameters.
     */
    private void printObjectsWithValues(BitSet objects, int[] length)
    {
	print("{ ");

	int numSet = 0;
	int numObjects = objects.length();
	for (int i = 0; i < numObjects; i++)
	{
	    if (objects.get(i))
	    {
		if (numSet > 0)
		{
		    System.out.print(", ");
		}
		++numSet;
		print(i);
		print("(");
		print(length[i]);
		print(")");
	    }
	}
	
	println(" }");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUALIFIER TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testQualifierAllocation
	(int numQualifierTypes, int maxNumQualifiers,
	 int maxNumQualifierAttributes, int numAttributes)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testQualifierAllocation("
		+ "numQualifierTypes=" + numQualifierTypes
		+ ", maxNumQualifiers=" + maxNumQualifiers
		+ ", maxNumQualifierAttributes=" + maxNumQualifierAttributes
		+ ", numAttributes=" + numAttributes + ")");
	println("===========================================================");

	Graph graph = null;
	AttributeDefinition[] attributes = null;
	QualifierSet qualifierSet = null;
	{
	    Object[] data = createGraphWithQualifiers
		(numQualifierTypes, maxNumQualifiers,
		 maxNumQualifierAttributes, numAttributes, 1);
	    graph = (Graph)data[0];
	    attributes = (AttributeDefinition[])data[1];
	    qualifierSet = (QualifierSet)data[2];
	}

	if (false)
	{
	    println("-------------------------------------------------------");
	    writeGraph(graph, true, false);
	    println("-------------------------------------------------------");
	}

	checkQualifierTypeData(graph, attributes, qualifierSet);
	checkQualifierData(graph, attributes, qualifierSet);
	checkQualifierAttributeResolution(graph, attributes, qualifierSet);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all qualifier types were populated properly, which is
     * verified by retrieving qualifier types and checking that they have
     * the correct set of qualifiers.
     */
    private void checkQualifierTypeData
	(Graph graph, AttributeDefinition[] attributes,
	 QualifierSet qualifierSet)
	throws TestFailedException
    {
	println("Testing Graph.getQualifierTypes()...");
	{
	    qualifierSet.clearSeenFlags();
	    QualifierTypeIterator iterator = graph.getQualifierTypes();
	    while (!iterator.atEnd())
	    {
		println("[" + iterator.getName() + "]");
		QualifierType qualifierType =
		    qualifierSet.find(iterator.getName());
		if (qualifierType == null)
		{
		    String msg = "encountered unknown qualifier type["
			+ iterator.getName() + "]";
		    fail(msg);
		}

		if (qualifierType.seen)
		{
		    String msg = "qualifier type[" + iterator.getName() 
			+ "] repeated in list";
		    fail(msg);
		}
		qualifierType.seen = true;

		checkQualifiersOfQualifierType
		    (qualifierType, iterator.getQualifiers());

		iterator.advance();
	    }

	    QualifierType qualifierType = qualifierSet.qualifierTypes;
	    while (qualifierType != null)
	    {
		if (!qualifierType.seen)
		{
		    String msg = "qualifier type[" + qualifierType.name
			+ "] not seen in list";
		    fail(msg);
		}
		qualifierType = qualifierType.next;
	    }
	}

	println("Testing Graph.getQualifierType(String)...");
	{
	    QualifierType qualifierType = qualifierSet.qualifierTypes;
	    while (qualifierType != null)
	    {
		println("[" + qualifierType.name + "]");
		QualifierTypeIterator iterator =
		    graph.getQualifierType(qualifierType.name);

		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getName()", iterator.getName(),
			    qualifierType.name);

		checkQualifiersOfQualifierType
		    (qualifierType, iterator.getQualifiers());

		iterator.advance();
		verify(false, "iterator.atEnd() == true", iterator.atEnd());

		qualifierType = qualifierType.next;
	    }
	}

	println("Testing Graph.getQualifiersByType(String)...");
	{
	    qualifierSet.clearSeenFlags();
	    QualifierType qualifierType = qualifierSet.qualifierTypes;
	    while (qualifierType != null)
	    {
		println("[" + qualifierType.name + "]");
		QualifierIterator iterator =
		    graph.getQualifiersByType(qualifierType.name);

		verify(false, "iterator.atEnd() == false", !iterator.atEnd());

		checkQualifiersOfQualifierType(qualifierType, iterator);

		qualifierType = qualifierType.next;
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the given QualifierIterator yields exactly the set of
     * qualifiers (as determined by comparing names) contained in the given
     * QualifierType, although the ordering may differ.
     */
    private void checkQualifiersOfQualifierType
	(QualifierType qualifierType, QualifierIterator iterator)
	throws TestFailedException
    {
	qualifierType.clearSeenFlags();
	while (!iterator.atEnd())
	{
	    println("[qualifier=" + iterator.getName() + "]");
	    Qualifier qualifier = qualifierType.find(iterator.getName());
	    if (qualifier == null)
	    {
		String msg = "encountered unknown qualifier["
		    + iterator.getName() + "]";
		fail(msg);
	    }

	    if (qualifier.seen)
	    {
		String msg = "qualifier[" + iterator.getName() 
		    + "] repeated in list";
		fail(msg);
	    }
	    qualifier.seen = true;

	    verifyEqual(false, "getType()", iterator.getType(),
			qualifierType.name);
	    
	    iterator.advance();
	}

	Qualifier qualifier = qualifierType.qualifiers;
	while (qualifier != null)
	{
	    if (!qualifier.seen)
	    {
		String msg = "qualifier[" + qualifier.name
		    + "] not seen in list";
		fail(msg);
	    }
	    qualifier = qualifier.next;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all qualifiers were populated properly.
     */
    private void checkQualifierData
	(Graph graph, AttributeDefinition[] attributes,
	 QualifierSet qualifierSet)
	throws TestFailedException
    {
	println("Testing Graph.getQualifiers()...");
	{
	    Map qualifiersMap = createUnseenQualifiersMap(qualifierSet);

	    QualifierIterator iterator = graph.getQualifiers();
	    while (!iterator.atEnd())
	    {
		println("[type=" + iterator.getType() + ", name="
			+ iterator.getName() + "]");
		Qualifier qualifier =
		    (Qualifier)qualifiersMap.get(iterator.getName());
		if (qualifier == null)
		{
		    String msg = "encountered unknown qualifier["
			+ iterator.getName() + "] in list";
		    fail(msg);
		}

		if (qualifier.seen)
		{
		    String msg = "qualifier[" + iterator.getName() 
			+ "] repeated in list";
		    fail(msg);
		}
		qualifier.seen = true;

		verifyEqual("getType()", iterator.getType(),
			    qualifier.type);
		verifyEqual("getName()", iterator.getName(),
			    qualifier.name);
		verifyEqual("getDescription()",
			    iterator.getDescription(), qualifier.description);

		checkQualifierAttributesOfQualifier
		    (qualifier, iterator.getAttributes(), attributes);

		iterator.advance();
	    }

	    java.util.Iterator qualifierIterator =
		qualifiersMap.values().iterator();
	    while (qualifierIterator.hasNext())
	    {
		Qualifier qualifier = (Qualifier)qualifierIterator.next();
		if (!qualifier.seen)
		{
		    String msg = "qualifier[" + qualifier.name
			+ "] not seen in list";
		    fail(msg);
		}
	    }
	}

	println("Testing Graph.getQualifier(String)...");
	{
	    QualifierType qualifierType = qualifierSet.qualifierTypes;
	    while (qualifierType != null)
	    {
		println("[type=" + qualifierType.name + "]");
		Qualifier qualifier = qualifierType.qualifiers;
		while (qualifier != null)
		{
		    println("[qualifier=" + qualifier.name + "]");
		    QualifierIterator iterator =
			graph.getQualifier(qualifier.name);

		    verify(false, "iterator.atEnd() == false",
			   !iterator.atEnd());
		    verifyEqual("getType()", iterator.getType(),
				qualifierType.name);
		    verifyEqual("getName()", iterator.getName(),
				qualifier.name);
		    verifyEqual("getDescription()", iterator.getDescription(),
				qualifier.description);

		    checkQualifierAttributesOfQualifier
			(qualifier, iterator.getAttributes(), attributes);

		    qualifier = qualifier.next;
		}

		qualifierType = qualifierType.next;
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a mapping from the names of qualifiers in all qualifier types
     * to Qualifier objects.
     *
     * This also clears the seen flag of all the qualifiers.
     * Returns {String -> Qualifier}.
     */
    private Map createUnseenQualifiersMap(QualifierSet qualifierSet)
    {
	Map retval = new HashMap();

	QualifierType qualifierType = qualifierSet.qualifierTypes;
	while (qualifierType != null)
	{
	    Qualifier qualifier = qualifierType.qualifiers;
	    while (qualifier != null)
	    {
		qualifier.seen = false;
		if (retval.put(qualifier.name, qualifier) != null)
		{
		    String msg = "qualifier[" + qualifier.name
			+ "] does not have a unique name";
		    throw new InternalErrorException(msg);
		}
		qualifier = qualifier.next;
	    }
	    qualifierType = qualifierType.next;
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the qualifier attributes of the given qualifier were
     * populated properly.
     */
    private void checkQualifierAttributesOfQualifier
	(Qualifier qualifier, QualifierAttributeIterator iterator,
	 AttributeDefinition[] attributes)
	throws TestFailedException
    {
	qualifier.clearSeenFlags();
	while (!iterator.atEnd())
	{
	    println("[qualifier attribute=" + iterator.getName() + "]");
	    QualifierAttribute qualifierAttribute =
		qualifier.find(iterator.getName());
	    if (qualifierAttribute == null)
	    {
		String msg = "encountered unknown qualifier attribute["
		    + iterator.getName() + "]";
		fail(msg);
	    }

	    if (qualifierAttribute.seen)
	    {
		String msg = "qualifier attribute[" + iterator.getName() 
		    + "] repeated in list";
		fail(msg);
	    }
	    qualifierAttribute.seen = true;

	    verifyEqual("getAttributeID()", iterator.getAttributeID(),
			qualifierAttribute.attribute);
	    
	    iterator.advance();
	}

	QualifierAttribute qualifierAttribute = qualifier.qualifierAttributes;
	while (qualifierAttribute != null)
	{
	    if (!qualifierAttribute.seen)
	    {
		String msg = "qualifierAttribute[" + qualifierAttribute.alias
		    + "] not seen in list";
		fail(msg);
	    }
	    qualifierAttribute = qualifierAttribute.next;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all qualifier attributes are resolvable via Graph.
     */
    private void checkQualifierAttributeResolution
	(Graph graph, AttributeDefinition[] attributes,
	 QualifierSet qualifierSet)
	throws TestFailedException
    {
	println("Testing Graph.resolveQualifierAttribute()...");
	QualifierType qualifierType = qualifierSet.qualifierTypes;
	while (qualifierType != null)
	{
	    println("[type=" + qualifierType.name + "]");
	    Qualifier qualifier = qualifierType.qualifiers;
	    while (qualifier != null)
	    {
		println("[qualifier=" + qualifier.name + "]");
		QualifierAttribute qualifierAttribute =
		    qualifier.qualifierAttributes;
		while (qualifierAttribute != null)
		{
		    println("[qualifier attribute="
			    + qualifierAttribute.alias + "]");

		    int attribute = graph.resolveQualifierAttribute
			(qualifier.name, qualifierAttribute.alias);
		    verifyEqual("resolveQualifierAttribute()", attribute,
				qualifierAttribute.attribute);

		    qualifierAttribute = qualifierAttribute.next;
		}
		qualifier = qualifier.next;
	    }
	    qualifierType = qualifierType.next;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with the given number of qualifier types, qualifiers,
     * and qualifier attributes, in addition to a basic set of attribute
     * definitions and enumerations.
     *
     * Returns {Graph, AttributeDefinition[], QualifierSet}.
     */
    private Object[] createGraphWithQualifiers
	(int numQualifierTypes, int maxNumQualifiers,
	 int maxNumQualifierAttributes, int numAttributes, int numEnumerations)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();
	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	AttributeDefinition[] attributes = addBasicAttributeDefinitions
	    (builder, numAttributes, numEnumerations);

	QualifierSet qualifierSet = addQualifierTypes
	    (builder, numQualifierTypes, maxNumQualifiers,
	     maxNumQualifierAttributes, attributes);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[3];
	retval[0] = graph;
	retval[1] = attributes;
	retval[2] = qualifierSet;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of qualifier types, with each having up to
     * the given number of qualifiers.
     */
    private QualifierSet addQualifierTypes
	(GraphBuilder builder, int numQualifierTypes, int maxNumQualifiers,
	 int maxNumQualifierAttributes, AttributeDefinition[] attributes)
	throws TestFailedException
    {
	QualifierSet retval = new QualifierSet();
	for (int i = 0; i < numQualifierTypes; i++)
	{
	    String name = m_nameGenerator.generate();
	    println("[qualifier type " + i + ": " + name + "]");

	    QualifierType qualifierType = retval.addQualifierType(name);
	    addQualifiers(builder, qualifierType, maxNumQualifiers,
			  maxNumQualifierAttributes, attributes);
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds some random number of qualifiers, between one and the given
     * maximum, to the given qualifier type, with each qualifier having
     * up to the given maximum number of qualifier attributes.
     */
    private void addQualifiers
	(GraphBuilder builder, QualifierType qualifierType,
	 int maxNumQualifiers, int maxNumQualifierAttributes,
	 AttributeDefinition[] attributes)
	throws TestFailedException
    {
	int numQualifiers = m_random.nextInt(maxNumQualifiers) + 1;
	for (int i = 0; i < numQualifiers; i++)
	{
	    String name = m_nameGenerator.generate();
	    String description = m_nameGenerator.generate();
	    println("[qualifier " + i + ": " + name + "]");

	    Qualifier qualifier =
		qualifierType.addQualifier(name, description);

	    try
	    {
		QualifierCreator creator = builder.addQualifier
		    (qualifierType.name, name, description);
		addQualifierAttributes(builder, creator, qualifier,
				       maxNumQualifierAttributes, attributes);
	    }
	    catch (DuplicateObjectException e)
	    {
		String msg = "addQualifier() threw " + e.toString();
		fail(msg);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds some random number of qualifier attributes, up to the given
     * maximum, to the given qualifier.
     */
    private void addQualifierAttributes
	(GraphBuilder builder, QualifierCreator creator, Qualifier qualifier,
	 int maxNumQualifierAttributes, AttributeDefinition[] attributes)
	throws TestFailedException
    {
	if (maxNumQualifierAttributes > attributes.length)
	{
	    throw new IllegalArgumentException();
	}

	int numQualifierAttributes =
	    m_random.nextInt(maxNumQualifierAttributes + 1);

	int[] selected = selectRandomSubset(attributes.length,
					    numQualifierAttributes);

	for (int i = 0; i < numQualifierAttributes; i++)
	{
	    int attribute = selected[i];
	    String name = attributes[attribute].name;
	    String alias = m_nameGenerator.generate();
	    println("[qualifier attr " + i + ": attr=" + attribute
		    + ", name=" + name + ", alias=" + alias + "]");
	    try
	    {
		switch (m_random.nextInt(3))
		{
		case 0:
		    println("associateAttribute(attribute)");
		    qualifier.associateAttribute(attribute, name);
		    creator.associateAttribute(attribute);
		    break;
		case 1:
		    println("associateAttribute(attribute, alias)");
		    qualifier.associateAttribute(attribute, alias);
		    creator.associateAttribute(attribute, alias);
		    break;
		case 2:
		    println("associateAttribute(name, alias)");
		    qualifier.associateAttribute(attribute, alias);
		    creator.associateAttribute(name, alias);
		    break;
		default:
		    throw new InternalErrorException();
		}
	    }
	    catch (DuplicateObjectException e)
	    {
		String msg = "associateAttribute() threw " + e.toString();
		fail(msg);
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of enumerations (without enumerators) and
     * attribute definitions (without values) to the graph.
     */
    private AttributeDefinition[] addBasicAttributeDefinitions
	(GraphBuilder builder, int numAttributes, int numEnumerations)
	throws TestFailedException
    {
	for (int i = 0; i < numEnumerations; i++)
	{
	    String enumerationName = m_nameGenerator.generate();
	    try
	    {
		EnumerationCreator creator =
		    builder.addEnumeration(enumerationName);
		verifyEqual("getEnumerationID()",
			    creator.getEnumerationID(), i);
	    }
	    catch (DuplicateObjectException e)
	    {
		e.printStackTrace();
		String msg = "addEnumeration(\"" + enumerationName
		    + "\") threw DuplicateObjectException";
		fail(msg);
	    }
	}

	return addAttributeDefinitions(builder, numAttributes,
				       numEnumerations);
    }

    ///////////////////////////////////////////////////////////////////////
    // DISPLAY TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testDisplayAllocation
	(int numDisplays, int maxNumDisplayMappings, int numAttributes)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testDisplayAllocation(numDisplays=" + numDisplays
		+ ", maxNumDisplayMappings=" + maxNumDisplayMappings
		+ ", numAttributes=" + numAttributes + ")");
	println("===========================================================");

	Graph graph = null;
	DisplaySet displaySet = null;
	{
	    Object[] data = createGraphWithDisplays
		(numDisplays, maxNumDisplayMappings, numAttributes, 1);
	    graph = (Graph)data[0];
	    displaySet = (DisplaySet)data[1];
	}

	if (false)
	{
	    println("-------------------------------------------------------");
	    writeGraph(graph, true, false);
	    println("-------------------------------------------------------");
	}

	checkDisplayData(graph, displaySet);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all displays were populated properly.
     */
    private void checkDisplayData(Graph graph, DisplaySet displaySet)
	throws TestFailedException
    {
	int numDisplays = displaySet.displays.length;
	println("Testing Graph.getDisplays()...");
	{
	    displaySet.clearSeenFlags();
	    DisplayIterator iterator = graph.getDisplays();
	    while (!iterator.atEnd())
	    {
		println("[display=" + iterator.getName() + "]");
		int id = iterator.getID();
		if (id < 0 || id >= numDisplays)
		{
		    String msg = "display id[" + id
			+ "] must be >= 0 and < " + numDisplays;
		    fail(msg);
		}

		Display display = displaySet.displays[id];

		if (display.seen)
		{
		    String msg = "display[" + iterator.getName() 
			+ "] repeated in list";
		    fail(msg);
		}
		display.seen = true;

		verifyEqual("getName()", iterator.getName(), display.name);

		checkDisplayMappingsOfDisplay
		    (display, iterator.getDisplayMappings());

		iterator.advance();
	    }

	    for (int i = 0; i < numDisplays; i++)
	    {
		Display display = displaySet.displays[i];
		if (!display.seen)
		{
		    String msg = "display[" + display.name
			+ "] not seen in list";
		    fail(msg);
		}
	    }
	}

	println("Testing Graph.getDisplay(int)...");
	{
	    for (int i = 0; i < numDisplays; i++)
	    {
		Display display = displaySet.displays[i];
		println("[display " + i + ": " + display.name + "]");

		DisplayIterator iterator = graph.getDisplay(i);

		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(), display.name);

		checkDisplayMappingsOfDisplay
		    (display, iterator.getDisplayMappings());

		iterator.advance();
		verify(false, "iterator.atEnd() == true", iterator.atEnd());
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the display mappings of the given display were
     * populated properly.
     */
    private void checkDisplayMappingsOfDisplay
	(Display display, DisplayMappingIterator iterator)
	throws TestFailedException
    {
	display.clearSeenFlags();
	while (!iterator.atEnd())
	{
	    println("[display mapping="
		    + iterator.getDisplayCharacteristic() + "]");
	    DisplayMapping displayMapping =
		display.find(iterator.getDisplayCharacteristic());
	    if (displayMapping == null)
	    {
		String msg = "encountered unknown display mapping["
		    + iterator.getDisplayCharacteristic() + "]";
		fail(msg);
	    }

	    if (displayMapping.seen)
	    {
		String msg =
		    "display mapping[" + iterator.getDisplayCharacteristic() 
		    + "] repeated in list";
		fail(msg);
	    }
	    displayMapping.seen = true;

	    verifyEqual("getAttributeID()", iterator.getAttributeID(),
			displayMapping.attribute);
	    verifyEqual("getDisplayCharacteristic()",
			iterator.getDisplayCharacteristic(),
			displayMapping.characteristic);
	    verifyEqual("checkNodeInTarget()", iterator.checkNodeInTarget(),
			displayMapping.node);
	    verifyEqual("checkLinkInTarget()", iterator.checkLinkInTarget(),
			displayMapping.link);
	    verifyEqual("checkPathInTarget()", iterator.checkPathInTarget(),
			displayMapping.path);
	    
	    iterator.advance();
	}

	DisplayMapping displayMapping = display.displayMappings;
	while (displayMapping != null)
	{
	    if (!displayMapping.seen)
	    {
		String msg = "displayMapping[" + displayMapping.characteristic
		    + "] not seen in list";
		fail(msg);
	    }
	    displayMapping = displayMapping.next;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with the given number of displays.
     *
     * Returns {Graph, DisplaySet}.
     */
    private Object[] createGraphWithDisplays
	(int numDisplays, int maxNumDisplayMappings,
	 int numAttributes, int numEnumerations)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();

	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	AttributeDefinition[] attributes = addBasicAttributeDefinitions
	    (builder, numAttributes, numEnumerations);

	DisplaySet displaySet = addDisplays
	    (builder, numDisplays, maxNumDisplayMappings, numAttributes);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[2];
	retval[0] = graph;
	retval[1] = displaySet;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of displays, with each having up to the given
     * maximum number of display mappings.
     */
    private DisplaySet addDisplays
	(GraphBuilder builder, int numDisplays,
	 int maxNumDisplayMappings, int numAttributes)
	throws TestFailedException
    {
	DisplaySet retval = new DisplaySet(numDisplays);
	for (int i = 0; i < numDisplays; i++)
	{
	    String name = m_nameGenerator.generate();
	    println("[display " + i + ": " + name + "]");

	    Display display = retval.addDisplay(name);
	    DisplayCreator creator = builder.addDisplay(name);
	    verifyEqual("getDisplayID()", creator.getDisplayID(), i);

	    int numDisplayMappings =
		m_random.nextInt(maxNumDisplayMappings + 1);
	    for (int j = 0; j < numDisplayMappings; j++)
	    {
		String characteristic = m_nameGenerator.generate();
		println("[display mapping " + j + ": " + characteristic + "]");

		int attribute = m_random.nextInt(numAttributes);
		boolean node = m_random.nextBoolean();
		boolean link = m_random.nextBoolean();
		boolean path = m_random.nextBoolean();

		display.addDisplayMapping(characteristic, attribute,
					  node, link, path);
		try
		{
		    creator.addDisplayMapping(characteristic, attribute,
					      node, link, path);
		}
		catch (DuplicateObjectException e)
		{
		    e.printStackTrace();
		    String msg = "addDisplayMapping() threw " + e.toString();
		    fail(msg);
		}
	    }
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // FILTER TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testFilterAllocation(int numFilters)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testFilterAllocation(numFilters=" + numFilters + ")");
	println("===========================================================");

	Graph graph = null;
	Filter[] filters = null;
	{
	    Object[] data = createGraphWithFilters(numFilters);
	    graph = (Graph)data[0];
	    filters = (Filter[])data[1];
	}

	if (false)
	{
	    println("-------------------------------------------------------");
	    writeGraph(graph, true, false);
	    println("-------------------------------------------------------");
	}

	checkFilterData(graph, filters);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all filters were populated properly.
     */
    private void checkFilterData(Graph graph, Filter[] filters)
	throws TestFailedException
    {
	int numFilters = filters.length;
	println("Testing Graph.getFilters()...");
	{
	    for (int i = 0; i < numFilters; i++)
	    {
		filters[i].seen = false;
	    }

	    FilterIterator iterator = graph.getFilters();
	    while (!iterator.atEnd())
	    {
		println("[filter=" + iterator.getName() + "]");
		int id = iterator.getID();
		if (id < 0 || id >= numFilters)
		{
		    String msg = "filter id[" + id
			+ "] must be >= 0 and < " + numFilters;
		    fail(msg);
		}

		Filter filter = filters[id];

		if (filter.seen)
		{
		    String msg = "filter[" + iterator.getName() 
			+ "] repeated in list";
		    fail(msg);
		}
		filter.seen = true;

		verifyEqual("getName()", iterator.getName(), filter.name);
		verifyEqual("getExpression()", iterator.getExpression(),
			    filter.expr);

		iterator.advance();
	    }

	    for (int i = 0; i < numFilters; i++)
	    {
		Filter filter = filters[i];
		if (!filter.seen)
		{
		    String msg = "filter[" + filter.name +"] not seen in list";
		    fail(msg);
		}
	    }
	}

	println("Testing Graph.getFilter(int)...");
	{
	    for (int i = 0; i < numFilters; i++)
	    {
		Filter filter = filters[i];
		println("[filter " + i + ": " + filter.name + "]");

		FilterIterator iterator = graph.getFilter(i);

		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(), filter.name);
		verifyEqual("getExpression()", iterator.getExpression(),
			    filter.expr);

		iterator.advance();
		verify(false, "iterator.atEnd() == true", iterator.atEnd());
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with the given number of filters.
     *
     * Returns {Graph, Filter[]}.
     */
    private Object[] createGraphWithFilters(int numFilters)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();

	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	Filter[] filters = addFilters(builder, numFilters);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[2];
	retval[0] = graph;
	retval[1] = filters;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of filters.
     */
    private Filter[] addFilters(GraphBuilder builder, int numFilters)
	throws TestFailedException
    {
	Filter[] retval = new Filter[numFilters];
	for (int i = 0; i < numFilters; i++)
	{
	    String name = m_nameGenerator.generate();
	    String expr = m_nameGenerator.generate();
	    println("[filter " + i + ": " + name + "]");

	    retval[i] = new Filter(name, expr);
	    int id = builder.addFilter(name, expr);
	    verifyEqual("addFilter()", id, i);
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // SELECTOR TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testSelectorAllocation
	(int numSelectors, int maxNumSelectorMappings, int numFilters)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testSelectorAllocation(numSelectors=" + numSelectors
		+ ", maxNumSelectorMappings=" + maxNumSelectorMappings
		+ ", numFilters=" + numFilters + ")");
	println("===========================================================");

	Graph graph = null;
	SelectorSet selectorSet = null;
	{
	    Object[] data = createGraphWithSelectors
		(numSelectors, maxNumSelectorMappings, numFilters, 1);
	    graph = (Graph)data[0];
	    selectorSet = (SelectorSet)data[1];
	}

	if (false)
	{
	    println("-------------------------------------------------------");
	    writeGraph(graph, true, false);
	    println("-------------------------------------------------------");
	}

	checkSelectorData(graph, selectorSet);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all selectors were populated properly.
     */
    private void checkSelectorData(Graph graph, SelectorSet selectorSet)
	throws TestFailedException
    {
	int numSelectors = selectorSet.selectors.length;
	println("Testing Graph.getSelectors()...");
	{
	    selectorSet.clearSeenFlags();
	    SelectorIterator iterator = graph.getSelectors();
	    while (!iterator.atEnd())
	    {
		println("[selector=" + iterator.getName() + "]");
		int id = iterator.getID();
		if (id < 0 || id >= numSelectors)
		{
		    String msg = "selector id[" + id
			+ "] must be >= 0 and < " + numSelectors;
		    fail(msg);
		}

		Selector selector = selectorSet.selectors[id];

		if (selector.seen)
		{
		    String msg = "selector[" + iterator.getName() 
			+ "] repeated in list";
		    fail(msg);
		}
		selector.seen = true;

		verifyEqual("getName()", iterator.getName(), selector.name);

		checkSelectorMappingsOfSelector
		    (selector, iterator.getSelectorMappings());

		iterator.advance();
	    }

	    for (int i = 0; i < numSelectors; i++)
	    {
		Selector selector = selectorSet.selectors[i];
		if (!selector.seen)
		{
		    String msg = "selector[" + selector.name
			+ "] not seen in list";
		    fail(msg);
		}
	    }
	}

	println("Testing Graph.getSelector(int)...");
	{
	    for (int i = 0; i < numSelectors; i++)
	    {
		Selector selector = selectorSet.selectors[i];
		println("[selector " + i + ": " + selector.name + "]");

		SelectorIterator iterator = graph.getSelector(i);

		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(), selector.name);

		checkSelectorMappingsOfSelector
		    (selector, iterator.getSelectorMappings());

		iterator.advance();
		verify(false, "iterator.atEnd() == true", iterator.atEnd());
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the selector mappings of the given selector were
     * populated properly.
     */
    private void checkSelectorMappingsOfSelector
	(Selector selector, SelectorMappingIterator iterator)
	throws TestFailedException
    {
	selector.clearSeenFlags();
	while (!iterator.atEnd())
	{
	    println("[selector mapping="
		    + iterator.getDisplayCharacteristic() + "]");
	    SelectorMapping selectorMapping =
		selector.find(iterator.getDisplayCharacteristic());
	    if (selectorMapping == null)
	    {
		String msg = "encountered unknown selector mapping["
		    + iterator.getDisplayCharacteristic() + "]";
		fail(msg);
	    }

	    if (selectorMapping.seen)
	    {
		String msg =
		    "selector mapping[" + iterator.getDisplayCharacteristic() 
		    + "] repeated in list";
		fail(msg);
	    }
	    selectorMapping.seen = true;

	    verifyEqual("getFilterID()", iterator.getFilterID(),
			selectorMapping.filter);
	    verifyEqual("getDisplayCharacteristic()",
			iterator.getDisplayCharacteristic(),
			selectorMapping.characteristic);
	    verifyEqual("checkNodeInTarget()", iterator.checkNodeInTarget(),
			selectorMapping.node);
	    verifyEqual("checkLinkInTarget()", iterator.checkLinkInTarget(),
			selectorMapping.link);
	    verifyEqual("checkPathInTarget()", iterator.checkPathInTarget(),
			selectorMapping.path);
	    
	    iterator.advance();
	}

	SelectorMapping selectorMapping = selector.selectorMappings;
	while (selectorMapping != null)
	{
	    if (!selectorMapping.seen)
	    {
		String msg =
		    "selectorMapping[" + selectorMapping.characteristic
		    + "] not seen in list";
		fail(msg);
	    }
	    selectorMapping = selectorMapping.next;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with the given number of selectors.
     *
     * Returns {Graph, SelectorSet}.
     */
    private Object[] createGraphWithSelectors
	(int numSelectors, int maxNumSelectorMappings,
	 int numFilters, int numEnumerations)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();

	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	addFilters(builder, numFilters);
	SelectorSet selectorSet = addSelectors
	    (builder, numSelectors, maxNumSelectorMappings, numFilters);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[2];
	retval[0] = graph;
	retval[1] = selectorSet;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of selectors, with each having up to the given
     * maximum number of selector mappings.
     */
    private SelectorSet addSelectors
	(GraphBuilder builder, int numSelectors,
	 int maxNumSelectorMappings, int numFilters)
	throws TestFailedException
    {
	SelectorSet retval = new SelectorSet(numSelectors);
	for (int i = 0; i < numSelectors; i++)
	{
	    String name = m_nameGenerator.generate();
	    println("[selector " + i + ": " + name + "]");

	    Selector selector = retval.addSelector(name);
	    SelectorCreator creator = builder.addSelector(name);
	    verifyEqual("getSelectorID()", creator.getSelectorID(), i);

	    int numSelectorMappings =
		m_random.nextInt(maxNumSelectorMappings + 1);
	    for (int j = 0; j < numSelectorMappings; j++)
	    {
		String characteristic = m_nameGenerator.generate();
		println("[selector mapping " + j + ": "
			+ characteristic + "]");

		int filter = m_random.nextInt(numFilters);
		boolean node = m_random.nextBoolean();
		boolean link = m_random.nextBoolean();
		boolean path = m_random.nextBoolean();

		selector.addSelectorMapping(characteristic, filter,
					    node, link, path);
		try
		{
		    creator.addSelectorMapping(characteristic, filter,
					       node, link, path);
		}
		catch (DuplicateObjectException e)
		{
		    e.printStackTrace();
		    String msg = "addSelectorMapping() threw " + e.toString();
		    fail(msg);
		}
	    }
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // PRESENTATION TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testPresentationAllocation
	(int numPresentations, int numDisplays, int numSelectors)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testPresentationAllocation("
		+ "numPresentations=" + numPresentations
		+ ", numDisplays=" + numDisplays
		+ ", numSelectors=" + numSelectors + ")");
	println("===========================================================");

	Graph graph = null;
	Presentation[] presentations = null;
	{
	    Object[] data = createGraphWithPresentations
		(numPresentations, numDisplays, numSelectors);

	    graph = (Graph)data[0];
	    presentations = (Presentation[])data[1];
	}

	if (false)
	{
	    println("-------------------------------------------------------");
	    writeGraph(graph, true, false);
	    println("-------------------------------------------------------");
	}

	checkPresentationData(graph, presentations);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all presentations were populated properly.
     */
    private void checkPresentationData
	(Graph graph, Presentation[] presentations)
	throws TestFailedException
    {
	int numPresentations = presentations.length;
	println("Testing Graph.getPresentations()...");
	{
	    for (int i = 0; i < numPresentations; i++)
	    {
		presentations[i].seen = false;
	    }

	    PresentationIterator iterator = graph.getPresentations();
	    while (!iterator.atEnd())
	    {
		println("[presentation=" + iterator.getName() + "]");
		int id = iterator.getID();
		if (id < 0 || id >= numPresentations)
		{
		    String msg = "presentation id[" + id
			+ "] must be >= 0 and < " + numPresentations;
		    fail(msg);
		}

		Presentation presentation = presentations[id];

		if (presentation.seen)
		{
		    String msg = "presentation[" + iterator.getName() 
			+ "] repeated in list";
		    fail(msg);
		}
		presentation.seen = true;

		verifyEqual("getName()", iterator.getName(),
			    presentation.name);
		verifyEqual("getDisplayID()", iterator.getDisplayID(),
			    presentation.display);
		verifyEqual("getSelectorID()", iterator.getSelectorID(),
			    presentation.selector);

		iterator.advance();
	    }

	    for (int i = 0; i < numPresentations; i++)
	    {
		Presentation presentation = presentations[i];
		if (!presentation.seen)
		{
		    String msg = "presentation[" + presentation.name
			+"] not seen in list";
		    fail(msg);
		}
	    }
	}

	println("Testing Graph.getPresentation(int)...");
	{
	    for (int i = 0; i < numPresentations; i++)
	    {
		Presentation presentation = presentations[i];
		println("[presentation " + i + ": " + presentation.name + "]");

		PresentationIterator iterator = graph.getPresentation(i);

		verify(false, "iterator.atEnd() == false", !iterator.atEnd());
		verifyEqual("getID()", iterator.getID(), i);
		verifyEqual("getName()", iterator.getName(),
			    presentation.name);
		verifyEqual("getDisplayID()", iterator.getDisplayID(),
			    presentation.display);
		verifyEqual("getSelectorID()", iterator.getSelectorID(),
			    presentation.selector);

		iterator.advance();
		verify(false, "iterator.atEnd() == true", iterator.atEnd());
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with the given number of presentations.
     *
     * Returns {Graph, Presentation[]}.
     */
    private Object[] createGraphWithPresentations
	(int numPresentations, int numDisplays, int numSelectors)
	throws TestFailedException
    {
	GraphBuilder builder = m_factory.makeGraphBuilder();

	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	addBasicAttributeDefinitions(builder, 1, 1);
	addDisplays(builder, numDisplays, 0, 1);
	addFilters(builder, 1);
	addSelectors(builder, numSelectors, 0, 1);

	Presentation[] presentations = addPresentations
	    (builder, numPresentations, numDisplays, numSelectors);

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[2];
	retval[0] = graph;
	retval[1] = presentations;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds the given number of presentations.
     */
    private Presentation[] addPresentations
	(GraphBuilder builder, int numPresentations,
	 int numDisplays, int numSelectors)
	throws TestFailedException
    {
	Presentation[] retval = new Presentation[numPresentations];
	for (int i = 0; i < numPresentations; i++)
	{
	    String name = m_nameGenerator.generate();
	    println("[presentation " + i + ": " + name + "]");

	    int display = m_random.nextInt(numDisplays);
	    int selector = m_random.nextInt(numSelectors);

	    retval[i] = new Presentation(name, display, selector);
	    int id = builder.addPresentation(name, display, selector);
	    verifyEqual("addPresentation()", id, i);
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////
    // MENU TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testMenuAllocation
	(MenuProbability probability, int numPresentations,
	 int numDisplays, int numSelectors,
	 int numFilters, int numAttributes)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testMenuAllocation(numPresentations=" + numPresentations
		+ ", numDisplays=" + numDisplays
		+ ", numSelectors=" + numSelectors
		+ ", numFilters=" + numFilters
		+ ", numAttributes=" + numAttributes + ")");
	println("===========================================================");

	Graph graph = null;
	Menu presentationMenu = null;
	Menu displayMenu = null;
	Menu selectorMenu = null;
	Menu filterMenu = null;
	Menu attributeMenu = null;
	{
	    Object[] data = createGraphWithMenus
		(probability, numPresentations, numDisplays, numSelectors,
		 numFilters, numAttributes);
	    graph = (Graph)data[0];
	    presentationMenu = (Menu)data[1];
	    displayMenu = (Menu)data[2];
	    selectorMenu = (Menu)data[3];
	    filterMenu = (Menu)data[4];
	    attributeMenu = (Menu)data[5];
	}

	if (false)
	{
	    println("-------------------------------------------------------");
	    writeGraph(graph, true, false);
	    println("-------------------------------------------------------");
	}

	checkMenuData("** PRESENTATION **", presentationMenu,
		      graph.getPresentationMenu());
	checkMenuData("** DISPLAY **", displayMenu, graph.getDisplayMenu());
	checkMenuData("** SELECTOR **", selectorMenu, graph.getSelectorMenu());
	checkMenuData("** FILTER **", filterMenu, graph.getFilterMenu());
	checkMenuData("** ATTRIBUTE **", attributeMenu,
		      graph.getAttributeMenu());

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the hierachy of menus underneath the given fake top-level
     * menu were populated properly.
     */
    private void checkMenuData
	(String topLevelName, Menu menu, MenuIterator iterator)
	throws TestFailedException
    {
	print("(" + topLevelName);

	verifyEqual(false, "iterator.atEnd()", iterator.atEnd(),
		    menu.submenus == null);
	if (menu.submenus != null)
	{
	    checkSubmenuData(menu, iterator, 1);
	}

	println(")");
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the two hierachy of menus, starting with the submenus of
     * the given menu and the menus provided by the given iterator, match
     * one-to-one in order and in nesting.
     */
    private void checkSubmenuData
	(Menu parent, MenuIterator iterator, int level)
	throws TestFailedException
    {
	Menu menu = parent.submenus;
	while (menu != null)
	{
	    println();
	    indent(level);
	    print("(" + menu.label + " " + menu.id);

	    if (iterator.atEnd())
	    {
		String msg = "missing menu[" + menu.label + "] in list";
		fail(msg);
	    }

	    verifyEqual(false, "getLabel()", iterator.getLabel(), menu.label);
	    verifyEqual(false, "getID()", iterator.getID(), menu.id);

	    if (menu.submenus != null)
	    {
		MenuIterator submenuIterator = iterator.getSubmenus();
		if (submenuIterator.atEnd())
		{
		    String msg =
			"missing submenus of menu[" + menu.label + "]";
		    fail(msg);
		}
		checkSubmenuData(menu, submenuIterator, level + 1);
	    }
	    else
	    {
		if (!iterator.getSubmenus().atEnd())
		{
		    String msg =
			"spurious submenus found for menu[" + menu.label + "]";
		    fail(msg);
		}
	    }

	    menu = menu.next;
	    iterator.advance();

	    print(")");
	}

	if (!iterator.atEnd())
	{
	    String msg = "excess menu[" + iterator.getLabel() + ", "
		+ iterator.getID() + "] in list";
	    fail(msg);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a graph with menus.
     *
     * Returns {Graph, Menu presentation, Menu display, Menu selector,
     * Menu filter, Menu attribute}.
     */
    private Object[] createGraphWithMenus
	(MenuProbability probability, int numPresentations,
	 int numDisplays, int numSelectors, int numFilters, int numAttributes)
	throws TestFailedException
    {
	final GraphBuilder builder = m_factory.makeGraphBuilder();

	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	addBasicAttributeDefinitions(builder, numAttributes, 1);
	addDisplays(builder, numDisplays, 0, numAttributes);
	addFilters(builder, numFilters);
	addSelectors(builder, numSelectors, 0, numFilters);
	addPresentations(builder, numPresentations, numDisplays, numSelectors);

	Menu presentationMenu =
	    addMenus("** PRESENTATIONS **", probability, numPresentations,
		     new MenuCreator() {
			     public MenuCreator addSubmenu
				 (String label, int id)
			     {
				 return builder.addPresentationSubmenu
				     (label, id);
			     }
			 });

	Menu displayMenu =
	    addMenus("** DISPLAYS **", probability, numDisplays,
		     new MenuCreator() {
			     public MenuCreator addSubmenu
				 (String label, int id)
			     {
				 return builder.addDisplaySubmenu(label, id);
			     }
			 });

	Menu selectorMenu =
	    addMenus("** SELECTORS **", probability, numSelectors,
		     new MenuCreator() {
			     public MenuCreator addSubmenu
				 (String label, int id)
			     {
				 return builder.addSelectorSubmenu(label, id);
			     }
			 });

	Menu filterMenu =
	    addMenus("** FILTERS **", probability, numFilters,
		     new MenuCreator() {
			     public MenuCreator addSubmenu
				 (String label, int id)
			     {
				 return builder.addFilterSubmenu(label, id);
			     }
			 });

	Menu attributeMenu =
	    addMenus("** ATTRIBUTES **", probability, numAttributes,
		     new MenuCreator() {
			     public MenuCreator addSubmenu
				 (String label, int id)
			     {
				 return builder.addAttributeSubmenu(label, id);
			     }
			 });

	Graph graph = builder.endConstruction();
	Object[] retval = new Object[6];
	retval[0] = graph;
	retval[1] = presentationMenu;
	retval[2] = displayMenu;
	retval[3] = selectorMenu;
	retval[4] = filterMenu;
	retval[5] = attributeMenu;
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds a hierarchy of random nested menus, returning the fake top-level
     * menu which contains all the top-level menu items.
     */
    private Menu addMenus(String label, MenuProbability probability,
			  int numObjects, MenuCreator creator)
	throws TestFailedException
    {
	Menu retval = new Menu(0, label, -1);

	if (DEBUG_PRINT_MENUS)
	{
	    print("(" + label);
	}

	int numSubmenus = probability.getNumSubmenus(0);
	for (int i = 0; i < numSubmenus; i++)
	{
	    addSubmenus(probability, numObjects, retval, creator, 1);
	}

	if (DEBUG_PRINT_MENUS)
	{
	    println(")");
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Adds a submenu to the given parent menu, and then possibly adds a
     * randomly-generated hierarchy of further submenus.
     */
    private void addSubmenus
	(MenuProbability probability, int numObjects,
	 Menu parentMenu, MenuCreator parentCreator, int level)
    {
	int numSubmenus = probability.getNumSubmenus(level);

	String label = m_nameGenerator.generate();
	int id = (numSubmenus == 0 ? m_random.nextInt(numObjects) : -1);

	if (DEBUG_PRINT_MENUS)
	{
	    println();
	    indent(level);
	    print("(" + label + " " + id);
	}

	Menu menu = parentMenu.addSubmenu(label, id);
	MenuCreator creator = parentCreator.addSubmenu(label, id);

	for (int i = 0; i < numSubmenus; i++)
	{
	    addSubmenus(probability, numObjects, menu, creator, level + 1);
	}

	if (DEBUG_PRINT_MENUS)
	{
	    print(")");
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // MISC UTILITIES
    ///////////////////////////////////////////////////////////////////////

    /**
     * Returns an array giving a random subset, of the given size, of the
     * integer range {0 .. numObjects - 1}.
     *
     * No elements are repeated in the result.
     */
    private int[] selectRandomSubset(int numObjects, int subsetSize)
    {
	int[] objects = new int[numObjects];
	for (int i = 0; i < numObjects; i++)
	{
	    objects[i] = i;
	}
	shuffle(objects);
	
	int[] retval = new int[subsetSize];
	for (int i = 0; i < subsetSize; i++)
	{
	    retval[i] = objects[i];
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the given graph contains the given number of objects
     * of each type.
     */
    private void checkNumObjects(Graph graph, int numNodes,
				 int numLinks, int numPaths)
	throws TestFailedException
    {
	{
	    int n = graph.getNumNodes();
	    verifyEqual("getNumNodes()", n, numNodes);

	    int nodes = countNumUniqueObjects(ObjectType.NODE, graph);
	    verifyEqual("# unique nodes", nodes, numNodes);
	}

	{
	    int n = graph.getNumLinks();
	    verifyEqual("getNumLinks()", n, numLinks);

	    int links = countNumUniqueObjects(ObjectType.LINK, graph);
	    verifyEqual("# unique links", links, numLinks);
	}

	{
	    int n = graph.getNumPaths();
	    verifyEqual("getNumPaths()", n, numPaths);

	    int paths = countNumUniqueObjects(ObjectType.PATH, graph);
	    verifyEqual("# unique paths", paths, numPaths);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Returns the number of unique objects (based on ID) of the given type
     * in the given graph.
     */
    private int countNumUniqueObjects(ObjectType type, Graph graph)
	throws TestFailedException
    {
	GrowableIntArray array = new GrowableIntArray();
	ObjectIterator iterator = graph.getObjects(type);
	while (!iterator.atEnd())
	{
	    verifyEqual("getObjectType()", iterator.getObjectType(), type);
	    array.append(iterator.getObjectID());

	    iterator.advance();
	}

	int[] sortedArray = deriveSortedArray(array);
	checkAllUnique(sortedArray, "object ID");
	return sortedArray.length;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Returns a histogram of the number of times an object appears in
     * the parameter {occurrences} which is an array of object IDs.
     */
    private int[] computeHistogram(int numObjects, int occurrences[])
	throws TestFailedException
    {
	int[] retval = new int[numObjects];

	for (int i = 0; i < occurrences.length; i++)
	{
	    int id = occurrences[i];
	    if (id < 0 || id >= numObjects)
	    {
		String msg = "id[" + id + "] must be >= 0 and < " + numObjects;
		fail(msg);
	    }

	    ++retval[id];
	}

	println("histogram:");
	for (int i = 0; i < numObjects; i++)
	{
	    println(i + ": " + retval[i]);
	}

	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Returns an {int[]} containing the data in {array} but also sorted
     * in ascending order.
     */
    private int[] deriveSortedArray(GrowableIntArray array)
    {
	int[] retval = deriveUnsortedArray(array);
	Arrays.sort(retval);
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Returns an {int[]} containing the data in {array}.
     */
    private int[] deriveUnsortedArray(GrowableIntArray array)
    {
	int n = array.getNumAllocated();
	int[] retval = new int[n];
	for (int i = 0; i < n; i++)
	{
	    retval[i] = array.getValue(i);
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that all values in {sortedArray} are unique.
     */
    private void checkAllUnique(int[] sortedArray, String description)
	throws TestFailedException
    {
	if (sortedArray.length > 1)
	{
	    for (int i = 1; i < sortedArray.length; i++)
	    {
		if (sortedArray[i] == sortedArray[i - 1])
		{
		    fail("found duplicate value[" + sortedArray[i]
			 + "] in " + description + " array");
		}
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Returns an IntBinArray with indexes between 0 and {numObjects - 1},
     * inclusive, allocated.
     */
    private IntBinArray createIntBinArray(int numObjects, boolean isOrdered)
	throws TestFailedException
    {
	IntBinArray retval = new IntBinArray(isOrdered);
	for (int i = 0; i < numObjects; i++)
	{
	    verifyEqual(false, "allocate()", retval.allocate(), i);
	}
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private void validateObjectID(ObjectType type, int numObjects, int id)
	throws TestFailedException
    {
	switch (type.getType())
	{
	case ObjectType._NODE: validateNodeID(numObjects, id); break;
	case ObjectType._LINK: validateLinkID(numObjects, id); break;
	case ObjectType._PATH: validatePathID(numObjects, id); break;
	default: throw new InternalErrorException();
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private void validateNodeID(int numNodes, int id)
	throws TestFailedException
    {
	validateID(numNodes, id, "node");
    }

    ///////////////////////////////////////////////////////////////////////

    private void validateLinkID(int numLinks, int id)
	throws TestFailedException
    {
	validateID(numLinks, id, "link");
    }

    ///////////////////////////////////////////////////////////////////////

    private void validatePathID(int numPaths, int id)
	throws TestFailedException
    {
	validateID(numPaths, id, "path");
    }

    ///////////////////////////////////////////////////////////////////////

    private void validateEnumerationID(int numEnumerations, int id)
	throws TestFailedException
    {
	validateID(numEnumerations, id, "enumeration");
    }

    ///////////////////////////////////////////////////////////////////////

    private void validateEnumeratorID(int numEnumerators, int id)
	throws TestFailedException
    {
	validateID(numEnumerators, id, "enumerator");
    }

    ///////////////////////////////////////////////////////////////////////

    private void validateAttributeID(int numAttributes, int id)
	throws TestFailedException
    {
	validateID(numAttributes, id, "attribute");
    }

    ///////////////////////////////////////////////////////////////////////

    private void validateID(int numObjects, int id, String description)
	throws TestFailedException
    {
	if (id < 0 || id >= numObjects)
	{
	    String msg = "invalid " + description + " ID[" + id
		+ "]: must be >= 0 and < " + numObjects;
	    fail(msg);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private void printValues(ValueIterator iterator)
	throws TestFailedException
    {
	System.out.println("[");

	int position = 0;
	while (!iterator.atEnd())
	{
	    System.out.print("  " + position + ": ");
	    printValue(iterator);
	    System.out.println();

	    ++position;
	}

	System.out.println("]");
    }

    ///////////////////////////////////////////////////////////////////////

    private void printValue(ValueIterator iterator)
	throws TestFailedException
    {
	verify(false, "iterator.atEnd() == false", iterator.atEnd() == false);
	switch (iterator.getType().getBaseType())
	{
	case ValueType._BOOLEAN:
	    System.out.print(iterator.getBooleanValue());
	    break;
	case ValueType._INTEGER:
	    System.out.print(iterator.getIntegerValue());
	    break;
	case ValueType._FLOAT:
	    System.out.print(iterator.getFloatValue());
	    break;
	case ValueType._DOUBLE:
	    System.out.print(iterator.getDoubleValue());
	    break;
	case ValueType._STRING:
	    System.out.print("\"");
	    System.out.print(iterator.getStringValue());
	    System.out.print("\"");
	    break;
	case ValueType._FLOAT3:
	    {
		float[] values = iterator.getFloat3Value();
		System.out.print("{ ");
		System.out.print(values[0]);
		System.out.print("; ");
		System.out.print(values[1]);
		System.out.print("; ");
		System.out.print(values[2]);
		System.out.print("; }");
	    }
	    break;
	case ValueType._DOUBLE3:
	    {
		double[] values = iterator.getDouble3Value();
		System.out.print("{ ");
		System.out.print(values[0]);
		System.out.print("; ");
		System.out.print(values[1]);
		System.out.print("; ");
		System.out.print(values[2]);
		System.out.print("; }");
	    }
	    break;
	case ValueType._ENUMERATION:
	    System.out.print("enum[");
	    System.out.print(iterator.getEnumerationValue());
	    System.out.print("] => ");
	    System.out.print(iterator.getEvaluatedEnumerationValue());
	    break;
	default: throw new InternalErrorException();
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private void verifyEqual(String s, ValueType m, ValueType n)
	throws TestFailedException
    {
	verifyEqual(true, s, m, n);
    }

    private void verifyEqual(boolean show, String s, ValueType m, ValueType n)
	throws TestFailedException
    {
	String comparison = s + "[ValueType." + m.getName()
	    + "] == ValueType." + n.getName();
	if (show)
	{
	    println(comparison);
	}
	if (m != n)
	{
	    throw new TestFailedException("Verification Failed: "
					  + comparison);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private void verifyEqual(String s, ObjectType m, ObjectType n)
	throws TestFailedException
    {
	verifyEqual(true, s, m, n);
    }

    private void verifyEqual(boolean show, String s,
			     ObjectType m, ObjectType n)
	throws TestFailedException
    {
	String comparison = s + "[ObjectType." + m.getName()
	    + "] == ObjectType." + n.getName();
	if (show)
	{
	    println(comparison);
	}
	if (m != n)
	{
	    throw new TestFailedException("Verification Failed: "
					  + comparison);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private void writeGraph(Graph graph, boolean isVerbose,
			    boolean includeHeader)
    {
	Writer writer = new BufferedWriter(new OutputStreamWriter(System.out));
	GraphFileWriter fileWriter =
	    new GraphFileWriter(writer, graph, isVerbose, includeHeader);
	try
	{
	    fileWriter.write();
	}
	catch (IOException e)
	{
	    println("ERROR writing graph: " + e.toString());
	}
    }

    private void indent(int level)
    {
	for (int i = 0; i < level; i++)
	{
	    print("  ");
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    /**
     * Whether to print a textual representation of the menus being
     * created by the routines that test menus.
     */
    private static final boolean  DEBUG_PRINT_MENUS = true;

    private GraphBuilderFactory  m_factory;
    private NameGenerator  m_nameGenerator = new NameGenerator("test");
    private TypeGenerator  m_typeGenerator = new TypeGenerator();

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE NESTED & INNER CLASSES
    ///////////////////////////////////////////////////////////////////////

    private static class Enumeration
    {
	public Enumeration(int id, String name)
	{
	    this.id = id;
	    this.name = name;
	}

	public int getNumEnumerators()
	{
	    int retval = 0;
	    Enumerator enumerator = enumerators;
	    while (enumerator != null)
	    {
		++retval;
		enumerator = enumerator.next;
	    }
	    return retval;
	}

	public Enumerator addEnumerator(int id, String name, int value)
	{
	    Enumerator enumerator = new Enumerator(id, name, value, this.id);
	    if (tail == null)
	    {
		enumerators = tail = enumerator;
	    }
	    else
	    {
		tail.next = enumerator;
		tail = enumerator;
	    }
	    return enumerator;
	}

	public void clearSeenFlags()
	{
	    Enumerator enumerator = enumerators;
	    while (enumerator != null)
	    {
		enumerator.seen = false;
		enumerator = enumerator.next;
	    }
	}

	public int id;
	public String name;
	public Enumerator enumerators;
	public Enumerator tail;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class Enumerator
    {
	public Enumerator(int id, String name, int value, int enumeration)
	{
	    this.id = id;
	    this.name = name;
	    this.value = value;
	    this.enumeration = enumeration;
	}

	public int id;
	public String name;
	public int value;
	public int enumeration;
	public boolean seen;
	public Enumerator next;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class AttributeDefinition
    {
	public AttributeDefinition(int id, String name,
				   ValueType type, int enumeration,
				   String expr, boolean isMutable)
	{
	    this.isMutable = isMutable;
	    this.id = id;
	    this.name = name;
	    this.type = type;
	    this.enumeration = enumeration;
	    this.expr = expr;
	}

	public AttributeValues getAttributeValues(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return nodeValues;
	    case ObjectType._LINK: return linkValues;
	    case ObjectType._PATH: return pathValues;
	    default: throw new InternalErrorException();
	    }
	}

	public int id;
	public String name;
	public ValueType type;
	public int enumeration;
	public String expr;
	public boolean isMutable;

	public AttributeValues nodeValues;
	public AttributeValues linkValues;
	public AttributeValues pathValues;
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Contains all the values of a single attribute definition
     * for a single object type (node, link, or path).
     */
    private class AttributeValues
    {
	////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	////////////////////////////////////////////////////////////////////

	public AttributeValues
	    (GraphBuilder builder, ObjectType objectType,
	     ValueType type, Enumeration enumeration,
	     BitSet objects, int[] length, int maxNumObjects)
	    throws TestFailedException
	{
	    if (type.isEnumerationType())
	    {
		if (enumeration == null)
		{
		    throw new IllegalArgumentException("missing enumeration");
		}
		if (enumeration.enumerators == null)
		{
		    throw new IllegalArgumentException("missing enumerators");
		}
	    }

	    m_objectType = objectType;
	    m_type = type;

	    if (enumeration != null)
	    {
		m_enumeration = enumeration;
		m_numEnumerators = enumeration.getNumEnumerators();
		m_enumerators =
		    gatherEnumerators(enumeration, m_numEnumerators);
	    }

	    m_objects = objects;
	    m_maxNumObjects = maxNumObjects;
	    m_numValues = countNumValues(length);

	    m_start = computeStart(objects, length, maxNumObjects);
	    m_length = length;

	    allocateValues();
	    fillWithRandomValues();
	    populateGraph(builder);
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	/**
	 * Checks that an attribute contains exactly the values populated
	 * for a given type of object (node, link, or path).
	 */
	public void checkAttributeValues
	    (AttributesByAttributeIterator iterator)
	    throws TestFailedException
	{
	    BitSet seenMap = new BitSet(m_objects.length());
	    while (!iterator.atEnd())
	    {
		verifyEqual(false, "getObjectType()", iterator.getObjectType(),
			    m_objectType);

		int id = iterator.getObjectID();
		validateObjectID(m_objectType, m_maxNumObjects, id);

		if (!m_objects.get(id))
		{

		    String msg = "encountered an object[" + id
			+ "] which was not given an attribute value";
		    fail(msg);
		}

		if (seenMap.get(id))
		{
		    fail("object[" + id + "] repeated in attributes list");
		}
		seenMap.set(id);

		checkObjectValues(id, iterator.getAttributeValues());

		iterator.advance();
	    }

	    int length = m_objects.length();
	    for (int i = 0; i < length; i++)
	    {
		if (m_objects.get(i) && !seenMap.get(i))
		{
		    String msg =
			"object[" + i + "] not seen in attributes list";
		    fail(msg);
		}
	    }
	}

	/**
	 * Checks that the object with the given id has exactly the values
	 * populated for the attribute definition represented by this class.
	 */
	public void checkObjectValues(int id, ValueIterator iterator)
	    throws TestFailedException
	{
	    validateObjectID(m_objectType, m_maxNumObjects, id);
	    if (!m_objects.get(id))
	    {
		String msg = "encountered an object[" + id
		    + "] which was not given an attribute value";
		fail(msg);
	    }

	    println("[" + id + ", start=" + m_start[id]
		    + ", length=" + m_length[id] + "]");

	    verify(false, "start", m_start[id], Op.GREATER_EQUAL, 0);
	    verify(false, "length", m_length[id], Op.GREATER_EQUAL, 0);

	    int start = m_start[id];
	    int length = m_length[id];
	    for (int i = 0; i < length; i++)
	    {
		if (iterator.atEnd())
		{
		    String msg = "object[" + id + "] is missing values "
			+ "starting at position " + i;
		    print(msg);
		    println(":");
		    for (int j = i; j < length; j++)
		    {
			print("\t" + j + ": ");
			printValue(start + j);
			println();
		    }
		    fail(msg);
		}

		compareValues(start + i, iterator);
		iterator.advance();
	    }

	    if (!iterator.atEnd())
	    {
		String msg = "object[" + id + "] has excess values";
		print(msg);
		println(":");
		while (!iterator.atEnd())
		{
		    print("\t");
		    GraphBuilderTester.this.printValue(iterator);
		    println();

		    iterator.advance();
		}
		fail(msg);
	    }
	}

	/**
	 * Returns a BitSet in which a bit is set at an index if an object
	 * with an ID equal to that index has a value in this class.
	 */
	public BitSet getAllocationMap()
	{
	    return m_objects;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	/**
	 * Checks that the current value in the given ValueIterator matches
	 * the value at the given index.
	 */
	private void compareValues(int i, ValueIterator iterator)
	    throws TestFailedException
	{
	    switch (m_type.getBaseType())
	    {
	    case ValueType._BOOLEAN:
		verifyEqual("boolean value", iterator.getBooleanValue(),
			    m_booleanValues.get(i));
		break;
	    case ValueType._INTEGER:
		verifyEqual("integer value", iterator.getIntegerValue(),
			    m_integerValues[i]);
		break;
	    case ValueType._FLOAT:
		verifyEqual("float value", iterator.getFloatValue(),
			    m_floatValues[i]);
		break;
	    case ValueType._DOUBLE:
		verifyEqual("double value", iterator.getDoubleValue(),
			    m_doubleValues[i]);
		break;
	    case ValueType._STRING:
		verifyEqual("string value", iterator.getStringValue(),
			    m_stringValues[i]);
		break;
	    case ValueType._FLOAT3:
		iterator.getFloat3Value(m_float3Temporary);
		verifyEqual("float3 x value", m_float3Temporary[0],
			    m_floatXValues[i]);
		verifyEqual("float3 y value", m_float3Temporary[1],
			    m_floatYValues[i]);
		verifyEqual("float3 z value", m_float3Temporary[2],
			    m_floatZValues[i]);
		break;
	    case ValueType._DOUBLE3:
		iterator.getDouble3Value(m_double3Temporary);
		verifyEqual("double3 x value", m_double3Temporary[0],
			    m_doubleXValues[i]);
		verifyEqual("double3 y value", m_double3Temporary[1],
			    m_doubleYValues[i]);
		verifyEqual("double3 z value", m_double3Temporary[2],
			    m_doubleZValues[i]);
		break;
	    case ValueType._ENUMERATION:
		verifyEqual("enumerator ID", iterator.getEnumerationValue(),
			    m_enumerators[m_enumeratorIndex[i]].id);
		verifyEqual("enumerator value",
			    iterator.getEvaluatedEnumerationValue(),
			    m_enumerators[m_enumeratorIndex[i]].value);
		break;
	    default: throw new InternalErrorException();
	    }
	}

	/**
	 * Prints the value at the given index.
	 */
	private void printValue(int i)
	{
	    switch (m_type.getBaseType())
	    {
	    case ValueType._BOOLEAN:
		print(m_booleanValues.get(i));
		break;
	    case ValueType._INTEGER:
		print(m_integerValues[i]);
		break;
	    case ValueType._FLOAT:
		print(m_floatValues[i]);
		break;
	    case ValueType._DOUBLE:
		print(m_doubleValues[i]);
		break;
	    case ValueType._STRING:
		print("\"");
		print(m_stringValues[i]);
		print("\"");
		break;
	    case ValueType._FLOAT3:
		print("{ ");
		print(m_floatXValues[i]);
		print("; ");
		print(m_floatYValues[i]);
		print("; ");
		print(m_floatZValues[i]);
		print("; }");
		break;
	    case ValueType._DOUBLE3:
		print("{ ");
		print(m_doubleXValues[i]);
		print("; ");
		print(m_doubleYValues[i]);
		print("; ");
		print(m_doubleZValues[i]);
		print("; }");
		break;
	    case ValueType._ENUMERATION:
		print("enum[");
		print(m_enumerators[m_enumeratorIndex[i]].id);
		print("] => ");
		print(m_enumerators[m_enumeratorIndex[i]].value);
		break;
	    default: throw new InternalErrorException();
	    }
	}

	/**
	 * Uses the given GraphBuilder to populate the attribute values
	 * contained in this class.
	 */
	private void populateGraph(GraphBuilder builder)
	    throws TestFailedException
	{
	    for (int i = 0; i < m_maxNumObjects; i++)
	    {
		int start = m_start[i];
		if (start >= 0)
		{
		    verify(false, "m_objects.get(" + i + ") == true",
			   m_objects.get(i));
		    if (m_type.isBaseType())
		    {
			verifyEqual(false, "m_length[" + i + "]",
				    m_length[i], 1);
		    }

		    AttributeCreator creator =
			builder.addObjectAttribute(m_objectType, i);
		    populateObject(creator, start, start + m_length[i]);
		}
	    }
	}

	/**
	 * Uses the given AttributeCreator to populate the attribute values
	 * at the given range of indexes.
	 */
	private void populateObject(AttributeCreator creator,
				    int start, int end)
	{
	    for (int i = start; i < end; i++)
	    {
		switch (m_type.getBaseType())
		{
		case ValueType._BOOLEAN:
		    creator.addBooleanValue(m_booleanValues.get(i));
		    break;
		case ValueType._INTEGER:
		    creator.addIntegerValue(m_integerValues[i]);
		    break;
		case ValueType._FLOAT:
		    creator.addFloatValue(m_floatValues[i]);
		    break;
		case ValueType._DOUBLE:
		    creator.addDoubleValue(m_doubleValues[i]);
		    break;
		case ValueType._STRING:
		    creator.addStringValue(m_stringValues[i]);
		    break;
		case ValueType._FLOAT3:
		    creator.addFloat3Value(m_floatXValues[i],
					   m_floatYValues[i],
					   m_floatZValues[i]);
		    break;
		case ValueType._DOUBLE3:
		    creator.addDouble3Value(m_doubleXValues[i],
					    m_doubleYValues[i],
					    m_doubleZValues[i]);
		    break;
		case ValueType._ENUMERATION:
		    {
			int index = m_enumeratorIndex[i];
			boolean useID = m_random.nextBoolean();
			if (useID)
			{
			    creator.addEnumerationValue
				(m_enumerators[index].id);
			}
			else
			{
			    creator.addEnumerationValue
				(m_enumerators[index].name);
			}
		    }
		    break;
		default: throw new InternalErrorException();
		}
	    }
	}

	/**
	 * Initializes all attribute value slots with a random value, and
	 * corresponds to creating a set of random values for a given
	 * attribute definition.
	 */
	private void fillWithRandomValues()
	{
	    for (int i = 0; i < m_numValues; i++)
	    {
		switch (m_type.getBaseType())
		{
		case ValueType._BOOLEAN:
		    if (m_random.nextBoolean())
		    {
			m_booleanValues.set(i);
		    }
		    break;
		case ValueType._INTEGER:
		    m_integerValues[i] = m_random.nextInt();
		    break;
		case ValueType._FLOAT:
		    m_floatValues[i] = m_random.nextFloat();
		    break;
		case ValueType._DOUBLE:
		    m_doubleValues[i] = m_random.nextDouble();
		    break;
		case ValueType._STRING:
		    m_stringValues[i] = m_nameGenerator.generate();
		    break;
		case ValueType._FLOAT3:
		    m_floatXValues[i] = m_random.nextFloat();
		    m_floatYValues[i] = m_random.nextFloat();
		    m_floatZValues[i] = m_random.nextFloat();
		    break;
		case ValueType._DOUBLE3:
		    m_doubleXValues[i] = m_random.nextDouble();
		    m_doubleYValues[i] = m_random.nextDouble();
		    m_doubleZValues[i] = m_random.nextDouble();
		    break;
		case ValueType._ENUMERATION:
		    m_enumeratorIndex[i] = m_random.nextInt(m_numEnumerators);
		    break;
		default: throw new InternalErrorException();
		}
	    }
	}

	/**
	 * Allocates space for the storage of m_numValues attribute values.
	 */
	private void allocateValues()
	{
	    switch (m_type.getBaseType())
	    {
	    case ValueType._BOOLEAN:
		m_booleanValues = new BitSet(m_numValues);
		break;
	    case ValueType._INTEGER:
		m_integerValues = new int[m_numValues];
		break;
	    case ValueType._FLOAT:
		m_floatValues = new float[m_numValues];
		break;
	    case ValueType._DOUBLE:
		m_doubleValues = new double[m_numValues];
		break;
	    case ValueType._STRING:
		m_stringValues = new String[m_numValues];
		break;
	    case ValueType._FLOAT3:
		m_floatXValues = new float[m_numValues];
		m_floatYValues = new float[m_numValues];
		m_floatZValues = new float[m_numValues];
		break;
	    case ValueType._DOUBLE3:
		m_doubleXValues = new double[m_numValues];
		m_doubleYValues = new double[m_numValues];
		m_doubleZValues = new double[m_numValues];
		break;
	    case ValueType._ENUMERATION:
		m_enumeratorIndex = new int[m_numValues];
		break;
	    default: throw new InternalErrorException();
	    }
	}

	/**
	 * Returns an array of all the enumerators in the given enumeration.
	 */
	private Enumerator[] gatherEnumerators(Enumeration enumeration,
					       int numEnumerators)
	    throws TestFailedException
	{
	    Enumerator[] retval = new Enumerator[numEnumerators];
	    Enumerator enumerator = enumeration.enumerators;
	    for (int i = 0; i < numEnumerators; i++)
	    {
		if (enumerator == null)
		{
		    throw new InternalErrorException("missing enumerator");
		}

		retval[i] = enumerator;
		enumerator = enumerator.next;
	    }
	    verify(false, "enumerator == null", enumerator == null);
	    return retval;
	}

	/**
	 * Returns an array giving the starting index of the attribute
	 * values of every object.
	 */
	private int[] computeStart(BitSet objects, int[] length,
				   int maxNumObjects)
	    throws TestFailedException
	{
	    verify(false, "objects.length()",
		   objects.length(), Op.LESS_EQUAL, maxNumObjects);
	    verifyEqual(false, "length.length", length.length, maxNumObjects);

	    int[] retval = new int[maxNumObjects];
	    int start = 0;
	    for (int i = 0; i < maxNumObjects; i++)
	    {
		if (objects.get(i))
		{
		    // NOTE: A value may still have zero length even when
		    //       start does not equal -1.
		    retval[i] = start;
		    start += length[i];
		    verify(false, "length[" + i + "]",
			   length[i], Op.GREATER_EQUAL, 0);
		}
		else
		{
		    retval[i] = -1;
		    verifyEqual(false, "length[" + i + "]", length[i], 0);
		}
	    }
	    return retval;
	}

	/**
	 * Returns the total number of values (where values in lists are
	 * counted separately) in all attribute values.
	 */
	private int countNumValues(int[] length)
	{
	    int retval = 0;
	    for (int i = 0; i < length.length; i++)
	    {
		retval += length[i];
	    }
	    return retval;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private ObjectType  m_objectType;
	private ValueType  m_type;
	private Enumeration  m_enumeration;
	private int  m_numEnumerators;
	private BitSet  m_objects;
	private int  m_maxNumObjects;
	private int  m_numValues;

	private int[]  m_start;
	private int[]  m_length;

	private Enumerator[]  m_enumerators;

	private BitSet  m_booleanValues;
	private int[]  m_integerValues;
	private float[]  m_floatValues;
	private double[]  m_doubleValues;
	private String[]  m_stringValues;
	private float[]  m_floatXValues;
	private float[]  m_floatYValues;
	private float[]  m_floatZValues;
	private double[]  m_doubleXValues;
	private double[]  m_doubleYValues;
	private double[]  m_doubleZValues;
	private int[]  m_enumeratorIndex;

	private float[]  m_float3Temporary = new float[3];
	private double[]  m_double3Temporary = new double[3];
    }

    ///////////////////////////////////////////////////////////////////////

    private class AttributeValueIterator
	extends ImmutableAbstractValueIterator
    {
	public AttributeValueIterator
	    (Graph graph, ObjectType type, int object,
	     ValueType valueType, int attribute)
	{
	    if (valueType.isListType())
	    {
		throw new IllegalArgumentException();
	    }

	    m_graph = graph;
	    m_type = type;
	    m_object = object;
	    m_valueType = valueType;
	    m_attribute = attribute;
	}

	public boolean atEnd() { return m_atEnd; }
	public void advance() { m_atEnd = true; }
	public void rewind() { m_atEnd = false; }
	public boolean isEmpty() { return false; }
	public int getLength() { return 1; }
	public ValueType getType() { return m_valueType; }

	public boolean getBooleanValue()
	{
	    if (m_valueType != ValueType.BOOLEAN)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getBooleanAttribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public int getIntegerValue()
	{
	    if (m_valueType != ValueType.INTEGER)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getIntegerAttribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public float getFloatValue()
	{
	    if (m_valueType != ValueType.FLOAT)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getFloatAttribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public double getDoubleValue()
	{
	    if (m_valueType != ValueType.DOUBLE)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getDoubleAttribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public String getStringValue()
	{
	    if (m_valueType != ValueType.STRING)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getStringAttribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public float[] getFloat3Value()
	{
	    if (m_valueType != ValueType.FLOAT3)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getFloat3Attribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public void getFloat3Value(float[] values)
	{
	    if (m_valueType != ValueType.FLOAT3)
	    { throw new TypeMismatchException(); }

	    try
	    { m_graph.getFloat3Attribute
		  (m_type, m_object, m_attribute, values); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public double[] getDouble3Value()
	{
	    if (m_valueType != ValueType.DOUBLE3)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getDouble3Attribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public void getDouble3Value(double[] values)
	{
	    if (m_valueType != ValueType.DOUBLE3)
	    { throw new TypeMismatchException(); }

	    try
	    { m_graph.getDouble3Attribute
		  (m_type, m_object, m_attribute, values); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public int getEnumerationValue()
	{
	    if (m_valueType != ValueType.ENUMERATION)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getEnumerationAttribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	public int getEvaluatedEnumerationValue()
	{
	    if (m_valueType != ValueType.ENUMERATION)
	    { throw new TypeMismatchException(); }

	    try
	    { return m_graph.getEvaluatedEnumerationAttribute
		  (m_type, m_object, m_attribute); }
	    catch (AttributeUnavailableException e)
	    { throw new RuntimeException(generateMessage()); }
	}

	private String generateMessage()
	{
	    return "object[" + m_object + "] is missing a value for "
		+ "attribute[" + m_attribute + "]";
	}

	private boolean  m_atEnd;
	private Graph  m_graph;
	private ObjectType  m_type;
	private int  m_object;
	private ValueType  m_valueType;
	private int  m_attribute;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class QualifierSet
    {
	public QualifierType addQualifierType(String name)
	{
	    QualifierType retval = new QualifierType(name);
	    retval.next = qualifierTypes;
	    qualifierTypes = retval;
	    return retval;
	}

	public void clearSeenFlags()
	{
	    QualifierType qualifierType = qualifierTypes;
	    while (qualifierType != null)
	    {
		qualifierType.seen = false;
		qualifierType = qualifierType.next;
	    }
	}

	public QualifierType find(String name)
	{
	    QualifierType qualifierType = qualifierTypes;
	    while (qualifierType != null)
	    {
		if (qualifierType.name.equals(name))
		{
		    return qualifierType;
		}
		qualifierType = qualifierType.next;
	    }
	    return null;
	}

	public QualifierType  qualifierTypes;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class QualifierType
    {
	public QualifierType(String name)
	{
	    this.name = name;
	}

	public Qualifier addQualifier(String name, String description)
	{
	    Qualifier retval =
		new Qualifier(this.name, name, description);
	    retval.next = qualifiers;
	    qualifiers = retval;
	    return retval;
	}

	public void clearSeenFlags()
	{
	    Qualifier qualifier = qualifiers;
	    while (qualifier != null)
	    {
		qualifier.seen = false;
		qualifier = qualifier.next;
	    }
	}

	public Qualifier find(String name)
	{
	    Qualifier qualifier = qualifiers;
	    while (qualifier != null)
	    {
		if (qualifier.name.equals(name))
		{
		    return qualifier;
		}
		qualifier = qualifier.next;
	    }
	    return null;
	}

	public boolean  seen;
	public String  name;
	public QualifierType  next;
	public Qualifier  qualifiers;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class Qualifier
    {
	public Qualifier(String type, String name, String description)
	{
	    this.type = type;
	    this.name = name;
	    this.description = description;
	}

	public QualifierAttribute associateAttribute(int attribute,
						     String alias)
	{
	    QualifierAttribute retval =
		new QualifierAttribute(attribute, alias);

	    retval.next = qualifierAttributes;
	    qualifierAttributes = retval;
	    return retval;
	}

	public void clearSeenFlags()
	{
	    QualifierAttribute qualifierAttribute = qualifierAttributes;
	    while (qualifierAttribute != null)
	    {
		qualifierAttribute.seen = false;
		qualifierAttribute = qualifierAttribute.next;
	    }
	}

	public QualifierAttribute find(String name)
	{
	    QualifierAttribute qualifierAttribute = qualifierAttributes;
	    while (qualifierAttribute != null)
	    {
		if (qualifierAttribute.alias.equals(name))
		{
		    return qualifierAttribute;
		}
		qualifierAttribute = qualifierAttribute.next;
	    }
	    return null;
	}

	public boolean  seen;
	public String  type;
	public String  name;
	public String  description;
	public Qualifier  next;
	public QualifierAttribute  qualifierAttributes;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class QualifierAttribute
    {
	public QualifierAttribute(int attribute, String alias)
	{
	    this.attribute = attribute;
	    this.alias = alias;
	}

	public boolean  seen;
	public int  attribute;
	public String  alias;
	public QualifierAttribute  next;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class DisplaySet
    {
	public DisplaySet(int numDisplays)
	{
	    displays = new Display[numDisplays];
	}

	public Display addDisplay(String name)
	{
	    Display retval = new Display(name);
	    displays[numDisplaysAdded++] = retval;
	    return retval;
	}

	public void clearSeenFlags()
	{
	    for (int i = 0; i < displays.length; i++)
	    {
		displays[i].seen = false;
	    }
	}

	public Display[]  displays;
	public int  numDisplaysAdded;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class Display
    {
	public Display(String name)
	{
	    this.name = name;
	}

	public DisplayMapping addDisplayMapping
	    (String characteristic, int attribute,
	     boolean node, boolean link, boolean path)
	{
	    DisplayMapping retval = new DisplayMapping
		(characteristic, attribute, node, link, path);
	    retval.next = displayMappings;
	    displayMappings = retval;
	    return retval;
	}

	public void clearSeenFlags()
	{
	    DisplayMapping displayMapping = displayMappings;
	    while (displayMapping != null)
	    {
		displayMapping.seen = false;
		displayMapping = displayMapping.next;
	    }
	}

	public DisplayMapping find(String characteristic)
	{
	    DisplayMapping displayMapping = displayMappings;
	    while (displayMapping != null)
	    {
		if (displayMapping.characteristic.equals(characteristic))
		{
		    return displayMapping;
		}
		displayMapping = displayMapping.next;
	    }
	    return null;
	}

	public boolean  seen;
	public String  name;
	public DisplayMapping  displayMappings;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class DisplayMapping
    {
	public DisplayMapping(String characteristic, int attribute,
			      boolean node, boolean link, boolean path)
	{
	    this.characteristic = characteristic;
	    this.attribute = attribute;
	    this.node = node;
	    this.link = link;
	    this.path = path;
	}

	public boolean  seen;
	public String  characteristic;
	public int  attribute;
	public boolean  node;
	public boolean  link;
	public boolean  path;
	public DisplayMapping  next;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class Filter
    {
	public Filter(String name, String expr)
	{
	    this.name = name;
	    this.expr = expr;
	}

	public boolean  seen;
	public String  name;
	public String  expr;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class SelectorSet
    {
	public SelectorSet(int numSelectors)
	{
	    selectors = new Selector[numSelectors];
	}

	public Selector addSelector(String name)
	{
	    Selector retval = new Selector(name);
	    selectors[numSelectorsAdded++] = retval;
	    return retval;
	}

	public void clearSeenFlags()
	{
	    for (int i = 0; i < selectors.length; i++)
	    {
		selectors[i].seen = false;
	    }
	}

	public Selector[]  selectors;
	public int  numSelectorsAdded;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class Selector
    {
	public Selector(String name)
	{
	    this.name = name;
	}

	public SelectorMapping addSelectorMapping
	    (String characteristic, int filter,
	     boolean node, boolean link, boolean path)
	{
	    SelectorMapping retval = new SelectorMapping
		(characteristic, filter, node, link, path);
	    retval.next = selectorMappings;
	    selectorMappings = retval;
	    return retval;
	}

	public void clearSeenFlags()
	{
	    SelectorMapping selectorMapping = selectorMappings;
	    while (selectorMapping != null)
	    {
		selectorMapping.seen = false;
		selectorMapping = selectorMapping.next;
	    }
	}

	public SelectorMapping find(String characteristic)
	{
	    SelectorMapping selectorMapping = selectorMappings;
	    while (selectorMapping != null)
	    {
		if (selectorMapping.characteristic.equals(characteristic))
		{
		    return selectorMapping;
		}
		selectorMapping = selectorMapping.next;
	    }
	    return null;
	}

	public boolean  seen;
	public String  name;
	public SelectorMapping  selectorMappings;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class SelectorMapping
    {
	public SelectorMapping(String characteristic, int filter,
			      boolean node, boolean link, boolean path)
	{
	    this.characteristic = characteristic;
	    this.filter = filter;
	    this.node = node;
	    this.link = link;
	    this.path = path;
	}

	public boolean  seen;
	public String  characteristic;
	public int  filter;
	public boolean  node;
	public boolean  link;
	public boolean  path;
	public SelectorMapping  next;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class Presentation
    {
	public Presentation(String name, int display, int selector)
	{
	    this.name = name;
	    this.display = display;
	    this.selector = selector;
	}

	public boolean  seen;
	public String  name;
	public int  display;
	public int  selector;
    }

    ///////////////////////////////////////////////////////////////////////

    private static class Menu
    {
	public Menu(int level, String label, int id)
	{
	    this.level = level;
	    this.label = label;
	    this.id = id;
	}

	public Menu addSubmenu(String label, int id)
	{
	    Menu retval = new Menu(level + 1, label, id);
	    if (tail == null)
	    {
		submenus = tail = retval;
	    }
	    else
	    {
		tail.next = retval;
		tail = retval;
	    }
	    return retval;
	}

	public int  level;
	public String  label;
	public int  id;
	public Menu  next;
	public Menu  submenus;
	public Menu  tail;
    }

    ///////////////////////////////////////////////////////////////////////

    private class MenuProbability
    {
	public MenuProbability(int maxDepth, int numTopLevelSubmenus,
			       int maxNumSubmenus, float probability)
	{
	    if (probability < 0.0f || probability > 1.0f)
	    {
		throw new IllegalArgumentException("bad probability");
	    }

	    m_maxDepth = maxDepth;
	    m_numTopLevelSubmenus = numTopLevelSubmenus;
	    m_maxNumSubmenus = maxNumSubmenus;
	    m_probability = probability;
	}

	public int getNumSubmenus(int level)
	{
	    int retval = 0;

	    if (level < m_maxDepth)
	    {
		if (level == 0)
		{
		    retval = m_numTopLevelSubmenus;
		}
		else
		{
		    if (m_random.nextFloat() < m_probability)
		    {
			retval = m_random.nextInt(m_maxNumSubmenus) + 1;
		    }
		}
	    }

	    return retval;
	}

	private int  m_maxDepth;
	private int  m_numTopLevelSubmenus;
	private int  m_maxNumSubmenus;
	private float  m_probability;
    }

    ///////////////////////////////////////////////////////////////////////

    private class TypeGenerator
    {
	public int getNumTypes()
	{
	    return NUM_ALL_TYPES;
	}

	public ValueType getTypeByNumber(int n)
	{
	    if (n < 0 || n >= NUM_ALL_TYPES)
	    {
		throw new IllegalArgumentException();
	    }
	    return m_allTypes[n];
	}

	public void generateAny(int numEnumerations)
	{
	    generate(numEnumerations, m_allTypes,
		     NUM_ALL_TYPES, NUM_ALL_NONENUMERATION_TYPES);
	}

	public void generateScalar(int numEnumerations)
	{
	    generate(numEnumerations, m_scalarTypes,
		     NUM_SCALAR_TYPES, NUM_SCALAR_NONENUMERATION_TYPES);
	}

	public void generateList(int numEnumerations)
	{
	    generate(numEnumerations, m_listTypes,
		     NUM_LIST_TYPES, NUM_LIST_NONENUMERATION_TYPES);
	}

	public ValueType getType()
	{
	    return m_type;
	}

	public int getEnumeration()
	{
	    return m_enumeration;
	}

	private void generate(int numEnumerations, ValueType[] types,
			      int numTypes, int numNonenumerationTypes)
	{
	    int index = m_random.nextInt(numEnumerations > 0 ? numTypes
					 : numNonenumerationTypes);
	    m_type = types[index];
	    m_enumeration = (m_type.isEnumerationType()
			     ? m_random.nextInt(numEnumerations) : -1);
	}

	private final ValueType[]  m_allTypes =
	{
	    ValueType.BOOLEAN, ValueType.INTEGER, ValueType.FLOAT,
	    ValueType.DOUBLE, ValueType.STRING, ValueType.FLOAT3,
	    ValueType.DOUBLE3, 

	    ValueType.BOOLEAN_LIST, ValueType.INTEGER_LIST,
	    ValueType.FLOAT_LIST, ValueType.DOUBLE_LIST,
	    ValueType.STRING_LIST, ValueType.FLOAT3_LIST,
	    ValueType.DOUBLE3_LIST,

	    ValueType.ENUMERATION, ValueType.ENUMERATION_LIST
	};

	private final ValueType[]  m_scalarTypes =
	{
	    ValueType.BOOLEAN, ValueType.INTEGER, ValueType.FLOAT,
	    ValueType.DOUBLE, ValueType.STRING, ValueType.FLOAT3,
	    ValueType.DOUBLE3, 

	    ValueType.ENUMERATION
	};

	private final ValueType[]  m_listTypes =
	{
	    ValueType.BOOLEAN_LIST, ValueType.INTEGER_LIST,
	    ValueType.FLOAT_LIST, ValueType.DOUBLE_LIST,
	    ValueType.STRING_LIST, ValueType.FLOAT3_LIST,
	    ValueType.DOUBLE3_LIST,

	    ValueType.ENUMERATION_LIST
	};

	private static final int  NUM_ALL_TYPES = 16;
	private static final int  NUM_ALL_NONENUMERATION_TYPES =
	    NUM_ALL_TYPES - 2;

	private static final int  NUM_SCALAR_TYPES = 8;
	private static final int  NUM_SCALAR_NONENUMERATION_TYPES =
	    NUM_SCALAR_TYPES - 1;

	private static final int  NUM_LIST_TYPES = 8;
	private static final int  NUM_LIST_NONENUMERATION_TYPES =
	    NUM_LIST_TYPES - 1;

	private ValueType  m_type;
	private int m_enumeration;
    }
}
