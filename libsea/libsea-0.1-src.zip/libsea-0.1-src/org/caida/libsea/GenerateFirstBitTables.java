// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

public class GenerateFirstBitTables
{
    public static void main(String[] args)
    {
	int[] t1 = computeFindFirstClearedBitTable();
	if (checkFindFirstClearedBitTable(t1))
	{
	    int[] t2 = computeSetFirstClearedBitTable(t1);
	    if (checkSetFirstClearedBitTable(t1, t2))
	    {
		int[] t3 = computeFindLastSetBitTable();
		if (checkFindLastSetBitTable(t3))
		{
		    int[] t4 = computeClearLastSetBitTable(t3);
		    if (checkClearLastSetBitTable(t3, t4))
		    {
			generateFindFirstClearedBitTable(t1);
			generateSetFirstClearedBitTable(t2);
			generateFindLastSetBitTable(t3);
			generateClearLastSetBitTable(t4);
		    }
		}
	    }
	}
    }

    private static int[] computeFindFirstClearedBitTable()
    {
	int[] retval = new int[256];

	retval[255] = -1;
	for (int i = 0; i < 255; i++)
	{
	    int p = 0;
	    int n = i;
	    while ((n & 0x1) == 0x1)
	    {
		++p;
		n >>= 1;
	    }

	    retval[i] = p;
	}

	return retval;
    }

    private static boolean checkFindFirstClearedBitTable(int[] table)
    {
	int[] masks = { 1, 3, 7, 15, 31, 63, 127, 255 };
	int[] values = { 0, 1, 3, 7, 15, 31, 63, 127 };

	for (int i = 0; i < 255; i++)
	{
	    if ((i & masks[table[i]]) != values[table[i]])
	    {
		System.out.println("FindFirstClearedBitTable["
				   + i + "] is wrong.");
		return false;
	    }
	}

	return true;
    }

    private static int[] computeSetFirstClearedBitTable(int[] table)
    {
	int[] bits = { 1, 2, 4, 8, 16, 32, 64, 128 };
	int[] retval = new int[256];

	retval[255] = 0xFF;
	for (int i = 0; i < 255; i++)
	{
	    retval[i] = i | bits[table[i]];
	}

	return retval;
    }

    private static boolean checkSetFirstClearedBitTable(int[] findTable,
							int[] setTable)
    {
	int[] bits = { 1, 2, 4, 8, 16, 32, 64, 128 };

	for (int i = 0; i < 255; i++)
	{
	    if ((i ^ setTable[i]) != bits[findTable[i]])
	    {
		System.out.println("SetFirstClearedBitTable["
				   + i + "] is wrong.");
		return false;
	    }
	}

	return true;
    }

    private static int[] computeFindLastSetBitTable()
    {
	int[] retval = new int[256];

	retval[0] = -1;
	for (int i = 1; i < 256; i++)
	{
	    int p = 0;
	    for (int n = i, j = 0; j < 8; j++, n >>= 1)
	    {
		if ((n & 0x1) == 0x1)
		{
		    p = j;
		}
	    }

	    retval[i] = p;
	}

	return retval;
    }

    private static boolean checkFindLastSetBitTable(int[] table)
    {
	int[] masks = { 255, 255-1, 255-3, 255-7, 255-15,
			255-31, 255-63, 255-127 };
	int[] values = { 1, 2, 4, 8, 16, 32, 64, 128 };

	for (int i = 1; i < 256; i++)
	{
	    if ((i & masks[table[i]]) != values[table[i]])
	    {
		System.out.println("FindLastSetBitTable[" + i + "] is wrong.");
		return false;
	    }
	}

	return true;
    }

    private static int[] computeClearLastSetBitTable(int[] table)
    {
	int[] bits = { 1, 2, 4, 8, 16, 32, 64, 128 };
	int[] retval = new int[256];

	retval[0] = 0;
	for (int i = 1; i < 256; i++)
	{
	    retval[i] = i & ~bits[table[i]];
	}

	return retval;
    }

    private static boolean checkClearLastSetBitTable(int[] findTable,
						     int[] clearTable)
    {
	int[] bits = { 1, 2, 4, 8, 16, 32, 64, 128 };

	for (int i = 1; i < 256; i++)
	{
	    if ((i ^ clearTable[i]) != bits[findTable[i]])
	    {
		System.out.println("ClearLastSetBitTable["
				   + i + "] is wrong.");
		return false;
	    }
	}

	return true;
    }


    private static void generateFindFirstClearedBitTable(int[] table)
    {
	System.out.println("    private static final int[] FIND_FIRST_CLEARED_BIT = ");
	System.out.println("    {");
	generateTable2(table);
	System.out.println("    };");
    }

    private static void generateSetFirstClearedBitTable(int[] table)
    {
	System.out.println("    private static final int[] SET_FIRST_CLEARED_BIT = ");
	System.out.println("    {");
	generateTable(table);
	System.out.println("    };");
    }

    private static void generateFindLastSetBitTable(int[] table)
    {
	System.out.println("    private static final int[] FIND_LAST_SET_BIT = ");
	System.out.println("    {");
	generateTable2(table);
	System.out.println("    };");
    }

    private static void generateClearLastSetBitTable(int[] table)
    {
	System.out.println("    private static final int[] CLEAR_LAST_SET_BIT = ");
	System.out.println("    {");
	generateTable(table);
	System.out.println("    };");
    }

    private static void generateTable(int[] table)
    {
	for (int i = 0; i < 32; i++)
	{
	    System.out.print("        ");
	    for (int j = 0; j < 8; j++)
	    {
		int n = i * 8 + j;

		System.out.print(table[n]);

		if (i < 31 || j < 7)
		{
		    System.out.print(", ");
		}
	    }
	    System.out.println();
	}
    }

    private static void generateTable2(int[] table)
    {
	for (int i = 0; i < 16; i++)
	{
	    System.out.print("        ");
	    for (int j = 0; j < 16; j++)
	    {
		int n = i * 16 + j;

		System.out.print(table[n]);

		if (i < 16 || j < 16)
		{
		    System.out.print(", ");
		}
	    }
	    System.out.println();
	}
    }
}
