// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

class GrowableIntArray
{
    ///////////////////////////////////////////////////////////////////////
    // PUBLIC INTERFACES
    ///////////////////////////////////////////////////////////////////////

    public interface ParallelSortable
    {
	void swap(int i, int j);
    }

    ////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ////////////////////////////////////////////////////////////////////////

    public GrowableIntArray()
    {
	this(DEFAULT_SEGMENT_SIZE);
    }

    // {segmentSize} must be a power of 2.
    public GrowableIntArray(int segmentSize)
    {
	if (segmentSize < MIN_SEGMENT_SIZE)
	{
	    segmentSize = MIN_SEGMENT_SIZE;
	}

	if ((segmentSize & -segmentSize) != segmentSize)
	{
	    String msg = "segmentSize must be a power of 2";
	    throw new IllegalArgumentException(msg);
        }

	m_segmentSize = segmentSize;
	m_segmentMask = segmentSize - 1;
	m_segmentSizeBits = MiscMath.log2(m_segmentSize);
    }

    ////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ////////////////////////////////////////////////////////////////////////

    public boolean isEmpty()
    {
	return getNumAllocated() == 0;
    }

    public int getValue(int index)
    {
	if (index >= m_numAllocatedSlots)
	{
	    throw new UnallocatedElementException();
	}

	return getValueUnchecked(index);
    }

    public void setValue(int index, int value)
    {
	if (index >= m_numAllocatedSlots)
	{
	    throw new UnallocatedElementException();
	}

	setValueUnchecked(index, value);
    }

    public int append(int value)
    {
	if (m_numAllocatedSlots == m_numUsableSlots)
	{
	    if (m_numAllocatedSegments == m_segments.length)
	    {
		expandSegmentsArray();
	    }

	    m_segments[m_numAllocatedSegments++] = new int[m_segmentSize];
	    m_numUsableSlots += m_segmentSize;
	}

	// Using running counters of the segment and offset at which
	// to append rather than always calling setValueUnchecked() saves
	// only about 22ms when doing a million appends (bringing down the
	// running time from about 140ms to 118ms).  That is to say, it
	// is not worth it.  I conjecture that the execution time is
	// dominated by memory allocation.

	setValueUnchecked(m_numAllocatedSlots, value);
	return m_numAllocatedSlots++;
    }

    public void clear()
    {
	m_numAllocatedSegments = 0;
	m_segments = new int[STARTING_NUM_SEGMENTS][];
	m_numUsableSlots = 0;
	m_numAllocatedSlots = 0;
    }

    public int getNumAllocated()
    {
	return m_numAllocatedSlots;
    }

    public int getNumFree()
    {
	return m_numAllocatedSegments * m_segmentSize - m_numAllocatedSlots;
    }

    /**
     * Sorts all elements in ascending order.
     */
    public void qsort()
    {
	quicksort(0, m_numAllocatedSlots - 1);
    }

    /**
     * Sorts all elements in ascending order, with any exchanges also
     * carried out in parallel on the given ParallelSortable.
     */
    public void qsort(ParallelSortable sortable)
    {
	quicksort(0, m_numAllocatedSlots - 1, sortable);
    }

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive,
     * in ascending order.
     */
    public void qsort(int start, int end)
    {
	if (start < 0 || start > end || end >= m_numAllocatedSlots)
	{
	    throw new IllegalArgumentException();
	}
	quicksort(start, end);
    }

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive,
     * in ascending order, with any exchanges also carried out in parallel
     * on the given ParallelSortable.
     */
    public void qsort(int start, int end, ParallelSortable sortable)
    {
	if (start < 0 || start > end || end >= m_numAllocatedSlots)
	{
	    throw new IllegalArgumentException();
	}
	quicksort(start, end, sortable);
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ////////////////////////////////////////////////////////////////////////

    private int getValueUnchecked(int index)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = index & m_segmentMask;

	return m_segments[segment][offset];
    }

    private void setValueUnchecked(int index, int value)
    {
	int segment = index >> m_segmentSizeBits;
	int offset = index & m_segmentMask;

	m_segments[segment][offset] = value;
    }

    private void expandSegmentsArray()
    {
	int[][] oldSegments = m_segments;
	m_segments = new int[oldSegments.length * 2][];
	System.arraycopy(oldSegments, 0, m_segments, 0, oldSegments.length);
    }

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive.
     *
     * <p>
     * This uses the same implementation of Quicksort as Sorter.iqsort()
     * except specialized to GrowableIntArray.
     * </p>
     *
     * <p>
     * When sorting a million integers under various distributions,
     * this "typically" takes about 1.5 times as long as Sorter.iqsort(),
     * the Quick Sort specialized for integers, which in turn takes about
     * 1.3 times as long as java.util.Arrays.sort().  Hence, this is about
     * twice (1.5 * 1.3 = 1.95) as slow as the Java sort().  In the same
     * scenario, ArrayPerformance.giqsort(), the Quick Sort specialized for
     * GrowableIntArray, takes about 2.0 times as long as this version,
     * and Sorter.qsort() takes about 4.5 times as long.  Hence, when
     * sorting a million integers, using this version instead of
     * Sorter.qsort() can result in a savings of between 2 to 8 seconds.
     * </p>
     *
     * <p>
     * See class ArrayPerformance for testing and timing code.
     * </p>
     */
    private void quicksort(int start, int end)
    {
	int n = end - start + 1;
	if (n <= 1) { return; }
	if (n < QSORT_INSERTION_THRESHOLD)
	{
	    // Perform insertion sort.
	    for (int i = start + 1; i <= end; i++)
	    {
		int segment = i >> m_segmentSizeBits;
		int offset = i & m_segmentMask;

		for (int j = i - 1; j >= start; j--)
		{
		    int newSegment = j >> m_segmentSizeBits;
		    int newOffset = j & m_segmentMask;

		    int dj_plus_1 = m_segments[segment][offset];
		    int dj = m_segments[newSegment][newOffset];

		    if (dj > dj_plus_1)
		    {
			// Swap elements at [j] and [j+1].
			m_segments[segment][offset] = dj;
			m_segments[newSegment][newOffset] = dj_plus_1;

			segment = newSegment;
			offset = newOffset;
		    }
		    else
		    {
			break;
		    }
		}
	    }
	}
	else
	{
	    int pm = start + n / 2;  // For small arrays, use middle element.
	    if (n > QSORT_MEDIUM_THRESHOLD)
	    {
		if (n > QSORT_LARGE_THRESHOLD)
		{
		    // For large arrays, use pseudomedian of 9 elements.
		    int s = n / 8;
		    int p1 = median3(start, start + s, start + 2 * s);
		    pm = median3(pm - s, pm, pm + s);
		    int pn = median3(end - 2 * s, end - s, end);
		    pm = median3(p1, pm, pn);
		}
		else
		{
		    // For medium arrays...
		    pm = median3(start, pm, end);
		}
	    }

	    int startSegment = start >> m_segmentSizeBits;
	    int startOffset = start & m_segmentMask;

	    int dv; // The pivot.
	    {
		int medianSegment = pm >> m_segmentSizeBits;
		int medianOffset = pm & m_segmentMask;

		// Swap elements at [start] and [pm].
		dv = m_segments[medianSegment][medianOffset];
		int t = m_segments[startSegment][startOffset];
		m_segments[startSegment][startOffset] = dv;
		m_segments[medianSegment][medianOffset] = t;
	    }

	    int a = start + 1;   int b = start + 1;
	    int c = end;         int d = end;

	    int segmentA = a >> m_segmentSizeBits;
	    int offsetA = a & m_segmentMask;

	    int segmentB = b >> m_segmentSizeBits;
	    int offsetB = b & m_segmentMask;

	    int segmentC = c >> m_segmentSizeBits;
	    int offsetC = c & m_segmentMask;

	    int segmentD = d >> m_segmentSizeBits;
	    int offsetD = d & m_segmentMask;

	    for (;;)
	    {
		while (b <= c)
		{
		    int db = m_segments[segmentB][offsetB];
		    int result = (db < dv ? -1 : db == dv ? 0 : 1);
		    if (result > 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    // Swap elements at [a] and [b].
			    m_segments[segmentB][offsetB] =
				m_segments[segmentA][offsetA];
			    m_segments[segmentA][offsetA] = db;

			    ++a;
			    if (++offsetA == m_segmentSize)
			    { ++segmentA;  offsetA = 0; }
			}
			++b;
			if (++offsetB == m_segmentSize)
			{ ++segmentB;  offsetB = 0; }
		    }
		}

		while (c >= b)
		{
		    int dc = m_segments[segmentC][offsetC];
		    int result = (dc < dv ? -1 : dc == dv ? 0 : 1);
		    if (result < 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    // Swap elements at [c] and [d].
			    m_segments[segmentC][offsetC] =
				m_segments[segmentD][offsetD];
			    m_segments[segmentD][offsetD] = dc;

			    --d;
			    if (offsetD == 0)
			    { --segmentD;  offsetD = m_segmentSize - 1; }
			    else { --offsetD; }
			}
			--c;
			if (offsetC == 0)
			{ --segmentC;  offsetC = m_segmentSize - 1; }
			else { --offsetC; }
		    }
		}

		if (b > c) { break; }

		{
		    // Swap elements at [b] and [c].
		    int t = m_segments[segmentB][offsetB];
		    m_segments[segmentB][offsetB] =
			m_segments[segmentC][offsetC];
		    m_segments[segmentC][offsetC] = t;
		}
		b++;
		if (++offsetB == m_segmentSize) { ++segmentB;  offsetB = 0; }

		c--;
		if (offsetC == 0) { --segmentC; offsetC = m_segmentSize - 1; }
		else { --offsetC; }
	    }

	    {
		int s = Math.min(a - start, b - a);
		int l = start;  int h = b - s;

		int fromSegment = startSegment;
		int fromOffset = startOffset;

		int toSegment = h >> m_segmentSizeBits;
		int toOffset = h & m_segmentMask;

		while (s > 0)
		{
		    // Swap elements at [from] and [to].
		    int t = m_segments[fromSegment][fromOffset];
		    m_segments[fromSegment][fromOffset] =
			m_segments[toSegment][toOffset];
		    m_segments[toSegment][toOffset] = t;

		    // Advance from and to (corresponds to l++, h++).
		    if (++fromOffset == m_segmentSize)
		    { ++fromSegment;  fromOffset = 0; }

		    if (++toOffset == m_segmentSize)
		    { ++toSegment;  toOffset = 0; }

		    --s;
		}
	    }

	    {
		int s = Math.min(d - c, end - d);
		int l = b;  int h = end - s + 1;

		int fromSegment = segmentB;
		int fromOffset = offsetB;

		int toSegment = h >> m_segmentSizeBits;
		int toOffset = h & m_segmentMask;

		while (s > 0)
		{
		    // Swap elements at [from] and [to].
		    int t = m_segments[fromSegment][fromOffset];
		    m_segments[fromSegment][fromOffset] =
			m_segments[toSegment][toOffset];
		    m_segments[toSegment][toOffset] = t;

		    // Advance from and to (corresponds to l++, h++);
		    if (++fromOffset == m_segmentSize)
		    { ++fromSegment;  fromOffset = 0; }

		    if (++toOffset == m_segmentSize)
		    { ++toSegment;  toOffset = 0; }

		    --s;
		}
	    }

	    quicksort(start, start + b - a - 1);
	    quicksort(end - (d - c) + 1, end);
	}
    }

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive,
     * with any exchanges also carried out in parallel on the given
     * ParallelSortable.
     *
     * <p>
     * This version is usually a few hundred milliseconds slower than
     * the version not taking a ParallelSortable argument when sorting
     * a million values.  This translates to an increase of around 50%
     * in the running time in certain cases.  Of course, the difference
     * becomes negligible as running time becomes more than a few seconds.
     * The value of having a separate version is therefore debateable,
     * but it may prove useful in cutting the total running time of
     * programs that must sort many large sets of values in a single session.
     * </p>
     */
    private void quicksort(int start, int end, ParallelSortable sortable)
    {
	int n = end - start + 1;
	if (n <= 1) { return; }
	if (n < QSORT_INSERTION_THRESHOLD)
	{
	    // Perform insertion sort.
	    for (int i = start + 1; i <= end; i++)
	    {
		int segment = i >> m_segmentSizeBits;
		int offset = i & m_segmentMask;

		for (int j = i - 1; j >= start; j--)
		{
		    int newSegment = j >> m_segmentSizeBits;
		    int newOffset = j & m_segmentMask;

		    int dj_plus_1 = m_segments[segment][offset];
		    int dj = m_segments[newSegment][newOffset];

		    if (dj > dj_plus_1)
		    {
			sortable.swap(j, j + 1);

			// Swap elements at [j] and [j+1].
			m_segments[segment][offset] = dj;
			m_segments[newSegment][newOffset] = dj_plus_1;

			segment = newSegment;
			offset = newOffset;
		    }
		    else
		    {
			break;
		    }
		}
	    }
	}
	else
	{
	    int pm = start + n / 2;  // For small arrays, use middle element.
	    if (n > QSORT_MEDIUM_THRESHOLD)
	    {
		if (n > QSORT_LARGE_THRESHOLD)
		{
		    // For large arrays, use pseudomedian of 9 elements.
		    int s = n / 8;
		    int p1 = median3(start, start + s, start + 2 * s);
		    pm = median3(pm - s, pm, pm + s);
		    int pn = median3(end - 2 * s, end - s, end);
		    pm = median3(p1, pm, pn);
		}
		else
		{
		    // For medium arrays...
		    pm = median3(start, pm, end);
		}
	    }

	    int startSegment = start >> m_segmentSizeBits;
	    int startOffset = start & m_segmentMask;

	    int dv; // The pivot.
	    {
		int medianSegment = pm >> m_segmentSizeBits;
		int medianOffset = pm & m_segmentMask;

		sortable.swap(start, pm);

		// Swap elements at [start] and [pm].
		dv = m_segments[medianSegment][medianOffset];
		int t = m_segments[startSegment][startOffset];
		m_segments[startSegment][startOffset] = dv;
		m_segments[medianSegment][medianOffset] = t;
	    }

	    int a = start + 1;   int b = start + 1;
	    int c = end;         int d = end;

	    int segmentA = a >> m_segmentSizeBits;
	    int offsetA = a & m_segmentMask;

	    int segmentB = b >> m_segmentSizeBits;
	    int offsetB = b & m_segmentMask;

	    int segmentC = c >> m_segmentSizeBits;
	    int offsetC = c & m_segmentMask;

	    int segmentD = d >> m_segmentSizeBits;
	    int offsetD = d & m_segmentMask;

	    for (;;)
	    {
		while (b <= c)
		{
		    int db = m_segments[segmentB][offsetB];
		    int result = (db < dv ? -1 : db == dv ? 0 : 1);
		    if (result > 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    sortable.swap(a, b);

			    // Swap elements at [a] and [b].
			    m_segments[segmentB][offsetB] =
				m_segments[segmentA][offsetA];
			    m_segments[segmentA][offsetA] = db;

			    ++a;
			    if (++offsetA == m_segmentSize)
			    { ++segmentA;  offsetA = 0; }
			}
			++b;
			if (++offsetB == m_segmentSize)
			{ ++segmentB;  offsetB = 0; }
		    }
		}

		while (c >= b)
		{
		    int dc = m_segments[segmentC][offsetC];
		    int result = (dc < dv ? -1 : dc == dv ? 0 : 1);
		    if (result < 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    sortable.swap(c, d);

			    // Swap elements at [c] and [d].
			    m_segments[segmentC][offsetC] =
				m_segments[segmentD][offsetD];
			    m_segments[segmentD][offsetD] = dc;

			    --d;
			    if (offsetD == 0)
			    { --segmentD;  offsetD = m_segmentSize - 1; }
			    else { --offsetD; }
			}
			--c;
			if (offsetC == 0)
			{ --segmentC;  offsetC = m_segmentSize - 1; }
			else { --offsetC; }
		    }
		}

		if (b > c) { break; }

		{
		    sortable.swap(b, c);

		    // Swap elements at [b] and [c].
		    int t = m_segments[segmentB][offsetB];
		    m_segments[segmentB][offsetB] =
			m_segments[segmentC][offsetC];
		    m_segments[segmentC][offsetC] = t;
		}
		b++;
		if (++offsetB == m_segmentSize) { ++segmentB;  offsetB = 0; }

		c--;
		if (offsetC == 0) { --segmentC; offsetC = m_segmentSize - 1; }
		else { --offsetC; }
	    }

	    {
		int s = Math.min(a - start, b - a);
		int l = start;  int h = b - s;

		int fromSegment = startSegment;
		int fromOffset = startOffset;

		int toSegment = h >> m_segmentSizeBits;
		int toOffset = h & m_segmentMask;

		while (s > 0)
		{
		    sortable.swap(l++, h++);

		    // Swap elements at [from] and [to].
		    int t = m_segments[fromSegment][fromOffset];
		    m_segments[fromSegment][fromOffset] =
			m_segments[toSegment][toOffset];
		    m_segments[toSegment][toOffset] = t;

		    // Advance from and to (corresponds to l++, h++).
		    if (++fromOffset == m_segmentSize)
		    { ++fromSegment;  fromOffset = 0; }

		    if (++toOffset == m_segmentSize)
		    { ++toSegment;  toOffset = 0; }

		    --s;
		}
	    }

	    {
		int s = Math.min(d - c, end - d);
		int l = b;  int h = end - s + 1;

		int fromSegment = segmentB;
		int fromOffset = offsetB;

		int toSegment = h >> m_segmentSizeBits;
		int toOffset = h & m_segmentMask;

		while (s > 0)
		{
		    sortable.swap(l++, h++);

		    // Swap elements at [from] and [to].
		    int t = m_segments[fromSegment][fromOffset];
		    m_segments[fromSegment][fromOffset] =
			m_segments[toSegment][toOffset];
		    m_segments[toSegment][toOffset] = t;

		    // Advance from and to (corresponds to l++, h++).
		    if (++fromOffset == m_segmentSize)
		    { ++fromSegment;  fromOffset = 0; }

		    if (++toOffset == m_segmentSize)
		    { ++toSegment;  toOffset = 0; }

		    --s;
		}
	    }

	    quicksort(start, start + b - a - 1, sortable);
	    quicksort(end - (d - c) + 1, end, sortable);
	}
    }

    private int median3(int i, int j, int k)
    {
	int di = getValueUnchecked(i);
	int dj = getValueUnchecked(j);
	int dk = getValueUnchecked(k);
	return di < dj
	    ? (dj < dk ? j : di < dk ? k : i)
	    : (dj > dk ? j : di > dk ? k : i);
    }

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE CONSTANTS
    ////////////////////////////////////////////////////////////////////////

    private static final int QSORT_INSERTION_THRESHOLD = 7;
    private static final int QSORT_MEDIUM_THRESHOLD = 7;
    private static final int QSORT_LARGE_THRESHOLD = 40;

    private static final boolean DEBUG = true;

    private static final int STARTING_NUM_SEGMENTS = 512;
    private static final int DEFAULT_SEGMENT_SIZE = 1024;
    private static final int MIN_SEGMENT_SIZE = 128;

    ////////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ////////////////////////////////////////////////////////////////////////

    private int  m_numAllocatedSegments = 0;
    private int[][]  m_segments = new int[STARTING_NUM_SEGMENTS][];
    private final int  m_segmentSize;
    private final int  m_segmentMask;
    private final int  m_segmentSizeBits;

    private int  m_numUsableSlots = 0;
    private int  m_numAllocatedSlots = 0;
}
