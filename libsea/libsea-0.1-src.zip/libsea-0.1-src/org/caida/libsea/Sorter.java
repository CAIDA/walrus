// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.Random;

/**
 * A class for sorting arbitrary data structures.
 *
 * <p>
 * Java provides methods in Arrays and Collections for sorting arrays of
 * primitive types and data in List objects.  These are very useful when
 * applicable.  There are, however, many common situations where they aren't
 * applicable, and it is a shame that Java doesn't include a more general
 * mechanism to satisfy these remaining needs.  This class is an attempt
 * at filling in the gap.
 * </p>
 *
 * <p>
 * This class implements the Quicksort algorithm as described in Jon Louis
 * Bentley and M. Douglas McIlroy's article, "Engineering a Sort Function,"
 * Software Practice & Experience, v23, n11, Nov 1993, pp 1249-1265.  This is
 * the same algorithm that Sun used in their implementation of Arrays.sort().
 * However, this class is an independent implementation based solely on that
 * article and does not incorporate any code from Sun's implementation.  I
 * have not even looked at the source of Sun's implementation, nor anyone
 * else's implementation, with the exception of the implementation given
 * in the article, of course.  Finally, the testing methodology employed
 * here also has its origin in the article.
 * </p>
 */
class Sorter
{
    ///////////////////////////////////////////////////////////////////////
    // PUBLIC INTERFACES
    ///////////////////////////////////////////////////////////////////////

    public interface Sortable
    {
	int compare(int i, int j);
	void swap(int i, int j);
    }

    ///////////////////////////////////////////////////////////////////////
    // PUBLIC STATIC METHODS
    ///////////////////////////////////////////////////////////////////////

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive,
     * using insertion sort (O(n**2)).
     *
     * <p>
     * Due to the quadratic running time in the worst case, this should
     * almost never be used.  The exception is when sorting a "small" number
     * of items, where "small" must be interpreted.
     * </p>
     */
    public static void isort(Sortable data, int start, int end)
    {
	for (int i = start + 1; i <= end; i++)
	{
	    for (int j = i; j > start && data.compare(j - 1, j) > 0; j--)
	    {
		data.swap(j - 1, j);
	    }
	}
    }

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive,
     * using shellsort (O(n**(4/3)) worst case using Sedgewick's increments).
     *
     * <p>
     * Testing shows this to be up to 10 times slower than qsort() when
     * sorting a million integers under various distributions (see
     * SorterTester).  This is sometimes slower than qsort() even on
     * already sorted data.  Also, this often does many more swaps than
     * qsort() (except on already sorted data, where it does none) which
     * could make it a lot slower on large elements.  Nevertheless, there
     * are occasions where ssort() is competitive (no more than about twice
     * the runtime) with qsort(), if not actually a little better.  For
     * instance, it seems to be competitive on the staggered and shuffled
     * distributions, and slightly better than qsort() when these
     * distributions are already sorted.
     * </p>
     *
     * <p>
     * In general, ssort() seems to perform worse than qsort() when there
     * are few distinct elements (for example, when sorting a million integers
     * where each is between 0 and 10), and on these occasions, ssort() may
     * take 10 times longer.  When there are many distinct elements, however,
     * ssort() seems competitive with qsort(), often being a little better
     * to just 3 times slower.
     * </p>
     */
    public static void ssort(Sortable data, int start, int end)
    {
	shellsort(m_sedgewickSequence, data, start, end);
    }

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive,
     * using an implementation of Quicksort that uses split-end partitioning
     * and an insertion sort for small subarrays.
     *
     * <p>
     * This corresponds to Program 7 in [Bentley & McIlroy], their final
     * version, exclusive of the use of vecswp() and all their optimizations
     * involving macros.  For instance, no attempt is made to store the pivot
     * in a separate variable instead of at the lowest slot in a given range.
     * </p>
     *
     * <p>
     * Timings in SorterTester show that qsort() usually takes roughly
     * between 2.2 and 2.6 times as long as java.util.Arrays.sort() to sort
     * a million integers under various distributions.  There are, of course,
     * cases where qsort() runs at less than 2.2 times or greater than 2.6
     * times the Java sort().  The method iqsort(), which works directly on
     * an integer array rather than taking a Sortable, and which uses the
     * same algorithm as qsort(), usually takes between 1.2 to 1.5 times
     * as long as the Java sort().  This suggests that qsort() is
     * approximately 1.5 to 2.5 times slower than iqsort(), at least when
     * the number of elements to sort is so small that the overhead of
     * calling through an interface is significant.  A million is considered
     * "small" in this way, at least when the elements are integers which
     * are cheap to swap and compare.
     * </p>
     *
     * <p>
     * For some unknown reason, it usually takes qsort() between 7 and 8
     * times as long to sort a GrowableIntArray as the Java sort() takes to
     * sort an equivalent integer array.  Obviously, accessing data indirectly
     * through first the Sortable interface and then through the
     * GrowableIntArray class cannot but slow down the sort.  For this reason,
     * GrowableIntArray has a qsort() method itself, which does indeed run
     * considerably faster, taking around twice as long as the Java sort().
     * </p>
     */
    public static void qsort(Sortable data, int start, int end)
    {
	int n = end - start + 1;
	if (n <= 1) { return; }
	if (n < QSORT_INSERTION_THRESHOLD)
	{
	    // Perform insertion sort.
	    for (int i = start + 1; i <= end; i++)
	    {
		for (int j = i; j > start && data.compare(j - 1, j) > 0; j--)
		{
		    data.swap(j, j - 1);
		}
	    }
	}
	else
	{
	    // Choose the pivot.
	    int pm = start + n / 2;  // For small arrays, use middle element.
	    if (n > QSORT_MEDIUM_THRESHOLD)
	    {
		if (n > QSORT_LARGE_THRESHOLD)
		{
		    // For large arrays, use pseudomedian of 9 elements.
		    int s = n / 8;
		    int p1 = median3(data, start, start + s, start + 2 * s);
		    pm = median3(data, pm - s, pm, pm + s);
		    int pn = median3(data, end - 2 * s, end - s, end);
		    pm = median3(data, p1, pm, pn);
		}
		else
		{
		    // For medium arrays...
		    pm = median3(data, start, pm, end);
		}
	    }

	    data.swap(start, pm);

	    int v = start;  // The index of the pivot.
	    int a = start + 1;   int b = start + 1;
	    int c = end;         int d = end;

	    // This loop implements split-end partitioning, whereby all the
	    // elements in the range that are equal to the pivot are first
	    // temporarily moved to either end and then finally combined at
	    // the center prior to the recursive calls.
	    //
	    //  initial:    [ P | ? ? ? ? ? ? ? ? ? ? ? ? ? ? ? ? ? ]
	    //                v  ab                               cd
	    //
	    //  scanning:   [ P = = | < < < | ? ? ? | > > > | = = = ]
	    //                v      a       b     c       d
	    //
	    //  cross over: [ P = = | < < < < < < > > > > > | = = = ]
	    //                v      a          c b        d
	    //
	    //  final:      [ < < < < < < = = = = = = > > > > > ]
	    for (;;)
	    {
		// Scan from left to right, passing over elements < the pivot
		// and packing elements equal to the pivot at the left end of
		// the range.
		while (b <= c)
		{
		    int result = data.compare(b, v);
		    if (result > 0) { break; }
		    else
		    {
			if (result == 0) { data.swap(a++, b); }
			++b;
		    }
		}

		// Scan from right to left, passing over elements > the pivot
		// and packing elements equal to the pivot at the right end of
		// the range.
		while (c >= b)
		{
		    int result = data.compare(c, v);
		    if (result < 0) { break; }
		    else
		    {
			if (result == 0) { data.swap(d--, c); }
			--c;
		    }
		}

		if (b > c) { break; }

		// At this point, the element at b is > the pivot, and
		// the element at c is < the pivot.  So swap them, and
		// continue scanning.
		data.swap(b++, c--);
	    }

	    // Move all the elements which were equal to the pivot and which
	    // were packed at the left end of the range to the "center."
	    {
		int s = Math.min(a - start, b - a);
		int l = start;  int h = b - s;
		while (s > 0) { data.swap(l++, h++); --s; }
	    }

	    // Move all the elements which were equal to the pivot and which
	    // were packed at the right end of the range to the "center."
	    {
		int s = Math.min(d - c, end - d);
		int l = b;  int h = end - s + 1;
		while (s > 0) { data.swap(l++, h++); --s; }
	    }

	    qsort(data, start, start + b - a - 1);
	    qsort(data, end - (d - c) + 1, end);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // SORT ROUTINES -- NOT FOR GENERAL USE
    ///////////////////////////////////////////////////////////////////////

    /**
     * (NOT FOR GENERAL USE) Sorts the elements with indexes in the range
     * (start, end), inclusive, using the same implementation of Quicksort
     * as qsort() except specialized to integer arrays.
     */
    public static void iqsort(int[] data, int start, int end)
    {
	int n = end - start + 1;
	if (n <= 1) { return; }
	if (n < QSORT_INSERTION_THRESHOLD)
	{
	    // Perform insertion sort.
	    for (int i = start + 1; i <= end; i++)
	    {
		for (int j = i; j > start && data[j - 1] > data[j]; j--)
		{
		    int t = data[j];  data[j] = data[j - 1];  data[j - 1] = t;
		}
	    }
	}
	else
	{
	    int pm = start + n / 2;  // For small arrays, use middle element.
	    if (n > QSORT_MEDIUM_THRESHOLD)
	    {
		if (n > QSORT_LARGE_THRESHOLD)
		{
		    // For large arrays, use pseudomedian of 9 elements.
		    int s = n / 8;
		    int p1 = median3(data, start, start + s, start + 2 * s);
		    pm = median3(data, pm - s, pm, pm + s);
		    int pn = median3(data, end - 2 * s, end - s, end);
		    pm = median3(data, p1, pm, pn);
		}
		else
		{
		    // For medium arrays...
		    pm = median3(data, start, pm, end);
		}
	    }

	    {
		int t = data[start];  data[start] = data[pm];  data[pm] = t;
	    }

	    int v = start;  // The index of the pivot.
	    int a = start + 1;   int b = start + 1;
	    int c = end;         int d = end;

	    for (;;)
	    {
		while (b <= c)
		{
		    int result = (data[b] < data[v] ? -1
				  : data[b] == data[v] ? 0 : 1);
		    if (result > 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    int t = data[a];  data[a] = data[b];  data[b] = t;
			    ++a;
			}
			++b;
		    }
		}

		while (c >= b)
		{
		    int result = (data[c] < data[v] ? -1
				  : data[c] == data[v] ? 0 : 1);
		    if (result < 0) { break; }
		    else
		    {
			if (result == 0)
			{
			    int t = data[d];  data[d] = data[c];  data[c] = t;
			    --d;
			}
			--c;
		    }
		}

		if (b > c) { break; }

		{
		    int t = data[b];  data[b] = data[c];  data[c] = t;
		}
		b++;  c--;
	    }

	    {
		int s = Math.min(a - start, b - a);
		int l = start;  int h = b - s;
		while (s > 0)
		{
		    int t = data[l];  data[l] = data[h];  data[h] = t;
		    l++;  h++;  --s;
		}
	    }

	    {
		int s = Math.min(d - c, end - d);
		int l = b;  int h = end - s + 1;
		while (s > 0)
		{
		    int t = data[l];  data[l] = data[h];  data[h] = t;
		    l++;  h++;  --s;
		}
	    }

	    iqsort(data, start, start + b - a - 1);
	    iqsort(data, end - (d - c) + 1, end);
	}
    }


    /**
     * (NOT FOR GENERAL USE) Sorts the elements with indexes in the range
     * (start, end), inclusive, using a largely straightforward implementation
     * of Quicksort.
     *
     * <p>
     * This corresponds to Program 4 in [Bentley & McIlroy] except with
     * the simple randomized selection replaced by a better mechanism for
     * selecting the pivot (as described later in the article).
     * </p>
     */
    public static void qsort2(Sortable data, int start, int end)
    {
	int n = end - start + 1;
	if (n > 1)
	{
	    int pm = start + n / 2;  // For small arrays, use middle element.
	    if (n > QSORT_MEDIUM_THRESHOLD)
	    {
		if (n > QSORT_LARGE_THRESHOLD)
		{
		    // For large arrays, use pseudomedian of 9 elements.
		    int s = n / 8;
		    int p1 = median3(data, start, start + s, start + 2 * s);
		    pm = median3(data, pm - s, pm, pm + s);
		    int pn = median3(data, end - 2 * s, end - s, end);
		    pm = median3(data, p1, pm, pn);
		}
		else
		{
		    // For medium arrays...
		    pm = median3(data, start, pm, end);
		}
	    }

	    data.swap(start, pm);

	    int i = start;
	    int j = end + 1;
	    for (;;)
	    {
		do { ++i; } while (i <= end && data.compare(i, start) < 0);
		do { --j; } while (data.compare(j, start) > 0);
		if (j < i) { break; }
		data.swap(i, j);
	    }

	    data.swap(start, j);

	    qsort2(data, start, j - 1);
	    qsort2(data, j + 1, end);
	}
    }

    /**
     * (NOT FOR GENERAL USE) Sorts the elements with indexes in the range
     * (start, end), inclusive, using a largely straightforward implementation
     * of Quicksort.
     *
     * <p>
     * This corresponds to Program 4 in [Bentley & McIlroy].
     * </p>
     */
    public static void qsort3(Sortable data, int start, int end)
    {
	int n = end - start + 1;
	if (n > 1)
	{
	    int pm = start + m_random.nextInt(n);
	    data.swap(start, pm);

	    int i = start;
	    int j = end + 1;
	    for (;;)
	    {
		do { ++i; } while (i <= end && data.compare(i, start) < 0);
		do { --j; } while (data.compare(j, start) > 0);
		if (j < i) { break; }
		data.swap(i, j);
	    }

	    data.swap(start, j);

	    qsort3(data, start, j - 1);
	    qsort3(data, j + 1, end);
	}
    }

    /**
     * (NOT FOR GENERAL USE) Sorts the elements with indexes in the range
     * (start, end), inclusive, using a very straightforward implementation
     * of Quicksort.
     *
     * <p>
     * This corresponds to Program 2 in [Bentley & McIlroy] except with
     * the pivot selection mechanism replaced by simple randomized selection.
     * </p>
     *
     * <p>
     * This can be quadratic O(n2/2) in comparisons on nearly-sorted input.
     * </p>
     */
    public static void qsort4(Sortable data, int start, int end)
    {
	int n = end - start + 1;
	if (n > 1)
	{
	    int pm = start + m_random.nextInt(n);
	    data.swap(start, pm);

	    int j = start;
	    for (int i = start + 1; i <= end; i++)
	    {
		if (data.compare(i, start) < 0)
		{
		    data.swap(i, ++j);
		}
	    }
	    data.swap(start, j);

	    qsort4(data, start, j - 1);
	    qsort4(data, j + 1, end);
	}
    }

    /**
     * (NOT FOR GENERAL USE) Sorts the elements with indexes in the range
     * (start, end), inclusive, using a very straightforward implementation
     * of Quicksort.
     *
     * <p>
     * This corresponds to Program 2 in [Bentley & McIlroy].
     * </p>
     *
     * <p>
     * This can be quadratic O(n2/2) in comparisons on nearly-sorted input.
     * </p>
     */
    public static void qsort5(Sortable data, int start, int end)
    {
	int n = end - start + 1;
	if (n > 1)
	{
	    int j = start;
	    for (int i = start + 1; i <= end; i++)
	    {
		if (data.compare(i, start) < 0)
		{
		    data.swap(i, ++j);
		}
	    }
	    data.swap(start, j);

	    qsort5(data, start, j - 1);
	    qsort5(data, j + 1, end);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE STATIC METHODS
    ///////////////////////////////////////////////////////////////////////

    /**
     * Sorts the elements with indexes in the range (start, end), inclusive,
     * using shellsort.
     */
    public static void shellsort(IncrementSequence sequence,
				 Sortable data, int start, int end)
    {
	int n = end - start + 1;
	if (n > 1)
	{
	    int s = sequence.findStartingIncrementIndex(n);
	    while (s >= 0)
	    {
		int h = sequence.getIncrement(s);
		for (int i = start + h; i <= end; i++)
		{
		    for (int j = i - h;
			 j >= start && data.compare(j, j + h) > 0;
			 j -= h)
		    {
			data.swap(j, j + h);
		    }
		}
		--s;
	    }
	}
    }

    /**
     * Returns the index of the median of the elements at the given three
     * indexes.
     *
     * <p>
     * In a set of three values, say a, b, and c, the value b is the "median
     * of three" if either a <= b <= c or c <= b <= a.
     * </p>
     *
     * <p>
     * This is a transliteration of Program 5 in [Bentley & McIlroy].
     * </p>
     */
    private static int median3(Sortable data, int i, int j, int k)
    {
	return data.compare(i, j) < 0
	    ? (data.compare(j, k) < 0 ? j : data.compare(i, k) < 0 ? k : i)
	    : (data.compare(j, k) > 0 ? j : data.compare(i, k) > 0 ? k : i);
    }

    /**
     * Returns the index of the median of the elements at the given three
     * indexes.
     */
    private static int median3(int[] data, int i, int j, int k)
    {
	return data[i] < data[j]
	    ? (data[j] < data[k] ? j : data[i] < data[k] ? k : i)
	    : (data[j] > data[k] ? j : data[i] > data[k] ? k : i);
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    /**
     * An empirical value specifying the upper bound on the size of a
     * subarray which will be handled with insertion sort.
     */
    private static final int QSORT_INSERTION_THRESHOLD = 7;

    /**
     * An empirical value specifying when an array is considered "medium"
     * sized with respect to the choice of algorithm to use in selecting
     * the pivot in QuickSort.
     */
    private static final int QSORT_MEDIUM_THRESHOLD = 7;

    /**
     * An empirical value specifying when an array is considered "large"
     * sized with respect to the choice of algorithm to use in selecting
     * the pivot in QuickSort.
     */
    private static final int QSORT_LARGE_THRESHOLD = 40;

    private static Random  m_random = new Random();

    private static IncrementSequence  m_sedgewickSequence =
	new SedgewickIncrementSequence();

    ///////////////////////////////////////////////////////////////////////
    // MAIN
    ///////////////////////////////////////////////////////////////////////

    public static void main(String[] args)
    {
	SedgewickIncrementSequence.generate();
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE NESTED CLASSES
    ///////////////////////////////////////////////////////////////////////

    private interface IncrementSequence
    {
	int findStartingIncrementIndex(int numValues);
	int getIncrement(int index);
    }

    ///////////////////////////////////////////////////////////////////////

    private static abstract class AbstractIncrementSequence
	implements IncrementSequence
    {
	public int findStartingIncrementIndex(int numValues)
	{
	    int retval = 0;
	    if (numValues > 3)
	    {
		// Knuth suggests not using an increment which is >= N/3.
		int maxIncrement = numValues / 3;
		int numIncrements = getNumIncrements();
		while (retval < numIncrements - 1
		       && getIncrement(retval + 1) < maxIncrement)
		{
		    ++retval;
		}
	    }
	    return retval;
	}

	protected abstract int getNumIncrements();
    }

    ///////////////////////////////////////////////////////////////////////

    private static class SedgewickIncrementSequence
	extends AbstractIncrementSequence
    {
	public int getIncrement(int index)
	{
	    return m_sedgewick[index];
	}

	protected int getNumIncrements()
	{
	    return m_sedgewick.length;
	}

	/**
	 * Sedgewick's sequence of increments for shellsort, as generated by
	 * generate().
	 */
	private static final int[]  m_sedgewick = {
	    1, 5, 19, 41, 109, 209, 505, 929, 2161, 3905, 8929, 16001, 36289,
	    64769, 146305, 260609, 587521, 1045505, 2354689, 4188161, 9427969,
	    16764929, 37730305, 67084289, 150958081, 268386305, 603906049
	};

	/**
	 * Generates Sedgewick's sequence of increments for shellsort.
	 *
	 * <p>
	 * See Knuth's _The Art of Computer Programming_, v3, 2nd Ed, p. 93,
	 * which cites J. Algorithms 7 (1986) 159-173.  Knuth states the first
	 * few values of the sequence are 1, 5, 19, 41, 109, and 209.
	 * </p>
	 */
	public static void generate()
	{
	    System.out.print("int[]  m_sedgewick = { ");

	    int s = 0;
	    int h = 0;
	    boolean more = true;
	    while (more)
	    {
		double dh;
		if ((s % 2) == 0)
		{
		    h = 9 * (1 << s) - 9 * (1 << s / 2) + 1;
		    dh = 9.0 * Math.pow(2.0, s)
			- 9.0 * Math.pow(2.0, s / 2) + 1.0;
		}
		else
		{
		    h = 8 * (1 << s) - 6 * (1 << (s + 1) / 2) + 1;
		    dh = 8.0 * Math.pow(2.0, s)
			- 6.0 * Math.pow(2.0, (s + 1) / 2) + 1.0;
		}

		// Knuth suggests not using an increment which is >= N/3.
		if (dh < Integer.MAX_VALUE / 3 && h < Integer.MAX_VALUE / 3)
		{
		    if (s > 0)
		    {
			System.out.print(", ");
		    }
		    System.out.print(h);
		    ++s;
		}
		else
		{
		    more = false;
		}
	    }

	    System.out.println(" };");
	}
    }
}
