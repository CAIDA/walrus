// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.io.Reader;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.IOException;

/**
 * A substitute for Sun's implementation of
 * <code>java.io.InputStreamReader</code> which does not suffer from slowdowns
 * caused by an excessive (and most likely flawed) use of exceptions.
 *
 * <p>
 * In my case, the performance degradation was caused by
 * <code>sun.io.ByteToCharASCII.convert()</code> throwing a large number of
 * <code>sun.io.ConversionBufferFullException</code> objects only to catch
 * them internally.  This lead to a program taking 23mins to do what it could
 * have done in 30s.  Profiling showed a lot of time being spent in
 * <code>java.lang.Throwable.fillInStackTrace()</code>.  You can read about
 * this bug at
 * <a href=http://developer.java.sun.com/developer/bugParade/bugs/4311984.html>
 * Bug ID: 4311984 Use of ConversionBufferFullException in ByteToChar*
 * Converters is slow</a>.
 * </p>
 *
 * <p>
 * Although solving the performance problem, this is by no means a full
 * replacement, as this only supports ASCII encodings.  Consider this a
 * limited workaround until Sun corrects the real problem.
 * </p>
 *
 * <p>
 * This is a clean-room implementation based on consulting the Java
 * specification only.
 * </p>
 *
 * @see java.io.InputStreamReader
 */
public class ASCIIInputStreamReader
    extends Reader
{
    public ASCIIInputStreamReader(InputStream input)
    {
	m_input = new BufferedInputStream(input);
    }

    public void close()
	throws IOException
    {
	m_input.close();
    }

    public int read()
	throws IOException
    {
	return m_input.read();
    }

    public int read(char[] buffer, int offset, int length)
	throws IOException
    {
	int retval = 0;

	int end = offset + length;
	for (int i = offset; i < end; i++, retval++)
	{
	    int c = m_input.read();
	    if (c < 0)
	    {
		break;
	    }
	    buffer[i] = (char)c;
	}

	return (retval == 0 ? -1 : retval);
    }

    private InputStream m_input;
}
