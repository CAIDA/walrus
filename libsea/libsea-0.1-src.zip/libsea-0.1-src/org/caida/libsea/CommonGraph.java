// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Observer;
import java.util.Observable;

abstract class CommonGraph
    implements Graph
{
    /////////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    /////////////////////////////////////////////////////////////////////////

    public CommonGraph(SharedHeap heap, OptimizationType type)
    {
	m_heap = heap;
	m_optimizationType = type;
    }

    /////////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS (Interface Graph)
    /////////////////////////////////////////////////////////////////////////

    public String getName()
    {
	return m_name;
    }

    public String getDescription()
    {
	return m_description;
    }

    public int getNumNodes()
    {
	return m_numNodes;
    }

    public int getNumLinks()
    {
	return m_numLinks;
    }

    public int getNumPaths()
    {
	return m_numPaths;
    }

    public int getNumPathLinks()
    {
	return m_numPathLinks;
    }

    public int getNumObjects(ObjectType type)
    {
	switch (type.getType())
	{
	case ObjectType._NODE: return getNumNodes();
	case ObjectType._LINK: return getNumLinks();
	case ObjectType._PATH: return getNumPaths();
	default: throw new InternalErrorException();
	}
    }

    public ObjectIterator getObjects(ObjectType type)
    {
	switch (type.getType())
	{
	case ObjectType._NODE: return getNodes();
	case ObjectType._LINK: return getLinks();
	case ObjectType._PATH: return getPaths();
	default: throw new InternalErrorException();
	}
    }

    public ObjectIterator getObject(ObjectType type, int id)
    {
	switch (type.getType())
	{
	case ObjectType._NODE: return getNode(id);
	case ObjectType._LINK: return getLink(id);
	case ObjectType._PATH: return getPath(id);
	default: throw new InternalErrorException();
	}
    }

    public EnumerationIterator getEnumerations()
    {
	return new EnumerationIteratorImpl
	    (0, m_enumerations.getLogicalLength());
    }

    public EnumerationIterator getEnumeration(int id)
    {
	assertNonnegative(id);
	if (!m_enumerations.checkAllocated(id))
	{
	    String msg = "enumeration[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return new EnumerationIteratorImpl(id, id + 1);
    }

    public EnumerationIterator getEnumeration(String name)
    {
	Enumeration enumeration = findEnumerationInstance(name);
	int id = enumeration.getID();
	return new EnumerationIteratorImpl(id, id + 1);
    }

    public ReadOnlyEnumeratorIterator getEnumerators()
    {
	return new ReadOnlyEnumeratorIteratorImpl
	    (0, m_enumerators.getLogicalLength());
    }

    public ReadOnlyEnumeratorIterator getEnumerator(int id)
    {
	assertNonnegative(id);
	if (!m_enumerators.checkAllocated(id))
	{
	    String msg = "enumerator[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return new ReadOnlyEnumeratorIteratorImpl(id, id + 1);
    }

    public ReadOnlyEnumeratorIterator getEnumerator(String enumerationName,
						    String enumeratorName)
    {
	Enumerator enumerator =
	    findEnumeratorInstance(enumerationName, enumeratorName);
	int id = enumerator.getID();
	return new ReadOnlyEnumeratorIteratorImpl(id, id + 1);
    }

    public int resolveEnumerator(String enumerationName, String enumeratorName)
    {
	String key = constructEnumeratorKey(enumerationName, enumeratorName);
	Enumerator enumerator =
	    findEnumeratorInstance(enumerationName, enumeratorName);
	return enumerator.getID();
    }

    public int evaluateEnumerator(int id)
    {
	assertNonnegative(id);
	Enumerator enumerator = findEnumeratorInstance(id);
	return enumerator.getValue();
    }

    public int evaluateEnumerator(String enumerationName,
				  String enumeratorName)
    {
	return evaluateEnumerator
	    (resolveEnumerator(enumerationName, enumeratorName));
    }

    public QualifierTypeIterator getQualifierTypes()
    {
	return new AllQualifierTypeIterator();
    }

    // NOTE: If there's no qualifier type with the given name,
    //       then this returns an empty iterator.
    public QualifierTypeIterator getQualifierType(String name)
    {
	QualifierTypeIterator retval = null;
	ContainerListNode node =
	    (ContainerListNode)m_qualifierTypesMap.get(name);
	if (node == null)
	{
	    retval = new EmptyQualifierTypeIterator();
	}
	else
	{
	    retval = new SingleQualifierTypeIterator(node);
	}
	return retval;
    }

    public QualifierIterator getQualifiers()
    {
	return new AllQualifierIterator();
    }

    // NOTE: If there's no qualifier type with the given name,
    //       then this returns an empty iterator.
    public QualifierIterator getQualifiersByType(String type)
    {
	QualifierIterator retval = null;
	ContainerListNode node =
	    (ContainerListNode)m_qualifierTypesMap.get(type);
	if (node == null)
	{
	    retval = new EmptyQualifierIterator();
	}
	else
	{
	    QualifierType qualifierType = (QualifierType)node.getObject();
	    retval = qualifierType.getQualifiers();
	}
	return retval;
    }

    // NOTE: If there's no qualifier with the given name,
    //       then this returns an empty iterator.
    public QualifierIterator getQualifier(String name)
    {
	QualifierIterator retval = null;
	ContainerListNode node = (ContainerListNode)m_qualifiersMap.get(name);
	if (node == null)
	{
	    retval = new EmptyQualifierIterator();
	}
	else
	{
	    retval = new SingleQualifierIterator(node);
	}
	return retval;
    }

    public int resolveQualifierAttribute(String qualifier, String attribute)
    {
	String key = constructQualifierAttributeKey(qualifier, attribute);
	Integer index = (Integer)m_qualifierAttributesMap.get(key);
	if (index == null)
	{
	    String msg = "qualifier attribute mapping[" + key + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return index.intValue();
    }

    public PresentationIterator getPresentations()
    {
	return new PresentationIteratorImpl
	    (0, m_presentations.getLogicalLength());
    }

    public PresentationIterator getPresentation(int id)
    {
	assertNonnegative(id);
	if (!m_presentations.checkAllocated(id))
	{
	    String msg = "presentation[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return new PresentationIteratorImpl(id, id + 1);
    }

    public DisplayIterator getDisplays()
    {
	return new DisplayIteratorImpl
	    (0, m_displays.getLogicalLength());
    }

    public DisplayIterator getDisplay(int id)
    {
	assertNonnegative(id);
	if (!m_displays.checkAllocated(id))
	{
	    String msg = "display[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return new DisplayIteratorImpl(id, id + 1);
    }

    public SelectorIterator getSelectors()
    {
	return new SelectorIteratorImpl
	    (0, m_selectors.getLogicalLength());
    }

    public SelectorIterator getSelector(int id)
    {
	assertNonnegative(id);
	if (!m_selectors.checkAllocated(id))
	{
	    String msg = "selector[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return new SelectorIteratorImpl(id, id + 1);
    }

    public FilterIterator getFilters()
    {
	return new FilterIteratorImpl
	    (0, m_filters.getLogicalLength());
    }

    public FilterIterator getFilter(int id)
    {
	assertNonnegative(id);
	if (!m_filters.checkAllocated(id))
	{
	    String msg = "filter[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	return new FilterIteratorImpl(id, id + 1);
    }

    public MenuIterator getPresentationMenu()
    {
	return m_presentationMenu.getSubmenus();
    }

    public MenuIterator getDisplayMenu()
    {
	return m_displayMenu.getSubmenus();
    }

    public MenuIterator getSelectorMenu()
    {
	return m_selectorMenu.getSubmenus();
    }

    public MenuIterator getFilterMenu()
    {
	return m_filterMenu.getSubmenus();
    }

    public MenuIterator getAttributeMenu()
    {
	return m_attributeMenu.getSubmenus();
    }

    public int getEnumerationIDRange()
    {
	return m_enumerations.getLogicalLength();
    }

    public int getEnumeratorIDRange()
    {
	return m_enumerators.getLogicalLength();
    }

    public int getPresentationIDRange()
    {
	return m_presentations.getLogicalLength();
    }

    public int getDisplayIDRange()
    {
	return m_displays.getLogicalLength();
    }

    public int getSelectorIDRange()
    {
	return m_selectors.getLogicalLength();
    }

    public int getFilterIDRange()
    {
	return m_filters.getLogicalLength();
    }

    public ValueIterator getObjectAttribute(ObjectType type, int object,
					    int attribute)
	throws AttributeUnavailableException
    {
	switch (type.getType())
	{
	case ObjectType._NODE: return getNodeAttribute(object, attribute);
	case ObjectType._LINK: return getLinkAttribute(object, attribute);
	case ObjectType._PATH: return getPathAttribute(object, attribute);
	default: throw new InternalErrorException();
	}
    }

    public int getNumBaseFilteredNodes()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getNumBaseFilteredLinks()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public int getNumBaseFilteredPaths()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public NodeIterator getBaseFilteredNodes()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public LinkIterator getBaseFilteredLinks()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public PathIterator getBaseFilteredPaths()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public ObjectFilter compileFilter(String expr)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public NodeIterator getFurtherFilteredNodes(ObjectFilter filter)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public LinkIterator getFurtherFilteredLinks(ObjectFilter filter)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public PathIterator getFurtherFilteredPaths(ObjectFilter filter)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public boolean checkNodeBaseFiltered(int node)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public boolean checkLinkBaseFiltered(int link)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public boolean checkPathBaseFiltered(int path)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public boolean checkNodeFiltered(ObjectFilter filter, int node)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public boolean checkLinkFiltered(ObjectFilter filter, int link)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public boolean checkPathFiltered(ObjectFilter filter, int path)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setNodeBaseFilter(ObjectFilter filter)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setLinkBaseFilter(ObjectFilter filter)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setPathBaseFilter(ObjectFilter filter)
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void applyNodeBaseFilter()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void applyLinkBaseFilter()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void applyPathBaseFilter()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void clearNodeBaseFiltering()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void clearLinkBaseFiltering()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void clearPathBaseFiltering()
    {
	throw new InternalErrorException("UNIMPLEMENTED");
    }

    public void setName(String name)
    {
	m_name = name;
    }

    public void setDescription(String description)
    {
	m_description = description;
    }

    public void removeObjects(ObjectType type)
    {
	switch (type.getType())
	{
	case ObjectType._NODE: removeNodes(); break;
	case ObjectType._LINK: removeLinks(); break;
	case ObjectType._PATH: removePaths(); break;
	default: throw new InternalErrorException();
	}
    }

    public void removeObject(ObjectType type, int id)
    {
	switch (type.getType())
	{
	case ObjectType._NODE: removeNode(id); break;
	case ObjectType._LINK: removeLink(id); break;
	case ObjectType._PATH: removePath(id); break;
	default: throw new InternalErrorException();
	}
    }

    public void removeEnumerations()
    {
	EnumerationIterator iterator = getEnumerations();
	while (!iterator.atEnd())
	{
	    if (iterator.isMutable())
	    {
		iterator.removeEnumeration();
	    }
	    else
	    {
		iterator.advance();
	    }
	}
    }

    public void removeEnumeration(String name)
    {
	EnumerationIterator iterator = getEnumeration(name);
	iterator.removeEnumeration();
    }

    public void removeQualifierTypes()
    {
	removeQualifierTypes(getQualifierTypes());
	if (DEBUG)
	{
	    if (!m_qualifierTypesMap.isEmpty())
	    {
		String msg = "m_qualifierTypesMap is not empty";
		throw new InternalErrorException(msg);
	    }

	    if (!m_qualifiersMap.isEmpty())
	    {
		String msg = "m_qualifiersMap is not empty";
		throw new InternalErrorException(msg);
	    }

	    if (!m_qualifierAttributesMap.isEmpty())
	    {
		String msg = "m_qualifierAttributesMap is not empty";
		throw new InternalErrorException(msg);
	    }

	    if (!m_qualifierTypesList.isEmpty())
	    {
		String msg = "m_qualifierTypes is not empty";
		throw new InternalErrorException(msg);
	    }

	    if (!m_qualifiersList.isEmpty())
	    {
		String msg = "m_qualifiers is not empty";
		throw new InternalErrorException(msg);
	    }
	}
    }

    public void removeQualifierType(String name)
    {
	removeQualifierTypes(getQualifierType(name));
    }

    public void removeQualifiers()
    {
	QualifierTypeIterator iterator = getQualifierTypes();
	while (!iterator.atEnd())
	{
	    iterator.removeQualifiers();
	}

	if (DEBUG)
	{
	    if (!m_qualifiersMap.isEmpty())
	    {
		String msg = "m_qualifiersMap is not empty";
		throw new InternalErrorException(msg);
	    }

	    if (!m_qualifierAttributesMap.isEmpty())
	    {
		String msg = "m_qualifierAttributesMap is not empty";
		throw new InternalErrorException(msg);
	    }

	    if (!m_qualifiersList.isEmpty())
	    {
		String msg = "m_qualifiers is not empty";
		throw new InternalErrorException(msg);
	    }
	}
    }

    public void removeQualifier(String name)
    {
	removeQualifiers(getQualifier(name));
    }

    public void removeQualifiersByType(String type)
    {
	QualifierType qualifierType = findQualifierTypeInstance(type);
	qualifierType.removeQualifiers();
    }

    public void removePresentations()
    {
	removePresentations(getPresentations());
	if (DEBUG && !m_presentations.isEmpty())
	{
	    String msg = "m_presentations is not empty";
	    throw new InternalErrorException(msg);
	}
    }

    public void removePresentation(int id)
    {
	removePresentations(getPresentation(id));
    }

    public void removeDisplays()
    {
	removeDisplays(getDisplays());
	if (DEBUG && !m_displays.isEmpty())
	{
	    String msg = "m_displays is not empty";
	    throw new InternalErrorException(msg);
	}
    }

    public void removeDisplay(int id)
    {
	removeDisplays(getDisplay(id));
    }

    public void removeSelectors()
    {
	removeSelectors(getSelectors());
	if (DEBUG && !m_selectors.isEmpty())
	{
	    String msg = "m_selectors is not empty";
	    throw new InternalErrorException(msg);
	}
    }

    public void removeSelector(int id)
    {
	removeSelectors(getSelector(id));
    }

    public void removeFilters()
    {
	removeFilters(getFilters());
	if (DEBUG && !m_filters.isEmpty())
	{
	    String msg = "m_filters is not empty";
	    throw new InternalErrorException(msg);
	}
    }

    public void removeFilter(int id)
    {
	removeFilters(getFilter(id));
    }

    public void removePresentationMenu()
    {
	m_presentationMenu.removeSubmenus();
    }

    public void removeDisplayMenu()
    {
	m_displayMenu.removeSubmenus();
    }

    public void removeSelectorMenu()
    {
	m_selectorMenu.removeSubmenus();
    }

    public void removeFilterMenu()
    {
	m_filterMenu.removeSubmenus();
    }

    public void removeAttributeMenu()
    {
	m_attributeMenu.removeSubmenus();
    }

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED METHODS
    ///////////////////////////////////////////////////////////////////////

    protected abstract void validateAttributeExistence(int attribute);
    protected abstract String findAttributeName(int attribute);
    protected abstract int findAttributeID(String name);
    protected abstract void addAttributeRemovalObserver(int attribute,
							Observer observer);
    protected abstract void removeAttributeRemovalObserver(int attribute,
							   Observer observer);

    protected EnumerationReader findEnumerationReader(String name)
    {
	return findEnumerationInstance(name);
    }

    protected EnumerationReader findEnumerationReader(int id)
    {
	return findEnumerationInstance(id);
    }

    protected EnumeratorReader findEnumeratorReader(String enumeration,
						    String enumerator)
    {
	return findEnumeratorInstance(enumeration, enumerator);
    }

    protected EnumeratorReader findEnumeratorReader(int id)
    {
	return findEnumeratorInstance(id);
    }

    protected final void assertNonnegative(int id)
    {
	if (id < 0)
	{
	    String msg = "id[" + id + "] must be nonnegative";
	    throw new IllegalArgumentException(msg);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ///////////////////////////////////////////////////////////////////////

    private void removeQualifierTypes(QualifierTypeIterator iterator)
    {
	while (!iterator.atEnd()) { iterator.removeQualifierType(); }
    }

    private void removeQualifiers(QualifierIterator iterator)
    {
	while (!iterator.atEnd()) { iterator.removeQualifier(); }
    }

    private void removePresentations(PresentationIterator iterator)
    {
	while (!iterator.atEnd()) { iterator.removePresentation(); }
    }

    private void removeDisplays(DisplayIterator iterator)
    {
	while (!iterator.atEnd()) { iterator.removeDisplay(); }
    }

    private void removeSelectors(SelectorIterator iterator)
    {
	while (!iterator.atEnd()) { iterator.removeSelector(); }
    }

    private void removeFilters(FilterIterator iterator)
    {
	while (!iterator.atEnd()) { iterator.removeFilter(); }
    }

    ///////////////////////////////////////////////////////////////////////

    private Enumeration findEnumerationInstance(String name)
    {
	Enumeration enumeration = (Enumeration)m_enumerationsMap.get(name);
	if (enumeration == null)
	{
	    String msg = "enumeration[" + name + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	else
	{
	    if (DEBUG && !enumeration.getName().equals(name))
	    {
		String msg = "enumeration[" + enumeration.getName()
		    + "] does not have name [" + name + "]";
		throw new InternalErrorException(msg);
	    }
	}
	return enumeration;
    }

    private Enumeration findEnumerationInstance(int id)
    {
	assertNonnegative(id);
	try {
	    Enumeration enumeration = (Enumeration)m_enumerations.getValue(id);
	    if (enumeration == null)
	    {
		String msg = "null enumeration reference in allocated slot";
		throw new InternalErrorException(msg);
	    }
	    return enumeration;
	}
	catch (UnallocatedElementException e)
	{
	    String msg = "enumeration[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    private Enumerator findEnumeratorInstance(String enumerationName,
					      String enumeratorName)
    {
	String key = constructEnumeratorKey(enumerationName, enumeratorName);
	Enumerator enumerator = (Enumerator)m_enumeratorsMap.get(key);
	if (enumerator == null)
	{
	    String msg = "enumerator[" + enumeratorName + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	else
	{
	    if (DEBUG && !enumerator.getName().equals(enumeratorName))
	    {
		String msg = "enumerator[" + enumerator.getName()
		    + "] does not have name [" + enumeratorName + "]";
		throw new InternalErrorException(msg);
	    }
	}
	return enumerator;
    }

    private Enumerator findEnumeratorInstance(int id)
    {
	assertNonnegative(id);
	try
	{
	    Enumerator enumerator = (Enumerator)m_enumerators.getValue(id);
	    if (enumerator == null)
	    {
		String msg = "null enumeration reference in allocated slot";
		throw new InternalErrorException(msg);
	    }
	    return enumerator;
	}
	catch (UnallocatedElementException e)
	{
	    String msg = "enumerator[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    private Enumeration addEnumeration(String name)
	throws DuplicateObjectException
    {
	int id = m_enumerations.allocate();
	Enumeration enumeration = new Enumeration(id, name);
	try
	{
	    addEnumerationMapping(enumeration);
	}
	catch (DuplicateObjectException e)
	{
	    m_enumerations.free(id);
	    throw e;
	}
	m_enumerations.setValue(id, enumeration);
	return enumeration;
    }

    private void removeEnumeration(Enumeration enumeration)
    {
	removeEnumerationMapping(enumeration);
	m_enumerations.free(enumeration.getID());
    }

    private void addEnumerationMapping(Enumeration enumeration)
	throws DuplicateObjectException
    {
	String key = enumeration.getName();
	Object oldValue = m_enumerationsMap.put(key, enumeration);
	if (oldValue != null)
	{
	    m_enumerationsMap.put(key, oldValue);
	    String msg = "enumeration mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private void removeEnumerationMapping(Enumeration enumeration)
    {
	String key = enumeration.getName();
	Object oldValue = m_enumerationsMap.remove(key);
	if (oldValue == null)
	{
	    String msg = "enumeration mapping[" + key + "] not found";
	    throw new InternalErrorException(msg);
	}
    }

    private void changeEnumerationMapping(Enumeration enumeration,
					  String oldName)
	throws DuplicateObjectException
    {
	Object oldNameValue = m_enumerationsMap.remove(oldName);
	if (oldNameValue == null)
	{
	    String msg = "enumeration mapping[" + oldName + "] not found";
	    throw new InternalErrorException(msg);
	}
	if (oldNameValue != enumeration)
	{
	    String msg =
		"enumeration[" + oldName + "] maps to a different object";
	    throw new InternalErrorException(msg);
	}

	String key = enumeration.getName();
	Object oldValue = m_enumerationsMap.put(key, enumeration);
	if (oldValue == null)
	{
	    refreshEnumeratorMappings(enumeration, oldName);
	}
	else
	{
	    m_enumerationsMap.put(oldName, oldNameValue);
	    m_enumerationsMap.put(key, oldValue);
	    String msg = "enumeration mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private void refreshEnumeratorMappings(Enumeration enumeration,
					   String oldName)
    {
	String newName = enumeration.getName();
	EnumeratorIterator iterator = enumeration.getEnumerators();
	while (!iterator.atEnd())
	{
	    String enumeratorName = iterator.getName();
	    String oldKey = constructEnumeratorKey(oldName, enumeratorName);

	    Object enumerator = m_enumeratorsMap.remove(oldKey);
	    if (enumerator == null)
	    {
		String msg = "enumerator mapping[" + oldKey + "] not found";
		throw new InternalErrorException(msg);
	    }

	    String newKey = constructEnumeratorKey(newName, enumeratorName);
	    Object oldValue = m_enumeratorsMap.put(newKey, enumerator);
	    if (oldValue != null)
	    {
		m_enumeratorsMap.put(newKey, oldValue);
		String msg =
		    "enumerator mapping[" + newKey + "] already exists";
		throw new InternalErrorException(msg);
	    }
	    
	    iterator.advance();
	}
    }

    private Enumerator addEnumerator(Enumeration enumeration,
				     String name, int value)
	throws DuplicateObjectException
    {
	int enumerationID = enumeration.getID();
	int id = m_enumerators.allocate();
	Enumerator enumerator = new Enumerator(id, name, value, enumerationID);
	try
	{
	    addEnumeratorMapping(enumeration, enumerator);
	}
	catch (DuplicateObjectException e)
	{
	    m_enumerators.free(id);
	    throw e;
	}
	m_enumerators.setValue(id, enumerator);
	return enumerator;
    }

    private void removeEnumerator(Enumeration enumeration,
				  Enumerator enumerator)
    {
	removeEnumeratorMapping(enumeration, enumerator);
	m_enumerators.free(enumerator.getID());
    }

    private void addEnumeratorMapping(Enumeration enumeration,
				      Enumerator enumerator)
	throws DuplicateObjectException
    {
	String key = constructEnumeratorKey(enumeration, enumerator);
	Object oldValue = m_enumeratorsMap.put(key, enumerator);
	if (oldValue != null)
	{
	    m_enumeratorsMap.put(key, oldValue);
	    String msg = "enumerator mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private void removeEnumeratorMapping(Enumeration enumeration,
					 Enumerator enumerator)
    {
	String key = constructEnumeratorKey(enumeration, enumerator);
	if (m_enumeratorsMap.remove(key) == null)
	{
	    String msg = "enumerator mapping[" + key + "] not found";
	    throw new InternalErrorException(msg);
	}
    }

    private void changeEnumeratorMapping(Enumeration enumeration,
					 Enumerator enumerator, String oldName)
	throws DuplicateObjectException
    {
	String key = constructEnumeratorKey(enumeration, enumerator);
	Object oldValue = m_enumeratorsMap.put(key, enumerator);
	if (oldValue == null)
	{
	    String oldKey =
		constructEnumeratorKey(enumeration.getName(), oldName);
	    if (m_enumeratorsMap.remove(oldKey) == null)
	    {
		m_enumeratorsMap.remove(key);
		String msg = "enumerator mapping[" + oldKey + "] not found";
		throw new InternalErrorException(msg);
	    }
	}
	else
	{
	    m_enumeratorsMap.put(key, oldValue);
	    String msg = "enumerator mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private String constructEnumeratorKey(Enumeration enumeration,
					  Enumerator enumerator)
    {
	return constructEnumeratorKey(enumeration.getName(),
				      enumerator.getName());
    }

    private String constructEnumeratorKey(String enumeration,
					  String enumerator)
    {
	return enumerator + ":" + enumeration;
    }

    ///////////////////////////////////////////////////////////////////////

    private QualifierType findOrCreateQualifierTypeInstance(String name)
    {
	QualifierType retval = null;
	ContainerListNode node =
	    (ContainerListNode)m_qualifierTypesMap.get(name);
	if (node == null)
	{
	    retval = new QualifierType(name);
	    try { addQualifierType(retval); }
	    catch (DuplicateObjectException e)
	    { e.printStackTrace();
	    throw new InternalErrorException(e.toString()); }
	}
	else
	{
	    retval = (QualifierType)node.getObject();
	    if (DEBUG && !retval.getName().equals(name))
	    {
		String msg = "qualifier type[" + retval.getName()
		    + "] does not have name [" + name + "]";
		throw new InternalErrorException(msg);
	    }
	}
	return retval;
    }

    private QualifierType findQualifierTypeInstance(String name)
    {
	ContainerListNode node =
	    (ContainerListNode)m_qualifierTypesMap.get(name);
	if (node == null)
	{
	    String msg = "qualifier type[" + name + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	QualifierType retval = (QualifierType)node.getObject();
	if (DEBUG && !retval.getName().equals(name))
	{
	    String msg = "qualifier type[" + retval.getName()
		+ "] does not have name [" + name + "]";
	    throw new InternalErrorException(msg);
	}
	return retval;
    }

    private Qualifier findQualifierInstance(String name)
    {
	ContainerListNode node = (ContainerListNode)m_qualifiersMap.get(name);
	if (node == null)
	{
	    String msg = "qualifier[" + name + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
	Qualifier retval = (Qualifier)node.getObject();
	if (DEBUG && !retval.getName().equals(name))
	{
	    String msg = "qualifier[" + retval.getName()
		+ "] does not have name [" + name + "]";
	    throw new InternalErrorException(msg);
	}
	return retval;
    }

    private void addQualifierType(QualifierType qualifierType)
	throws DuplicateObjectException
    {
	ContainerListNode node = addQualifierTypeMapping(qualifierType);
	m_qualifierTypesList.append(node);
    }

    private void removeQualifierType(QualifierType qualifierType)
    {
	ContainerListNode node = removeQualifierTypeMapping(qualifierType);
	m_qualifierTypesList.unlink(node);
    }

    private ContainerListNode addQualifierTypeMapping
	(QualifierType qualifierType)
	throws DuplicateObjectException
    {
	ContainerListNode retval = new ContainerListNode(qualifierType);
	String key = qualifierType.getName();
	Object oldValue = m_qualifierTypesMap.put(key, retval);
	if (oldValue != null)
	{
	    m_qualifierTypesMap.put(key, oldValue);
	    String msg = "qualifier type mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
	return retval;
    }

    private ContainerListNode removeQualifierTypeMapping
	(QualifierType qualifierType)
    {
	String key = qualifierType.getName();
	ContainerListNode retval =
	    (ContainerListNode)m_qualifierTypesMap.remove(key);
	if (retval == null)
	{
	    String msg = "qualifier type mapping[" + key + "] not found";
	    throw new InternalErrorException(msg);
	}
	return retval;
    }

    private void changeQualifierTypeMapping(QualifierType qualifierType,
					    String oldName)
	throws DuplicateObjectException
    {
	Object newValue = m_qualifierTypesMap.remove(oldName);
	if (newValue == null)
	{
	    String msg = "qualifier type mapping[" + oldName + "] not found";
	    throw new InternalErrorException(msg);
	}

	String key = qualifierType.getName();
	Object oldValue = m_qualifierTypesMap.put(key, newValue);
	if (oldValue != null)
	{
	    m_qualifierTypesMap.put(key, oldValue);
	    m_qualifierTypesMap.put(oldName, newValue);
	    String msg = "qualifier type mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private void addQualifier(Qualifier qualifier)
	throws DuplicateObjectException
    {
	ContainerListNode node = addQualifierMapping(qualifier);
	m_qualifiersList.append(node);
    }

    private void removeQualifier(Qualifier qualifier)
    {
	ContainerListNode node = removeQualifierMapping(qualifier);
	m_qualifiersList.unlink(node);
    }

    private ContainerListNode addQualifierMapping(Qualifier qualifier)
	throws DuplicateObjectException
    {
	ContainerListNode retval = new ContainerListNode(qualifier);
	String key = qualifier.getName();
	Object oldValue = m_qualifiersMap.put(key, retval);
	if (oldValue != null)
	{
	    m_qualifiersMap.put(key, oldValue);
	    String msg = "qualifier mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
	return retval;
    }

    private ContainerListNode removeQualifierMapping(Qualifier qualifier)
    {
	String key = qualifier.getName();
	ContainerListNode retval =
	    (ContainerListNode)m_qualifiersMap.remove(key);
	if (retval == null)
	{
	    String msg = "qualifier mapping[" + key + "] not found";
	    throw new InternalErrorException(msg);
	}
	return retval;
    }

    private void changeQualifierMapping(Qualifier qualifier, String oldName)
	throws DuplicateObjectException
    {
	Object newValue = m_qualifiersMap.remove(oldName);
	if (newValue == null)
	{
	    String msg = "qualifier mapping[" + oldName + "] not found";
	    throw new InternalErrorException(msg);
	}

	String key = qualifier.getName();
	Object oldValue = m_qualifiersMap.put(key, newValue);
	if (oldValue == null)
	{
	    refreshQualifierAttributeMappings(qualifier, oldName);
	}
	else
	{
	    m_qualifiersMap.put(key, oldValue);
	    m_qualifiersMap.put(oldName, newValue);
	    String msg = "qualifier mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private void refreshQualifierAttributeMappings(Qualifier qualifier,
						   String oldName)
    {
	String newName = qualifier.getName();
	QualifierAttributeIterator iterator = qualifier.getAttributes();
	while (!iterator.atEnd())
	{
	    String attributeName = iterator.getName();
	    String oldKey =
		constructQualifierAttributeKey(oldName, attributeName);

	    Object attribute = m_qualifierAttributesMap.remove(oldKey);
	    if (attribute == null)
	    {
		String msg =
		    "qualifier attribute mapping[" + oldKey + "] not found";
		throw new InternalErrorException(msg);
	    }

	    String newKey =
		constructQualifierAttributeKey(newName, attributeName);
	    Object oldValue = m_qualifierAttributesMap.put(newKey, attribute);
	    if (oldValue != null)
	    {
		m_qualifierAttributesMap.put(newKey, oldValue);
		String msg = "qualifier attribute mapping["
		    + newKey + "] already exists";
		throw new InternalErrorException(msg);
	    }
	    
	    iterator.advance();
	}
    }

    private void addQualifierAttributeMapping
	(Qualifier qualifier, QualifierAttribute qualifierAttribute)
	throws DuplicateObjectException
    {
	String key =
	    constructQualifierAttributeKey(qualifier, qualifierAttribute);
	Integer newValue = new Integer(qualifierAttribute.getAttribute());
	Object oldValue = m_qualifierAttributesMap.put(key, newValue);
	if (oldValue != null)
	{
	    m_qualifierAttributesMap.put(key, oldValue);
	    String msg =
		"qualifier attribute mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private void removeQualifierAttributeMapping
	(Qualifier qualifier, QualifierAttribute qualifierAttribute)
    {
	String key =
	    constructQualifierAttributeKey(qualifier, qualifierAttribute);
	if (m_qualifierAttributesMap.remove(key) == null)
	{
	    String msg = "qualifier attribute mapping[" + key + "] not found";
	    throw new InternalErrorException(msg);
	}
    }

    private void changeQualifierAttributeMapping
	(Qualifier qualifier, QualifierAttribute qualifierAttribute,
	 String oldName)
	throws DuplicateObjectException
    {
	Object newValue = m_qualifierAttributesMap.remove(oldName);
	if (newValue == null)
	{
	    String msg =
		"qualifier attribute mapping[" + oldName + "] not found";
	    throw new InternalErrorException(msg);
	}

	String key = qualifier.getName();
	Object oldValue = m_qualifierAttributesMap.put(key, newValue);
	if (oldValue != null)
	{
	    m_qualifierAttributesMap.put(key, oldValue);
	    m_qualifierAttributesMap.put(oldName, newValue);
	    String msg =
		"qualifier attribute mapping[" + key + "] already exists";
	    throw new DuplicateObjectException(msg);
	}
    }

    private String constructQualifierAttributeKey
	(Qualifier qualifier, QualifierAttribute qualifierAttribute)
    {
	return constructQualifierAttributeKey
	    (qualifier.getName(), qualifierAttribute.getName());
    }

    private String constructQualifierAttributeKey
	(String qualifier, String qualifierAttribute)
    {
	return qualifierAttribute + ":" + qualifier;
    }

    ///////////////////////////////////////////////////////////////////////

    private Presentation findPresentationInstance(int id)
    {
	assertNonnegative(id);
	try
	{
	    return (Presentation)m_presentations.getValue(id);
	}
	catch (UnallocatedElementException e)
	{
	    String msg = "presentation[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    private Display findDisplayInstance(int id)
    {
	assertNonnegative(id);
	try
	{
	    return (Display)m_displays.getValue(id);
	}
	catch (UnallocatedElementException e)
	{
	    String msg = "display[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    private Selector findSelectorInstance(int id)
    {
	assertNonnegative(id);
	try
	{
	    return (Selector)m_selectors.getValue(id);
	}
	catch (UnallocatedElementException e)
	{
	    String msg = "selector[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    private Filter findFilterInstance(int id)
    {
	assertNonnegative(id);
	try
	{
	    return (Filter)m_filters.getValue(id);
	}
	catch (UnallocatedElementException e)
	{
	    String msg = "filter[" + id + "] not found";
	    throw new ObjectNotFoundException(msg);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED FIELDS
    ///////////////////////////////////////////////////////////////////////

    protected static final boolean  DEBUG = true;

    protected SharedHeap  m_heap;
    protected OptimizationType  m_optimizationType;

    protected String  m_name = "";
    protected String  m_description = "";

    protected int  m_numNodes;
    protected int  m_numLinks;
    protected int  m_numPaths;
    protected int  m_numPathLinks;

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    // The keys are just the names of the enumerations.
    private Map  m_enumerationsMap = new HashMap(); // String -> Enumeration

    // The keys are of the form `EnumeratorName:EnumerationName'; see
    // constructEnumeratorKey().
    private Map  m_enumeratorsMap = new HashMap();  // String -> Enumerator

    // Contains Enumeration objects indexed by ID.
    private ObjectArray  m_enumerations = new ObjectArray();

    // Contains Enumerator objects indexed by ID.
    private ObjectArray  m_enumerators = new ObjectArray();

    ///////////////////////////////////////////////////////////////////////

    // This maps qualifier type names to indices in m_qualifierTypes.
    // {String -> ContainerListNode<QualifierType>}
    private Map  m_qualifierTypesMap = new HashMap();

    // This maps qualifier names to indices in m_qualifiers.
    // {String -> ContainerListNode<Qualifier>}
    private Map  m_qualifiersMap = new HashMap();

    // This maps composite names to attribute IDs.
    // The keys are of the form `qualifierAttributeName:qualifierName';
    // see constructQualifierAttributeKey().
    private Map  m_qualifierAttributesMap = new HashMap(); // String -> Integer

    // A list of ContainerListNode<QualifierType> objects.
    private ListHead  m_qualifierTypesList = new ListHead();

    // A list of ContainerListNode<Qualifier> objects.
    private ListHead  m_qualifiersList = new ListHead();

    ///////////////////////////////////////////////////////////////////////

    // Contains Presentation objects indexed by ID.
    private ObjectArray  m_presentations = new ObjectArray();

    // Contains Display objects indexed by ID.
    private ObjectArray  m_displays = new ObjectArray();

    // Contains Selector objects indexed by ID.
    private ObjectArray  m_selectors = new ObjectArray();

    // Contains Filter objects indexed by ID.
    private ObjectArray  m_filters = new ObjectArray();

    ///////////////////////////////////////////////////////////////////////

    private Menu  m_presentationMenu =
	new Menu(null, new AuxillaryMenuItem(m_presentations, "presentation"),
		 "*** TOP-LEVEL PRESENTATION MENU ***", -1);

    private Menu  m_displayMenu =
	new Menu(null, new AuxillaryMenuItem(m_displays, "display"),
		 "*** TOP-LEVEL DISPLAY MENU ***", -1);

    private Menu  m_selectorMenu =
	new Menu(null, new AuxillaryMenuItem(m_selectors, "selector"),
		 "*** TOP-LEVEL SELECTOR MENU ***", -1);

    private Menu  m_filterMenu =
	new Menu(null, new AuxillaryMenuItem(m_filters, "filter"),
		 "*** TOP-LEVEL FILTER MENU ***", -1);

    private Menu  m_attributeMenu =
	new Menu(null, new AttributeMenuItem(),
		 "*** TOP-LEVEL ATTRIBUTE MENU ***", -1);

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED INNER CLASSES
    ///////////////////////////////////////////////////////////////////////

    protected abstract class CommonGraphBuilder
	implements GraphBuilder
    {
	/////////////////////////////////////////////////////////////////////
	// CONSTRUCTORS
	/////////////////////////////////////////////////////////////////////

	public CommonGraphBuilder()
	{
	}

	/////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS (interface GraphBuilder)
	/////////////////////////////////////////////////////////////////////

	public void setGraphName(String name)
	{
	    assertInConstruction();
	    m_name = name;
	}

	public void setGraphDescription(String description)
	{
	    assertInConstruction();
	    m_description = description;
	}

	public EnumerationCreator addEnumeration(String name)
	    throws DuplicateObjectException
	{
	    assertInConstruction();
	    Enumeration enumeration = CommonGraph.this.addEnumeration(name);
	    return new EnumerationCreatorImpl(enumeration);
	}

	public QualifierCreator addQualifier(String type, String name,
					     String description)
	    throws DuplicateObjectException
	{
	    assertInConstruction();
	    commitCurrentAttributeDefinition();
	    QualifierType qualifierType =
		CommonGraph.this.findOrCreateQualifierTypeInstance(type);
	    Qualifier qualifier = qualifierType.addQualifier(name);
	    qualifier.setDescription(description);
	    return new QualifierCreatorImpl(qualifier);
	}

	public int addPresentation(String name, int display, int selector)
	{
	    assertInConstruction();
	    Presentation presentation =
		new Presentation(name, display, selector);
	    int retval = m_presentations.allocate();
	    m_presentations.setValue(retval, presentation);
	    return retval;
	}

	public DisplayCreator addDisplay(String name)
	{
	    assertInConstruction();
	    commitCurrentAttributeDefinition();
	    Display display = new Display(name);
	    int index = m_displays.allocate();
	    m_displays.setValue(index, display);
	    return new DisplayCreatorImpl(display, index);
	}

	public SelectorCreator addSelector(String name)
	{
	    assertInConstruction();
	    commitCurrentAttributeDefinition();
	    Selector selector = new Selector(name);
	    int index = m_selectors.allocate();
	    m_selectors.setValue(index, selector);
	    return new SelectorCreatorImpl(selector, index);
	}

	public int addFilter(String name, String expr)
	{
	    assertInConstruction();
	    commitCurrentAttributeDefinition();
	    Filter filter = new Filter(name, expr);
	    int retval = m_filters.allocate();
	    m_filters.setValue(retval, filter);
	    return retval;
	}

	public MenuCreator addPresentationSubmenu(String label,
						  int presentation)
	{
	    assertInConstruction();
	    Menu submenu =
		m_presentationMenu.appendSubmenu(label, presentation);
	    return new MenuCreatorImpl(submenu);
	}

	public MenuCreator addDisplaySubmenu(String label, int display)
	{
	    assertInConstruction();
	    Menu submenu = m_displayMenu.appendSubmenu(label, display);
	    return new MenuCreatorImpl(submenu);
	}

	public MenuCreator addSelectorSubmenu(String label, int selector)
	{
	    assertInConstruction();
	    Menu submenu = m_selectorMenu.appendSubmenu(label, selector);
	    return new MenuCreatorImpl(submenu);
	}

	public MenuCreator addFilterSubmenu(String label, int filter)
	{
	    assertInConstruction();
	    Menu submenu = m_filterMenu.appendSubmenu(label, filter);
	    return new MenuCreatorImpl(submenu);
	}

	public MenuCreator addAttributeSubmenu(String label, int attribute)
	{
	    assertInConstruction();
	    commitCurrentAttributeDefinition();
	    Menu submenu = m_attributeMenu.appendSubmenu(label, attribute);
	    return new MenuCreatorImpl(submenu);
	}

	/////////////////////////////////////////////////////////////////////
	// PROTECTED METHODS
	/////////////////////////////////////////////////////////////////////

	protected abstract void commitCurrentAttributeDefinition();

	protected void endCommonConstruction()
	{
	    assertInConstruction();
	    m_finishedConstruction = true;
	}

	protected void assertInConstruction()
	{
	    if (m_finishedConstruction)
	    {
		String msg =
		    "attempted to continue building after end of construction";
		throw new MisconstructionException(msg);
	    }
	}

	/////////////////////////////////////////////////////////////////////
	// PROTECTED FIELDS
	/////////////////////////////////////////////////////////////////////

	protected boolean  m_haveAllocatedNodes;
	protected boolean  m_haveAllocatedLinks;
	protected boolean  m_haveAllocatedPaths;
	protected boolean  m_haveAllocatedPathLinks;

	protected int  m_numLinksAdded;
	protected int  m_numPathsAdded;
	protected int  m_numPathLinksAdded;
	protected int  m_numOutgoingLinksAdded;
	protected int  m_numIncomingLinksAdded;

	/////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	/////////////////////////////////////////////////////////////////////

	private boolean  m_finishedConstruction;

	/////////////////////////////////////////////////////////////////////
	// PRIVATE INNER CLASSES
	/////////////////////////////////////////////////////////////////////

	private class EnumerationCreatorImpl
	    implements EnumerationCreator
	{
	    public EnumerationCreatorImpl(Enumeration enumeration)
	    {
		m_enumeration = enumeration;
	    }

	    public int getEnumerationID()
	    {
		return m_enumeration.getID();
	    }

	    public int addEnumerator(String name, int value)
		throws DuplicateObjectException
	    {
		assertInConstruction();
		if (m_enumeration.isMutable())
		{
		    Enumerator enumerator =
			m_enumeration.addEnumerator(name, value);
		    return enumerator.getID();
		}
		else
		{
		    String msg = "attempted to add an enumerator to an "
			+ "enumeration which has become immutable";
		    throw new ConstructionOrderException(msg);
		}
	    }

	    private Enumeration  m_enumeration;
	}

	/////////////////////////////////////////////////////////////////////

	private class QualifierCreatorImpl
	    implements QualifierCreator
	{
	    public QualifierCreatorImpl(Qualifier qualifier)
	    {
		m_qualifier = qualifier;
	    }

	    public void associateAttribute(int attribute)
		throws DuplicateObjectException
	    {
		assertInConstruction();
		m_qualifier.addQualifierAttribute(attribute);
	    }

	    public void associateAttribute(int attribute, String alias)
		throws DuplicateObjectException		
	    {
		assertInConstruction();
		m_qualifier.addQualifierAttribute(attribute, alias);
	    }

	    public void associateAttribute(String name, String alias)
		throws DuplicateObjectException
	    {
		assertInConstruction();
		m_qualifier.addQualifierAttribute(name, alias);
	    }

	    private Qualifier  m_qualifier;
	}

	/////////////////////////////////////////////////////////////////////

	private class DisplayCreatorImpl
	    implements DisplayCreator
	{
	    public DisplayCreatorImpl(Display display, int id)
	    {
		m_display = display;
		m_id = id;
	    }

	    public int getDisplayID()
	    {
		assertInConstruction();
		return m_id;
	    }

	    public void addDisplayMapping
		(String characteristic, int attribute,
		 boolean node, boolean link, boolean path)
		throws DuplicateObjectException
	    {
		assertInConstruction();
		m_display.addDisplayMapping(characteristic, attribute,
					    node, link, path);
	    }

	    private Display  m_display;
	    private int  m_id;
	}

	/////////////////////////////////////////////////////////////////////

	private class SelectorCreatorImpl
	    implements SelectorCreator
	{
	    public SelectorCreatorImpl(Selector selector, int id)
	    {
		m_selector = selector;
		m_id = id;
	    }

	    public int getSelectorID()
	    {
		assertInConstruction();
		return m_id;
	    }

	    public void addSelectorMapping
		(String characteristic, int filter,
		 boolean node, boolean link, boolean path)
		throws DuplicateObjectException
	    {
		assertInConstruction();
		m_selector.addSelectorMapping(characteristic, filter,
					      node, link, path);
	    }

	    private Selector  m_selector;
	    private int  m_id;
	}

	///////////////////////////////////////////////////////////////////

	private class MenuCreatorImpl
	    implements MenuCreator
	{
	    public MenuCreatorImpl(Menu menu)
	    {
		m_menu = menu;
	    }

	    public MenuCreator addSubmenu(String label, int id)
	    {
		assertInConstruction();
		Menu submenu = m_menu.appendSubmenu(label, id);
		return new MenuCreatorImpl(submenu);
	    }

	    private Menu  m_menu;
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE INNER CLASSES
    ///////////////////////////////////////////////////////////////////////

    protected interface EnumerationReader
	extends RemovableObject
    {
	boolean isMutable();
	int getID();
	String getName();
	EnumeratorIterator getEnumerators();
	EnumeratorReader getEnumeratorReader(String name);
	EnumeratorReader getEnumeratorReader(int id);
	void becomeImmutable();
    }

    ///////////////////////////////////////////////////////////////////////

    private class Enumeration
	extends ListNode
	implements RemovableObject, EnumerationReader
    {
	public Enumeration(int id, String name)
	{
	    super();
	    m_id = id;
	    m_name = name;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public boolean isMutable()
	{
	    assertNotRemoved();
	    return m_isMutable;
	}

	public int getID()
	{
	    assertNotRemoved();
	    return m_id;
	}

	public String getName()
	{
	    assertNotRemoved();
	    return m_name;
	}

	public EnumeratorIterator getEnumerators()
	{
	    assertNotRemoved();
	    return new EnumeratorIteratorImpl();
	}

	public EnumeratorReader getEnumeratorReader(String name)
	{
	    assertNotRemoved();
	    return CommonGraph.this.findEnumeratorInstance(m_name, name);
	}

	public EnumeratorReader getEnumeratorReader(int id)
	{
	    assertNotRemoved();
	    return CommonGraph.this.findEnumeratorInstance(id);
	}

	public void setName(String name)
	{
	    assertNotRemoved();
	    assertMutable();
	    m_name = name;
	}

	public Enumerator addEnumerator(String name, int value)
	    throws DuplicateObjectException
	{
	    assertNotRemoved();
	    assertMutable();
	    Enumerator enumerator =
		CommonGraph.this.addEnumerator(this, name, value);
	    m_enumeratorsList.append(enumerator);
	    return enumerator;
	}

	public void removeEnumerator(Enumerator enumerator)
	{
	    if (enumerator.getEnumeration() != m_id)
	    {
		String msg = "attempted to remove an enumerator of a "
		    + "different enumeration[" + enumerator.getEnumeration()
		    + "] than this[" + m_id + "]";
		throw new IllegalArgumentException(msg);
	    }
	    enumerator.becomeRemoved();
	    CommonGraph.this.removeEnumerator(this, enumerator);
	    m_enumeratorsList.unlink(enumerator);
	}

	public void removeEnumerators()
	{
	    assertNotRemoved();
	    assertMutable();
	    ListIterator iterator = m_enumeratorsList.getNodes();
	    while (!iterator.atEnd())
	    {
		Enumerator enumerator = (Enumerator)iterator.getNode();
		iterator.advance();
		removeEnumerator(enumerator);
	    }
	}

	public void becomeImmutable()
	{
	    assertNotRemoved();
	    m_isMutable = false;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS (interface RemovableObject)
	////////////////////////////////////////////////////////////////////

	public boolean isRemoved()
	{
	    return m_removableObject.isRemoved();
	}

	public void becomeRemoved()
	{
	    assertNotRemoved();
	    if (m_isMutable)
	    {
		removeEnumerators();
		m_removableObject.becomeRemoved();
	    }
	    else
	    {
		String msg = "attempted to remove an immutable enumeration";
		throw new ImmutableDataException(msg);
	    }
	}

	public void addRemovalObserver(Observer observer)
	{
	    assertNotRemoved();
	    m_removableObject.addRemovalObserver(observer);
	}

	public void removeRemovalObserver(Observer observer)
	{
	    assertNotRemoved();
	    m_removableObject.removeRemovalObserver(observer);
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void assertNotRemoved()
	{
	    if (m_removableObject.isRemoved())
	    {
		String msg =
		    "attempted to access an enumeration after removal";
		throw new RemovedObjectException(msg);
	    }
	}

	private void assertMutable()
	{
	    if (!m_isMutable)
	    {
		String msg = "enumeration has immutable dependent(s) "
		    + "and therefore is immutable";
		throw new ImmutableDataException(msg);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private boolean  m_isMutable = true;
	private int  m_id;
	private String  m_name;

	// Contains Enumerator objects.
	private ListHead  m_enumeratorsList = new ListHead();
	private CommonRemovableObject  m_removableObject
	    = new CommonRemovableObject();

	////////////////////////////////////////////////////////////////////

	private class EnumeratorIteratorImpl
	    implements EnumeratorIterator
	{
	    public EnumeratorIteratorImpl()
	    {
		rewind();
	    }

	    public boolean atEnd()
	    {
		return m_current == null;
	    }

	    public void advance()
	    {
		if (m_current != null)
		{
		    if (m_addedEnumerator)
		    {
			m_current = null;
		    }
		    else
		    {
			m_current = (Enumerator)m_current.getNext();
			if (m_current == m_enumeratorsList.getHead())
			{
			    m_current = null;
			}
		    }
		}
	    }

	    public void rewind()
	    {
		m_addedEnumerator = false;
		m_current = (Enumerator)m_enumeratorsList.getHead();
	    }

	    public int getID()
	    {
		assertNotAtEnd();
		Enumeration.this.assertNotRemoved();
		return m_current.getID();
	    }

	    public String getName()
	    {
		assertNotAtEnd();
		Enumeration.this.assertNotRemoved();
		return m_current.getName();
	    }

	    public int getValue()
	    {
		assertNotAtEnd();
		Enumeration.this.assertNotRemoved();
		return m_current.getValue();
	    }

	    public int getEnumeration()
	    {
		assertNotAtEnd();
		Enumeration.this.assertNotRemoved();
		return m_current.getEnumeration();
	    }

	    public void setName(String name)
		throws DuplicateObjectException
	    {
		assertNotAtEnd();
		Enumeration.this.assertNotRemoved();
		Enumeration.this.assertMutable();
		String oldName = m_current.getName();
		if (!name.equals(oldName))
		{
		    try
		    {
			m_current.setName(name);
			CommonGraph.this.changeEnumeratorMapping
			    (Enumeration.this, m_current, oldName);
		    }
		    catch (DuplicateObjectException e)
		    {
			m_current.setName(oldName);
			throw e;
		    }
		}
	    }

	    public void setValue(int value)
	    {
		assertNotAtEnd();
		Enumeration.this.assertNotRemoved();
		Enumeration.this.assertMutable();
		m_current.setValue(value);
	    }

	    public void removeEnumerator()
	    {
		assertNotAtEnd();
		Enumeration.this.assertNotRemoved();
		Enumeration.this.assertMutable();
		Enumerator enumerator = m_current;
		advance();
		Enumeration.this.removeEnumerator(enumerator);
	    }

	    public void addEnumerator(String name, int value)
		throws DuplicateObjectException
	    {
		Enumeration.this.assertNotRemoved();
		Enumeration.this.assertMutable();
		m_current = Enumeration.this.addEnumerator(name, value);
		m_addedEnumerator = true;
	    }

	    private void assertNotAtEnd()
	    {
		if (m_current == null)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    private boolean  m_addedEnumerator;
	    private Enumerator  m_current;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected interface EnumeratorReader
    {
	boolean isRemoved();
	int getID();
	String getName();
	int getValue();
    }

    ///////////////////////////////////////////////////////////////////////

    private class Enumerator
	extends ListNode
	implements EnumeratorReader
    {
	public Enumerator(int id, String name, int value, int enumeration)
	{
	    super();
	    m_id = id;
	    m_name = name;
	    m_value = value;
	    m_enumeration = enumeration;
	}

	////////////////////////////////////////////////////////////////////
	// PUBLIC METHODS
	////////////////////////////////////////////////////////////////////

	public boolean isRemoved()
	{
	    return m_isRemoved;
	}

	public int getID()
	{
	    assertNotRemoved();
	    return m_id;
	}

	public String getName()
	{
	    assertNotRemoved();
	    return m_name;
	}

	public int getValue()
	{
	    assertNotRemoved();
	    return m_value;
	}

	public int getEnumeration()
	{
	    assertNotRemoved();
	    return m_enumeration;
	}

	public void setName(String name)
	{
	    assertNotRemoved();
	    m_name = name;
	}

	public void setValue(int value)
	{
	    assertNotRemoved();
	    m_value = value;
	}

	public void becomeRemoved()
	{
	    m_isRemoved = true;
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE METHODS
	////////////////////////////////////////////////////////////////////

	private void assertNotRemoved()
	{
	    if (m_isRemoved)
	    {
		String msg = "attempted to access an enumerator after removal";
		throw new RemovedObjectException(msg);
	    }
	}

	////////////////////////////////////////////////////////////////////
	// PRIVATE FIELDS
	////////////////////////////////////////////////////////////////////

	private boolean  m_isRemoved;
	private int  m_id;
	private String  m_name;
	private int  m_value;
	private int  m_enumeration;
    }

    ///////////////////////////////////////////////////////////////////////

    private class EnumerationIteratorImpl
	implements EnumerationIterator
    {
	public EnumerationIteratorImpl(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start
		|| end > m_enumerations.getLogicalLength())
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingEnumerations();
	}

	public boolean atEnd()
	{
	    return m_enumeration == null;
	}

	public void advance()
	{
	    if (m_enumeration != null)
	    {
		if (m_addedEnumeration || m_current == m_end - 1)
		{
		    m_enumeration = null;
		}
		else
		{
		    ++m_current;
		    skipMissingEnumerations();
		}
	    }
	}

	public void rewind()
	{
	    m_addedEnumeration = false;
	    m_current = m_start;
	    skipMissingEnumerations();
	}

	public boolean isMutable()
	{
	    assertNotAtEnd();
	    return m_enumeration.isMutable();
	}

	public int getID()
	{
	    assertNotAtEnd();
	    return m_enumeration.getID();
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_enumeration.getName();
	}

	public EnumeratorIterator getEnumerators()
	{
	    assertNotAtEnd();
	    return m_enumeration.getEnumerators();
	}

	public void setName(String name)
	    throws DuplicateObjectException
	{
	    assertNotAtEnd();
	    assertMutable();
	    String oldName = m_enumeration.getName();
	    if (!name.equals(oldName))
	    {
		try
		{
		    m_enumeration.setName(name);
		    CommonGraph.this
			.changeEnumerationMapping(m_enumeration, oldName);
		}
		catch (DuplicateObjectException e)
		{
		    m_enumeration.setName(oldName);
		    throw e;
		}
	    }
	}

	public void removeEnumerators()
	{
	    assertNotAtEnd();	    
	    assertMutable();
	    m_enumeration.removeEnumerators();
	}

	public void removeEnumeration()
	{
	    assertNotAtEnd();
	    assertMutable();
	    m_enumeration.becomeRemoved();
	    CommonGraph.this.removeEnumeration(m_enumeration);
	    m_enumeration = null;
	    if (!m_addedEnumeration)
	    {
		++m_current;
		skipMissingEnumerations();
	    }
	}

	public void addEnumeration(String name)
	    throws DuplicateObjectException
	{
	    assertMutable();
	    m_enumeration = CommonGraph.this.addEnumeration(name);
	    m_addedEnumeration = true;
	    m_current = m_enumeration.getID();
	}

	private void skipMissingEnumerations()
	{
	    m_enumeration = null;
	    while (m_current < m_end)
	    {
		if (m_enumerations.checkAllocated(m_current))
		{
		    m_enumeration =
			CommonGraph.this.findEnumerationInstance(m_current);
		    break;
		}
		else
		{
		    ++m_current;
		}
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_enumeration == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private void assertMutable()
	{
	    if (!m_enumeration.isMutable())
	    {
		String msg = "enumeration[" + m_enumeration.getName()
		    + "] is immutable";
		throw new ImmutableDataException(msg);
	    }
	}

	private boolean  m_addedEnumeration = false;
	private Enumeration  m_enumeration;

	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class ReadOnlyEnumeratorIteratorImpl
	implements ReadOnlyEnumeratorIterator
    {
	public ReadOnlyEnumeratorIteratorImpl(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start
		|| end > m_enumerators.getLogicalLength())
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingEnumerators();
	}

	public boolean atEnd()
	{
	    return m_enumerator == null;
	}

	public void advance()
	{
	    if (m_enumerator != null)
	    {
		m_enumerator = null;
		if (m_current < m_end - 1)
		{
		    ++m_current;
		    skipMissingEnumerators();
		}
	    }
	}

	public void rewind()
	{
	    m_current = m_start;
	    skipMissingEnumerators();
	}

	public int getID()
	{
	    assertNotAtEnd();
	    assertNotRemoved();
	    return m_enumerator.getID();
	}

	public String getName()
	{
	    assertNotAtEnd();
	    assertNotRemoved();
	    return m_enumerator.getName();
	}

	public int getValue()
	{
	    assertNotAtEnd();
	    assertNotRemoved();
	    return m_enumerator.getValue();
	}

	public int getEnumeration()
	{
	    assertNotAtEnd();
	    assertNotRemoved();
	    return m_enumerator.getEnumeration();
	}

	private void skipMissingEnumerators()
	{
	    m_enumerator = null;
	    while (m_current < m_end)
	    {
		if (m_enumerators.checkAllocated(m_current))
		{
		    m_enumerator =
			CommonGraph.this.findEnumeratorInstance(m_current);
		    try
		    {
			if (m_enumeration == null
			    || m_enumeration.getID()
			    != m_enumerator.getEnumeration())
			{
			    m_enumeration =
				CommonGraph.this.findEnumerationInstance
				(m_enumerator.getEnumeration());
			}
		    }
		    catch (ObjectNotFoundException e)
		    { throw new InternalErrorException(e.toString()); }
		    break;
		}
		else
		{
		    ++m_current;
		}
	    }
	}

	private void assertNotRemoved()
	{
	    if (m_enumeration.isRemoved())
	    {
		String msg =
		    "attempted to access an enumeration after removal";
		throw new RemovedObjectException(msg);
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_enumerator == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private Enumerator  m_enumerator;
	private Enumeration  m_enumeration;

	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class QualifierType
    {
	public QualifierType(String name)
	{
	    m_name = name;
	}

	public String getName()
	{
	    return m_name;
	}

	public QualifierIterator getQualifiers()
	{
	    return new ByTypeQualifierIterator();
	}

	public void setName(String name)
	{
	    m_name = name;
	}

	public Qualifier addQualifier(String name)
	    throws DuplicateObjectException
	{
	    Qualifier qualifier = new Qualifier(m_name, name);
	    addQualifier(qualifier);
	    return qualifier;
	}

	public void removeQualifiers()
	{
	    while (!m_qualifiersByTypeList.isEmpty())
	    {
		Qualifier qualifier =
		    (Qualifier)m_qualifiersByTypeList.getHead();
		removeQualifier(qualifier);
	    }
	}

	public void assumeQualifierOwnership(Qualifier qualifier,
					     QualifierType currentOwner)
	{
	    currentOwner.m_qualifiersByTypeList.unlink(qualifier);
	    m_qualifiersByTypeList.append(qualifier);
	}

	public void removeQualifier(Qualifier qualifier)
	{
	    CommonGraph.this.removeQualifier(qualifier);
	    m_qualifiersByTypeList.unlink(qualifier);
	    qualifier.removeQualifierAttributes();
	}

	public void addQualifier(Qualifier qualifier)
	    throws DuplicateObjectException
	{
	    CommonGraph.this.addQualifier(qualifier);
	    m_qualifiersByTypeList.append(qualifier);
	}

 	private String  m_name;

	// Contains Qualifier objects.
	private ListHead  m_qualifiersByTypeList = new ListHead();

	///////////////////////////////////////////////////////////////////

	private class ByTypeQualifierIterator
	    extends AbstractQualifierIterator
	{
	    public ByTypeQualifierIterator()
	    {
		super();
		rewind();
	    }

	    public void advance()
	    {
		if (m_current != null)
		{
		    if (m_addedQualifier)
		    {
			m_current = null;
		    }
		    else
		    {
			m_current = (Qualifier)m_current.getNext();
			if (m_current == m_qualifiersByTypeList.getHead())
			{
			    m_current = null;
			}
		    }
		}
	    }

	    public void rewind()
	    {
		m_addedQualifier = false;
		m_current = (Qualifier)m_qualifiersByTypeList.getHead();
	    }

	    public void setType(String type)
	    {
		assertNotAtEnd();

		String currentType = m_current.getType();
		if (!currentType.equals(m_name))
		{
		    String msg = "qualifier[" + m_current.getName()
			+ "] in type[" + m_name + "] has a different type ["
			+ currentType + "]";
		    throw new InternalErrorException(msg);
		}

		if (!type.equals(currentType))
		{
		    Qualifier qualifier = m_current;
		    advance();
		    QualifierType qualifierType = CommonGraph.this
			.findOrCreateQualifierTypeInstance(type);
		    qualifierType.assumeQualifierOwnership
			(qualifier, QualifierType.this);
		}
	    }

	    public void removeQualifier()
	    {
		assertNotAtEnd();
		Qualifier qualifier = m_current;
		advance();
		QualifierType.this.removeQualifier(qualifier);
	    }

	    public void addQualifier(String type, String name)
		throws DuplicateObjectException
	    {
		m_current = QualifierType.this.addQualifier(name);
		m_addedQualifier = true;
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class Qualifier
	extends ListNode
    {
	public Qualifier(String type, String name)
	{
	    m_type = type;
	    m_name = name;
	}

	public String getType()
	{
	    return m_type;
	}

	public String getName()
	{
	    return m_name;
	}

	public String getDescription()
	{
	    return m_description;
	}

	public QualifierAttributeIterator getAttributes()
	{
	    return new QualifierAttributeIteratorImpl();
	}

	public void setType(String type)
	{
	    m_type = type;
	}

	public void setName(String name)
	{
	    m_name = name;
	}

	public void setDescription(String description)
	{
	    m_description = description;
	}

	public QualifierAttribute addQualifierAttribute(int attribute,
							String name)
	    throws DuplicateObjectException
	{
	    CommonGraph.this.validateAttributeExistence(attribute);

	    QualifierAttribute qualifierAttribute =
		new QualifierAttribute(name, attribute);
	    addQualifierAttribute(qualifierAttribute);
	    return qualifierAttribute;
	}

	public QualifierAttribute addQualifierAttribute(int attribute)
	    throws DuplicateObjectException
	{
	    CommonGraph.this.validateAttributeExistence(attribute);

	    String name = CommonGraph.this.findAttributeName(attribute);
	    return addQualifierAttribute(attribute, name);
	}

	public QualifierAttribute addQualifierAttribute(String attributeName,
							String alias)
	    throws DuplicateObjectException
	{
	    int attribute = CommonGraph.this.findAttributeID(attributeName);
	    return addQualifierAttribute(attribute, alias);
	}

	public void removeQualifierAttributes()
	{
	    while (!m_attributesList.isEmpty())
	    {
		QualifierAttribute qualifierAttribute =
		    (QualifierAttribute)m_attributesList.getHead();
		removeQualifierAttribute(qualifierAttribute);
	    }
	}

	private void removeQualifierAttribute
	    (QualifierAttribute qualifierAttribute)
	{
	    CommonGraph.this.removeAttributeRemovalObserver
		(qualifierAttribute.getAttribute(),
		 qualifierAttribute.getObserver());
	    m_attributesList.unlink(qualifierAttribute);
	    CommonGraph.this
		.removeQualifierAttributeMapping(this, qualifierAttribute);
	}

	private void addQualifierAttribute
	    (QualifierAttribute qualifierAttribute)
	    throws DuplicateObjectException
	{
	    AttributeDefinitionObserver observer =
		new AttributeDefinitionObserver(qualifierAttribute);
	    qualifierAttribute.setObserver(observer);
	    CommonGraph.this.addAttributeRemovalObserver
		(qualifierAttribute.getAttribute(), observer);

	    CommonGraph.this
		.addQualifierAttributeMapping(this, qualifierAttribute);
	    m_attributesList.append(qualifierAttribute);
	}

	private String  m_type;
	private String  m_name;
	private String  m_description = "";

	// Contains QualifierAttribute objects.
	private ListHead  m_attributesList = new ListHead();

	//////////////////////////////////////////////////////////////////

	private class AttributeDefinitionObserver
	    implements Observer
	{
	    public AttributeDefinitionObserver
		(QualifierAttribute qualifierAttribute)
	    {
		m_qualifierAttribute = qualifierAttribute;
	    }

	    public void update(Observable o, Object arg)
	    {
		Qualifier.this.removeQualifierAttribute(m_qualifierAttribute);
	    }

	    private QualifierAttribute  m_qualifierAttribute;
	}

	//////////////////////////////////////////////////////////////////

	private class QualifierAttributeIteratorImpl
	    implements QualifierAttributeIterator
	{
	    public QualifierAttributeIteratorImpl()
	    {
		rewind();
	    }

	    public boolean atEnd()
	    {
		return m_current == null;
	    }

	    public void advance()
	    {
		if (m_current != null)
		{
		    if (m_addedQualifierAttribute)
		    {
			m_current = null;
		    }
		    else
		    {
			m_current = (QualifierAttribute)m_current.getNext();
			if (m_current == m_attributesList.getHead())
			{
			    m_current = null;
			}
		    }
		}
	    }

	    public void rewind()
	    {
		m_addedQualifierAttribute = false;
		m_current = (QualifierAttribute)m_attributesList.getHead();
	    }

	    public String getName()
	    {
		assertNotAtEnd();
		return m_current.getName();
	    }

	    public int getAttributeID()
	    {
		assertNotAtEnd();
		return m_current.getAttribute();
	    }

	    public void setName(String name)
		throws DuplicateObjectException
	    {
		assertNotAtEnd();
		String oldName = m_current.getName();
		if (!name.equals(oldName))
		{
		    try
		    {
			m_current.setName(name);
			CommonGraph.this.changeQualifierAttributeMapping
			    (Qualifier.this, m_current, oldName);
		    }
		    catch (DuplicateObjectException e)
		    {
			m_current.setName(oldName);
			throw e;
		    }
		}
	    }

	    public void dissociateAttribute()
	    {
		assertNotAtEnd();
		QualifierAttribute qualifierAttribute = m_current;
		advance();
		Qualifier.this.removeQualifierAttribute(qualifierAttribute);
	    }

	    public void associateAttribute(int attribute)
		throws DuplicateObjectException
	    {
		Qualifier.this.addQualifierAttribute(attribute);
		m_addedQualifierAttribute = true;
	    }

	    public void associateAttribute(int attribute, String alias)
		throws DuplicateObjectException		
	    {
		Qualifier.this.addQualifierAttribute(attribute, alias);
		m_addedQualifierAttribute = true;
	    }

	    public void associateAttribute(String name, String alias)
		throws DuplicateObjectException
	    {
		Qualifier.this.addQualifierAttribute(name, alias);
		m_addedQualifierAttribute = true;
	    }

	    private void assertNotAtEnd()
	    {
		if (m_current == null)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    private boolean  m_addedQualifierAttribute;
	    private QualifierAttribute  m_current;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class QualifierAttribute
	extends ListNode
    {
	public QualifierAttribute(String name, int attribute)
	{
	    m_name = name;
	    m_attribute = attribute;
	}

	public String getName()
	{
	    return m_name;
	}

	public int getAttribute()
	{
	    return m_attribute;
	}

	public Observer getObserver()
	{
	    return m_observer;
	}

	public void setName(String name)
	{
	    m_name = name;
	}

	public void setObserver(Observer observer)
	{
	    m_observer = observer;
	}

	private String  m_name;
	private int  m_attribute;
	private Observer  m_observer;
    }

    ///////////////////////////////////////////////////////////////////////

    private abstract class AbstractQualifierIterator
	implements QualifierIterator
    {
	public AbstractQualifierIterator() {}

	public boolean atEnd()
	{
	    return m_current == null;
	}

	public String getType()
	{
	    assertNotAtEnd();
	    return m_current.getType();
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_current.getName();
	}

	public String getDescription()
	{
	    assertNotAtEnd();
	    return m_current.getDescription();
	}

	public QualifierAttributeIterator getAttributes()
	{
	    assertNotAtEnd();
	    return m_current.getAttributes();
	}

	public void setName(String name)
	    throws DuplicateObjectException
	{
	    assertNotAtEnd();
	    String oldName = m_current.getName();
	    if (!name.equals(oldName))
	    {
		try
		{
		    m_current.setName(name);
		    CommonGraph.this
			.changeQualifierMapping(m_current, oldName);
		}
		catch (DuplicateObjectException e)
		{
		    m_current.setName(oldName);
		    throw e;
		}
	    }
	}

	public void setDescription(String description)
	{
	    assertNotAtEnd();
	    m_current.setDescription(description);
	}

	public void removeAttributes()
	{
	    assertNotAtEnd();
	    m_current.removeQualifierAttributes();
	}

	public void addQualifier(String type, String name)
	    throws DuplicateObjectException
	{
	    QualifierType qualifierType =
		CommonGraph.this.findOrCreateQualifierTypeInstance(type);
	    m_current = qualifierType.addQualifier(name);
	    m_addedQualifier = true;
	}

	protected void assertNotAtEnd()
	{
	    if (m_current == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	protected boolean  m_addedQualifier;
	protected Qualifier  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private abstract class AbstractExternalQualifierIterator
	extends AbstractQualifierIterator
    {
	public AbstractExternalQualifierIterator()
	{
	    super();
	}

	public void setType(String type)
	{
	    assertNotAtEnd();
	    String currentType = m_current.getType();
	    if (!type.equals(currentType))
	    {
		Qualifier current = m_current;
		advance();
		QualifierType oldQualifierType =
		    CommonGraph.this.findQualifierTypeInstance(currentType);
		QualifierType newQualifierType =
		    CommonGraph.this.findOrCreateQualifierTypeInstance(type);
		newQualifierType.assumeQualifierOwnership
		    (current, oldQualifierType);
		finishRemoval();
	    }
	}

	public void removeQualifier()
	{
	    assertNotAtEnd();
	    Qualifier current = m_current;
	    advance();
	    QualifierType qualifierType =
		CommonGraph.this.findQualifierTypeInstance(current.getType());
	    qualifierType.removeQualifier(current);
	    finishRemoval();
	}

	protected void finishRemoval() {}
    }

    ///////////////////////////////////////////////////////////////////////

    private class AllQualifierIterator
	extends AbstractExternalQualifierIterator
    {
	public AllQualifierIterator()
	{
	    super();
	    rewind();
	}

	public void advance()
	{
	    if (m_current != null)
	    {
		if (m_addedQualifier)
		{
		    m_current = null;
		}
		else
		{
		    m_currentNode = (ContainerListNode)m_currentNode.getNext();
		    m_current =
			(m_currentNode == m_qualifiersList.getHead()
			 ? null : (Qualifier)m_currentNode.getObject());
		}
	    }
	}

	public void rewind()
	{
	    m_addedQualifier = false;
	    m_currentNode = (ContainerListNode)m_qualifiersList.getHead();
	    m_current = (m_currentNode == null
			 ? null : (Qualifier)m_currentNode.getObject());
	}

	private ContainerListNode  m_currentNode;
    }

    ///////////////////////////////////////////////////////////////////////

    private class SingleQualifierIterator
	extends AbstractExternalQualifierIterator
    {
	public SingleQualifierIterator(ContainerListNode node)
	{
	    super();

	    m_singleNode = node;
	    rewind();
	}

	public void advance()
	{
	    m_current = null;
	}

	public void rewind()
	{
	    m_addedQualifier = false;
	    m_current = (m_singleNode == null
			 ? null : (Qualifier)m_singleNode.getObject());
	}

	protected void finishRemoval()
	{
	    if (!m_addedQualifier)
	    {
		m_singleNode = null;
	    }
	}

	private ContainerListNode  m_singleNode;
    }

    ///////////////////////////////////////////////////////////////////////

    private class EmptyQualifierIterator
	extends AbstractExternalQualifierIterator
    {
	public EmptyQualifierIterator()
	{
	    super();
	    rewind();
	}

	public void advance()
	{
	    m_current = null;
	}

	public void rewind()
	{
	    m_addedQualifier = false;
	    m_current = null;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private abstract class AbstractQualifierTypeIterator
	implements QualifierTypeIterator
    {
	public AbstractQualifierTypeIterator() {}

	public boolean atEnd()
	{
	    return m_current == null;
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_current.getName();
	}

	public QualifierIterator getQualifiers()
	{
	    assertNotAtEnd();
	    return m_current.getQualifiers();
	}

	public void setName(String name)
	    throws DuplicateObjectException
	{
	    assertNotAtEnd();
	    String oldName = m_current.getName();
	    if (!name.equals(oldName))
	    {
		try
		{
		    m_current.setName(name);
		    CommonGraph.this
			.changeQualifierTypeMapping(m_current, oldName);
		}
		catch (DuplicateObjectException e)
		{
		    m_current.setName(oldName);
		    throw e;
		}
	    }
	}

	public void removeQualifiers()
	{
	    assertNotAtEnd();
	    m_current.removeQualifiers();
	}

	public void addQualifierType(String name)
	    throws DuplicateObjectException
	{
	    QualifierType qualifierType = new QualifierType(name);
	    CommonGraph.this.addQualifierType(qualifierType);
	    m_current = qualifierType;
	    m_addedQualifierType = true;
	}

	public void removeQualifierType()
	{
	    assertNotAtEnd();
	    QualifierType current = m_current;
	    advance();
	    CommonGraph.this.removeQualifierType(current);
	    current.removeQualifiers();
	    finishRemoval();
	}

	protected void finishRemoval() {}

	protected void assertNotAtEnd()
	{
	    if (m_current == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	protected boolean  m_addedQualifierType;
	protected QualifierType  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class AllQualifierTypeIterator
	extends AbstractQualifierTypeIterator
    {
	public AllQualifierTypeIterator()
	{
	    super();
	    rewind();
	}

	public void advance()
	{
	    if (m_current != null)
	    {
		if (m_addedQualifierType)
		{
		    m_current = null;
		}
		else
		{
		    m_currentNode = (ContainerListNode)m_currentNode.getNext();
		    m_current =
			(m_currentNode == m_qualifierTypesList.getHead()
			 ? null : (QualifierType)m_currentNode.getObject());
		}
	    }
	}

	public void rewind()
	{
	    m_addedQualifierType = false;
	    m_currentNode = (ContainerListNode)m_qualifierTypesList.getHead();
	    m_current = (m_currentNode == null
			 ? null : (QualifierType)m_currentNode.getObject());
	}

	private ContainerListNode  m_currentNode;
    }

    ///////////////////////////////////////////////////////////////////////

    private class SingleQualifierTypeIterator
	extends AbstractQualifierTypeIterator
    {
	public SingleQualifierTypeIterator(ContainerListNode node)
	{
	    super();

	    m_singleNode = node;
	    rewind();
	}

	public void advance()
	{
	    m_current = null;
	}

	public void rewind()
	{
	    m_addedQualifierType = false;
	    m_current = (m_singleNode == null
			 ? null : (QualifierType)m_singleNode.getObject());
	}

	protected void finishRemoval()
	{
	    if (!m_addedQualifierType)
	    {
		m_singleNode = null;
	    }
	}

	private ContainerListNode  m_singleNode;
    }

    ///////////////////////////////////////////////////////////////////////

    private class EmptyQualifierTypeIterator
	extends AbstractQualifierTypeIterator
    {
	public EmptyQualifierTypeIterator()
	{
	    super();
	    rewind();
	}

	public void advance()
	{
	    m_current = null;
	}

	public void rewind()
	{
	    m_addedQualifierType = false;
	    m_current = null;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class Presentation
	extends CommonRemovableObject
    {
	public Presentation(String name, int displayID, int selectorID)
	{
	    super();
	    m_name = name;
	    m_display = displayID;
	    m_selector = selectorID;

	    Display display = CommonGraph.this.findDisplayInstance(displayID);
	    Selector selector =
		CommonGraph.this.findSelectorInstance(selectorID);
	    display.addRemovalObserver(m_removalObserver);
	    selector.addRemovalObserver(m_removalObserver);
	}

	public String getName()
	{
	    assertNotRemoved();
	    return m_name;
	}

	public int getDisplayID()
	{
	    assertNotRemoved();
	    return m_display;
	}

	public int getSelectorID()
	{
	    assertNotRemoved();
	    return m_selector;
	}

	public void setName(String name)
	{
	    assertNotRemoved();
	    m_name = name;
	}

	public void setDisplayID(int displayID)
	{
	    assertNotRemoved();
	    if (displayID != m_display)
	    {
		Display display =
		    CommonGraph.this.findDisplayInstance(displayID);
		display.addRemovalObserver(m_removalObserver);

		Display oldDisplay =
		    CommonGraph.this.findDisplayInstance(m_display);
		oldDisplay.removeRemovalObserver(m_removalObserver);
		m_display = displayID;
	    }
	}

	public void setSelectorID(int selectorID)
	{
	    assertNotRemoved();
	    if (selectorID != m_selector)
	    {
		Selector selector =
		    CommonGraph.this.findSelectorInstance(selectorID);
		selector.addRemovalObserver(m_removalObserver);

		Selector oldSelector =
		    CommonGraph.this.findSelectorInstance(m_selector);
		oldSelector.removeRemovalObserver(m_removalObserver);
		m_selector = selectorID;
	    }
	}

	protected void processRemovalRequest()
	{
	    Display display =
		CommonGraph.this.findDisplayInstance(m_display);
	    Selector selector =
		CommonGraph.this.findSelectorInstance(m_selector);
	    display.removeRemovalObserver(m_removalObserver);
	    selector.removeRemovalObserver(m_removalObserver);
	}

	private String  m_name;
	private int  m_display;
	private int  m_selector;
	private RemovalObserver  m_removalObserver = new RemovalObserver();

	//////////////////////////////////////////////////////////////////

	private class RemovalObserver
	    implements Observer
	{
	    public void update(Observable o, Object arg)
	    {
		Presentation.this.assertNotRemoved();
		processRemovalRequest();
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private class PresentationIteratorImpl
	implements PresentationIterator
    {
	public PresentationIteratorImpl(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start)
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingPresentations();
	}

	public boolean atEnd()
	{
	    return m_presentation == null;
	}

	public void advance()
	{
	    if (m_presentation != null)
	    {
		if (m_addedPresentation || m_current == m_end - 1)
		{
		    m_presentation = null;
		}
		else
		{
		    ++m_current;
		    skipMissingPresentations();
		}
	    }
	}

	public void rewind()
	{
	    m_addedPresentation = false;
	    m_current = m_start;
	    skipMissingPresentations();
	}

	public int getID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_presentation.getName();
	}

	public int getDisplayID()
	{
	    assertNotAtEnd();
	    return m_presentation.getDisplayID();
	}

	public int getSelectorID()
	{
	    assertNotAtEnd();
	    return m_presentation.getSelectorID();
	}

	public void setName(String name)
	{
	    assertNotAtEnd();
	    m_presentation.setName(name);
	}

	public void setDisplayID(int id)
	{
	    assertNotAtEnd();
	    m_presentation.setDisplayID(id);
	}

	public void setSelectorID(int id)
	{
	    assertNotAtEnd();
	    m_presentation.setSelectorID(id);
	}

	public void removePresentation()
	{
	    assertNotAtEnd();
	    m_presentation.becomeRemoved();
	    m_presentations.free(m_current);
	    m_presentation = null;

	    if (!m_addedPresentation)
	    {
		++m_current;
		skipMissingPresentations();
	    }
	}

	public void addPresentation(String name, int display, int selector)
	{
	    m_presentation = new Presentation(name, display, selector);
	    m_current = m_presentations.allocate();
	    m_presentations.setValue(m_current, m_presentation);
	    m_addedPresentation = true;
	}

	private void skipMissingPresentations()
	{
	    m_presentation = null;
	    while (m_current < m_end)
	    {
		if (m_presentations.checkAllocated(m_current))
		{
		    m_presentation =
			(Presentation)m_presentations.getValue(m_current);
		    if (m_presentation == null)
		    {
			String msg =
			    "null presentation reference in allocated slot";
			throw new InternalErrorException(msg);
		    }
		    break;
		}
		else
		{
		    ++m_current;
		}
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_presentation == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private boolean  m_addedPresentation = false;
	private Presentation  m_presentation;

	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class Display
	extends CommonRemovableObject
    {
	public Display(String name)
	{
	    super();
	    m_name = name;
	}

	public String getName()
	{
	    assertNotRemoved();
	    return m_name;
	}

	public DisplayMappingIterator getDisplayMappings()
	{
	    assertNotRemoved();
	    return new DisplayMappingIteratorImpl();
	}

	public void setName(String name)
	{
	    assertNotRemoved();
	    m_name = name;
	}

	public void addDisplayMapping(String characteristic, int attribute,
				      boolean node, boolean link, boolean path)
	    throws DuplicateObjectException
	{
	    assertNotRemoved();
	    DisplayMapping displayMapping = new DisplayMapping
		(characteristic, attribute, node, link, path);
	    addDisplayMapping(displayMapping);
	}

	public void removeDisplayMappings()
	{
	    assertNotRemoved();
	    while (!m_mappingsList.isEmpty())
	    {
		DisplayMapping displayMapping =
		    (DisplayMapping)m_mappingsList.getHead();
		removeDisplayMapping(displayMapping);
	    }
	}

	protected void processRemovalRequest()
	{
	    removeDisplayMappings();
	}

	private void addDisplayMapping(DisplayMapping displayMapping)
	    throws DuplicateObjectException
	{
	    CommonGraph.this.validateAttributeExistence
		(displayMapping.getAttributeID());
	    checkForDuplicateCharacteristic
		(displayMapping.getDisplayCharacteristic());

	    AttributeDefinitionObserver observer =
		new AttributeDefinitionObserver(displayMapping);
	    displayMapping.setObserver(observer);
	    CommonGraph.this.addAttributeRemovalObserver
		(displayMapping.getAttributeID(), observer);

	    m_mappingsList.append(displayMapping);
	}

	private void removeDisplayMapping(DisplayMapping displayMapping)
	{
	    CommonGraph.this.removeAttributeRemovalObserver
		(displayMapping.getAttributeID(),
		 displayMapping.getObserver());
	    m_mappingsList.unlink(displayMapping);
	}

	private void changeDisplayMappingAttribute
	    (DisplayMapping displayMapping, int attribute)
	{
	    CommonGraph.this.validateAttributeExistence(attribute);	    

	    int oldAttribute = displayMapping.getAttributeID();
	    Observer observer = displayMapping.getObserver();
	    CommonGraph.this
		.removeAttributeRemovalObserver(oldAttribute, observer);
	    CommonGraph.this.addAttributeRemovalObserver(attribute, observer);
	    displayMapping.setAttributeID(attribute);
	}

	private void checkForDuplicateCharacteristic(String characteristic)
	    throws DuplicateObjectException
	{
	    ListIterator iterator = m_mappingsList.getNodes();
	    while (!iterator.atEnd())
	    {
		DisplayMapping displayMapping =
		    (DisplayMapping)iterator.getNode();

		if (displayMapping.getDisplayCharacteristic()
		    .equals(characteristic))
		{
		    String msg = "characteristic[" + characteristic
			+ "] already exists";
		    throw new DuplicateObjectException(msg);
		}

		iterator.advance();
	    }
	}

	private String  m_name;

	// Contains DisplayMapping objects.
	private ListHead  m_mappingsList = new ListHead();

	//////////////////////////////////////////////////////////////////

	private class AttributeDefinitionObserver
	    implements Observer
	{
	    public AttributeDefinitionObserver(DisplayMapping displayMapping)
	    {
		m_displayMapping = displayMapping;
	    }

	    public void update(Observable o, Object arg)
	    {
		Display.this.assertNotRemoved();
		Display.this.removeDisplayMapping(m_displayMapping);
	    }

	    private DisplayMapping  m_displayMapping;
	}

	//////////////////////////////////////////////////////////////////

	private class DisplayMappingIteratorImpl
	    implements DisplayMappingIterator
	{
	    public DisplayMappingIteratorImpl()
	    {
		rewind();
	    }

	    public boolean atEnd()
	    {
		return m_current == null;
	    }

	    public void advance()
	    {
		if (m_current != null)
		{
		    if (m_addedDisplayMapping)
		    {
			m_current = null;
		    }
		    else
		    {
			m_current = (DisplayMapping)m_current.getNext();
			if (m_current == m_mappingsList.getHead())
			{
			    m_current = null;
			}
		    }
		}
	    }

	    public void rewind()
	    {
		m_addedDisplayMapping = false;
		m_current = (DisplayMapping)m_mappingsList.getHead();
	    }

	    public int getAttributeID()
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		return m_current.getAttributeID();
	    }

	    public String getDisplayCharacteristic()
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		return m_current.getDisplayCharacteristic();
	    }

	    public boolean checkNodeInTarget()
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		return m_current.checkNodeInTarget();
	    }

	    public boolean checkLinkInTarget()
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		return m_current.checkLinkInTarget();
	    }

	    public boolean checkPathInTarget()
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		return m_current.checkPathInTarget();
	    }

	    public boolean checkObjectInTarget(ObjectType type)
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		return m_current.checkObjectInTarget(type);
	    }

	    public void setAttributeID(int id)
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		if (id != m_current.getAttributeID())
		{
		    Display.this.changeDisplayMappingAttribute(m_current, id);
		}
	    }

	    public void setDisplayCharacteristic(String characteristic)
		throws DuplicateObjectException
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		Display.this.checkForDuplicateCharacteristic(characteristic);
		m_current.setDisplayCharacteristic(characteristic);
	    }

	    public void setNodeInTarget(boolean flag)
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		m_current.setNodeInTarget(flag);
	    }

	    public void setLinkInTarget(boolean flag)
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		m_current.setLinkInTarget(flag);
	    }

	    public void setPathInTarget(boolean flag)
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		m_current.setPathInTarget(flag);
	    }

	    public void setObjectInTarget(ObjectType type, boolean flag)
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		m_current.setObjectInTarget(type, flag);
	    }

	    public void removeDisplayMapping()
	    {
		assertNotAtEnd();
		Display.this.assertNotRemoved();
		DisplayMapping displayMapping = m_current;
		advance();
		Display.this.removeDisplayMapping(displayMapping);
	    }

	    public void addDisplayMapping
		(String characteristic, int attribute,
		 boolean node, boolean link, boolean path)
		throws DuplicateObjectException
	    {
		Display.this.assertNotRemoved();
		Display.this.addDisplayMapping
		    (characteristic, attribute, node, link, path);
		m_addedDisplayMapping = true;
	    }

	    private void assertNotAtEnd()
	    {
		if (m_current == null)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    private boolean  m_addedDisplayMapping;
	    private DisplayMapping  m_current;
	}
    }

    //////////////////////////////////////////////////////////////////

    private class DisplayMapping
	extends ListNode
    {
	public DisplayMapping(String characteristic, int attribute,
			      boolean node, boolean link, boolean path)
	{
	    m_characteristic = characteristic;
	    m_attribute = attribute;
	    m_nodeInTarget = node;
	    m_linkInTarget = link;
	    m_pathInTarget = path;
	}

	public int getAttributeID()
	{
	    return m_attribute;
	}

	public String getDisplayCharacteristic()
	{
	    return m_characteristic;
	}

	public boolean checkNodeInTarget()
	{
	    return m_nodeInTarget;
	}

	public boolean checkLinkInTarget()
	{
	    return m_linkInTarget;
	}

	public boolean checkPathInTarget()
	{
	    return m_pathInTarget;
	}

	public boolean checkObjectInTarget(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return checkNodeInTarget();
	    case ObjectType._LINK: return checkLinkInTarget();
	    case ObjectType._PATH: return checkPathInTarget();
	    default: throw new InternalErrorException();
	    }
	}

	public Observer getObserver()
	{
	    return m_observer;
	}

	public void setAttributeID(int id)
	{
	    m_attribute = id;
	}

	public void setDisplayCharacteristic(String characteristic)
	{
	    m_characteristic = characteristic;
	}

	public void setNodeInTarget(boolean flag)
	{
	    m_nodeInTarget = flag;
	}

	public void setLinkInTarget(boolean flag)
	{
	    m_linkInTarget = flag;
	}

	public void setPathInTarget(boolean flag)
	{
	    m_pathInTarget = flag;
	}

	public void setObjectInTarget(ObjectType type, boolean flag)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: setNodeInTarget(flag); break;
	    case ObjectType._LINK: setLinkInTarget(flag); break;
	    case ObjectType._PATH: setPathInTarget(flag); break;
	    default: throw new InternalErrorException();
	    }
	}

	public void setObserver(Observer observer)
	{
	    m_observer = observer;
	}

	private String  m_characteristic;
	private int  m_attribute;
	private boolean  m_nodeInTarget;
	private boolean  m_linkInTarget;
	private boolean  m_pathInTarget;
	private Observer  m_observer;
    }

    ///////////////////////////////////////////////////////////////////////

    private class DisplayIteratorImpl
	implements DisplayIterator
    {
	public DisplayIteratorImpl(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start)
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingDisplays();
	}

	public boolean atEnd()
	{
	    return m_display == null;
	}

	public void advance()
	{
	    if (m_display != null)
	    {
		if (m_addedDisplay || m_current == m_end - 1)
		{
		    m_display = null;
		}
		else
		{
		    ++m_current;
		    skipMissingDisplays();
		}
	    }
	}

	public void rewind()
	{
	    m_addedDisplay = false;
	    m_current = m_start;
	    skipMissingDisplays();
	}

	public int getID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_display.getName();
	}

	public DisplayMappingIterator getDisplayMappings()
	{
	    assertNotAtEnd();
	    return m_display.getDisplayMappings();
	}

	public void setName(String name)
	{
	    assertNotAtEnd();
	    m_display.setName(name);
	}

	public void removeDisplayMappings()
	{
	    assertNotAtEnd();
	    m_display.removeDisplayMappings();
	}

	public void removeDisplay()
	{
	    assertNotAtEnd();
	    m_display.becomeRemoved();
	    m_displays.free(m_current);
	    m_display = null;

	    if (!m_addedDisplay)
	    {
		++m_current;
		skipMissingDisplays();
	    }
	}

	public void addDisplay(String name)
	{
	    m_display = new Display(name);
	    m_current = m_displays.allocate();
	    m_displays.setValue(m_current, m_display);
	    m_addedDisplay = true;
	}

	private void skipMissingDisplays()
	{
	    m_display = null;
	    while (m_current < m_end)
	    {
		if (m_displays.checkAllocated(m_current))
		{
		    m_display = (Display)m_displays.getValue(m_current);
		    if (m_display == null)
		    {
			String msg ="null display reference in allocated slot";
			throw new InternalErrorException(msg);
		    }
		    break;
		}
		else
		{
		    ++m_current;
		}
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_display == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private boolean  m_addedDisplay = false;
	private Display  m_display;

	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class Selector
	extends CommonRemovableObject
    {
	public Selector(String name)
	{
	    super();
	    m_name = name;
	}

	public String getName()
	{
	    assertNotRemoved();
	    return m_name;
	}

	public SelectorMappingIterator getSelectorMappings()
	{
	    assertNotRemoved();
	    return new SelectorMappingIteratorImpl();
	}

	public void setName(String name)
	{
	    assertNotRemoved();
	    m_name = name;
	}

	public void addSelectorMapping
	    (String characteristic, int filter,
	     boolean node, boolean link, boolean path)
	    throws DuplicateObjectException
	{
	    assertNotRemoved();
	    SelectorMapping selectorMapping = new SelectorMapping
		(characteristic, filter, node, link, path);
	    addSelectorMapping(selectorMapping);
	}

	public void removeSelectorMappings()
	{
	    assertNotRemoved();
	    while (!m_mappingsList.isEmpty())
	    {
		SelectorMapping selectorMapping =
		    (SelectorMapping)m_mappingsList.getHead();
		removeSelectorMapping(selectorMapping);
	    }
	}

	protected void processRemovalRequest()
	{
	    removeSelectorMappings();
	}

	private void addSelectorMapping(SelectorMapping selectorMapping)
	    throws DuplicateObjectException
	{
	    checkForDuplicateCharacteristic
		(selectorMapping.getDisplayCharacteristic());

	    Filter filter = CommonGraph.this
		.findFilterInstance(selectorMapping.getFilterID());
	    FilterObserver observer = new FilterObserver(selectorMapping);
	    selectorMapping.setObserver(observer);
	    filter.addRemovalObserver(observer);
	    m_mappingsList.append(selectorMapping);
	}

	private void removeSelectorMapping(SelectorMapping selectorMapping)
	{
	    Filter filter = CommonGraph.this
		.findFilterInstance(selectorMapping.getFilterID());
	    filter.removeRemovalObserver(selectorMapping.getObserver());
	    m_mappingsList.unlink(selectorMapping);
	}

	private void changeSelectorMappingFilter
	    (SelectorMapping selectorMapping, int filter)
	{
	    Filter newFilter = CommonGraph.this.findFilterInstance(filter);
	    Filter oldFilter = CommonGraph.this
		.findFilterInstance(selectorMapping.getFilterID());
	    Observer observer = selectorMapping.getObserver();
	    oldFilter.removeRemovalObserver(observer);
	    newFilter.addRemovalObserver(observer);
	    selectorMapping.setFilterID(filter);
	}

	private void checkForDuplicateCharacteristic(String characteristic)
	    throws DuplicateObjectException
	{
	    ListIterator iterator = m_mappingsList.getNodes();
	    while (!iterator.atEnd())
	    {
		SelectorMapping selectorMapping =
		    (SelectorMapping)iterator.getNode();

		if (selectorMapping.getDisplayCharacteristic()
		    .equals(characteristic))
		{
		    String msg = "characteristic[" + characteristic
			+ "] already exists";
		    throw new DuplicateObjectException(msg);
		}

		iterator.advance();
	    }
	}

	private String  m_name;

	// Contains SelectorMapping objects.
	private ListHead  m_mappingsList = new ListHead();

	//////////////////////////////////////////////////////////////////

	private class FilterObserver
	    implements Observer
	{
	    public FilterObserver(SelectorMapping selectorMapping)
	    {
		m_selectorMapping = selectorMapping;
	    }

	    public void update(Observable o, Object arg)
	    {
		Selector.this.assertNotRemoved();
		Selector.this.removeSelectorMapping(m_selectorMapping);
	    }

	    private SelectorMapping  m_selectorMapping;
	}

	//////////////////////////////////////////////////////////////////

	private class SelectorMappingIteratorImpl
	    implements SelectorMappingIterator
	{
	    public SelectorMappingIteratorImpl()
	    {
		rewind();
	    }

	    public boolean atEnd()
	    {
		return m_current == null;
	    }

	    public void advance()
	    {
		if (m_current != null)
		{
		    if (m_addedSelectorMapping)
		    {
			m_current = null;
		    }
		    else
		    {
			m_current = (SelectorMapping)m_current.getNext();
			if (m_current == m_mappingsList.getHead())
			{
			    m_current = null;
			}
		    }
		}
	    }

	    public void rewind()
	    {
		m_addedSelectorMapping = false;
		m_current = (SelectorMapping)m_mappingsList.getHead();
	    }

	    public int getFilterID()
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		return m_current.getFilterID();
	    }

	    public String getDisplayCharacteristic()
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		return m_current.getDisplayCharacteristic();
	    }

	    public boolean checkNodeInTarget()
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		return m_current.checkNodeInTarget();
	    }

	    public boolean checkLinkInTarget()
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		return m_current.checkLinkInTarget();
	    }

	    public boolean checkPathInTarget()
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		return m_current.checkPathInTarget();
	    }

	    public boolean checkObjectInTarget(ObjectType type)
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		return m_current.checkObjectInTarget(type);
	    }

	    public void setFilterID(int id)
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		if (id != m_current.getFilterID())
		{
		    Selector.this.changeSelectorMappingFilter(m_current, id);
		}
	    }

	    public void setDisplayCharacteristic(String characteristic)
		throws DuplicateObjectException
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		Selector.this.checkForDuplicateCharacteristic(characteristic);
		m_current.setDisplayCharacteristic(characteristic);
	    }

	    public void setNodeInTarget(boolean flag)
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		m_current.setNodeInTarget(flag);
	    }

	    public void setLinkInTarget(boolean flag)
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		m_current.setLinkInTarget(flag);
	    }

	    public void setPathInTarget(boolean flag)
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		m_current.setPathInTarget(flag);
	    }

	    public void setObjectInTarget(ObjectType type, boolean flag)
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		m_current.setObjectInTarget(type, flag);
	    }

	    public void removeSelectorMapping()
	    {
		assertNotAtEnd();
		Selector.this.assertNotRemoved();
		SelectorMapping selectorMapping = m_current;
		advance();
		Selector.this.removeSelectorMapping(selectorMapping);
	    }

	    public void addSelectorMapping
		(String characteristic, int filter,
		 boolean node, boolean link, boolean path)
		throws DuplicateObjectException
	    {
		Selector.this.assertNotRemoved();
		Selector.this.addSelectorMapping
		    (characteristic, filter, node, link, path);
		m_addedSelectorMapping = true;
	    }

	    private void assertNotAtEnd()
	    {
		if (m_current == null)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    private boolean  m_addedSelectorMapping;
	    private SelectorMapping  m_current;
	}
    }

    //////////////////////////////////////////////////////////////////

    private class SelectorMapping
	extends ListNode
    {
	public SelectorMapping(String characteristic, int filter,
			       boolean node, boolean link, boolean path)
	{
	    m_characteristic = characteristic;
	    m_filter = filter;
	    m_nodeInTarget = node;
	    m_linkInTarget = link;
	    m_pathInTarget = path;
	}

	public int getFilterID()
	{
	    return m_filter;
	}

	public String getDisplayCharacteristic()
	{
	    return m_characteristic;
	}

	public boolean checkNodeInTarget()
	{
	    return m_nodeInTarget;
	}

	public boolean checkLinkInTarget()
	{
	    return m_linkInTarget;
	}

	public boolean checkPathInTarget()
	{
	    return m_pathInTarget;
	}

	public boolean checkObjectInTarget(ObjectType type)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: return checkNodeInTarget();
	    case ObjectType._LINK: return checkLinkInTarget();
	    case ObjectType._PATH: return checkPathInTarget();
	    default: throw new InternalErrorException();
	    }
	}

	public Observer getObserver()
	{
	    return m_observer;
	}

	public void setFilterID(int id)
	{
	    m_filter = id;
	}

	public void setDisplayCharacteristic(String characteristic)
	{
	    m_characteristic = characteristic;
	}

	public void setNodeInTarget(boolean flag)
	{
	    m_nodeInTarget = flag;
	}

	public void setLinkInTarget(boolean flag)
	{
	    m_linkInTarget = flag;
	}

	public void setPathInTarget(boolean flag)
	{
	    m_pathInTarget = flag;
	}

	public void setObjectInTarget(ObjectType type, boolean flag)
	{
	    switch (type.getType())
	    {
	    case ObjectType._NODE: setNodeInTarget(flag); break;
	    case ObjectType._LINK: setLinkInTarget(flag); break;
	    case ObjectType._PATH: setPathInTarget(flag); break;
	    default: throw new InternalErrorException();
	    }
	}

	public void setObserver(Observer observer)
	{
	    m_observer = observer;
	}

	private String  m_characteristic;
	private int  m_filter;
	private boolean  m_nodeInTarget;
	private boolean  m_linkInTarget;
	private boolean  m_pathInTarget;
	private Observer  m_observer;
    }

    ///////////////////////////////////////////////////////////////////////

    private class SelectorIteratorImpl
	implements SelectorIterator
    {
	public SelectorIteratorImpl(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start)
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingSelectors();
	}

	public boolean atEnd()
	{
	    return m_selector == null;
	}

	public void advance()
	{
	    if (m_selector != null)
	    {
		if (m_addedSelector || m_current == m_end - 1)
		{
		    m_selector = null;
		}
		else
		{
		    ++m_current;
		    skipMissingSelectors();
		}
	    }
	}

	public void rewind()
	{
	    m_addedSelector = false;
	    m_current = m_start;
	    skipMissingSelectors();
	}

	public int getID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_selector.getName();
	}

	public SelectorMappingIterator getSelectorMappings()
	{
	    assertNotAtEnd();
	    return m_selector.getSelectorMappings();
	}

	public void setName(String name)
	{
	    assertNotAtEnd();
	    m_selector.setName(name);
	}

	public void removeSelectorMappings()
	{
	    assertNotAtEnd();
	    m_selector.removeSelectorMappings();
	}

	public void removeSelector()
	{
	    assertNotAtEnd();
	    m_selector.becomeRemoved();
	    m_selectors.free(m_current);
	    m_selector = null;

	    if (!m_addedSelector)
	    {
		++m_current;
		skipMissingSelectors();
	    }
	}

	public void addSelector(String name)
	{
	    m_selector = new Selector(name);
	    m_current = m_selectors.allocate();
	    m_selectors.setValue(m_current, m_selector);
	    m_addedSelector = true;
	}

	private void skipMissingSelectors()
	{
	    m_selector = null;
	    while (m_current < m_end)
	    {
		if (m_selectors.checkAllocated(m_current))
		{
		    m_selector = (Selector)m_selectors.getValue(m_current);
		    if (m_selector == null)
		    {
			String msg =
			    "null selector reference in allocated slot";
			throw new InternalErrorException(msg);
		    }
		    break;
		}
		else
		{
		    ++m_current;
		}
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_selector == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private boolean  m_addedSelector = false;
	private Selector  m_selector;

	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class Filter
	extends CommonRemovableObject
    {
	public Filter(String name, String expr)
	{
	    super();
	    m_name = name;
	    m_expr = expr;
	}

	public String getName()
	{
	    assertNotRemoved();
	    return m_name;
	}

	public String getExpression()
	{
	    assertNotRemoved();
	    return m_expr;
	}

	public ObjectFilter getCompiledExpression()
	{
	    assertNotRemoved();
	    throw new InternalErrorException("UNIMPLEMENTED");
	}

	public void setName(String name)
	{
	    assertNotRemoved();
	    m_name = name;
	}

	public void setExpression(String expr)
	{
	    assertNotRemoved();
	    m_expr = expr;
	    m_compiledExpr = null;
	}

	private String  m_name;
	private String  m_expr;
	private ObjectFilter  m_compiledExpr;
    }

    ///////////////////////////////////////////////////////////////////////

    private class FilterIteratorImpl
	implements FilterIterator
    {
	public FilterIteratorImpl(int start, int end)
	{
	    if (start < 0 || end < 0 || end < start)
	    {
		throw new IllegalArgumentException();
	    }

	    m_start = start;
	    m_end = end;
	    m_current = start;
	    skipMissingFilters();
	}

	public boolean atEnd()
	{
	    return m_filter == null;
	}

	public void advance()
	{
	    if (m_filter != null)
	    {
		if (m_addedFilter || m_current == m_end - 1)
		{
		    m_filter = null;
		}
		else
		{
		    ++m_current;
		    skipMissingFilters();
		}
	    }
	}

	public void rewind()
	{
	    m_addedFilter = false;
	    m_current = m_start;
	    skipMissingFilters();
	}

	public int getID()
	{
	    assertNotAtEnd();
	    return m_current;
	}

	public String getName()
	{
	    assertNotAtEnd();
	    return m_filter.getName();
	}

	public String getExpression()
	{
	    assertNotAtEnd();
	    return m_filter.getExpression();
	}

	public ObjectFilter getCompiledExpression()
	{
	    assertNotAtEnd();
	    return m_filter.getCompiledExpression();
	}

	public void setName(String name)
	{
	    assertNotAtEnd();
	    m_filter.setName(name);
	}

	public void setExpression(String expr)
	{
	    assertNotAtEnd();
	    m_filter.setExpression(expr);
	}

	public void removeFilter()
	{
	    assertNotAtEnd();
	    m_filter.becomeRemoved();
	    m_filters.free(m_current);
	    m_filter = null;

	    if (!m_addedFilter)
	    {
		++m_current;
		skipMissingFilters();
	    }
	}

	public void addFilter(String name, String expr)
	{
	    m_filter = new Filter(name, expr);
	    m_current = m_filters.allocate();
	    m_filters.setValue(m_current, m_filter);
	    m_addedFilter = true;
	}

	private void skipMissingFilters()
	{
	    m_filter = null;
	    while (m_current < m_end)
	    {
		if (m_filters.checkAllocated(m_current))
		{
		    m_filter = (Filter)m_filters.getValue(m_current);
		    if (m_filter == null)
		    {
			String msg = "null filter reference in allocated slot";
			throw new InternalErrorException(msg);
		    }
		    break;
		}
		else
		{
		    ++m_current;
		}
	    }
	}

	private void assertNotAtEnd()
	{
	    if (m_filter == null)
	    {
		throw new IndexOutOfBoundsException();
	    }
	}

	private boolean  m_addedFilter = false;
	private Filter  m_filter;

	private int  m_start;
	private int  m_end;
	private int  m_current;
    }

    ///////////////////////////////////////////////////////////////////////

    private class AttributeMenuItem
	implements MenuItem
    {
	public AttributeMenuItem() {}

	public void addRemovalObserver(int id, Observer observer)
	{
	    CommonGraph.this.addAttributeRemovalObserver(id, observer);
	}

	public void removeRemovalObserver(int id, Observer observer)
	{
	    CommonGraph.this.removeAttributeRemovalObserver(id, observer);
	}
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE NESTED CLASSES
    ///////////////////////////////////////////////////////////////////////

    private static class Menu
	extends ListNode
    {
	public Menu(Menu parent, MenuItem menuItem, String label, int id)
	{
	    m_parent = parent;
	    m_menuItem = menuItem;
	    m_label = label;
	    m_id = id;
	    acquireMenuItem();
	}

	public String getLabel()
	{
	    return m_label;
	}

	public int getID()
	{
	    return m_id;
	}

	public MenuIterator getSubmenus()
	{
	    return new MenuIteratorImpl();
	}

	public void setLabel(String label)
	{
	    m_label = label;
	}

	public void setID(int id)
	{
	    if (id != m_id)
	    {
		releaseMenuItem();
		m_id = id;
		acquireMenuItem();
	    }
	}

	public void removeSubmenus()
	{
	    MenuIterator iterator = getSubmenus();
	    while (!iterator.atEnd())
	    {
		iterator.removeMenu();
	    }
	}

	public void removeSubmenu(Menu submenu)
	{
	    if (submenu.m_parent != this)
	    {
		String msg =
		    "attempted to remove a submenu of a different menu";
		throw new IllegalArgumentException(msg);
	    }
	    submenu.releaseMenuItem();
	    m_submenus.unlink(submenu);
	}

	public Menu appendSubmenu(String label, int id)
	{
	    releaseMenuItem(); // Menus with submenus can't be selected.
	    Menu submenu = new Menu(this, m_menuItem, label, id);
	    m_submenus.append(submenu);
	    return submenu;
	}

	private void releaseMenuItem()
	{
	    if (m_id >= 0)
	    {
		m_menuItem.removeRemovalObserver(m_id, m_removalObserver);
		m_id = -1;
	    }
	}

	private void acquireMenuItem()
	{
	    if (m_id >= 0)
	    {
		m_menuItem.addRemovalObserver(m_id, m_removalObserver);
	    }
	}

	private Menu  m_parent; // This is null for (only) top-level menus.
	private MenuItem  m_menuItem;
	private String  m_label;
	private int  m_id;
	private ListHead  m_submenus = new ListHead();
	private RemovalObserver  m_removalObserver = new RemovalObserver();

	///////////////////////////////////////////////////////////////////

	private class RemovalObserver
	    implements Observer
	{
	    public void update(Observable o, Object arg)
	    {
		if (m_id < 0)
		{
		    String msg =
			"update() called after menu item had been released";
		    throw new InternalErrorException(msg);
		}
		if (m_parent == null)
		{
		    String msg = "m_parent is null";
		    throw new InternalErrorException(msg);
		}

		m_parent.removeSubmenu(Menu.this);
	    }
	}

	///////////////////////////////////////////////////////////////////

	private class MenuIteratorImpl
	    implements MenuIterator
	{
	    public MenuIteratorImpl()
	    {
		rewind();
	    }

	    public boolean atEnd()
	    {
		return m_current == null;
	    }

	    public void advance()
	    {
		if (m_current != null)
		{
		    if (m_addedMenu)
		    {
			m_current = null;
		    }
		    else
		    {
			m_current = (Menu)m_current.getNext();
			if (m_current == m_submenus.getHead())
			{
			    m_current = null;
			}
		    }
		}
	    }

	    public void rewind()
	    {
		m_addedMenu = false;
		m_current = (Menu)m_submenus.getHead();
	    }

	    public String getLabel()
	    {
		assertNotAtEnd();
		return m_current.getLabel();
	    }

	    public int getID()
	    {
		assertNotAtEnd();
		return m_current.getID();
	    }

	    public MenuIterator getSubmenus()
	    {
		assertNotAtEnd();
		return m_current.getSubmenus();
	    }

	    public void setLabel(String label)
	    {
		assertNotAtEnd();
		m_current.setLabel(label);
	    }

	    public void setID(int id)
	    {
		assertNotAtEnd();
		m_current.setID(id);
	    }

	    public void removeSubmenus()
	    {
		assertNotAtEnd();
		m_current.removeSubmenus();
	    }

	    public void removeMenu()
	    {
		assertNotAtEnd();
		Menu menu = m_current;
		advance();
		Menu.this.removeSubmenu(menu);
	    }

	    public void insertMenu(String label, int id)
	    {
		Menu menu = new Menu(Menu.this, m_menuItem, label, id);
		m_submenus.insertNodeBeforeCurrent(menu, m_current);
		m_current = menu;

		// We should not set m_addedMenu, since we really do want
		// the user to be able to iterate through the remainder of
		// the submenus.
	    }

	    public void appendMenu(String label, int id)
	    {
		m_current = Menu.this.appendSubmenu(label, id);
		m_addedMenu = true;
	    }

	    private void assertNotAtEnd()
	    {
		if (m_current == null)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    private boolean  m_addedMenu;
	    private Menu  m_current;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private interface MenuItem
    {
	void addRemovalObserver(int id, Observer observer);
	void removeRemovalObserver(int id, Observer observer);
    }

    ///////////////////////////////////////////////////////////////////////

    private static class AuxillaryMenuItem
	implements MenuItem
    {
	public AuxillaryMenuItem(ObjectArray array, String type)
	{
	    m_array = array;
	    m_type = type;
	}

	public void addRemovalObserver(int id, Observer observer)
	{
	    validateArguments(id, observer);
	    RemovableObject removableObject = getRemovableObject(id);
	    removableObject.addRemovalObserver(observer);
	}

	public void removeRemovalObserver(int id, Observer observer)
	{
	    validateArguments(id, observer);
	    RemovableObject removableObject = getRemovableObject(id);
	    removableObject.removeRemovalObserver(observer);
	}

	private RemovableObject getRemovableObject(int id)
	{
	    try
	    {
		return (RemovableObject)m_array.getValue(id);
	    }
	    catch (UnallocatedElementException e)
	    {
		String msg = m_type + "[" + id + "] not found";
		throw new ObjectNotFoundException(msg);
	    }
	}

	private void validateArguments(int id, Observer observer)
	{
	    if (id < 0)
	    {
		String msg = "id[" + id + "] must be nonnegative";
		throw new IllegalArgumentException(msg);
	    }

	    if (observer == null)
	    {
		String msg = "observer must be non-null";
		throw new IllegalArgumentException(msg);
	    }
	}

	private ObjectArray  m_array;
	private String  m_type;
    }

    ///////////////////////////////////////////////////////////////////////
    // PROTECTED INNER CLASSES (utility)
    ///////////////////////////////////////////////////////////////////////

    protected interface RemovableObject
    {
	boolean isRemoved();
	void becomeRemoved();
	void addRemovalObserver(Observer observer);
	void removeRemovalObserver(Observer observer);
    }

    ///////////////////////////////////////////////////////////////////////

    protected static class CommonRemovableObject
	implements RemovableObject
    {
	public CommonRemovableObject() {}

	public boolean isRemoved()
	{
	    return m_isRemoved;
	}

	public void becomeRemoved()
	{
	    assertNotRemoved();
	    m_removalObservable.notifyObserversUnconditionally();
	    processRemovalRequest();
	    m_isRemoved = true;
	}

	public void addRemovalObserver(Observer observer)
	{
	    assertNotRemoved();
	    m_removalObservable.addObserver(observer);
	}

	public void removeRemovalObserver(Observer observer)
	{
	    assertNotRemoved();
	    m_removalObservable.deleteObserver(observer);
	}

	protected void processRemovalRequest() {}

	protected void assertNotRemoved()
	{
	    if (m_isRemoved)
	    {
		String msg = "attempted to access an object after removal";
		throw new RemovedObjectException(msg);
	    }
	}

	protected ObservableObject  m_removalObservable =
	    new ObservableObject();

	private boolean  m_isRemoved = false;
    }

    ///////////////////////////////////////////////////////////////////////

    protected interface ListIterator 
	extends Iterator
    {
	ListNode getNode();
	void unlink();
	void insert(ListNode node);
	void append(ListNode node);
    }

    ///////////////////////////////////////////////////////////////////////

    protected static class ListHead
    {
	public ListHead() {}

	public boolean isEmpty()
	{
	    return m_head == null;
	}

	public ListNode getHead()
	{
	    return m_head;
	}

	public ListIterator getNodes()
	{
	    return new ListIteratorImpl();
	}

	public void unlink(ListNode node)
	{
	    if (m_head == node)
	    {
		m_head = (node.getNext() == node ? null : node.getNext());
	    }
	    node.unlink();
	}

	public void append(ListNode node)
	{
	    if (m_head == null)
	    {
		m_head = node;
	    }
	    else
	    {
		node.linkSelfBefore(m_head);
	    }
	}

	public void insertNodeBeforeCurrent(ListNode node, ListNode current)
	{
	    node.linkSelfBefore(current);
	    if (m_head == current)
	    {
		m_head = node;
	    }
	}

	public void insertNodeAfterCurrent(ListNode node, ListNode current)
	{
	    node.linkSelfAfter(current);
	}

	public void clear()
	{
	    m_head = null;
	}

	private ListNode  m_head;

	///////////////////////////////////////////////////////////////////

	private class ListIteratorImpl
	    implements ListIterator
	{
	    public ListIteratorImpl()
	    {
		rewind();
	    }

	    public boolean atEnd()
	    {
		return m_current == null;
	    }

	    public void advance()
	    {
		if (m_current != null)
		{
		    if (m_addedNode)
		    {
			m_current = null;
		    }
		    else
		    {
			m_current = m_current.getNext();
			if (m_current == m_head)
			{
			    m_current = null;
			}
		    }
		}
	    }

	    public void rewind()
	    {
		m_addedNode = false;
		m_current = m_head;
	    }

	    public ListNode getNode()
	    {
		assertNotAtEnd();
		return m_current;
	    }

	    public void unlink()
	    {
		assertNotAtEnd();
		ListNode node = m_current;
		advance();
		ListHead.this.unlink(node);
	    }

	    public void insert(ListNode node)
	    {
		if (m_current == null)
		{
		    append(node);
		}
		else
		{
		    ListHead.this.insertNodeBeforeCurrent(node, m_current);
		    m_current = node;
		}
	    }

	    public void append(ListNode node)
	    {
		ListHead.this.append(node);
		m_current = node;
		m_addedNode = true;
	    }

	    private void assertNotAtEnd()
	    {
		if (m_current == null)
		{
		    throw new IndexOutOfBoundsException();
		}
	    }

	    private boolean  m_addedNode;
	    private ListNode  m_current;
	}
    }

    ///////////////////////////////////////////////////////////////////////

    protected static class ListNode
    {
	public ListNode()
	{
	    m_previous = m_next = this;
	}

	public ListNode getPrevious()
	{
	    return m_previous;
	}

	public ListNode getNext()
	{
	    return m_next;
	}

	public void unlink()
	{
	    m_previous.m_next = m_next;
	    m_next.m_previous = m_previous;
	    m_previous = m_next = this;
	}

	// Link this before node.
	public void linkSelfBefore(ListNode node)
	{
	    m_next = node;
	    m_previous = node.m_previous;
	    node.m_previous.m_next = this;
	    node.m_previous = this;
	}

	// Link this after node.
	public void linkSelfAfter(ListNode node)
	{
	    m_next = node.m_next;
	    m_previous = node;
	    node.m_next.m_previous = this;
	    node.m_next = this;
	}

	private ListNode  m_previous;
	private ListNode  m_next;
    }

    ///////////////////////////////////////////////////////////////////////

    protected static class ContainerListNode
	extends ListNode
    {
	public ContainerListNode()
	{
	    super();
	}

	public ContainerListNode(Object object)
	{
	    super();
	    m_object = object;
	}

	public Object getObject()
	{
	    return m_object;
	}

	public void setObject(Object object)
	{
	    m_object = object;
	}

	private Object  m_object;
    }
}
