// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.util.Arrays;

class SorterTester
    extends AbstractTester
{
    ///////////////////////////////////////////////////////////////////////
    // MAIN
    ///////////////////////////////////////////////////////////////////////

    public static void main(String[] args)
    {
	int startingTest = parseArguments(args);
	SorterTester tester = new SorterTester();
	tester.testAll(startingTest);
    }

    ///////////////////////////////////////////////////////////////////////
    // CONSTRUCTORS
    ///////////////////////////////////////////////////////////////////////

    public SorterTester()
    {
	super();
    }

    ///////////////////////////////////////////////////////////////////////
    // PUBLIC METHODS
    ///////////////////////////////////////////////////////////////////////

    public void testAll(int startingTest)
    {
	try
	{
	    if (startingTest == 0)
	    {
		println("\n**** TEST 0 ****");
		for (int i = 0; i < 50; i++)
		{
		    testInsertionSort(i);
		}
		testInsertionSort(100);
		testInsertionSort(1023);
		testInsertionSort(1024);
		testInsertionSort(1025);
	    }

	    if (startingTest <= 1)
	    {
		println("\n**** TEST 1 ****");
		for (int i = 0; i < 50; i++)
		{
		    testShellSort(i);
		}
		testShellSort(100);
		testShellSort(1023);
		testShellSort(1024);
		testShellSort(1025);
	    }

	    if (startingTest <= 2)
	    {
		println("\n**** TEST 2 ****");
		for (int i = 0; i < 50; i++)
		{
		    testQuickSort5(i);
		}
		testQuickSort5(100);
		testQuickSort5(1023);
		testQuickSort5(1024);
		testQuickSort5(1025);
	    }

	    if (startingTest <= 3)
	    {
		println("\n**** TEST 3 ****");
		for (int i = 0; i < 50; i++)
		{
		    testQuickSort4(i);
		}
		testQuickSort4(100);
		testQuickSort4(1023);
		testQuickSort4(1024);
		testQuickSort4(1025);
	    }

	    if (startingTest <= 4)
	    {
		println("\n**** TEST 4 ****");
		for (int i = 0; i < 50; i++)
		{
		    testQuickSort3(i);
		}
		testQuickSort3(100);
		testQuickSort3(1023);
		testQuickSort3(1024);
		testQuickSort3(1025);
	    }

	    if (startingTest <= 5)
	    {
		println("\n**** TEST 5 ****");
		for (int i = 0; i < 50; i++)
		{
		    testQuickSort2(i);
		}
		testQuickSort2(100);
		testQuickSort2(1023);
		testQuickSort2(1024);
		testQuickSort2(1025);
		testQuickSort2(5000);
		testQuickSort2(50000);
	    }

	    if (startingTest <= 6)
	    {
		println("\n**** TEST 6 ****");
		for (int i = 0; i < 50; i++)
		{
		    testQuickSort(i);
		}
		testQuickSort(100);
		testQuickSort(1023);
		testQuickSort(1024);
		testQuickSort(1025);
		testQuickSort(5000);
		testQuickSort(50000);
	    }

	    if (startingTest <= 7)
	    {
		println("\n**** TEST 7 ****");
		for (int i = 0; i < 50; i++)
		{
		    testIntQuickSort(i);
		}
		testIntQuickSort(100);
		testIntQuickSort(1023);
		testIntQuickSort(1024);
		testIntQuickSort(1025);
		testIntQuickSort(5000);
		testIntQuickSort(50000);
	    }

	    if (startingTest <= 8)
	    {
		println("\n**** TEST 8 ****");
		int[] sizes = { 100, 1023, 1024, 1025 };
		for (int n = 0; n < sizes.length; n++)
		{
		    int size = sizes[n];
		    for (int m = 1; m < 2 * size; m *= 2)
		    {
			testUsingDistributions(size, m, 5, true);
		    }
		}
	    }

	    if (startingTest <= 8)
	    {
		println("===============================================");
		println("Stopped testing at test 8.");
		println("Use a higher starting number than 8");
		println("to run tests 9 and beyond.");
		println("===============================================");
		System.exit(0);
	    }

	    if (startingTest <= 9)
	    {
		println("\n**** TEST 9 ****");
		int[] sizes = { 100, 1023, 1024, 1025 };
		for (int n = 0; n < sizes.length; n++)
		{
		    int size = sizes[n];
		    for (int m = 1; m < 2 * size; m *= 2)
		    {
			timeUsingDistributions(size, m, 5);
		    }
		}
	    }

	    if (startingTest <= 9)
	    {
		println("===============================================");
		println("Stopped testing at test 9.");
		println("Use a higher starting number than 9");
		println("to run tests 10 and beyond.");
		println("===============================================");
		System.exit(0);
	    }

	    if (startingTest <= 10)
	    {
		println("\n**** TEST 10 ****");
		int[] sizes = { 10000, 100000, 500000 };
		for (int n = 0; n < sizes.length; n++)
		{
		    int size = sizes[n];
		    for (int m = 2; m < 2 * size; m *= 2)
		    {
			timeUsingDistributions(size, m, 5);
		    }
		}
	    }

	    if (startingTest <= 10)
	    {
		println("===============================================");
		println("Stopped testing at test 10.");
		println("Use a higher starting number than 10");
		println("to run tests 11 and beyond.");
		println("===============================================");
		System.exit(0);
	    }

	    if (startingTest <= 11)
	    {
		println("\n**** TEST 11 ****");
		int[] sizes = { 1000000 };
		for (int n = 0; n < sizes.length; n++)
		{		
		    int size = sizes[n];

		    testUsingDistributions(size, 2, 5, false);
		    testUsingDistributions(size, 16, 5, false);
		    for (int m = 256; m < 2 * size; m *= 2)
		    {
			testUsingDistributions(size, m, 5, false);
		    }
		}
	    }

	    if (startingTest <= 12)
	    {
		println("\n**** TEST 12 ****");
		int[] sizes = { 1000000 };
		for (int n = 0; n < sizes.length; n++)
		{
		    int size = sizes[n];

		    timeUsingDistributions(size, 2, 5);
		    timeUsingDistributions(size, 16, 5);
		    for (int m = 256; m < 2 * size; m *= 2)
		    {
			timeUsingDistributions(size, m, 5);
		    }
		}
	    }
	}
	catch (TestFailedException e)
	{
	    e.printStackTrace();
	    System.out.println("FAILED: " + e);
	}
	catch (RuntimeException e)
	{
	    e.printStackTrace();
	    System.out.println("ERROR: " + e);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    private void testUsingDistributions(int size, int m, int dither,
					boolean showValues)
	throws TestFailedException
    {
	testUsingDistributions(size, m, dither,
			       new SawtoothDistribution(), showValues);
	testUsingDistributions(size, m, dither,
			       new RandomDistribution(), showValues);
	testUsingDistributions(size, m, dither,
			       new StaggeredDistribution(), showValues);
	testUsingDistributions(size, m, dither,
			       new PlateauDistribution(), showValues);
	testUsingDistributions(size, m, dither,
			       new ShuffledDistribution(), showValues);
    }

    ///////////////////////////////////////////////////////////////////////

    private void timeUsingDistributions(int size, int m, int dither)
	throws TestFailedException
    {
	timeUsingDistributions(size, m, dither, new SawtoothDistribution());
	timeUsingDistributions(size, m, dither, new RandomDistribution());
	timeUsingDistributions(size, m, dither,	new StaggeredDistribution());
	timeUsingDistributions(size, m, dither, new PlateauDistribution());
	timeUsingDistributions(size, m, dither, new ShuffledDistribution());
    }

    ///////////////////////////////////////////////////////////////////////
    // INSERTION SORT TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testInsertionSort(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testInsertionSort(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	IntSortable sortable = new IntSortable(array);
	CountingSortable counting = new CountingSortable(sortable);	
	Sorter.isort(counting, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);
	printStats(counting);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // SHELL SORT TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testShellSort(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testShellSort(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	IntSortable sortable = new IntSortable(array);
	CountingSortable counting = new CountingSortable(sortable);	
	Sorter.ssort(counting, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);
	printStats(counting);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUICK SORT 5 TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testQuickSort5(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testQuickSort5(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	IntSortable sortable = new IntSortable(array);
	CountingSortable counting = new CountingSortable(sortable);	
	Sorter.qsort5(counting, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);
	printStats(counting);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUICK SORT 4 TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testQuickSort4(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testQuickSort4(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	IntSortable sortable = new IntSortable(array);
	CountingSortable counting = new CountingSortable(sortable);	
	Sorter.qsort4(counting, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);
	printStats(counting);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUICK SORT 3 TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testQuickSort3(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testQuickSort3(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	IntSortable sortable = new IntSortable(array);
	CountingSortable counting = new CountingSortable(sortable);	
	Sorter.qsort3(counting, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);
	printStats(counting);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUICK SORT 2 TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testQuickSort2(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testQuickSort2(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	IntSortable sortable = new IntSortable(array);
	CountingSortable counting = new CountingSortable(sortable);	
	Sorter.qsort2(counting, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);
	printStats(counting);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUICK SORT TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testQuickSort(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testQuickSort(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	IntSortable sortable = new IntSortable(array);
	CountingSortable counting = new CountingSortable(sortable);	
	Sorter.qsort(counting, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);
	printStats(counting);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // INTEGER QUICK SORT TESTING
    ///////////////////////////////////////////////////////////////////////

    private void testIntQuickSort(int numValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testIntQuickSort(numValues=" + numValues + ")");
	println("===========================================================");

	int[] array = createRandomValues(numValues);
	int[] sortedArray = createSortedArray(array);	

	Sorter.iqsort(array, 0, numValues - 1);

	checkSorted(array);
	compare(array, sortedArray);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUICK SORT TESTING USING DISTRIBUTIONS
    ///////////////////////////////////////////////////////////////////////

    private void testUsingDistributions(int numValues, int m, int dither,
					Distribution distribution,
					boolean showValues)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testUsingDistributions(numValues=" + numValues + ", m="
		+ m + ", dither=" + dither + ", distribution="
		+ distribution.getName() + ")");
	println("===========================================================");

	Distribution cached = new CachedDistribution(distribution);
	int[] array = cached.make(numValues, m);
	if (showValues)
	{
	    printValues(array);
	}

	testUsingDistribution(numValues, m, cached);
	testUsingDistribution
	    (numValues, m, new ReversedDistribution(cached));
	testUsingDistribution
	    (numValues, m, new FirstHalfReversedDistribution(cached));
	testUsingDistribution
	    (numValues, m, new SecondHalfReversedDistribution(cached));
	testUsingDistribution
	    (numValues, m, new SortedDistribution(cached));
	testUsingDistribution
	    (numValues, m, new DitheredDistribution(cached, dither));

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    private void testUsingDistribution(int numValues, int m,
				       Distribution distribution)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("testUsingDistribution(numValues=" + numValues + ", m="
		+ m + ", distribution=" + distribution.getName() + ")");
	println("===========================================================");

	int maxMultiplier = 10;
	int maxComparisons = maxMultiplier * numValues
	    * (int)Math.ceil(Math.log(numValues) / Math.log(2.0));
	println("maxComparisons = " + maxComparisons);

	int[] array = distribution.make(numValues, m);
	int[] sortedArray = createSortedArray(array);	

	int numComparisonsIS = 0;
	int numSwappingsIS = 0;
	{
	    if (numValues < QUADRATIC_THRESHOLD)
	    {
		int[] data = (int[])array.clone();
		IntSortable sortable = new IntSortable(data);
		CountingSortable counting = new CountingSortable(sortable);
		Sorter.isort(counting, 0, numValues - 1);

		checkSorted(data);
		compare(data, sortedArray);

		numComparisonsIS = counting.getNumComparisons();
		numSwappingsIS = counting.getNumSwappings();
	    }
	}

	int numComparisonsSS = 0;
	int numSwappingsSS = 0;
	{
	    if (numValues < SHELLSORT_THRESHOLD)
	    {
		int[] data = (int[])array.clone();
		IntSortable sortable = new IntSortable(data);
		CountingSortable counting = new CountingSortable(sortable);
		Sorter.ssort(counting, 0, numValues - 1);

		checkSorted(data);
		compare(data, sortedArray);

		numComparisonsSS = counting.getNumComparisons();
		numSwappingsSS = counting.getNumSwappings();
	    }
	}

	int numComparisonsQS5 = 0;
	int numSwappingsQS5 = 0;
	{
	    if (numValues < QUADRATIC_THRESHOLD)
	    {
		int[] data = (int[])array.clone();
		IntSortable sortable = new IntSortable(data);
		CountingSortable counting = new CountingSortable(sortable);
		Sorter.qsort5(counting, 0, numValues - 1);

		checkSorted(data);
		compare(data, sortedArray);

		numComparisonsQS5 = counting.getNumComparisons();
		numSwappingsQS5 = counting.getNumSwappings();
	    }
	}

	int numComparisonsQS4 = 0;
	int numSwappingsQS4 = 0;
	{
	    if (numValues < QUADRATIC_THRESHOLD)
	    {
		int[] data = (int[])array.clone();
		IntSortable sortable = new IntSortable(data);
		CountingSortable counting = new CountingSortable(sortable);
		Sorter.qsort4(counting, 0, numValues - 1);

		checkSorted(data);
		compare(data, sortedArray);

		numComparisonsQS4 = counting.getNumComparisons();
		numSwappingsQS4 = counting.getNumSwappings();
	    }
	}

	int numComparisonsQS3 = 0;
	int numSwappingsQS3 = 0;
	{
	    if (numValues < LARGE_INPUT_THRESHOLD)
	    {
		int[] data = (int[])array.clone();
		IntSortable sortable = new IntSortable(data);
		CountingSortable counting = new CountingSortable(sortable);
		Sorter.qsort3(counting, 0, numValues - 1);

		checkSorted(data);
		compare(data, sortedArray);

		numComparisonsQS3 = counting.getNumComparisons();
		numSwappingsQS3 = counting.getNumSwappings();
	    }
	}

	int numComparisonsQS2 = 0;
	int numSwappingsQS2 = 0;
	{
	    if (numValues < LARGE_INPUT_THRESHOLD)
	    {
		int[] data = (int[])array.clone();
		IntSortable sortable = new IntSortable(data);
		CountingSortable counting = new CountingSortable(sortable);
		WatchingSortable watching =
		    new WatchingSortable(counting, maxComparisons);
		Sorter.qsort2(watching, 0, numValues - 1);

		checkSorted(data);
		compare(data, sortedArray);

		numComparisonsQS2 = counting.getNumComparisons();
		numSwappingsQS2 = counting.getNumSwappings();
	    }
	}

	int numComparisonsQS;
	int numSwappingsQS;
	{
	    int[] data = (int[])array.clone();
	    IntSortable sortable = new IntSortable(data);
	    CountingSortable counting = new CountingSortable(sortable);
	    WatchingSortable watching =
		new WatchingSortable(counting, maxComparisons);
	    Sorter.qsort(watching, 0, numValues - 1);

	    if (numValues < LARGE_INPUT_THRESHOLD)
	    {
		checkSorted(data);
		compare(data, sortedArray);
	    }

	    numComparisonsQS = counting.getNumComparisons();
	    numSwappingsQS = counting.getNumSwappings();
	}

	String name = distribution.getName();
	println("@ " + numValues + " " + m + " IS "
		+ numComparisonsIS + " " + numSwappingsIS + " " + name);
	println("@ " + numValues + " " + m + " SS "
		+ numComparisonsSS + " " + numSwappingsSS + " " + name);
	println("@ " + numValues + " " + m + " QS5 "
		+ numComparisonsQS5 + " " + numSwappingsQS5 + " " + name);
	println("@ " + numValues + " " + m + " QS4 "
		+ numComparisonsQS4 + " " + numSwappingsQS4 + " " + name);
	println("@ " + numValues + " " + m + " QS3 "
		+ numComparisonsQS3 + " " + numSwappingsQS3 + " " + name);
	println("@ " + numValues + " " + m + " QS2 "
		+ numComparisonsQS2 + " " + numSwappingsQS2 + " " + name);
	println("@ " + numValues + " " + m + " QS "
		+ numComparisonsQS + " " + numSwappingsQS + " " + name);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // QUICK SORT TIMING USING DISTRIBUTIONS
    ///////////////////////////////////////////////////////////////////////

    private void timeUsingDistributions(int numValues, int m, int dither,
					Distribution distribution)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("timeUsingDistributions(numValues=" + numValues + ", m="
		+ m + ", dither=" + dither + ", distribution="
		+ distribution.getName() + ")");
	println("===========================================================");

	Distribution cached = new CachedDistribution(distribution);
	// By caching the value here, we ensure that the time needed to
	// make a distribution does not skew our timing results.
	int[] array = cached.make(numValues, m);

	timeUsingDistribution(numValues, m, cached);
	timeUsingDistribution
	    (numValues, m, new ReversedDistribution(cached));
	timeUsingDistribution
	    (numValues, m, new FirstHalfReversedDistribution(cached));
	timeUsingDistribution
	    (numValues, m, new SecondHalfReversedDistribution(cached));
	timeUsingDistribution
	    (numValues, m, new SortedDistribution(cached));
	timeUsingDistribution
	    (numValues, m, new DitheredDistribution(cached, dither));

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////

    private void timeUsingDistribution(int numValues, int m,
				       Distribution distribution)
	throws TestFailedException
    {
	println();
	println("===========================================================");
	println("timeUsingDistribution(numValues=" + numValues + ", m="
		+ m + ", distribution=" + distribution.getName() + ")");
	println("===========================================================");

	System.gc();

	int maxMultiplier = 10;
	int maxComparisons = maxMultiplier * numValues
	    * (int)Math.ceil(Math.log(numValues) / Math.log(2.0));
	println("maxComparisons = " + maxComparisons);

	int[] array = distribution.make(numValues, m);
	int[] working = new int[numValues];

	long ssortStart;
	long ssortEnd;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    IntSortable sortable = new IntSortable(working);
	    ssortStart = System.currentTimeMillis();
	    Sorter.ssort(sortable, 0, numValues - 1);
	    ssortEnd = System.currentTimeMillis();
	}
	long ssortTime = ssortEnd - ssortStart;

	long qsortStart;
	long qsortEnd;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    IntSortable sortable = new IntSortable(working);
	    qsortStart = System.currentTimeMillis();
	    Sorter.qsort(sortable, 0, numValues - 1);
	    qsortEnd = System.currentTimeMillis();
	}
	long qsortTime = qsortEnd - qsortStart;

	long iqsortStart;
	long iqsortEnd;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    iqsortStart = System.currentTimeMillis();
	    Sorter.iqsort(working, 0, numValues - 1);
	    iqsortEnd = System.currentTimeMillis();
	}
	long iqsortTime = iqsortEnd - iqsortStart;

	long sortStart;
	long sortEnd;
	{
	    System.arraycopy(array, 0, working, 0, array.length);
	    sortStart = System.currentTimeMillis();
	    Arrays.sort(working);
	    sortEnd = System.currentTimeMillis();
	}
	long sortTime = sortEnd - sortStart;

	String name = distribution.getName();
	println("* " + numValues + " " + m + " SS " + ssortTime + " " + name);
	println("* " + numValues + " " + m + " QS " + qsortTime + " " + name);
	println("* " + numValues + " " + m + " iQS " + iqsortTime + " " +name);
	println("* " + numValues + " " + m + " S " + sortTime + " " + name);

	double ratioSS = (double)ssortTime / (double)sortTime;
	double ratioQS = (double)qsortTime / (double)sortTime;
	double ratioIQS = (double)iqsortTime / (double)sortTime;
	println("% " + numValues + " " + m + " " + ratioSS + " "
		+ ratioQS + " " + ratioIQS + " " + name);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // UTILITIES
    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the elements of the given arrays are the same at the
     * same positions.
     */
    private void compare(int[] array, int[] sorted)
	throws TestFailedException
    {
	println("Comparing results...");
	for (int i = 0; i < array.length; i++)
	{
	    verifyEqual(false, "array[" + i + "]", array[i], sorted[i]);
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Checks that the elements in the given array are in ascending order.
     */
    private void checkSorted(int[] array)
	throws TestFailedException
    {
	boolean showValues = (array.length < PRINTING_THRESHOLD); 
	println("Checking array is sorted...");
	if (array.length > 0)
	{
	    if (showValues)
	    {
		println("[0: " + array[0] + "]");
	    }
	    for (int i = 1; i < array.length; i++)
	    {
		if (showValues)
		{
		    println("[" + i + ": " + array[i] + "]");
		}
		if (array[i] < array[i - 1])
		{
		    String msg = "element at position " + i
			+ " is not >= previous element";
		    fail(msg);
		}
	    }
	}
    }

    ///////////////////////////////////////////////////////////////////////

    /**
     * Creates a new sorted array from the given array.
     */
    private int[] createSortedArray(int[] array)
    {
	int[] retval = (int[])array.clone();
	Arrays.sort(retval);
	return retval;
    }

    ///////////////////////////////////////////////////////////////////////

    private void printStats(CountingSortable sortable)
    {
	printStats(sortable.getNumComparisons(), sortable.getNumSwappings());
    }

    private void printStats(int numComparisons, int numSwappings)
    {
	println("# comparisons: " + numComparisons);
	println("# swappings: " + numSwappings);
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    private static final int  PRINTING_THRESHOLD = 100;
    private static final int  QUADRATIC_THRESHOLD = 2000;
    private static final int  SHELLSORT_THRESHOLD = 1000001;
    private static final int  LARGE_INPUT_THRESHOLD = 2000;

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE INNER CLASSES
    ///////////////////////////////////////////////////////////////////////

    private class IntSortable
	implements Sorter.Sortable
    {
	public IntSortable(int[] array)
	{
	    m_array = array;
	}

	public int compare(int i, int j)
	{
	    int di = m_array[i];
	    int dj = m_array[j];
	    return di < dj ? -1 : di == dj ? 0 : 1;
	}

	public void swap(int i, int j)
	{
	    int t = m_array[i];
	    m_array[i] = m_array[j];
	    m_array[j] = t;
	}

	private int[]  m_array;
    }

    ///////////////////////////////////////////////////////////////////////

    private class CountingSortable
	implements Sorter.Sortable
    {
	public CountingSortable(Sorter.Sortable sortable)
	{
	    m_sortable = sortable;
	}

	public int getNumComparisons()
	{
	    return m_numComparisons;
	}

	public int getNumSwappings()
	{
	    return m_numSwappings;
	}

	public int compare(int i, int j)
	{
	    ++m_numComparisons;
	    return m_sortable.compare(i, j);
	}

	public void swap(int i, int j)
	{
	    ++m_numSwappings;
	    m_sortable.swap(i, j);
	}

	private Sorter.Sortable  m_sortable;
	private int  m_numComparisons;
	private int  m_numSwappings;
    }

    ///////////////////////////////////////////////////////////////////////

    private class WatchingSortable
	implements Sorter.Sortable
    {
	public WatchingSortable(Sorter.Sortable sortable, int maxComparisons)
	{
	    m_sortable = sortable;
	    m_maxComparisons = maxComparisons;
	}

	public int compare(int i, int j)
	{
	    ++m_numComparisons;
	    if (m_numComparisons >= m_maxComparisons)
	    {
		String msg = "reached max # comparisons["
		    + m_maxComparisons + "]";
		throw new RuntimeException(msg);
	    }
	    return m_sortable.compare(i, j);
	}

	public void swap(int i, int j)
	{
	    m_sortable.swap(i, j);
	}

	private Sorter.Sortable  m_sortable;
	private int  m_maxComparisons;
	private int  m_numComparisons;
    }

    ///////////////////////////////////////////////////////////////////////

    private interface Distribution
    {
	String getName();
	int[] make(int numValues, int m);
    }

    ///////////////////////////////////////////////////////////////////////

    private class CachedDistribution
	implements Distribution
    {
	public CachedDistribution(Distribution distribution)
	{
	    m_distribution = distribution;
	}

	public String getName()
	{
	    return m_distribution.getName();
	}

	public int[] make(int numValues, int m)
	{
	    if (m_cache == null)
	    {
		m_cache = m_distribution.make(numValues, m);
	    }
	    return m_cache;
	}

	private Distribution  m_distribution;
	private int[]  m_cache;
    }

    ///////////////////////////////////////////////////////////////////////

    private class ReversedDistribution
	implements Distribution
    {
	public ReversedDistribution(Distribution distribution)
	{
	    m_distribution = distribution;
	}

	public String getName()
	{
	    return "reversed " + m_distribution.getName();
	}

	public int[] make(int numValues, int m)
	{
	    int[] retval = m_distribution.make(numValues, m);
	    SorterTester.this.reverse(retval);
	    return retval;
	}

	private Distribution  m_distribution;
    }

    ///////////////////////////////////////////////////////////////////////

    private class FirstHalfReversedDistribution
	implements Distribution
    {
	public FirstHalfReversedDistribution(Distribution distribution)
	{
	    m_distribution = distribution;
	}

	public String getName()
	{
	    return "first half reversed " + m_distribution.getName();
	}

	public int[] make(int numValues, int m)
	{
	    int[] retval = m_distribution.make(numValues, m);
	    if (numValues > 1)
	    {
		SorterTester.this.reverse(retval, 0, numValues / 2 - 1);
	    }
	    return retval;
	}

	private Distribution  m_distribution;
    }

    ///////////////////////////////////////////////////////////////////////

    private class SecondHalfReversedDistribution
	implements Distribution
    {
	public SecondHalfReversedDistribution(Distribution distribution)
	{
	    m_distribution = distribution;
	}

	public String getName()
	{
	    return "second half reversed " + m_distribution.getName();
	}

	public int[] make(int numValues, int m)
	{
	    int[] retval = m_distribution.make(numValues, m);
	    if (numValues > 1)
	    {
		SorterTester.this.reverse
		    (retval, numValues / 2, numValues - 1);
	    }
	    return retval;
	}

	private Distribution  m_distribution;
    }

    ///////////////////////////////////////////////////////////////////////

    private class SortedDistribution
	implements Distribution
    {
	public SortedDistribution(Distribution distribution)
	{
	    m_distribution = distribution;
	}

	public String getName()
	{
	    return "sorted " + m_distribution.getName();
	}

	public int[] make(int numValues, int m)
	{
	    int[] retval = m_distribution.make(numValues, m);
	    Arrays.sort(retval);
	    return retval;
	}

	private Distribution  m_distribution;
    }

    ///////////////////////////////////////////////////////////////////////

    private class DitheredDistribution
	implements Distribution
    {
	public DitheredDistribution(Distribution distribution, int amount)
	{
	    m_distribution = distribution;
	    m_amount = amount;
	}

	public String getName()
	{
	    return "dithered " + m_distribution.getName();
	}

	public int[] make(int numValues, int m)
	{
	    int[] retval = m_distribution.make(numValues, m);
	    for (int i = 0; i < numValues; i++)
	    {
		retval[i] += i % m_amount;
	    }
	    return retval;
	}

	private Distribution  m_distribution;
	private int  m_amount;
    }

    ///////////////////////////////////////////////////////////////////////
    // The following distributions are based on those in the
    // [Bentley & McIlroy] paper.
    ///////////////////////////////////////////////////////////////////////

    private abstract class AbstractDistribution
	implements Distribution
    {
	public int[] make(int numValues, int m)
	{
	    int[] retval = new int[numValues];
	    for (int i = 0; i < numValues; i++)
	    {
		retval[i] = generateValue(i, numValues, m);
	    }
	    return retval;
	}

	protected abstract int generateValue(int i, int numValues, int m);
    }

    private class SawtoothDistribution
	extends AbstractDistribution
    {
	public String getName()
	{
	    return "sawtooth distribution";
	}

	protected int generateValue(int i, int numValues, int m)
	{
	    return i % m;
	}
    }

    private class RandomDistribution
	extends AbstractDistribution
    {
	public String getName()
	{
	    return "random distribution";
	}

	protected int generateValue(int i, int numValues, int m)
	{
	    return m_random.nextInt(m);
	}
    }

    private class StaggeredDistribution
	extends AbstractDistribution
    {
	public String getName()
	{
	    return "staggered distribution";
	}

	protected int generateValue(int i, int numValues, int m)
	{
	    return (i * m + i) % numValues;
	}
    }

    private class PlateauDistribution
	extends AbstractDistribution
    {
	public String getName()
	{
	    return "plateau distribution";
	}

	protected int generateValue(int i, int numValues, int m)
	{
	    return Math.min(i, m);
	}
    }

    private class ShuffledDistribution
	extends AbstractDistribution
    {
	public String getName()
	{
	    return "shuffled distribution";
	}

	protected int generateValue(int i, int numValues, int m)
	{
	    int retval;
	    if (m_random.nextInt(m) > 0)
	    {
		retval = m_j;
		m_j += 2;
	    }
	    else
	    {
		retval = m_k;
		m_k += 2;
	    }
	    return retval;
	}

	private int  m_j = 0;
	private int  m_k = 1;
    }
}

