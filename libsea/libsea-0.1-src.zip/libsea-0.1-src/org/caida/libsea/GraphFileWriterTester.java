// 
// The LibSea Graph Library.
// Copyright (C) 2000,2001,2002 The Regents of the University of California.
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// 
// ######END_HEADER######
// 


package org.caida.libsea;

import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.IOException;

class GraphFileWriterTester
    extends AbstractTester
{
    public static void main(String[] args)
    {
	int startingTest = 0;

	if (args.length > 0)
	{
	    try
	    {
		startingTest = Integer.parseInt(args[0]);
	    }
	    catch (NumberFormatException e)
	    {
		System.err.println("ERROR: Malformed starting test number.");
		System.exit(1);
	    }

	    if (startingTest < 0)
	    {
		System.err.println
		    ("ERROR: Starting test number must be >= 0.");
		System.exit(1);
	    }
	}

	new GraphFileWriterTester().testAll(startingTest);
    }

    public GraphFileWriterTester()
    {
	super();
    }

    public void testAll(int startingTest)
    {
	try
	{
	    if (startingTest == 0)
	    {
		println("**** TEST 0 ****");
		testSampleGraph1(makeImmutableGraph(), false);
		testSampleGraph1(makeImmutableGraph(), true);
	    }

	    if (startingTest <= 1)
	    {
		println("**** TEST 1 ****");
		testSampleGraph2(makeImmutableGraph(), false);
		testSampleGraph2(makeImmutableGraph(), true);
	    }

	    if (startingTest <= 2)
	    {
		println("**** TEST 2 ****");
		testSampleGraph3(makeImmutableGraph(), false);
		testSampleGraph3(makeImmutableGraph(), true);
	    }
	}
	catch (TestFailedException e)
	{
	    e.printStackTrace();
	    System.out.println("FAILED: " + e);
	}
	catch (DuplicateObjectException e)
	{
	    e.printStackTrace();
	    System.out.println("ERROR: " + e);
	}
	catch (RuntimeException e)
	{
	    e.printStackTrace();
	    System.out.println("ERROR: " + e);
	}
    }

    public void testSampleGraph1(GraphBuilder builder, boolean isVerbose)
	throws TestFailedException, DuplicateObjectException
    {
	println();
	println("===========================================================");
	println("testSampleGraph1(isVerbose=" + isVerbose + ")");
	println("===========================================================");

	builder.setGraphName("Minimal Graph");
	builder.allocateNodes(0);
	builder.allocateLinks(0);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);
	Graph graph = builder.endConstruction();
	writeGraph(isVerbose, graph);

	println("ALL PASSED!");
    }

    public void testSampleGraph2(GraphBuilder builder, boolean isVerbose)
	throws TestFailedException, DuplicateObjectException
    {
	println();
	println("===========================================================");
	println("testSampleGraph2(isVerbose=" + isVerbose + ")");
	println("===========================================================");

	builder.setGraphName("Binary Tree");
	builder.setGraphDescription("A complete binary tree of height 2.");

	builder.allocateNodes(7);
	builder.allocateLinks(6);
	builder.allocatePaths(0);
	builder.allocatePathLinks(0);

	verifyEqual("addLink()", builder.addLink(0, 1), 0);
	verifyEqual("addLink()", builder.addLink(0, 2), 1);
	verifyEqual("addLink()", builder.addLink(1, 3), 2);
	verifyEqual("addLink()", builder.addLink(1, 4), 3);
	verifyEqual("addLink()", builder.addLink(2, 5), 4);
	verifyEqual("addLink()", builder.addLink(2, 6), 5);

	Graph graph = builder.endConstruction();
	writeGraph(isVerbose, graph);

	println("ALL PASSED!");
    }

    public void testSampleGraph3(GraphBuilder builder, boolean isVerbose)
	throws TestFailedException, DuplicateObjectException
    {
	println();
	println("===========================================================");
	println("testSampleGraph3(isVerbose=" + isVerbose + ")");
	println("===========================================================");

	builder.setGraphName("Qualified Binary Tree");
	builder.setGraphDescription("A complete binary tree of height 2.");

	builder.allocateNodes(7);
	builder.allocateLinks(6);
	builder.allocatePaths(2);
	builder.allocatePathLinks(4);

	verifyEqual("addLink()", builder.addLink(0, 1), 0);
	verifyEqual("addLink()", builder.addLink(0, 2), 1);
	verifyEqual("addLink()", builder.addLink(1, 3), 2);
	verifyEqual("addLink()", builder.addLink(1, 4), 3);
	verifyEqual("addLink()", builder.addLink(2, 5), 4);
	verifyEqual("addLink()", builder.addLink(2, 6), 5);

	verifyEqual("addPath()", builder.addPath(), 0);
	builder.addPathLink(0);
	builder.addPathLink(2);

	verifyEqual("addPath()", builder.addPath(), 1);
	builder.addPathLink(1);
	builder.addPathLink(4);

	{
	    EnumerationCreator creator = builder.addEnumeration("link_speed");
	    verifyEqual("addEnumeration()", creator.getEnumerationID(), 0);
	    creator.addEnumerator("UNKNOWN", 0);
	    creator.addEnumerator("OC3", 1);
	    creator.addEnumerator("OC12", 2);
	    creator.addEnumerator("OC48", 3);
	}

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("root", ValueType.BOOLEAN, -1, null), 0);
	builder.addNodeAttribute(0).addBooleanValue(true);

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("link", ValueType.BOOLEAN, -1, null), 1);
	builder.addLinkAttribute(0).addBooleanValue(true);
	builder.addLinkAttribute(2).addBooleanValue(true);
	builder.addLinkAttribute(3).addBooleanValue(true);

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("root2", ValueType.BOOLEAN, -1, null), 2);
	builder.addNodeAttribute(0).addBooleanValue(true);

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("label", ValueType.STRING, -1, "-none-"), 3);
	builder.addNodeAttribute(0).addStringValue("Root");
	builder.addNodeAttribute(1).addStringValue("Node A");
	builder.addNodeAttribute(2).addStringValue("Node B");
	builder.addLinkAttribute(0).addStringValue("Link A");
	builder.addLinkAttribute(1).addStringValue("Link B");
	builder.addPathAttribute(0).addStringValue("Path A");
	builder.addPathAttribute(1).addStringValue("Path B");

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("bytes", ValueType.INTEGER, -1, "0"), 4);
	builder.addNodeAttribute(0).addIntegerValue(122);
	builder.addNodeAttribute(1).addIntegerValue(5);
	builder.addNodeAttribute(2).addIntegerValue(255);
	builder.addLinkAttribute(0).addIntegerValue(127);
	builder.addLinkAttribute(1).addIntegerValue(260);

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("log_bytes", ValueType.FLOAT, -1,
		     "if $bytes > 1 then log($bytes) else 0.0"), 5);

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("speed", ValueType.ENUMERATION, 0,
		     "#link_speed:UNKNOWN"), 6);
	builder.addLinkAttribute(0).addEnumerationValue("OC3");
	builder.addLinkAttribute(3).addEnumerationValue("OC12");
	builder.addLinkAttribute(5).addEnumerationValue("OC3");

	verifyEqual("addAttributeDefinition()", builder.addAttributeDefinition
		    ("color", ValueType.FLOAT3, -1, null), 7);
	builder.addNodeAttribute(0).addFloat3Value(0.0f, 0.0f, 0.0f);
	builder.addNodeAttribute(1).addFloat3Value(0.5f, 0.6f, 0.7f);
	builder.addNodeAttribute(2).addFloat3Value(1.0f, 0.9f, 0.8f);
	builder.addNodeAttribute(3).addFloat3Value(0.1f, 0.2f, 0.3f);
	builder.addNodeAttribute(4).addFloat3Value(0.4f, 0.5f, 0.6f);
	builder.addNodeAttribute(5).addFloat3Value(0.7f, 0.8f, 0.9f);
	builder.addNodeAttribute(6).addFloat3Value(0.3f, 0.3f, 0.3f);

	{
	    QualifierCreator creator =
		builder.addQualifier("tree", "left_tree", "Left subtree.");
	    creator.associateAttribute(0);
	    creator.associateAttribute(1, "left_tree_link");
	    creator.associateAttribute("color", "left_tree_color");
	}
	
	verifyEqual("addFilter()", builder.addFilter
		    ("HighBytes", "$bytes > 100000"), 0);

	{
	    DisplayCreator creator = builder.addDisplay("Bytes");
	    verifyEqual("addDisplay()", creator.getDisplayID(), 0);
	    creator.addDisplayMapping("color", 7, true, false, false);
	    creator.addDisplayMapping("size", 4, false, true, true);
	}

	{
	    DisplayCreator creator = builder.addDisplay("LogBytes");
	    verifyEqual("addDisplay()", creator.getDisplayID(), 1);
	    creator.addDisplayMapping("color", 7, true, false, false);
	    creator.addDisplayMapping("size", 5, true, false, true);
	}

	{
	    SelectorCreator creator = builder.addSelector("HighBytes");
	    verifyEqual("addSelector()", creator.getSelectorID(), 0);
	    creator.addSelectorMapping("show", 0, true, false, false);
	    creator.addSelectorMapping("size", 0, false, true, true);
	}

	verifyEqual("addPresentation()",
		    builder.addPresentation("Bytes", 0, 0), 0);

	verifyEqual("addPresentation()",
		    builder.addPresentation("LogBytes", 1, 0), 1);

	builder.addPresentationSubmenu("Bytes Presentation", 0);
	builder.addPresentationSubmenu("Log Bytes Presentation", 0);

	builder.addDisplaySubmenu("Bytes Display", 0);
	builder.addDisplaySubmenu("Log Bytes Display", 1);

	builder.addSelectorSubmenu("High Bytes Selector", 0);

	builder.addFilterSubmenu("High Bytes Filter", 0);

	Graph graph = builder.endConstruction();
	writeGraph(isVerbose, graph);

	println("ALL PASSED!");
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE METHODS
    ///////////////////////////////////////////////////////////////////////

    private void writeGraph(boolean isVerbose, Graph graph)
	throws TestFailedException
    {
	try
	{
	    new GraphFileWriter(m_writer, graph, isVerbose, false).write();
	}
	catch (IOException e)
	{
	    e.printStackTrace();
	    throw new TestFailedException(e.toString());
	}
    }

    private GraphBuilder makeImmutableGraph()
    {
	return GraphFactory.makeImmutableGraph();
    }

    private GraphBuilder makeMutableGraph()
    {
	return GraphFactory.makeMutableGraph();
    }

    ///////////////////////////////////////////////////////////////////////
    // PRIVATE FIELDS
    ///////////////////////////////////////////////////////////////////////

    private Writer  m_writer =
	new BufferedWriter(new OutputStreamWriter(System.out));
}
